<?php
$MODULE_PHP='vendor-endpoints.php';


add_action('rest_api_init', function () {
    register_rest_route('vogo/v1', '/vendor_report/performance', [
        'methods' => 'GET',
        'callback' => 'vogo_vendor_report_performance',
        'permission_callback' => 'validate_general_mobile_general_app_jwt'
    ]);

    register_rest_route('vogo/v1', '/vendor_report/low_stock', [
        'methods' => 'GET',
        'callback' => 'vogo_vendor_report_low_stock',
        'permission_callback' => 'validate_general_mobile_general_app_jwt'
    ]);

    register_rest_route('vogo/v1', '/vendor_report/profitability', [
        'methods' => 'GET',
        'callback' => 'vogo_vendor_report_profitability',
        'permission_callback' => 'validate_general_mobile_general_app_jwt'
    ]);

});



function vogo_vendor_report_performance($request) {
    global $wpdb;
    $vendor_id = vogo_get_current_vendor_id();
    if (!$vendor_id) return new WP_REST_Response(['success' => false, 'error' => 'Unauthorized'], 403);

    $query = $wpdb->prepare("SELECT p.ID, p.post_title,
        (SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_order_items oi
         JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id
         WHERE oim.meta_key = '_product_id' AND oim.meta_value = p.ID) AS orders,
        pm.meta_value AS stock
        FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->prefix}postmeta pm ON p.ID = pm.post_id AND pm.meta_key = '_stock'
        WHERE p.post_type = 'product' AND p.post_status = 'publish' AND p.post_author = %d", $vendor_id);

    $results = $wpdb->get_results($query);

    return new WP_REST_Response(['success' => true, 'data' => $results], 200);
}

function vogo_vendor_report_low_stock($request) {
    global $wpdb;
    $vendor_id = vogo_get_current_vendor_id();
    if (!$vendor_id) return new WP_REST_Response(['success' => false, 'error' => 'Unauthorized'], 403);

    $results = $wpdb->get_results($wpdb->prepare("SELECT p.ID, p.post_title, pm.meta_value AS stock
        FROM {$wpdb->posts} p
        JOIN {$wpdb->prefix}postmeta pm ON p.ID = pm.post_id
        WHERE p.post_type = 'product' AND p.post_status = 'publish' AND pm.meta_key = '_stock'
        AND CAST(pm.meta_value AS UNSIGNED) < 5 AND p.post_author = %d", $vendor_id));

    return new WP_REST_Response(['success' => true, 'data' => $results], 200);
}

function vogo_vendor_report_profitability($request) {
    global $wpdb;
    $vendor_id = vogo_get_current_vendor_id();
    if (!$vendor_id) return new WP_REST_Response(['success' => false, 'error' => 'Unauthorized'], 403);

    $results = $wpdb->get_results($wpdb->prepare("SELECT p.ID, p.post_title,
        cost.meta_value AS cost_price, price.meta_value AS sale_price,
        (CAST(price.meta_value AS DECIMAL) - CAST(cost.meta_value AS DECIMAL)) AS profit_per_unit
        FROM {$wpdb->posts} p
        JOIN {$wpdb->prefix}postmeta cost ON p.ID = cost.post_id AND cost.meta_key = '_cost'
        JOIN {$wpdb->prefix}postmeta price ON p.ID = price.post_id AND price.meta_key = '_price'
        WHERE p.post_type = 'product' AND p.post_status = 'publish' AND p.post_author = %d", $vendor_id));

    return new WP_REST_Response(['success' => true, 'data' => $results], 200);
}
