<?php
$MODULE_PHP='all-account.php';
/**
 * VOGO API ACCOUNT
 * ADI-TEHNIC
 * 
 */

add_action('rest_api_init', function(){

register_rest_route('vogo/v1', '/account/delete', [
    'methods'  => 'POST',
    'callback' => 'vogo_delete_account2',
    'permission_callback' => 'vogo_permission_check'
]);  

  register_rest_route('vogo/v1/account', '/locationIsFarAway', [
    'methods' => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'location_is_far_away',
  ]);  

  register_rest_route('vogo/v1/account', '/vogo_get_privacy', [
    'methods' => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'vogo_get_privacy',
  ]);    
  

  register_rest_route('vogo/v1', '/account/user_roles_get_by_username', array(
    'methods'  => 'POST',
    'callback' => 'user_roles_get_by_username',
    'permission_callback' => '__return_true'
  ));

  register_rest_route('vogo/v1', '/account/currentLocationIsFarAwayFromSaved  ', array(
    'methods'  => 'POST',
    'callback' => 'location_is_far_away',
    'permission_callback' => 'vogo_permission_check'
  ));  

    register_rest_route('vogo/v1','/account/get_postcode_from_street_address',[
        'methods'=>'POST',
        'callback'=>'get_postcode_from_street_address',
        'permission_callback'=>'vogo_permission_check'
    ]);  

    register_rest_route('vogo/v1','/account/vogo_set_myrefferal_code',[
        'methods'=>'POST',
        'callback'=>'vogo_set_myrefferal_code',
        'permission_callback'=>'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1','/account/vogo_get_myrefferal_code',[
        'methods'=>'POST',
        'callback'=>'vogo_get_myrefferal_code',
        'permission_callback'=>'vogo_permission_check'
    ]);    

    register_rest_route('vogo/v1','/account/vogo_get_referred_by',[
        'methods'=>'POST',
        'callback'=>'vogo_get_referred_by',
        'permission_callback'=>'vogo_permission_check'
    ]);        

    register_rest_route('vogo/v1','/account/vogo_set_referred_by',[
        'methods'=>'POST',
        'callback'=>'vogo_set_referred_by',
        'permission_callback'=>'vogo_permission_check'
    ]);          
    
    
    register_rest_route('vogo/v1','/account/update-account-main-data',[
        'methods'=>'POST',
        'callback'=>'vogo_edit_account_info',
        'permission_callback'=>'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1','/account/update-address',[
        'methods'=>'POST',
        'callback'=>'update_address',
        'permission_callback'=>'vogo_permission_check'
    ]);
    
    register_rest_route('vogo/v1','/account/address-list',[
        'methods'=>'POST',
        'callback'=>'address_list',
        'permission_callback'=>'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/account/get_shippment_address', [
        'methods'  => 'POST',
        'callback' => 'vogo_get_shipping_address',
        'permission_callback' => 'vogo_permission_check', // optional: replace with JWT validation
    ]);   

    register_rest_route('vogo/v1', '/account/set_shippment_address', [
        'methods'  => 'POST',
        'callback' => 'vogo_set_shipping_address',
        'permission_callback' => 'vogo_permission_check', // optional: replace with JWT validation
    ]);       

    register_rest_route('vogo/v1', '/account/change_password_by_username', [
        'methods'  => 'POST',
        'callback' => 'vogo_change_password_by_username',
        'permission_callback' => '__return_true', // optional: replace with JWT validation
    ]);       
   

    register_rest_route('vogo/v1', '/account/Address-List2', [
        'methods'             => 'POST',
        'callback'            => 'vogo_list_all_user_addresses2',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/account/standard-address', [
      'methods' => 'POST',
      'callback' => 'vogo_add_edit_standard_address2',
      'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1','/account/add-new-custom-address',[
    'methods' => 'POST',
    'callback' => 'vogo_add_new_custom_address',
    'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/account/edit-custom-address', [
    'methods'             => 'POST',
    'callback'            => 'vogo_edit_custom_address',
    'permission_callback' => 'vogo_permission_check',
    ]);    

    register_rest_route('vogo/v1','/account/delete-custom-address',[
    'methods'=>'POST','callback'=>'vogo_delete_custom_address','permission_callback'=>'vogo_permission_check'
    ]);    

    register_rest_route('vogo/v1', '/account/update-account-image', [
        'methods'             => 'POST',
        'callback'            => 'vogo_update_account_image_simple',
        'permission_callback' => 'vogo_permission_check', // JWT required
    ]);

    register_rest_route('vogo/v1','/account/get-account-image',[
        'methods'=>'POST',
        'callback'=>'vogo_get_account_image',
        'permission_callback'=>'vogo_permission_check'
    ]);    

  register_rest_route('vogo/v1','/account/remove-account-image',[
    'methods'=>'POST',
    'callback'=>'vogo_remove_account_image',
    'permission_callback'=>'vogo_permission_check'
  ]);    

// Payments (My Account) – POST only
  register_rest_route('vogo/v1','/account/payment_info_get',[
    'methods'=>'POST','callback'=>'myaccount_payment_info_get','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/account/payment_info_save',[
    'methods'=>'POST','callback'=>'myaccount_payment_info_save','permission_callback'=>'vogo_permission_check'
  ]);
    
});

/**
 * Update billing or shipping address
 */
function update_address(WP_REST_Request $request){
    global $wpdb; 
      //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  checkBearer($request,$module);
  
  
  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    



    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; 
    vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");

    $p=$request->get_json_params(); 
    vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:0");

    $user_id=extract_user_from_jwt_token($request); 
    if(is_wp_error($user_id)) return $user_id;

    

    $type=strtolower(sanitize_text_field($p['address_type']??'')); 
    $module=$module.'.type:'.$type;
    if(!in_array($type,['billing','shipping'])){
        vogo_error_log3("[STEP 1] Invalid address_type=$type | IP:$ip | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return ['success'=>false,'error'=>'Invalid address_type','user_id'=>$user_id];
    }

    $fields=['first_name','last_name','company','address_1','address_2','city','state','state_name','postcode','country','country_name','phone','email','dialCode','lat','long'];
    foreach($fields as $f){
        if(isset($p[$f])){
            $v=is_email($p[$f])?sanitize_email($p[$f]):sanitize_text_field($p[$f]);
            update_user_meta($user_id,"{$type}_{$f}",$v);
            vogo_error_log3("[STEP 2] Updated {$type}_{$f}=$v | IP:$ip | USER:$user_id");
        }
    }

    if($type==='billing' && !empty($p['same_as_billing'])){
        foreach($fields as $f){
            if(isset($p[$f])){
                $v=is_email($p[$f])?sanitize_email($p[$f]):sanitize_text_field($p[$f]);
                update_user_meta($user_id,"shipping_{$f}",$v);
                vogo_error_log3("[STEP 3] Copied billing_$f to shipping_$f=$v | IP:$ip | USER:$user_id");
            }
        }
    }

    vogo_error_log3("[STEP 4] Address updated successfully | type=$type | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");

    // snapshot address meta (safe fallback if missing)
    $get_addr = function($uid,$pref){
        return [
            'first_name'     => (string)get_user_meta($uid,"{$pref}_first_name",true),
            'last_name'      => (string)get_user_meta($uid,"{$pref}_last_name",true),
            'company'        => (string)get_user_meta($uid,"{$pref}_company",true),
            'street'         => (string)get_user_meta($uid,"{$pref}_address_1",true),
            'street_2'       => (string)get_user_meta($uid,"{$pref}_address_2",true),
            'city'           => (string)get_user_meta($uid,"{$pref}_city",true),
            'county'         => (string)get_user_meta($uid,"{$pref}_state",true),
            'address_code'   => (string)get_user_meta($uid,"{$pref}_postcode",true),
            'country'        => (string)get_user_meta($uid,"{$pref}_country",true),
            'phone'          => (string)get_user_meta($uid,"{$pref}_phone",true),
            'email'          => (string)get_user_meta($uid,"{$pref}_email",true),
            'dialCode'       => (string)get_user_meta($uid,"{$pref}_dialCode",true),
            'lat'            => (string)get_user_meta($uid,"{$pref}_lat",true),
            'long'           => (string)get_user_meta($uid,"{$pref}_long",true),
        ];
    };

    $current   = $get_addr($user_id,$type);
    $billing   = $get_addr($user_id,'billing');
    $shipping  = $get_addr($user_id,'shipping');

    // current address compact view
    $current_compact = [
        'type'          => $type,
        'id'            => null, // usermeta has no SQL id; BC-safe
        'street'        => $current['street'],
        'address_code'  => $current['address_code'],
        'lat'           => $current['lat'],
        'long'          => $current['long'],
    ];

    vogo_error_log3("[STEP 4] Address updated successfully | type=$type | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");

    return [
        'success'=>true,
        'module' => $module.'.TEND',
        'message'=>'Address updated successfully',
        'user_id'=>$user_id,
        'user_login'=>wp_get_current_user()->user_login,
        'address_current'=>$current_compact,
        'billing'=>$billing,
        'shipping'=>$shipping
    ];

}

/**
 * Return user addresses:
 * - billing/shipping din usermeta
 * - custom din wp_user_addresses (status='active' case-insensitive)
 * Output: include address_id și coordonate dacă există coloanele.
 */
function address_list(WP_REST_Request $request){
  global $wpdb;

  $MODULE_PHP = basename(__FILE__);
  $module = $MODULE_PHP.'.'.__FUNCTION__;

  // Auth
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  if (is_wp_error($user_id)) return ['success'=>false,'message'=>$user_id->get_error_message()];

  // Billing/Shipping
  $fields=['first_name','last_name','company','address_1','address_2','city','state','state_name','postcode','country','country_name','phone','email','dialCode','lat','long'];
  $std=[];
  foreach(['billing','shipping'] as $type){
    $addr=['type'=>$type]; $found=false;
    foreach($fields as $f){ $v=get_user_meta($user_id,"{$type}_{$f}",true); $addr[$f]=$v; if($v!==''&&$v!==null) $found=true; }
    if($found) $std[]=$addr;
  }

  // Custom din SQL cu SELECT dinamic pe coloanele existente
  $table = $wpdb->prefix.'user_addresses';
  $cols  = $wpdb->get_col("SHOW COLUMNS FROM {$table}", 0);
  if (!is_array($cols)) $cols=[];

  $sel = [
    "id AS address_id",
    "address_name",
    "street_address",
    "street_address_2",
    "city",
    "county",
    "address_code",
    "status"
  ];

  // opționale existente
  if (in_array('phone',$cols,true))        $sel[]="phone";
  if (in_array('email',$cols,true))        $sel[]="email";
  if (in_array('country',$cols,true))      $sel[]="country";
  if (in_array('first_name',$cols,true))   $sel[]="first_name";
  if (in_array('last_name',$cols,true))    $sel[]="last_name";
  if (in_array('is_default',$cols,true))   $sel[]="is_default";

  // coordonate: preferă lat/long, altfel latitude/longitude
  $latExpr  = in_array('lat',$cols,true)        ? "lat"        : (in_array('latitude',$cols,true)  ? "latitude"  : "''");
  $longExpr = in_array('long',$cols,true)       ? "`long`"     : (in_array('longitude',$cols,true) ? "longitude" : "''");
  $sel[] = "$latExpr AS lat";
  $sel[] = "$longExpr AS `long`";

  // ORDER BY
  $order = in_array('is_default',$cols,true) ? "ORDER BY is_default DESC, id DESC" : "ORDER BY id DESC";

  $sql = "SELECT ".implode(',', $sel)." FROM {$table} WHERE user_id=%d AND LOWER(status)='active' {$order}";
  vogo_error_log3("##############SQL: ".$wpdb->prepare($sql,$user_id)); // doar SQL

  $rows = $wpdb->get_results($wpdb->prepare($sql,$user_id), ARRAY_A) ?: [];

  $custom=[];
  foreach($rows as $r){
    $custom[]=[
      'address_id' => (string)$r['address_id'],
      'type'       => 'other',
      'label'      => (string)$r['address_name'],
      'fields'     => [
        'address_1' => (string)($r['street_address']??''),
        'address_2' => (string)($r['street_address_2']??''),
        'city'      => (string)($r['city']??''),
        'state'     => (string)($r['county']??''),
        'postcode'  => (string)($r['address_code']??''),
        'country'   => (string)($r['country']??''),
        'first_name'=> (string)($r['first_name']??''),
        'last_name' => (string)($r['last_name']??''),
        'phone'     => (string)($r['phone']??''),
        'email'     => (string)($r['email']??''),
        'lat'       => (string)($r['lat']??''),
        'long'      => (string)($r['long']??'')
      ],
      'is_default' => isset($r['is_default']) ? (bool)$r['is_default'] : false,
      'status'     => (string)($r['status']??'active')
    ];
  }

  if (empty($std) && empty($custom)) return ['success'=>false,'message'=>'No address found','user_id'=>$user_id];

  return [
    'success'=>true,
    'message'=>'Addresses retrieved',
    'module'=>$module.'.TEND',
    'user_id'=>$user_id,
    'user_login'=>wp_get_current_user()->user_login,
    'data'=>$std,
    'custom_addresses'=>$custom
  ];
}


/**
 * Get shipping address by decoding JWT from Authorization header using VOGO_JWT_SECRET
 * No vogo_error_log3 calls. Includes audit in response. Requires Bearer.
 */
function vogo_get_shipping_address(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP = basename(__FILE__); $module = $MODULE_PHP.'.'.__FUNCTION__;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

  // STEP 0 – Require Authorization: Bearer
  $auth = $request->get_header('authorization');
  if (!$auth || stripos($auth,'Bearer ')!==0){
    return new WP_REST_Response([
      'success'=>false,
      'module'=>$module.'.TEND',
      'error'=>'Authorization header missing or not Bearer',
      'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>false]
    ],401);
  }

  // STEP 1 – Decode JWT (blocking)
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  if (is_wp_error($user_id)){
    return new WP_REST_Response([
      'success'=>false,
      'module'=>$module.'.TEND',
      'error'=>$user_id->get_error_message(),
      'audit'=>['ip'=>$ip,'active_db'=>DB_NAME]
    ],401);
  }

  // STEP 2 – Collect shipping meta
  $keys=['shipping_first_name','shipping_last_name','shipping_company','shipping_address_1','shipping_address_2','shipping_city','shipping_state','shipping_postcode','shipping_country','shipping_phone','shipping_email','shipping_dialCode'];
  $shipping=[]; foreach($keys as $k){ $shipping[$k]=get_user_meta($user_id,$k,true) ?: ''; }

  // Lat/Long with fallbacks
  $lat = get_user_meta($user_id,'shipping_lat',true);
  if ($lat===''){ $lat = get_user_meta($user_id,'shipping_latitude',true); }
  $lng = get_user_meta($user_id,'shipping_long',true);
  if ($lng===''){ $lng = get_user_meta($user_id,'shipping_longitude',true); }
  $shipping['shipping_lat']  = (string)($lat ?? '');
  $shipping['shipping_long'] = (string)($lng ?? '');

  // Compact view
  $shipping_compact=[
    'street'=>(string)$shipping['shipping_address_1'],
    'address_code'=>(string)$shipping['shipping_postcode'],
    'lat'=>(string)$shipping['shipping_lat'],
    'long'=>(string)$shipping['shipping_long'],
  ];

  // STEP 3 – Response
  $current = wp_get_current_user();
  return new WP_REST_Response([
    'success'=>true,
    'module'=>$module.'.TEND',
    'user_id'=>$user_id,
    'user_login'=>($current && $current->exists()) ? $current->user_login : '',
    'lat'=>(string)$shipping['shipping_lat'],
    'long'=>(string)$shipping['shipping_long'],
    'shipping'=>$shipping,
    'shipping_compact'=>$shipping_compact,
    'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>true]
  ],200);
}

/**
 * Set shipping address from JWT-authenticated user
 * Hardened: strict checks, try/catch, safe casting, .TEND module, no logs.
 */
function vogo_set_shipping_address(WP_REST_Request $request){
  $MODULE_PHP = basename(__FILE__); $module = $MODULE_PHP.'.'.__FUNCTION__;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  try{
    if(!function_exists('extract_user_from_jwt_token')){
      return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'JWT extractor missing','audit'=>['ip'=>$ip,'active_db'=>defined('DB_NAME')?DB_NAME:'?','auth_prefix_ok'=>null]],500);
    }

    $auth = $request->get_header('authorization');
    if(!$auth || stripos($auth,'Bearer ')!==0){
      return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Authorization header missing or not Bearer','audit'=>['ip'=>$ip,'active_db'=>defined('DB_NAME')?DB_NAME:'?','auth_prefix_ok'=>false]],401);
    }

    $user_id = extract_user_from_jwt_token($request);
    if($user_id instanceof WP_REST_Response) return $user_id;
    if(is_wp_error($user_id)){
      return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>$user_id->get_error_message(),'audit'=>['ip'=>$ip,'active_db'=>defined('DB_NAME')?DB_NAME:'?','auth_prefix_ok'=>true]],401);
    }
    $user_id = (int)$user_id; if($user_id<=0){ return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Invalid user_id from JWT'],401); }

    $raw = $request->get_json_params(); $p = is_array($raw)?$raw:[];
    $meta_keys=['shipping_first_name','shipping_last_name','shipping_company','shipping_address_1','shipping_address_2','shipping_city','shipping_state','shipping_postcode','shipping_country','shipping_phone','shipping_email','shipping_dialCode'];
    $saved=[];

    foreach($meta_keys as $k){
      if(array_key_exists($k,$p)){
        $val = is_scalar($p[$k]) ? sanitize_text_field($p[$k]) : '';
        update_user_meta($user_id,$k,$val);
        $saved[$k]=$val;
      }
    }

    // lat/long inputs: shipping_lat/shipping_latitude/lat and shipping_long/shipping_longitude/long
    $lat = $p['shipping_lat'] ?? ($p['shipping_latitude'] ?? ($p['lat'] ?? null));
    $lng = $p['shipping_long'] ?? ($p['shipping_longitude'] ?? ($p['long'] ?? null));
    $lat_s = ($lat!==null && $lat!=='') ? (string)round((float)$lat,8) : '';
    $lng_s = ($lng!==null && $lng!=='') ? (string)round((float)$lng,8) : '';
    if($lat_s!==''){ update_user_meta($user_id,'shipping_lat',$lat_s); $saved['shipping_lat']=$lat_s; }
    if($lng_s!==''){ update_user_meta($user_id,'shipping_long',$lng_s); $saved['shipping_long']=$lng_s; }
    if(array_key_exists('shipping_latitude',$p))   update_user_meta($user_id,'shipping_latitude',$lat_s);
    if(array_key_exists('shipping_longitude',$p))  update_user_meta($user_id,'shipping_longitude',$lng_s);

    $u = wp_get_current_user();
    return new WP_REST_Response([
      'success'=>true,
      'module'=>$module.'.TEND',
      'user_id'=>$user_id,
      'user_login'=>($u && $u->exists()) ? $u->user_login : '',
      'lat'=>$lat_s,
      'long'=>$lng_s,
      'saved'=>$saved,
      'audit'=>['ip'=>$ip,'active_db'=>defined('DB_NAME')?DB_NAME:'?','auth_prefix_ok'=>true]
    ],200);

  }catch(Throwable $e){
    return new WP_REST_Response([
      'success'=>false,
      'module'=>$module.'.TEND',
      'error'=>'Unhandled exception',
      'exception'=>$e->getMessage(),
      'audit'=>['ip'=>$ip,'active_db'=>defined('DB_NAME')?DB_NAME:'?']
    ],500);
  }
}


function vogo_change_password_by_username(WP_REST_Request $request) {
    $module = 'change-password';
    $username = sanitize_user($request->get_param('username'));
    $new_password = $request->get_param('new_password');
    $confirm_password = $request->get_param('confirm_password');

    // STEP 1: Validate input
    if (empty($username) || empty($new_password) || empty($confirm_password)) {
        vogo_error_log2($module, 'STEP 1: Missing parameters.');
        return new WP_REST_Response(['success' => false, 'message' => 'Missing parameters.'], 400);
    }

    // STEP 2: Check if passwords match
    if ($new_password !== $confirm_password) {
        vogo_error_log2($module, 'STEP 2: Passwords do not match.');
        return new WP_REST_Response(['success' => false, 'message' => 'Passwords do not match.'], 400);
    }

    // STEP 3: Get user by username
    $user = get_user_by('login', $username);
    if (!$user) {
        vogo_error_log2($module, 'STEP 3: User not found: ' . $username);
        return new WP_REST_Response(['success' => false, 'message' => 'User not found.'], 404);
    }

    // STEP 4: Update password
    wp_set_password($new_password, $user->ID);
    vogo_error_log2($module, 'STEP 4: Password updated for user ID ' . $user->ID);

    return new WP_REST_Response(['success' => true, 'message' => 'Password updated successfully.'], 200);
}

function vogo_list_all_user_addresses2(WP_REST_Request $request) {
  global $wpdb;

  // === helpers locale (adi-tehnic) ===
  $maybe_decode_fields = function($v){
      if (is_array($v)) return $v;
      if (is_null($v) || $v === '') return [];
      // încearcă unserialize
      $try_unser = @unserialize($v);
      if ($try_unser !== false || $v === 'b:0;') return is_array($try_unser) ? $try_unser : [];
      // încearcă json
      $try_json = json_decode($v, true);
      if (json_last_error() === JSON_ERROR_NONE && is_array($try_json)) return $try_json;
      return [];
  };
  $norm_label_slug = function($label){
      return sanitize_title(trim((string)$label));
  };

  // === STEP 0: auth & context ===
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  if (is_wp_error($user_id)) {
      return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()], 401);
  }

  $db_name = DB_NAME;
  vogo_error_log3("[ADDR][LIST][STEP 1] ACTIVE DB: $db_name | IP:$ip | USER:$user_id");

  // === STEP 1: Woo billing & shipping ===
  $types  = ['billing', 'shipping'];
  $fields = [
    'first_name','last_name','company','address_1','address_2',
    'city','state','state_name','postcode','country',
    'country_name','phone','email','dialCode'
  ];

  $billing_shipping = [];
  foreach ($types as $type) {
      $entry = ['type' => $type];
      foreach ($fields as $f) {
          $entry[$f] = get_user_meta($user_id, "{$type}_{$f}", true);
      }
      // adaugă identificatori utili în UI
      $entry['unique_code'] = get_user_meta($user_id, "{$type}_unique_code", true) ?: "{$type}_{$user_id}";
      $entry['id']          = $entry['unique_code']; // id artificial pt UI/editoare
      $entry['label']       = ucfirst($type);
      $entry['label_slug']  = $type;

      // includem doar dacă are macar address_1
      if (!empty($entry['address_1'])) {
          $billing_shipping[] = $entry;
      }
  }
  vogo_error_log3("[ADDR][LIST][STEP 2] Woo addresses: ".count($billing_shipping)." | USER:$user_id");

  // === STEP 2: Custom din SQL (wp_user_addresses) ===
  $table = $wpdb->prefix . 'user_addresses';
  // Tabela este opțională; dacă nu există, nu aruncăm eroare
  $custom_sql = [];
  $table_exists = $wpdb->get_var($wpdb->prepare(
      "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s",
      $table
  ));
  if ($table_exists) {
      $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM {$table} WHERE user_id = %d AND status IN ('active','default') ORDER BY id DESC", $user_id),
        ARRAY_A
      );
      foreach ((array)$rows as $r) {
          $fields_decoded = $maybe_decode_fields($r['fields'] ?? []);
          $label = $r['label'] ?? '';
          $custom_sql[] = [
              'id'         => (string)($r['id'] ?? ''),               // INT autoincrement din SQL
              'type'       => strtolower($r['type'] ?? 'other'),
              'label'      => $label,
              'label_slug' => $norm_label_slug($label),
              'fields'     => is_array($fields_decoded) ? $fields_decoded : [],
              'is_default' => (bool)($r['is_default'] ?? 0),
              'status'     => $r['status'] ?? 'active',
              'created_at' => $r['created_at'] ?? '',
              'updated_at' => $r['updated_at'] ?? '',
              'source'     => 'sql',
          ];
      }
  }
  vogo_error_log3("[ADDR][LIST][STEP 3] SQL custom addresses: ".count($custom_sql)." | USER:$user_id");

  // === STEP 3: Custom din user_meta (vogo_addresses) ===
  $custom_meta = [];
  $meta_list = get_user_meta($user_id, 'vogo_addresses', true);
  if (is_array($meta_list) && !empty($meta_list)) {
      foreach ($meta_list as $a) {
          $label = $a['label'] ?? '';
          $custom_meta[] = [
              'id'         => (string)($a['id'] ?? ''),                // UUID
              'type'       => strtolower($a['type'] ?? 'other'),
              'label'      => $label,
              'label_slug' => !empty($a['label_slug']) ? $a['label_slug'] : $norm_label_slug($label),
              'fields'     => isset($a['fields']) && is_array($a['fields']) ? $a['fields'] : [],
              'is_default' => !empty($a['is_default']),
              'status'     => 'active',
              'created_at' => $a['created_at'] ?? '',
              'updated_at' => $a['updated_at'] ?? '',
              'source'     => 'meta',
          ];
      }
  }
  vogo_error_log3("[ADDR][LIST][STEP 4] META custom addresses: ".count($custom_meta)." | USER:$user_id");

  // === STEP 4: Unificare custom (SQL + META) ===
  // nu de-duplicăm agresiv; le lăsăm cu 'source' diferit
  $custom_addresses = array_values(array_merge($custom_sql, $custom_meta));

  // SORTARE opțională: default primele, apoi created_at desc
  usort($custom_addresses, function($a,$b){
      $ad = !empty($a['is_default']); $bd = !empty($b['is_default']);
      if ($ad !== $bd) return $ad ? -1 : 1;
      return strcmp(($b['created_at'] ?? ''), ($a['created_at'] ?? ''));
  });

  vogo_error_log3("[ADDR][LIST][STEP 5] Custom unified: ".count($custom_addresses)." | USER:$user_id");

  // === STEP 5: Payload final ===
  $resp = [
      'success'          => true,
      'message'          => 'Addresses retrieved',
      'user_id'          => $user_id,
      'user_login'       => wp_get_current_user()->user_login,
      'billing_shipping' => $billing_shipping,    // id = unique_code | label = Billing/Shipping | label_slug = billing/shipping
      'custom_addresses' => $custom_addresses     // id = SQL id sau UUID; label(+slug); fields{...}; is_default; source
  ];

  return new WP_REST_Response($resp, 200);
}


function vogo_add_edit_standard_address2(WP_REST_Request $request) {
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  $db_name = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db_name | IP: $ip | User: $user_id");

  $data = $request->get_json_params();
  $type = sanitize_text_field($data['type'] ?? '');
  $code = sanitize_text_field($data['unique_code'] ?? '');

  if (empty($type) || empty($code)) {
    return new WP_REST_Response([
      'success' => false,
      'message' => 'Missing type or unique_code'
    ], 400);
  }

  $fields = ['first_name','last_name','company','address_1','address_2','city','state','state_name','postcode','country','country_name','phone','email','dialCode','latitudine','longitudine'];
  $action = 'insert';

  // STEP 2: Check if code already exists for this user and type
  $existing_code = get_user_meta($user_id, "{$type}_unique_code", true);
  if ($existing_code === $code) $action = 'update';

  // STEP 3: Save all fields as usermeta
  foreach ($fields as $field) {
    $value = sanitize_text_field($data[$field] ?? '');
    update_user_meta($user_id, "{$type}_{$field}", $value);
  }
  update_user_meta($user_id, "{$type}_unique_code", $code);

  vogo_error_log3("[STEP 2] $action standard address | type: $type | code: $code | IP: $ip | User: $user_id");

  return new WP_REST_Response([
    'success' => true,
    'action' => $action,
    'message' => strtoupper($action) . " standard address with code '{$code}' for user {$user_id}"
  ], 200);
}

/**
 * Insert a new custom address into wp_user_addresses
 * Requirements: Authorization: Bearer, JWT user, mandatory: address_name, street_address, city, county
 * Response: includes module '<file>.<func>.TEND' and lat/long resolved from DB
 */
function vogo_add_new_custom_address(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP = basename(__FILE__); $module = $MODULE_PHP.'.'.__FUNCTION__;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

  // STEP 0 – Bearer
  $auth = $request->get_header('authorization');
  if(!$auth || stripos($auth,'Bearer ')!==0){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Authorization header missing or not Bearer','audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>false]],401);
  }

  // STEP 1 – JWT user
  $user_id = extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response) return $user_id;
  if(is_wp_error($user_id)) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>$user_id->get_error_message(),'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>true]],401);
  $user_id = (int)$user_id; if($user_id<=0) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Invalid user_id'],401);

  // STEP 2 – Input + aliases
  $p = (array)$request->get_json_params();
  if(!isset($p['address_name'])   && isset($p['label']))               $p['address_name']=$p['label'];
  if(!isset($p['street_address']) && isset($p['address_1']))           $p['street_address']=$p['address_1'];
  if(!isset($p['street_address_2']) && isset($p['address_2']))         $p['street_address_2']=$p['address_2'];
  if(!isset($p['address_code'])   && isset($p['address_postal_code'])) $p['address_code']=$p['address_postal_code'];
  if(!isset($p['address_code'])   && isset($p['postcode']))            $p['address_code']=$p['postcode'];
  if(!isset($p['county'])         && isset($p['state']))               $p['county']=$p['state'];

  $address_name   = trim(sanitize_text_field($p['address_name']   ?? ''));
  $street_address = sanitize_text_field($p['street_address']      ?? '');
  $street_address_2 = sanitize_text_field($p['street_address_2']  ?? '');
  $city           = sanitize_text_field($p['city']                ?? '');
  $county         = sanitize_text_field($p['county']              ?? '');
  $address_code   = sanitize_text_field($p['address_code']        ?? '');
  $status_raw     = strtolower(sanitize_text_field($p['status']   ?? 'active'));
  $status         = in_array($status_raw,['active','inactive'],true)?$status_raw:'active';

  // lat/long from payload (accept lat/long/latitude/longitude)
  $lat_in = $p['lat'] ?? ($p['latitude'] ?? null);
  $lon_in = $p['long']?? ($p['longitude']?? null);
  $lat_s  = ($lat_in!==null && $lat_in!=='') ? (string)round((float)$lat_in,8) : '';
  $lon_s  = ($lon_in!==null && $lon_in!=='') ? (string)round((float)$lon_in,8) : '';

  // Required
  if($address_name==='') return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'address_name is required','audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],400);
  if($street_address===''||$city===''||$county==='') return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'Missing minimal fields: street_address, city, county','audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],400);

  $table = $wpdb->prefix.'user_addresses';

  // STEP 3 – Duplicate (user_id+address_name)
  $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE user_id=%d AND LOWER(TRIM(address_name))=LOWER(TRIM(%s)) LIMIT 1",$user_id,$address_name));
  if($exists) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>"exista deja o adresa cu Numele: {$address_name}",'audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],409);

  // STEP 4 – Build row; include optional cols if present
  $cols = $wpdb->get_col("SHOW COLUMNS FROM {$table}",0);
  $row = [
    'user_id'=>$user_id,'address_name'=>$address_name,'street_address'=>$street_address,'street_address_2'=>$street_address_2,
    'city'=>$city,'county'=>$county,'address_code'=>$address_code,'status'=>$status
  ];
  if(in_array('phone',$cols,true))      $row['phone']=sanitize_text_field($p['phone']??'');
  if(in_array('email',$cols,true))      $row['email']=sanitize_text_field($p['email']??'');
  if(in_array('is_default',$cols,true)) $row['is_default']=!empty($p['is_default'])?1:0;
  if(in_array('country',$cols,true))    $row['country']=sanitize_text_field($p['country']??'');
  if(in_array('first_name',$cols,true)) $row['first_name']=sanitize_text_field($p['first_name']??'');
  if(in_array('last_name',$cols,true))  $row['last_name']=sanitize_text_field($p['last_name']??'');
  if(in_array('dialCode',$cols,true))   $row['dialCode']=sanitize_text_field($p['dialCode']??'');

  // map lat/long to existing schema (lat/long or latitude/longitude)
  if($lat_s!==''){
    if(in_array('lat',$cols,true)) $row['lat']=$lat_s; elseif(in_array('latitude',$cols,true)) $row['latitude']=$lat_s;
  }
  if($lon_s!==''){
    if(in_array('long',$cols,true)) $row['long']=$lon_s; elseif(in_array('longitude',$cols,true)) $row['longitude']=$lon_s;
  }

  // STEP 5 – Insert
  $ok = $wpdb->insert($table,$row);
  if($ok===false) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'DB insert failed','sql_error'=>$wpdb->last_error,'audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],500);
  $sql_id = (int)$wpdb->insert_id;

  // STEP 6 – Reload to reflect DB values
  $new = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1",$sql_id),ARRAY_A);
  $resp_lat  = '';
  $resp_long = '';
  if($new){
    if(array_key_exists('lat',$new))       $resp_lat  = (string)($new['lat']??'');
    elseif(array_key_exists('latitude',$new)) $resp_lat  = (string)($new['latitude']??'');
    if(array_key_exists('long',$new))      $resp_long = (string)($new['long']??'');
    elseif(array_key_exists('longitude',$new)) $resp_long = (string)($new['longitude']??'');
  }

  // STEP 7 – Response
  return new WP_REST_Response([
    'success'=>true,
    'module'=>$module.'.TEND',
    'user_id'=>$user_id,
    'sql_id'=>$sql_id,
    'lat'=>$resp_lat,
    'long'=>$resp_long,
    'address'=>[
      'address_name'=>$address_name,
      'street_address'=>$street_address,
      'street_address_2'=>$street_address_2,
      'city'=>$city,
      'county'=>$county,
      'address_code'=>$address_code,
      'status'=>$status
    ],
    'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>true]
  ],200);
}


/**
 * Update a custom address row in wp_user_addresses by SQL id.
 * Requires Authorization: Bearer. Returns module '<file>.<func>.TEND'.
 * Supports coord columns: lat/long OR latitude/longitude.
 */
function vogo_edit_custom_address(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $ip=$_SERVER['REMOTE_ADDR']??'unknown';

  // Bearer
  $auth=$request->get_header('authorization');
  if(!$auth || stripos($auth,'Bearer ')!==0){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Authorization header missing or not Bearer','audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>false]],401);
  }

  // JWT
  $user_id=extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response) return $user_id;
  if(is_wp_error($user_id)) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>$user_id->get_error_message(),'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>true]],401);
  $user_id=(int)$user_id;

  // Input
  $raw=(array)$request->get_json_params();
  $address_id=(int)($raw['address_id']??0);
  if($address_id<=0) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'Missing address_id','audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],400);

  $table=$wpdb->prefix.'user_addresses';
  $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1",$address_id),ARRAY_A);
  if(!$row) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'Address not found','audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],404);
  if((int)$row['user_id']!==$user_id) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'Forbidden','audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],403);

  // Aliases -> canonical
  if(!isset($raw['address_name']) && isset($raw['label'])) $raw['address_name']=$raw['label'];
  if(!isset($raw['street_address']) && isset($raw['address_1'])) $raw['street_address']=$raw['address_1'];
  if(!isset($raw['street_address_2']) && isset($raw['address_2'])) $raw['street_address_2']=$raw['address_2'];
  if(!isset($raw['county']) && isset($raw['state'])) $raw['county']=$raw['state'];
  if(!isset($raw['address_code']) && isset($raw['address_postal_code'])) $raw['address_code']=$raw['address_postal_code'];
  if(!isset($raw['address_code']) && isset($raw['postcode'])) $raw['address_code']=$raw['postcode'];

  // Build update set
  $allowed=['address_name','street_address','street_address_2','city','county','address_code','status'];
  $upd=[];
  foreach($allowed as $k){
    if(array_key_exists($k,$raw)){
      $val=sanitize_text_field($raw[$k]);
      if($k==='status'){ $val=in_array(strtolower($val),['active','inactive'],true)?strtolower($val):$row['status']; }
      $upd[$k]=$val;
    }
  }

  // Coords mapping for both schemas
  $cols=$wpdb->get_col("SHOW COLUMNS FROM {$table}",0);
  $lat_in=$raw['lat']??($raw['latitude']??null);
  $lon_in=$raw['long']??($raw['longitude']??null);
  $lat_s=($lat_in!==null && $lat_in!=='')?(string)round((float)$lat_in,8):null;
  $lon_s=($lon_in!==null && $lon_in!=='')?(string)round((float)$lon_in,8):null;

  // choose target columns based on existing schema
  if($lat_s!==null){
    if(in_array('lat',$cols,true)) $upd['lat']=$lat_s;
    elseif(in_array('latitude',$cols,true)) $upd['latitude']=$lat_s;
  }
  if($lon_s!==null){
    if(in_array('long',$cols,true)) $upd['long']=$lon_s;
    elseif(in_array('longitude',$cols,true)) $upd['longitude']=$lon_s;
  }

  if(empty($upd)){
    return new WP_REST_Response(['success'=>true,'module'=>$module.'.TEND','message'=>'Nothing to update','user_id'=>$user_id,'address'=>[
      'id'=>(string)$row['id'],
      'address_name'=>(string)$row['address_name'],
      'street_address'=>(string)$row['street_address'],
      'street_address_2'=>(string)$row['street_address_2'],
      'city'=>(string)$row['city'],
      'county'=>(string)$row['county'],
      'address_code'=>(string)$row['address_code'],
      'status'=>(string)$row['status'],
      'lat'=>(string)($row['lat']??$row['latitude']??''),
      'long'=>(string)($row['long']??$row['longitude']??'')
    ],'audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],200);
  }

  // Update
  $ok=$wpdb->update($table,$upd,['id'=>$address_id]);
  if($ok===false) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','message'=>'DB update failed','sql_error'=>$wpdb->last_error,'audit'=>['ip'=>$ip,'active_db'=>DB_NAME]],500);

  // Reload + response with fallback keys
  $new=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1",$address_id),ARRAY_A);

  return new WP_REST_Response([
    'success'=>true,
    'module'=>$module.'.TEND',
    'user_id'=>$user_id,
    'address'=>[
      'id'=>(string)$new['id'],
      'address_name'=>(string)$new['address_name'],
      'street_address'=>(string)$new['street_address'],
      'street_address_2'=>(string)$new['street_address_2'],
      'city'=>(string)$new['city'],
      'county'=>(string)$new['county'],
      'address_code'=>(string)$new['address_code'],
      'status'=>(string)$new['status'],
      'lat'=>(string)($new['lat']??$new['latitude']??''),
      'long'=>(string)($new['long']??$new['longitude']??'')
    ],
    'audit'=>['ip'=>$ip,'active_db'=>DB_NAME,'auth_prefix_ok'=>true]
  ],200);
}


/**
 * HARD DELETE a custom address from wp_user_addresses by SQL id.
 * - Auth via JWT (current user)
 * - Requires: address_id (== wp_user_addresses.id)
 * - Ownership check: row.user_id must equal current user
 * - Also prunes mirror entry from usermeta 'vogo_addresses' (by label) if present
 */
function vogo_delete_custom_address(WP_REST_Request $request){
    global $wpdb;

    // STEP 0: boot & diagnostics
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $raw = (array)$request->get_json_params();
    vogo_error_log3("VOGO_LOG_START | MODULE:delete_custom_address | DB:".DB_NAME." | IP:$ip | RAW:".json_encode($raw));

    // STEP 1: auth
    $user_id = extract_user_from_jwt_token($request);
    if ($user_id instanceof WP_REST_Response) return $user_id;
    if (is_wp_error($user_id)) {
        vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message());
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()], 401);
    }

    // STEP 2: input
    $address_id = intval($raw['address_id'] ?? 0);
    if ($address_id <= 0) {
        vogo_error_log3("[STEP 2][ERR] Missing address_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'Missing address_id'], 400);
    }

    $table = $wpdb->prefix.'user_addresses';

    // STEP 3: read row & ownership check
    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table} WHERE id=%d LIMIT 1", $address_id),
        ARRAY_A
    );
    if (!$row) {
        vogo_error_log3("[STEP 3][ERR] Address not found | id:$address_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'Address not found'], 404);
    }
    if (intval($row['user_id']) !== intval($user_id)) {
        vogo_error_log3("[STEP 3][ERR] Forbidden delete | owner:{$row['user_id']} != $user_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'Forbidden'], 403);
    }

    // STEP 4: hard delete
    $deleted = $wpdb->delete($table, ['id'=>$address_id], ['%d']);
    if ($deleted === false) {
        vogo_error_log3("[STEP 4][ERR] DB delete failed | id:$address_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'DB delete failed'], 500);
    }

    // STEP 5 (optional): prune mirror from usermeta 'vogo_addresses' by label match
    $label = (string)($row['address_name'] ?? '');
    if ($label !== '') {
        $list = get_user_meta($user_id, 'vogo_addresses', true);
        if (is_array($list) && !empty($list)) {
            $canon = function($s){ return mb_strtolower(trim((string)$s)); };
            $new   = [];
            $pruned = false;
            foreach ($list as $a) {
                $alabel = isset($a['label']) ? $a['label'] : (isset($a['label_slug']) ? $a['label_slug'] : '');
                if ($canon($alabel) === $canon($label)) { $pruned = true; continue; }
                $new[] = $a;
            }
            if ($pruned) {
                update_user_meta($user_id, 'vogo_addresses', $new);
                vogo_error_log3("[STEP 5] Pruned mirror from usermeta for label='$label'");
            }
        }
    }

    vogo_error_log3("[STEP 6] DELETE OK | id:$address_id | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");

    // STEP 6: response (return the deleted snapshot)
    return new WP_REST_Response([
        'success' => true,
        'message' => 'Custom address deleted',
        'user_id' => $user_id,
        'deleted' => [
            'id'               => (string)$row['id'],
            'address_name'     => (string)$row['address_name'],
            'street_address'   => (string)$row['street_address'],
            'street_address_2' => (string)$row['street_address_2'],
            'city'             => (string)$row['city'],
            'county'           => (string)$row['county'],
            'address_code'     => (string)$row['address_code'],
            'status'           => (string)$row['status'],
        ]
    ], 200);
}

/**
 * Update basic Woo/WordPress account info for the current user.
 * Allowed inputs (aliases supported):
 *   - first_name
 *   - last_name
 *   - display_name
 *   - email | user_email
 *   - phone | billing_phone
 *   - website | user_url
 *
 * Rules:
 *   - Auth via JWT (extract_user_from_jwt_token).
 *   - Email must be valid and unique.
 *   - Website is normalized (adds https:// if missing scheme).
 *   - Updates WP core fields via wp_update_user; phone goes to usermeta (billing_phone + phone).
 *   - Returns a compact "updated" map with only changed fields.
 */
function vogo_edit_account_info(WP_REST_Request $request){
    // STEP 0: boot & diagnostics
    $ip  = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $raw = (array) $request->get_json_params();
    vogo_error_log3("VOGO_LOG_START | MODULE:edit_account_info | DB:".DB_NAME." | IP:$ip | RAW:".json_encode($raw));

    // STEP 1: auth
    $user_id = extract_user_from_jwt_token($request);
    if ($user_id instanceof WP_REST_Response) return $user_id;
    if (is_wp_error($user_id)) {
        vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message());
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()], 401);
    }

    sync_vogo_user_info ($user_id);

    // STEP 2: sanitize inputs + aliasing
    $allowed = [
        'first_name','last_name','display_name','nickname',
        'user_email','email',
        'billing_phone','phone',
        'user_url','website',
    ];
    $in = [];
    foreach ($allowed as $k) {
        if (array_key_exists($k, $raw)) {
            if ($k === 'user_email' || $k === 'email') {
                $in[$k] = sanitize_email($raw[$k]);
            } elseif ($k === 'user_url' || $k === 'website') {
                $in[$k] = trim((string)$raw[$k]);
            } else {
                $in[$k] = sanitize_text_field($raw[$k]);
            }
        }
    }

    // Canonicalize aliases
    if (!empty($in['email']) && empty($in['user_email'])) {
        $in['user_email'] = $in['email']; unset($in['email']);
    }
    if (!empty($in['website']) && empty($in['user_url'])) {
        $in['user_url'] = $in['website']; unset($in['website']);
    }
    if (!empty($in['phone']) && empty($in['billing_phone'])) {
        $in['billing_phone'] = $in['phone']; unset($in['phone']);
    }

    // Early exit if nothing to update
    $updatable = array_intersect_key($in, array_flip([
        'first_name','last_name','display_name','nickname','user_email','billing_phone','user_url'
    ]));
    if (empty($updatable)) {
        vogo_error_log3("[STEP 2] Nothing to update | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>true,'message'=>'Nothing to update','user_id'=>$user_id], 200);
    }

    // STEP 3: fetch current user
    $user = get_user_by('id', $user_id);
    if (!$user) {
        vogo_error_log3("[STEP 3][ERR] User not found | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'User not found'], 404);
    }

    // STEP 4: validate email (if provided)
    if (isset($updatable['user_email'])) {
        $new_email = $updatable['user_email'];
        if (empty($new_email) || !is_email($new_email)) {
            vogo_error_log3("[STEP 4][ERR] Invalid email '$new_email' | USER:$user_id");
            vogo_error_log3("VOGO_LOG_END");
            return new WP_REST_Response(['success'=>false,'message'=>'Invalid email'], 400);
        }
        $existing_uid = email_exists($new_email);
        if ($existing_uid && intval($existing_uid) !== intval($user_id)) {
            vogo_error_log3("[STEP 4][ERR] Email in use by user $existing_uid | USER:$user_id");
            vogo_error_log3("VOGO_LOG_END");
            return new WP_REST_Response(['success'=>false,'message'=>'Email already in use'], 409);
        }
    }

    // STEP 5: normalize website (if provided)
    if (isset($updatable['user_url'])) {
        $url = trim($updatable['user_url']);
        if ($url !== '') {
            if (!preg_match('#^https?://#i', $url)) {
                $url = 'https://' . $url;
            }
            $url = esc_url_raw($url);
            // If still empty after esc_url_raw, treat as invalid
            if ($url === '') {
                vogo_error_log3("[STEP 5][ERR] Invalid website URL | USER:$user_id");
                vogo_error_log3("VOGO_LOG_END");
                return new WP_REST_Response(['success'=>false,'message'=>'Invalid website URL'], 400);
            }
            $updatable['user_url'] = $url;
        }
    }

    // STEP 6: build core WP update payload
    $core = ['ID' => $user_id];
    foreach (['user_email','display_name','first_name','last_name','nickname','user_url'] as $k) {
        if (isset($updatable[$k])) $core[$k] = $updatable[$k];
    }

    $updated = [];

    // STEP 7: wp_update_user for core fields
    if (count($core) > 1) { // has at least one field besides ID
        $r = wp_update_user($core);
        if (is_wp_error($r)) {
            vogo_error_log3("[STEP 7][ERR] wp_update_user: ".$r->get_error_message()." | USER:$user_id");
            vogo_error_log3("VOGO_LOG_END");
            return new WP_REST_Response(['success'=>false,'message'=>$r->get_error_message()], 500);
        }
        foreach (['user_email','display_name','first_name','last_name','nickname','user_url'] as $k) {
            if (isset($updatable[$k])) $updated[$k] = $updatable[$k];
        }
    }

    // STEP 8: usermeta updates (phone + optional sync)
    if (isset($updatable['billing_phone'])) {
        update_user_meta($user_id, 'billing_phone', $updatable['billing_phone']);
        update_user_meta($user_id, 'phone', $updatable['billing_phone']); // keep a plain 'phone' mirror if UI needs it
        $updated['billing_phone'] = $updatable['billing_phone'];
    }
    if (isset($updatable['first_name'])) update_user_meta($user_id, 'first_name', $updatable['first_name']);
    if (isset($updatable['last_name']))  update_user_meta($user_id, 'last_name',  $updatable['last_name']);
    if (isset($updatable['user_email'])) update_user_meta($user_id, 'billing_email', $updatable['user_email']); // keep Woo emails in sync

    // STEP 9: finalize
    vogo_error_log3("[STEP 9] Account info updated | USER:$user_id | UPDATED:".json_encode($updated));
    vogo_error_log3("VOGO_LOG_END");

    $u = get_user_by('id', $user_id);

    return new WP_REST_Response([
        'success'     => true,
        'message'     => 'Account info updated',
        'user_id'     => $user_id,
        'user_login'  => $u ? $u->user_login : '',
        'updated'     => $updated
    ], 200);
}

/**
 * Upload user's avatar from a single multipart file field: "imagine".
 * - Auth via JWT (extract_user_from_jwt_token)
 * - Saves to Media Library as attachment
 * - Stores vogo_profile_image_id + vogo_profile_image_url in usermeta
 * - Returns URLs for common sizes
 *
 * POST (multipart/form-data):
 *   imagine: <file>   // required
 */
function vogo_update_account_image_simple(WP_REST_Request $request){
 // [LOG START]
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | MODULE:update_account_image_everywhere | ACTIVE DB: ".DB_NAME." | IP:$ip");

  // [STEP 1] Auth
  $user_id=extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response){ vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return $user_id; }
  if(is_wp_error($user_id)){ vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401); }

  // [STEP 2] File pick (imagine|file)
  $files=$request->get_file_params(); $f=$files['imagine']??($files['file']??($_FILES['imagine']??($_FILES['file']??null)));
  if(empty($f)||!empty($f['error'])){ $code=$f['error']??'N/A'; vogo_error_log3("[STEP 2][ERR] Missing file or upload error:$code | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Missing file \"imagine\" (or \"file\") or upload error'],400); }
  if(!empty($f['size']) && $f['size']>10*1024*1024){ vogo_error_log3("[STEP 2][ERR] Too large >10MB | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Image too large (max 10MB)'],413); }

  // [STEP 3] WP media libs
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/media.php';
  require_once ABSPATH.'wp-admin/includes/image.php';

  // [STEP 4] Upload to Media Library
  $attach_id=media_handle_upload(isset($files['imagine'])||isset($_FILES['imagine'])?'imagine':'file',0);
  if(is_wp_error($attach_id)){ vogo_error_log3("[STEP 4][ERR] media_handle_upload: ".$attach_id->get_error_message()." | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Upload failed','error'=>$attach_id->get_error_message()],500); }

  // [STEP 5] Build URLs
  $full=wp_get_attachment_image_url($attach_id,'full')?:''; $thumb=wp_get_attachment_image_src($attach_id,'thumbnail'); $medium=wp_get_attachment_image_src($attach_id,'medium'); $large=wp_get_attachment_image_src($attach_id,'large');
  $sizes=['full'=>$full,'thumbnail'=>$thumb?$thumb[0]:'','medium'=>$medium?$medium[0]:'','large'=>$large?$large[0]:''];

  // [STEP 6] Save metas (multi-compat)
  update_user_meta($user_id,'vogo_profile_image_id',(int)$attach_id);
  update_user_meta($user_id,'vogo_profile_image_url',$full);
  update_user_meta($user_id,'simple_local_avatar',['full'=>(int)$attach_id]);        // compat local avatar
  update_user_meta($user_id,'wp_user_avatar',(int)$attach_id);                        // compat WP User Avatar
  update_user_meta($user_id,'_wp_attachment_wp_user_avatar',(int)$attach_id);         // compat alt plugin

  // [ADI-ADD] Also update 'custom_avatar' URL for themes/plugins that read it
  // ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat
  update_user_meta($user_id,'custom_avatar',$full);


  vogo_error_log3("[STEP 6] Avatar updated | USER:$user_id | ATTACH:$attach_id | URL:$full | IP:$ip");
  vogo_error_log3("VOGO_LOG_END");

  // [STEP 7] Response
  $u=get_userdata($user_id);
  return new WP_REST_Response([
    'success'=>true,'message'=>'Account image updated',
    'user_id'=>$user_id,'user_login'=>$u?$u->user_login:'',
    'attachment_id'=>$attach_id,'url'=>$full,'sizes'=>$sizes
  ],200);
}

// ============================
// FORCE AVATAR EVERYWHERE
// ============================
add_filter('pre_get_avatar', function($avatar,$id_or_email,$args){
  // Resolve user
  if(is_numeric($id_or_email))      $user=get_user_by('id',$id_or_email);
  elseif(is_object($id_or_email)&&!empty($id_or_email->user_id)) $user=get_user_by('id',$id_or_email->user_id);
  // was: else $user = get_user_by('email', $id_or_email);
else {
    // WordPress may pass int, string (email), WP_User, WP_Comment, or generic object.
    if ($id_or_email instanceof WP_User) {
        // Already a user object
        $user = $id_or_email;
    } elseif (is_object($id_or_email) && isset($id_or_email->user_email)) {
        // Generic object that carries an email prop
        $user = get_user_by('email', (string) $id_or_email->user_email);
    } elseif (is_object($id_or_email) && isset($id_or_email->user_id)) {
        // Objects like WP_Comment expose user_id
        $user = get_user_by('id', (int) $id_or_email->user_id);
    } elseif (is_numeric($id_or_email)) {
        // Numeric → assume user ID
        $user = get_user_by('id', (int) $id_or_email);
    } else {
        // Fallback → treat as email string
        $user = get_user_by('email', (string) $id_or_email);
    }
}

  if(!$user) return $avatar;
  $uid=(int)$user->ID;

  // Find attachment id from metas
  $img_id=(int)(get_user_meta($uid,'vogo_profile_image_id',true)?:0);
  if(!$img_id){ $s=get_user_meta($uid,'simple_local_avatar',true); if(is_array($s)&&!empty($s['full'])) $img_id=(int)$s['full']; }
  if(!$img_id){ $img_id=(int)(get_user_meta($uid,'wp_user_avatar',true)?:0); }
  if(!$img_id){ $img_id=(int)(get_user_meta($uid,'_wp_attachment_wp_user_avatar',true)?:0); }
  if(!$img_id) return $avatar; // fallback Gravatar

  $size=isset($args['size'])?(int)$args['size']:96;
  $img_url=wp_get_attachment_image_url($img_id,$size>=300?'large':($size>=150?'medium':'thumbnail'));
  if(!$img_url) return $avatar;

  $alt=esc_attr(get_the_author_meta('display_name',$uid)); $class='avatar avatar-'.$size.' photo';
  return sprintf('<img alt="%s" src="%s" class="%s" height="%d" width="%d" loading="lazy">',$alt,esc_url($img_url),esc_attr($class),$size,$size);
},10,3);

// Also override get_avatar_url for plugins/themes calling it directly
add_filter('get_avatar_url', function($url,$id_or_email,$args){
  if(is_numeric($id_or_email))      $user=get_user_by('id',$id_or_email);
  elseif(is_object($id_or_email)&&!empty($id_or_email->user_id)) $user=get_user_by('id',$id_or_email->user_id);
  // was: else $user = get_user_by('email', $id_or_email);
else {
    // WordPress may pass int, string (email), WP_User, WP_Comment, or generic object.
    if ($id_or_email instanceof WP_User) {
        // Already a user object
        $user = $id_or_email;
    } elseif (is_object($id_or_email) && isset($id_or_email->user_email)) {
        // Generic object that carries an email prop
        $user = get_user_by('email', (string) $id_or_email->user_email);
    } elseif (is_object($id_or_email) && isset($id_or_email->user_id)) {
        // Objects like WP_Comment expose user_id
        $user = get_user_by('id', (int) $id_or_email->user_id);
    } elseif (is_numeric($id_or_email)) {
        // Numeric → assume user ID
        $user = get_user_by('id', (int) $id_or_email);
    } else {
        // Fallback → treat as email string
        $user = get_user_by('email', (string) $id_or_email);
    }
}

  if(!$user) return $url;
  $uid=(int)$user->ID;

  $img_id=(int)(get_user_meta($uid,'vogo_profile_image_id',true)?:0);
  if(!$img_id){ $s=get_user_meta($uid,'simple_local_avatar',true); if(is_array($s)&&!empty($s['full'])) $img_id=(int)$s['full']; }
  if(!$img_id){ $img_id=(int)(get_user_meta($uid,'wp_user_avatar',true)?:0); }
  if(!$img_id){ $img_id=(int)(get_user_meta($uid,'_wp_attachment_wp_user_avatar',true)?:0); }
  if(!$img_id) return $url;

  $size=isset($args['size'])?(int)$args['size']:96;
  $img_url=wp_get_attachment_image_url($img_id,$size>=300?'large':($size>=150?'medium':'thumbnail'));
  return $img_url?:$url;
},10,3);

/** Return user's current account image (avatar) with sizes. */
function vogo_get_account_image(WP_REST_Request $request){
  // [LOG START]
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | MODULE:get_account_image | ACTIVE DB: ".DB_NAME." | IP:$ip");

  // [STEP 1] Auth
  $user_id=extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response){ vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return $user_id; }
  if(is_wp_error($user_id)){ vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401); }
  $u=get_userdata($user_id);

  // [STEP 2] Find attachment id from metas (multi-compat)
  $img_id=(int)(get_user_meta($user_id,'vogo_profile_image_id',true)?:0);
  if(!$img_id){ $s=get_user_meta($user_id,'simple_local_avatar',true); if(is_array($s)&&!empty($s['full'])) $img_id=(int)$s['full']; }
  if(!$img_id){ $img_id=(int)(get_user_meta($user_id,'wp_user_avatar',true)?:0); }
  if(!$img_id){ $img_id=(int)(get_user_meta($user_id,'_wp_attachment_wp_user_avatar',true)?:0); }

  // [ADI-ADD] Support 'custom_avatar' URL stored in usermeta (no attachment id)
  // ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat
  $custom_url = '';
  if(!$img_id){
    $custom_url = (string) ( get_user_meta($user_id,'custom_avatar',true) ?: '' );
    if(!empty($custom_url)){ vogo_error_log3("[STEP 2][ADI-ADD] custom_avatar URL detected | USER:$user_id | URL:$custom_url | IP:$ip"); }
  }

  // [STEP 3] Build URLs
  $full=$img_id? (wp_get_attachment_image_url($img_id,'full')?:'') : '';
  $thumb=$img_id? wp_get_attachment_image_src($img_id,'thumbnail') : null;
  $medium=$img_id? wp_get_attachment_image_src($img_id,'medium')   : null;
  $large=$img_id? wp_get_attachment_image_src($img_id,'large')     : null;

  // [ADI-ADD] If no attachment id but we have custom_avatar URL, use it as full
  // ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat
  if(!$img_id && !empty($custom_url)){
    $full = $custom_url; $thumb = null; $medium = null; $large = null;
  }


  $sizes = ['full'=>$full,'thumbnail'=>$thumb?$thumb[0]:'','medium'=>$medium?$medium[0]:'','large'=>$large?$large[0]:''];
  // [ADI-ADD] account image exists also if custom_url provided (attachment_id may be 0)
  // ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat
  $exists = ($img_id>0 && !empty($full)) || (!empty($custom_url) && !empty($full));


  vogo_error_log3("[STEP 3] Avatar lookup | USER:$user_id | ATTACH:$img_id | URL:$full | IP:$ip");
  vogo_error_log3("VOGO_LOG_END");

  // [STEP 4] Response
  return new WP_REST_Response([
    'success'=>true,
    'message'=>$exists?'Account image found':'No account image set',
    'user_id'=>$user_id,
    'user_login'=>$u?$u->user_login:'',
    'attachment_id'=>$img_id,
    'url'=>$full,
    'sizes'=>$sizes
  ],200);
}

/** Remove user's account image metas; optionally delete media attachment. */
function vogo_remove_account_image(WP_REST_Request $request){
  // [LOG START]
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | MODULE:remove_account_image | ACTIVE DB: ".DB_NAME." | IP:$ip");

  // [STEP 1] Auth
  $user_id=extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response){ vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return $user_id; }
  if(is_wp_error($user_id)){ vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401); }
  $u=get_userdata($user_id);

  // [STEP 2] Params
  $p=$request->get_json_params(); if(empty($p)) $p=$_REQUEST;
  $delete_media_raw=$p['delete_media']??false;
  $delete_media = in_array(strtolower((string)$delete_media_raw), ['1','true','yes','y'], true) || $delete_media_raw===true;

  // [STEP 3] Detect current attachment id (multi-compat)
  $img_id=(int)(get_user_meta($user_id,'vogo_profile_image_id',true)?:0);
  if(!$img_id){ $s=get_user_meta($user_id,'simple_local_avatar',true); if(is_array($s)&&!empty($s['full'])) $img_id=(int)$s['full']; }
  if(!$img_id){ $img_id=(int)(get_user_meta($user_id,'wp_user_avatar',true)?:0); }
  if(!$img_id){ $img_id=(int)(get_user_meta($user_id,'_wp_attachment_wp_user_avatar',true)?:0); }

  // [STEP 4] Delete metas
  delete_user_meta($user_id,'vogo_profile_image_id');
  delete_user_meta($user_id,'vogo_profile_image_url');
  delete_user_meta($user_id,'simple_local_avatar');
  delete_user_meta($user_id,'wp_user_avatar');
  delete_user_meta($user_id,'_wp_attachment_wp_user_avatar');

  // [STEP 5] Optionally delete media
  $media_deleted=false; $delete_error='';
  if($delete_media && $img_id>0){
    require_once ABSPATH.'wp-admin/includes/file.php';
    require_once ABSPATH.'wp-admin/includes/media.php';
    require_once ABSPATH.'wp-admin/includes/image.php';
    $res=wp_delete_attachment($img_id,true); // true = force delete
    if($res){ $media_deleted=true; } else { $delete_error='Failed to delete attachment (maybe already removed).'; }
  }

  vogo_error_log3("[STEP 5] Avatar removed | USER:$user_id | ATTACH:$img_id | DELETE_MEDIA:".($delete_media?'yes':'no')." | RESULT:".($media_deleted?'deleted':'kept')." | IP:$ip");
  if($delete_error!=='') vogo_error_log3("[STEP 5][WARN] $delete_error | IP:$ip | USER:$user_id");
  vogo_error_log3("VOGO_LOG_END");

  // [STEP 6] Response
  return new WP_REST_Response([
    'success'=>true,
    'message'=>$img_id? 'Account image removed' : 'No account image was set',
    'user_id'=>$user_id,
    'user_login'=>$u?$u->user_login:'',
    'removed_attachment_id'=>$img_id,
    'media_deleted'=>$media_deleted,
    'note'=>$delete_error
  ],200);
}

function myaccount_payment_info_get(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP:$ip | USER:unknown"); vogo_error_log3("ACTIVE DB: $active_db");
  $raw=file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw | IP:$ip | USER:unknown");

  // [STEP 1] JWT user
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  $user = get_user_by('id',$user_id); $user_login = $user ? $user->user_login : 'unknown';

  // [STEP 2] Read primary (fallback: latest)
  $table = $wpdb->prefix.'user_bank_accounts';
  $q1 = $wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND status='active' ORDER BY is_primary DESC, id DESC LIMIT 1",$user_id);
  vogo_error_log3("##############SQL: $q1");
  $row = $wpdb->get_row($q1, ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error: ".$wpdb->last_error." | IP:$ip | USER:$user_id"); }

  $resp = [
    'success'=>true,
    'user_id'=>$user_id,
    'user_login'=>$user_login,
    'data'=> $row ? [
      'id'=>(int)$row['id'],
      'account_holder_name'=>$row['account_holder_name'],
      'bank_name'=>$row['bank_name'],
      'account_number'=>$row['account_number'],
      'iban_number'=>$row['iban_number'],
      'ifsc_code'=>$row['ifsc_code'],
      'is_primary'=> (bool)$row['is_primary']
    ] : null
  ];
  vogo_error_log3("VOGO_LOG_END | IP:$ip | USER:$user_id"); return new WP_REST_Response($resp,200);
}

function myaccount_payment_info_save(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP:$ip | USER:unknown"); vogo_error_log3("ACTIVE DB: $active_db");
  $raw=file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw | IP:$ip | USER:unknown");

  // [STEP 1] JWT user
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  $user = get_user_by('id',$user_id); $user_login = $user ? $user->user_login : 'unknown';

  // [STEP 2] Parse + sanitize
  $p = $request->get_json_params() ?: [];
  $id = intval($p['id'] ?? 0); // optional for update
  $account_holder_name = sanitize_text_field($p['account_holder_name'] ?? '');
  $bank_name           = sanitize_text_field($p['bank_name'] ?? '');
  $account_number      = sanitize_text_field($p['account_number'] ?? '');
  $iban_number         = sanitize_text_field($p['iban_number'] ?? '');
  $ifsc_code           = sanitize_text_field($p['ifsc_code'] ?? '');
  $is_primary          = !empty($p['is_primary']) ? 1 : 0;

  // [STEP 3] Basic validations
  if(!$account_holder_name || !$bank_name){ return new WP_REST_Response(['success'=>false,'error'=>'Missing required fields: account_holder_name, bank_name','user_id'=>$user_id,'user_login'=>$user_login],400); }

  // [STEP 4] UPSERT (unique key by user_id + iban_number if provided, else by user_id + account_number)
  $table = $wpdb->prefix.'user_bank_accounts';
  $unique_where = (!empty($iban_number))
    ? $wpdb->prepare("user_id=%d AND iban_number=%s",$user_id,$iban_number)
    : $wpdb->prepare("user_id=%d AND account_number=%s",$user_id,$account_number);

  $existing = $wpdb->get_row("SELECT * FROM $table WHERE $unique_where LIMIT 1", ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error: ".$wpdb->last_error." | IP:$ip | USER:$user_id"); }

  // Ensure only one primary per user if requested
  if($is_primary===1){
    $qClear = $wpdb->prepare("UPDATE $table SET is_primary=0, modified_by=%d WHERE user_id=%d",$user_id,$user_id);
    vogo_error_log3("##############SQL: $qClear"); $wpdb->query($qClear);
    if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error(clear primary): ".$wpdb->last_error." | IP:$ip | USER:$user_id"); }
  }

  $data = [
    'user_id'=>$user_id,'account_holder_name'=>$account_holder_name,'bank_name'=>$bank_name,
    'account_number'=>$account_number,'iban_number'=>$iban_number,'ifsc_code'=>$ifsc_code,
    'is_primary'=>$is_primary,'status'=>'active','modified_by'=>$user_id
  ];

  $insert_id=0; $modified_id=0;

  if($id>0){
    // force update by id (owned by user)
    $qCheck = $wpdb->prepare("SELECT id FROM $table WHERE id=%d AND user_id=%d",$id,$user_id);
    vogo_error_log3("##############SQL: $qCheck"); $ok = $wpdb->get_var($qCheck);
    if($ok){
      vogo_error_log3("##############SQL: UPDATE $table ... WHERE id=$id");
      $wpdb->update($table,$data,['id'=>$id]);
      if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error(update by id): ".$wpdb->last_error." | IP:$ip | USER:$user_id"); 
        return new WP_REST_Response(['success'=>false,'error'=>'SQL update failed','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
      }
      $modified_id=$id;
    } else {
      return new WP_REST_Response(['success'=>false,'error'=>'Record not found or not owned by user','user_id'=>$user_id,'user_login'=>$user_login],404);
    }
  } elseif($existing){
    // update existing by unique key
    vogo_error_log3("##############SQL: UPDATE $table ... WHERE id=".$existing['id']);
    $wpdb->update($table,$data,['id'=>$existing['id']]);
    if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error(update existing): ".$wpdb->last_error." | IP:$ip | USER:$user_id"); 
      return new WP_REST_Response(['success'=>false,'error'=>'SQL update failed','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
    }
    $modified_id = intval($existing['id']);
  } else {
    // insert new
    $data['created_by']=$user_id;
    vogo_error_log3("##############SQL: INSERT INTO $table ...");
    $ok = $wpdb->insert($table,$data);
    if(!$ok || $wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error(insert): ".$wpdb->last_error." | IP:$ip | USER:$user_id"); 
      return new WP_REST_Response(['success'=>false,'error'=>'SQL insert failed','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
    }
    $insert_id = intval($wpdb->insert_id);
  }

  // [STEP 5] Return current primary (or the saved row)
  $qRes = $wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND status='active' ORDER BY is_primary DESC, id DESC LIMIT 1",$user_id);
  vogo_error_log3("##############SQL: $qRes"); $row = $wpdb->get_row($qRes, ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error(select after save): ".$wpdb->last_error." | IP:$ip | USER:$user_id"); }

  $resp = [
    'success'=>true,
    'user_id'=>$user_id,
    'user_login'=>$user_login,
    'insert_id'=>$insert_id,
    'modified_id'=>$modified_id,
    'data'=> $row ? [
      'id'=>(int)$row['id'],
      'account_holder_name'=>$row['account_holder_name'],
      'bank_name'=>$row['bank_name'],
      'account_number'=>$row['account_number'],
      'iban_number'=>$row['iban_number'],
      'ifsc_code'=>$row['ifsc_code'],
      'is_primary'=> (bool)$row['is_primary']
    ] : null
  ];
  vogo_error_log3("VOGO_LOG_END | IP:$ip | USER:$user_id"); return new WP_REST_Response($resp,200);
}

function vogo_set_myrefferal_code(WP_REST_Request $request){
  global $wpdb; $module='set_myrefferal_code'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("STEP 1 - START set_myrefferal_code | DB:$db | IP:$ip | user:unknown", $module);

  // STEP 2 - JWT user extraction
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("STEP 2 - JWT FAILED | IP:$ip", $module); return $user_or_err; }
  $user_id = (int)$user_or_err; if($user_id<=0){ vogo_error_log3("STEP 2 - Invalid user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'auth_failed'],403); }

  sync_vogo_user_info ($user_id);
  // STEP 3 - Input ref_code (exact field required)
  $p = $request->get_json_params(); $ref_code = sanitize_text_field($p['my_referral_code']??'');
  if($ref_code===''){ vogo_error_log3("STEP 3 - Missing ref_code | uid:$user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'ref_code_required'],400); }

  // STEP 4 - Save exactly as requested (update wp_vogo_user_info.my_referral_code)
  $t = $wpdb->prefix.'vogo_user_info';
  $sql = $wpdb->prepare("UPDATE $t SET my_referral_code=%s WHERE user_id=%d", $ref_code, $user_id);
  vogo_error_log3("##############SQL: $sql", $module);
  $res = $wpdb->query($sql);
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }
  if($res===0){ vogo_error_log3("[$module] user_info_not_found | uid:$user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'user_info_not_found'],404); }
  vogo_error_log3("STEP 4 - my_referral_code saved | uid:$user_id | ref_code:$ref_code | IP:$ip", $module);

  // STEP 5 - Done
  vogo_error_log3("STEP 5 - DONE | uid:$user_id | IP:$ip", $module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response(['success'=>true,'user_id'=>$user_id,'my_referral_code'=>$ref_code,'message'=>'ref_code_saved'],200);
}

function vogo_get_myrefferal_code(WP_REST_Request $request){
  global $wpdb; $module='get_myrefferal_code'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("STEP 1 - START get_myrefferal_code | DB:$db | IP:$ip | user:unknown", $module);

  // STEP 2 - JWT user extraction
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("STEP 2 - JWT FAILED | IP:$ip", $module); return $user_or_err; }
  $user_id = (int)$user_or_err; if($user_id<=0){ vogo_error_log3("STEP 2 - Invalid user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'auth_failed'],403); }

  // STEP 3 - Read my_referral_code from wp_vogo_user_info
  $t = $wpdb->prefix.'vogo_user_info';
  $sql = $wpdb->prepare("SELECT my_referral_code FROM $t WHERE user_id=%d LIMIT 1", $user_id);
  vogo_error_log3("##############SQL: $sql", $module);
  $row = $wpdb->get_row($sql, ARRAY_A);
  if(!$row){ vogo_error_log3("[$module] user_info_not_found | uid:$user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'user_info_not_found'],404); }

  $ref_code = is_string($row['my_referral_code'] ?? '') ? trim($row['my_referral_code']) : '';

  // STEP 4 - Done
  vogo_error_log3("STEP 4 - DONE | uid:$user_id | ref_code_len:".strlen($ref_code)." | IP:$ip", $module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response([
    'success'=>true,
    'user_id'=>$user_id,
    'my_referral_code'=>$ref_code
  ],200);
}


function vogo_set_referred_by(WP_REST_Request $request){
  global $wpdb; $module='set_referred_by'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("STEP 1 - START set_referred_by | DB:$db | IP:$ip | user:unknown", $module);

  // STEP 2 - JWT user extraction
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("STEP 2 - JWT FAILED | IP:$ip", $module); return $user_or_err; }
  $user_id = (int)$user_or_err; if($user_id<=0){ vogo_error_log3("STEP 2 - Invalid user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'auth_failed'],403); }

  sync_vogo_user_info ($user_id);

  // STEP 3 - Input used_refferal_code (exact field required)
  $p = $request->get_json_params(); $used_code = sanitize_text_field($p['used_refferal_code']??'');
  if($used_code===''){ vogo_error_log3("STEP 3 - Missing used_refferal_code | uid:$user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'used_refferal_code_required'],400); }

  // STEP 4 - Find referrer by my_referral_code (single SELECT returns id + nickname)
  $t = $wpdb->prefix.'vogo_user_info';
  $sql_find = $wpdb->prepare("SELECT user_id, client_nickname FROM $t WHERE my_referral_code=%s LIMIT 1", $used_code);
  vogo_error_log3("##############SQL: $sql_find", $module);
  $row = $wpdb->get_row($sql_find, ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }
  if(!$row || !is_array($row)){ vogo_error_log3("STEP 4 - ref_code_not_found | code:$used_code | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'ref_code_not_found'],404); }

  $ref_user_id = (int)$row['user_id'];
  $parent_nickname = (isset($row['client_nickname']) && is_scalar($row['client_nickname'])) ? trim((string)$row['client_nickname']) : '';
  if($ref_user_id===$user_id){ vogo_error_log3("STEP 4 - self_referral_blocked | uid:$user_id | code:$used_code | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'cannot_refer_self'],409); }

  // STEP 5 - Link current user -> parent_user_id and save used_refferal_code
  $sql_upd = $wpdb->prepare("UPDATE $t SET parent_user_id=%d, used_refferal_code=%s WHERE user_id=%d", $ref_user_id, $used_code, $user_id);
  vogo_error_log3("##############SQL: $sql_upd", $module);
  $res = $wpdb->query($sql_upd);
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }
  if($res===0){ vogo_error_log3("[$module] user_info_not_found | uid:$user_id | IP:$ip", $module); return new WP_REST_Response(['success'=>false,'error'=>'user_info_not_found'],404); }

  vogo_error_log3("STEP 5 - referred_by set | uid:$user_id -> parent_user_id:$ref_user_id | code:$used_code | IP:$ip", $module);
  vogo_error_log3("STEP 6 - DONE | uid:$user_id | IP:$ip", $module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response([
    'success'=>true,
    'user_id'=>$user_id,
    'parent_user_id'=>$ref_user_id,
    'parent_nickname'=>$parent_nickname,
    'used_refferal_code'=>$used_code,
    'message'=>'referred_by_set'
  ],200);
}


function vogo_get_referred_by(WP_REST_Request $request){
  global $wpdb; $module='get_referred_by'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("STEP 1 - START get_referred_by | DB:$db | IP:$ip | user:unknown",$module);

  // STEP 2 - JWT user extraction
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("STEP 2 - JWT FAILED | IP:$ip",$module); return $user_or_err; }
  $user_id = (int)$user_or_err; if($user_id<=0){ vogo_error_log3("STEP 2 - Invalid user_id from JWT | IP:$ip",$module); return new WP_REST_Response(['success'=>false,'error'=>'auth_failed'],403); }

  // STEP 3 - One-shot fetch (ui = current user, p = parent)
  $t = $wpdb->prefix.'vogo_user_info';
  $sql = $wpdb->prepare("SELECT ui.my_referral_code, ui.used_refferal_code, ui.parent_user_id, p.client_nickname AS parent_nickname FROM $t ui LEFT JOIN $t p ON p.user_id = ui.parent_user_id WHERE ui.user_id=%d LIMIT 1", $user_id);
  vogo_error_log3("##############SQL: $sql", $module);
  $row = $wpdb->get_row($sql, ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error,$module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }
  if(!$row){ vogo_error_log3("[$module] user_info_not_found | uid:$user_id | IP:$ip",$module); return new WP_REST_Response(['success'=>false,'error'=>'user_info_not_found'],404); }

  // [ADI-ADD] Safe casts to avoid trim(NULL) deprecations
  $my_ref_code     = (isset($row['my_referral_code'])     && is_scalar($row['my_referral_code']))     ? trim((string)$row['my_referral_code'])       : '';
  $used_ref_code   = (isset($row['used_refferal_code'])   && is_scalar($row['used_refferal_code']))   ? trim((string)$row['used_refferal_code'])     : '';
  $parent_user_id  = (int)($row['parent_user_id'] ?? 0);
  $parent_nickname = (isset($row['parent_nickname'])      && is_scalar($row['parent_nickname']))      ? trim((string)$row['parent_nickname'])        : '';

  vogo_error_log3("STEP 4 - DONE | uid:$user_id | parent:$parent_user_id | IP:$ip",$module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response([
    'success'            => true,
    'user_id'            => $user_id,
    'my_referral_code'   => $my_ref_code,
    'used_refferal_code' => $used_ref_code,
    'parent_user_id'     => $parent_user_id,
    'parent_nickname'    => $parent_nickname
  ],200);
}


function user_roles_get_by_username(WP_REST_Request $request) {
  global $wpdb;
  $MODULE_PHP = "login-endpoints.php"; 
  $module = $MODULE_PHP . ' user_roles_get_by_username_public';

  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $raw_input = file_get_contents('php://input') ?: '';
  vogo_error_log3("START get_roles_public | IP:$ip | Raw:$raw_input", $module);

  try {
    $username = sanitize_text_field($request->get_param('username'));
    if (!$username) {
      vogo_error_log3("Missing 'username' param", $module);
      return new WP_REST_Response([
        'success' => false,
        'error'   => "Parameter 'username' is required."
      ], 400);
    }

    // Caută după login sau email
    $sql_user = $wpdb->prepare(
      "SELECT ID, user_login, user_email FROM {$wpdb->users} WHERE user_login=%s OR user_email=%s LIMIT 1",
      $username, $username
    );
    vogo_error_log3("SQL users: $sql_user", $module);
    $target = $wpdb->get_row($sql_user);

    if (!$target) {
      vogo_error_log3("User not found for: $username", $module);
      return new WP_REST_Response([
        'success' => false,
        'error'   => "User not found for identifier: {$username}"
      ], 404);
    }

    $target_id    = (int)$target->ID;
    $target_login = $target->user_login;
    $target_email = $target->user_email;

    // Citește rolurile din usermeta
    $cap_key = $wpdb->prefix . 'capabilities';
    $sql_caps = $wpdb->prepare(
      "SELECT meta_value FROM {$wpdb->usermeta} WHERE user_id=%d AND meta_key=%s LIMIT 1",
      $target_id, $cap_key
    );
    vogo_error_log3("SQL usermeta: $sql_caps", $module);
    $cap_row = $wpdb->get_var($sql_caps);

    $caps = function_exists('maybe_unserialize') ? maybe_unserialize($cap_row) : @unserialize($cap_row);
    $role_slugs = [];
    if (is_array($caps)) {
      foreach ($caps as $k => $v) { if ($v) { $role_slugs[] = $k; } }
    }

    // Nume frumoase pentru roluri (dacă există registry)
    $role_names = [];
    $roles_registry = function_exists('wp_roles') ? wp_roles() : null;
    if ($roles_registry && is_array($role_slugs)) {
      foreach ($role_slugs as $slug) {
        $role_obj = $roles_registry->roles[$slug] ?? null;
        $role_names[] = is_array($role_obj) && isset($role_obj['name']) ? $role_obj['name'] : $slug;
      }
    } else {
      $role_names = $role_slugs;
    }

    return new WP_REST_Response([
      'success' => true,
      'data' => [
        'queried_username'  => $username,
        'target_user_id'    => $target_id,
        'target_user_login' => $target_login,
        'target_user_email' => $target_email,
        'roles'             => $role_slugs,
        'roles_display'     => $role_names
      ]
    ], 200);

  } catch (Throwable $e) {
    vogo_error_log3("ERROR get_roles_public: ".$e->getMessage(), $module);
    return new WP_REST_Response([
      'success' => false,
      'error'   => "Internal error: ".$e->getMessage()
    ], 500);
  }
}
/* Helper: Haversine distance in meters */
function _haversine_m($lat1,$lon1,$lat2,$lon2){
  $R=6371000;
  $dLat=deg2rad($lat2-$lat1); $dLon=deg2rad($lon2-$lon1);
  $a=sin($dLat/2)**2 + cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLon/2)**2;
  return $R * 2 * asin(min(1,sqrt($a)));
}

/**
 * Check if {lat,long} is farther than 100m from ANY saved user location.
 * Sources: billing/shipping usermeta + custom addresses (wp_user_addresses, status='active').
 * Returns nearest_address {source, address_id, address_code, distance_m}.
 * Bearer+JWT obligatoriu. Log DOAR SQL. module: '<file>.<func>.TEND'
 * Request JSON: { "lat": <num>, "long": <num> }
 */
function location_is_far_away(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP = basename(__FILE__); $module = $MODULE_PHP.'.'.__FUNCTION__;

  // Bearer
  $auth = $request->get_header('authorization');
  if(!$auth || stripos($auth,'Bearer ')!==0){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'Authorization header missing or not Bearer'],401);
  }

  // JWT
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  if (is_wp_error($user_id)) return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>$user_id->get_error_message()],401);
  $user_id = (int)$user_id;

  // Input
  $p = (array)$request->get_json_params();
  if(!isset($p['lat']) || !isset($p['long'])){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'lat and long are required'],400);
  }
  $ref_lat = (float)$p['lat']; $ref_long = (float)$p['long'];
  if(!is_finite($ref_lat) || !is_finite($ref_long)){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'lat/long must be numeric'],400);
  }

  // Collect coordinates with metadata
  $points = [];

  // 1) billing/shipping (include postcode ca address_code; fără id)
  foreach(['billing','shipping'] as $t){
    $lat = get_user_meta($user_id,"{$t}_lat",true);          if($lat==='') $lat = get_user_meta($user_id,"{$t}_latitude",true);
    $lon = get_user_meta($user_id,"{$t}_long",true);         if($lon==='') $lon = get_user_meta($user_id,"{$t}_longitude",true);
    $code= get_user_meta($user_id,"{$t}_postcode",true);     if($code==='') $code = get_user_meta($user_id,"{$t}_address_postal_code",true);
    if($lat!=='' && $lon!==''){
      $latf=(float)$lat; $lonf=(float)$lon;
      if(is_finite($latf) && is_finite($lonf)){
        $points[] = ['source'=>$t,'address_id'=>null,'address_code'=>(string)$code,'lat'=>$latf,'long'=>$lonf];
      }
    }
  }

  // 2) custom addresses din SQL
  $table = $wpdb->prefix.'user_addresses';
  $cols  = $wpdb->get_col("SHOW COLUMNS FROM {$table}",0); if(!is_array($cols)) $cols=[];
  $latExpr  = in_array('lat',$cols,true) ? "lat" : (in_array('latitude',$cols,true) ? "latitude" : "NULL");
  $lonExpr  = in_array('long',$cols,true)? "`long`" : (in_array('longitude',$cols,true)? "longitude" : "NULL");
  $sql = "SELECT id, {$latExpr} AS lat, {$lonExpr} AS `long`, address_code FROM {$table} WHERE user_id=%d AND LOWER(status) IN ('active','default')";
  vogo_error_log3("##############SQL: ".$wpdb->prepare($sql,$user_id));
  $rows = $wpdb->get_results($wpdb->prepare($sql,$user_id), ARRAY_A) ?: [];
  foreach($rows as $r){
    if($r['lat']!==null && $r['long']!==null && $r['lat']!=='' && $r['long']!==''){
      $latf=(float)$r['lat']; $lonf=(float)$r['long'];
      if(is_finite($latf) && is_finite($lonf)){
        $points[] = ['source'=>'custom','address_id'=>(string)$r['id'],'address_code'=>(string)($r['address_code']??''),'lat'=>$latf,'long'=>$lonf];
      }
    }
  }

  if(empty($points)){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.TEND','error'=>'No saved coordinates for this user'],404);
  }

  // Compute nearest
  $min = ['distance_m'=>INF,'idx'=>-1];
  foreach($points as $i=>$pt){
    $d = _haversine_m($ref_lat,$ref_long,$pt['lat'],$pt['long']);
    if($d < $min['distance_m']){ $min=['distance_m'=>$d,'idx'=>$i]; }
  }
  $nearest = ($min['idx']>=0) ? $points[$min['idx']] : null;
  $nearest_distance_m = is_finite($min['distance_m']) ? round($min['distance_m'],2) : null;

  $threshold_m = 100.0;
  $is_far = ($nearest_distance_m===null) ? null : ($nearest_distance_m > $threshold_m);

  return new WP_REST_Response([
    'success'=>true,
    'module'=>$module.'.TEND',
    'user_id'=>$user_id,
    'input'=>['lat'=>(string)$ref_lat,'long'=>(string)$ref_long],
    'nearest_distance_m'=>$nearest_distance_m,
    'threshold_m'=>$threshold_m,
    'locationIsFarAway'=>$is_far,
    'nearest_address'=>$nearest ? [
      'source'=>$nearest['source'],                 // 'custom' | 'billing' | 'shipping'
      'address_id'=>$nearest['address_id'],        // string|null
      'address_code'=>$nearest['address_code']     // string
    ] : null
  ],200);
}

function vogo_get_privacy(WP_REST_Request $request){
  $MODULE_PHP = basename(__FILE__); 
  $module = $MODULE_PHP.'.'.__FUNCTION__;
  $base = rtrim(home_url(), '/');

  // [ADI-ADD] Material Icons map (Flutter: use Icons.<name>)
  $ICONS = [
    'privacy_policy'   => 'privacy_tip',
    'terms'            => 'gavel',
    'cookie_policy'    => 'cookie',
    'cookie_settings'  => 'settings',
    'do_not_sell'      => 'block',
    'do_not_share'     => 'block',
    'limit_sensitive'  => 'shield',
    'request_access'   => 'folder_shared',
    'request_download' => 'download',
    'request_rectify'  => 'edit',
    'request_erase'    => 'delete_forever',
    'request_restrict' => 'pause_circle',
    'request_object'   => 'report',
    'withdraw_consent' => 'undo',
  ];

  // accept both: page or info
  $page = $request->get_param('page');
  if ($page===null) { $page = $request->get_param('info'); }
  if ($page===null) {
    $jp = (array)$request->get_json_params();
    if (isset($jp['page'])) $page = $jp['page'];
    elseif (isset($jp['info'])) $page = $jp['info'];
  }
  $page = sanitize_key((string)$page);

  $MAP = [
    'privacy_policy'=>['Privacy Policy','/privacy-policy/?from_mobile_app=true'],
    'terms'=>['Terms of Service','/terms-2/?from_mobile_app=true'],
    'cookie_policy'=>['Cookie Policy','/cookie_policy/?from_mobile_app=true'],
    'cookie_settings'=>['Cookie Settings','/cookie_policy/?from_mobile_app=true'],
   // 'do_not_sell'=>['Do Not Sell','/privacy-all/?from_mobile_app=true'],
   // 'do_not_share'=>['Do Not Share','/privacy-all/?from_mobile_app=true'],
   // 'limit_sensitive'=>['Limit Sensitive PI','/privacy/privacy-alle'],
    'request_access'=>['Access My Data','/privacy/privacy-all?from_mobile_app=true'],
    'request_download'=>['Download My Data','/privacy/privacy-all?from_mobile_app=true'],
    'request_rectify'=>['Correct My Data','/privacy-all/?from_mobile_app=true'],
    'request_erase'=>['Delete My Data','/privacy-all/?from_mobile_app=true'],
    'request_restrict'=>['Restrict Processing','/privacy/rprivacy-all'],
    'request_object'=>['Object to Processing','/privacy/privacy-all'],
    'withdraw_consent'=>['Withdraw Consent','/privacy-all/?from_mobile_app=true'],
  ];

  if ($page==='') {
    return new WP_REST_Response([
      'success'=>false,'module'=>$module.'.TEND',
      'error'=>'missing param: page|info',
      'allowed'=>array_merge(['list'],array_keys($MAP))
    ],400);
  }

  if ($page==='list') {
    $items=[];
    foreach($MAP as $k=>[$label,$path]){
      $items[]=[
        'key'=>$k,
        'label'=>$label,
        'url'=>$base.$path,
        // [ADI-ADD] icon pentru Flutter (Material Icons)
        'icon'=> $ICONS[$k] ?? 'description'
      ];
    }
    return new WP_REST_Response([
      'success'=>true,'module'=>$module.'.TEND','page'=>'list','items'=>$items
    ],200);
  }

  if (!array_key_exists($page,$MAP)) {
    return new WP_REST_Response([
      'success'=>false,'module'=>$module.'.TEND',
      'error'=>'invalid key','allowed'=>array_merge(['list'],array_keys($MAP))
    ],400);
  }

  [$label,$path] = $MAP[$page];
  return new WP_REST_Response([
    'success'=>true,'module'=>$module.'.TEND',
    'page'=>$page,'label'=>$label,'url'=>$base.$path,
    // [ADI-ADD] icon și pe răspunsul single
    'icon'=> $ICONS[$page] ?? 'description'
  ],200);
}

function vogo_delete_account(WP_REST_Request $request) {
    global $wpdb;
    $MODULE_PHP = basename(__FILE__);
    $module = $MODULE_PHP.'.'.__FUNCTION__;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

    vogo_error_log3("VOGO_LOG_START | MODULE:delete_account | DB:".DB_NAME." | IP:$ip");

    // STEP 1 – JWT
    $user_id = extract_user_from_jwt_token($request);
    if ($user_id instanceof WP_REST_Response) {
        vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0");
        vogo_error_log3("VOGO_LOG_END");
        return $user_id;
    }
    if (is_wp_error($user_id)) {
        vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401);
    }
    $user_id = (int)$user_id;

    vogo_error_log3("[STEP 1] Auth OK | USER:$user_id | IP:$ip");

    // STEP 2 – GET USER
    $user = get_userdata($user_id);
    if (!$user) {
        vogo_error_log3("[STEP 2][ERR] User not found | USER:$user_id | IP:$ip");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'User not found'],404);
    }

    // STEP 3 – Delete avatar
    $img_id = (int)(get_user_meta($user_id,'vogo_profile_image_id',true) ?: 0);
    if ($img_id > 0) {
        require_once ABSPATH.'wp-admin/includes/file.php';
        require_once ABSPATH.'wp-admin/includes/media.php';
        require_once ABSPATH.'wp-admin/includes/image.php';
        wp_delete_attachment($img_id, true);
    }

    delete_user_meta($user_id,'vogo_profile_image_id');
    delete_user_meta($user_id,'vogo_profile_image_url');
    delete_user_meta($user_id,'simple_local_avatar');
    delete_user_meta($user_id,'wp_user_avatar');
    delete_user_meta($user_id,'_wp_attachment_wp_user_avatar');
    delete_user_meta($user_id,'custom_avatar');

    vogo_error_log3("[STEP 3] Avatar removed | USER:$user_id | ATTACH:$img_id");

    // STEP 4 – Delete custom addresses
    $table_addr = $wpdb->prefix."user_addresses";
    if ($wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = %s",
        $table_addr
    ))) {
        $sql_del_addr = $wpdb->prepare("DELETE FROM $table_addr WHERE user_id=%d", $user_id);
        vogo_error_log3("##############SQL: $sql_del_addr");
        $wpdb->query($sql_del_addr);
    }

    // STEP 5 – Delete bank info
    $table_bank = $wpdb->prefix."user_bank_accounts";
    if ($wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = %s",
        $table_bank
    ))) {
        $sql_del_bank = $wpdb->prepare("DELETE FROM $table_bank WHERE user_id=%d", $user_id);
        vogo_error_log3("##############SQL: $sql_del_bank");
        $wpdb->query($sql_del_bank);
    }

    // STEP 6 – Referral cleanup
    $t = $wpdb->prefix.'vogo_user_info';
    $sql_ref = $wpdb->prepare(
        "UPDATE $t SET my_referral_code=NULL, used_refferal_code=NULL, parent_user_id=NULL WHERE user_id=%d",
        $user_id
    );
    vogo_error_log3("##############SQL: $sql_ref");
    $wpdb->query($sql_ref);

    // STEP 7 – Hard delete WordPress user
    require_once ABSPATH.'wp-admin/includes/user.php';
    $deleted = wp_delete_user($user_id, null); // hard-delete all user posts, including Woo orders


    if (!$deleted) {
        vogo_error_log3("[STEP 7][ERR] wp_delete_user failed | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'Account deletion failed'],500);
    }

    vogo_error_log3("[STEP 7] User deleted | USER:$user_id");

    vogo_error_log3("VOGO_LOG_END");

    return new WP_REST_Response([
        'success'=>true,
        'message'=>'Account deleted successfully',
        'user_deleted'=>$user_id,
        'audit'=>[
            'ip'=>$ip,
            'active_db'=>DB_NAME
        ]
    ],200);
}

/**
 * Send an account deletion request email only (no data deletion).
 */
function vogo_delete_account2(WP_REST_Request $request) {
    $MODULE_PHP = basename(__FILE__);
    $module = $MODULE_PHP.'.'.__FUNCTION__;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

    vogo_error_log3("VOGO_LOG_START | MODULE:delete_account2 | DB:".DB_NAME." | IP:$ip");

    // STEP 1 – JWT
    $user_id = extract_user_from_jwt_token($request);
    if ($user_id instanceof WP_REST_Response) {
        vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0");
        vogo_error_log3("VOGO_LOG_END");
        return $user_id;
    }
    if (is_wp_error($user_id)) {
        vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401);
    }
    $user_id = (int)$user_id;
    vogo_error_log3("[STEP 1] Auth OK | USER:$user_id | IP:$ip");

    // STEP 2 – Load user for account name
    $user = get_userdata($user_id);
    if (!$user) {
        vogo_error_log3("[STEP 2][ERR] User not found | USER:$user_id | IP:$ip");
        vogo_error_log3("VOGO_LOG_END");
        return new WP_REST_Response(['success'=>false,'message'=>'User not found'],404);
    }
    $account_name = $user->user_login;
    vogo_error_log3("[STEP 2] User loaded | USER:$user_id | ACCOUNT:$account_name");

    // STEP 3 – Send deletion request email
    $to = 'info@vogo.family';
    $subject = 'VOGO account deletion request';
    $message = 'solicitare stergere cont ...'.$account_name;
    $sent = wp_mail($to, $subject, $message);
    vogo_error_log3("[STEP 3] Email sent status: ".($sent ? 'true' : 'false')." | TO:$to | USER:$user_id");

    vogo_error_log3("VOGO_LOG_END");

    if (!$sent) {
        return new WP_REST_Response(['success'=>false,'message'=>'Email send failed'],500);
    }

    return new WP_REST_Response([
        'success'=>true,
        'message'=>'Deletion request email sent',
        'user_id'=>$user_id
    ],200);
}
