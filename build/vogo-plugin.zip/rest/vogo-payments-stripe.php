<?php
/* ================================================
vogo-payments-stripe.php
 * [ADI-ADD] VOGO Payments: create-payment-intent (Stripe)
 * Requirements:
 * - Define STRIPE_SECRET_KEY in wp-config.php (live/test)
 * - Stripe PHP SDK loaded (Composer autoload or plugin)
 * Compliance: POST only, vogo_permission_check, JWT user via extract_user_from_jwt_token()
 * Output: paymentIntentClientSecret, customerEphemeralKeySecret, user_id, user_login
 * 
 * doar ce ține de WooPayments/Stripe în afara CRUD token (ex. webhook Stripe dacă îl folosești, sau utilitare specifice).
 * 
 * 
 * ================================================ */


add_action('rest_api_init', function () {

  // 2025.10.31 update as stripe model with ABi

    register_rest_route('vogo/v1/payment/stripe', '/create_stripe_payment_intent', [    
    'methods' => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'create_stripe_payment_intent', // same name requested
  ]);

    register_rest_route('vogo/v1/payment/stripe', '/saved_cards', [        
    'methods' => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'stripe_saved_cards_list',
  ]);

  register_rest_route('vogo/v1/payment/stripe','/delete_card',[
    'methods'=>'POST',
    'permission_callback'=>'vogo_permission_check',
    'callback'=>'stripe_delete_card',
  ]);  


  // end 2025.10.31 update as stripe model with ABi



  register_rest_route('vogo/v1', '/payment/stripe/create-payment-intent', [
    'methods'  => 'POST', // Adi rule: POST only
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'create_payment_intent',
  ]);

 register_rest_route('vogo/v1/payment/stripe', '/paymentsheet-bootstrap', [
    'methods' => 'POST', 'permission_callback' => 'vogo_permission_check', 'callback' => 'stripe_paymentsheet_bootstrap',
  ]);
  register_rest_route('vogo/v1/payment/stripe', '/ephemeral-key', [
    'methods' => 'POST', 'permission_callback' => 'vogo_permission_check', 'callback' => 'stripe_ephemeral_key',
  ]);
  register_rest_route('vogo/v1/payment/stripe', '/create-setup-intent', [
    'methods' => 'POST', 'permission_callback' => 'vogo_permission_check', 'callback' => 'stripe_create_setup_intent',
  ]);
  // Webhook: no JWT; verify via Stripe-Signature header
  register_rest_route('vogo/v1/payment/stripe', '/webhook', [
    'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => 'stripe_webhook_handler',
  ]);  
});

/**
 * [ADI-ADD] Create Stripe PaymentIntent + Ephemeral Key
 * Security: JWT user required. Validates amount/currency. Uses per-user Stripe Customer (creates if missing).
 * Performance: avoids redundant Stripe calls; caches customer id in user meta.
 */
function create_payment_intent(WP_REST_Request $request){
  global $wpdb; $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  try{
    /* ---------- LOG START ---------- */
    vogo_error_log3("VOGO_LOG_START | create_payment_intent | DB=".DB_NAME." | IP=$ip | USER=?");
    vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params()));

    /* STEP 1: Auth — extract current user from JWT */
    $user_or_response = extract_user_from_jwt_token($request);
    if ($user_or_response instanceof WP_REST_Response) { return $user_or_response; }
    $user_id = intval($user_or_response);
    $user    = get_user_by('id', $user_id);
    $user_login = $user ? $user->user_login : 'unknown';
    vogo_error_log3("[STEP 1] Auth OK | user_id=$user_id | user_login=$user_login | IP=$ip");

    /* STEP 2: Validate input */
    $params   = $request->get_json_params();
    $amount   = isset($params['amount']) ? intval($params['amount']) : 0;        // in minor units
    $currency = isset($params['currency']) ? strtolower(sanitize_text_field($params['currency'])) : '';
    if ($amount <= 0) return new WP_REST_Response(['success'=>false,'error'=>'Invalid amount','user_id'=>$user_id,'user_login'=>$user_login], 400);
    if (!preg_match('/^[a-z]{3}$/',$currency)) return new WP_REST_Response(['success'=>false,'error'=>'Invalid currency','user_id'=>$user_id,'user_login'=>$user_login], 400);

    // Optional: basic allowlist; extend as needed
    $allowed = ['usd','eur','ron','gbp'];
    if (!in_array($currency,$allowed,true)) return new WP_REST_Response(['success'=>false,'error'=>'Unsupported currency','user_id'=>$user_id,'user_login'=>$user_login], 400);
    vogo_error_log3("[STEP 2] Input OK | amount=$amount | currency=$currency | IP=$ip | USER=$user_id");

    /* STEP 3: Init Stripe */
    if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
      return new WP_REST_Response(['success'=>false,'error'=>'Stripe secret key not configured','user_id'=>$user_id,'user_login'=>$user_login], 500);
    }
    if (!class_exists(\Stripe\Stripe::class)) {
      return new WP_REST_Response(['success'=>false,'error'=>'Stripe SDK missing','user_id'=>$user_id,'user_login'=>$user_login], 500);
    }
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    // Optional telemetry off
    \Stripe\Stripe::setAppInfo('vogo.family', '1.0.0', 'https://vogo.family');

    /* STEP 4: Ensure Stripe Customer for this user */
    $meta_key = '_stripe_customer_id';
    $customer_id = get_user_meta($user_id, $meta_key, true);
    if (!$customer_id) {
      vogo_error_log3("[STEP 4.1] Creating Stripe Customer | USER=$user_id | IP=$ip");
      $customer = \Stripe\Customer::create([
        'metadata' => ['wp_user_id'=>$user_id,'wp_user_login'=>$user_login],
        'email'    => $user ? $user->user_email : null,
        'name'     => $user_login,
      ]);
      $customer_id = $customer->id;
      update_user_meta($user_id, $meta_key, $customer_id);
      vogo_error_log3("[STEP 4.2] Customer created | id=$customer_id | USER=$user_id");
    } else {
      vogo_error_log3("[STEP 4] Reusing Stripe Customer | id=$customer_id | USER=$user_id");
    }

    /* STEP 5: Create PaymentIntent */
    $pi_params = [
      'amount'   => $amount,
      'currency' => $currency,
      'customer' => $customer_id,
      'automatic_payment_methods' => ['enabled'=>true], // Cards, wallets, etc.
      // Optional: attach order context
      'metadata' => [
        'wp_user_id'   => $user_id,
        'wp_user_login'=> $user_login,
        'site'         => home_url(),
      ],
    ];
    vogo_error_log3("##############SQL: N/A (Stripe create PI) | ".json_encode($pi_params)); // per Adi rule: log executed ops
    $payment_intent = \Stripe\PaymentIntent::create($pi_params);
    $client_secret  = $payment_intent->client_secret;
    vogo_error_log3("[STEP 5] PaymentIntent created | id={$payment_intent->id} | USER=$user_id");

    /* STEP 6: Create Ephemeral Key for Mobile SDKs */
    // Stripe requires explicit API version for EphemeralKey
    $stripe_api_version = '2024-06-20';
    $ek = \Stripe\EphemeralKey::create(['customer'=>$customer_id], ['stripe_version'=>$stripe_api_version]);
    $ek_secret = $ek->secret;
    vogo_error_log3("[STEP 6] EphemeralKey created | USER=$user_id");

    /* STEP 7: Response */
    $resp = [
      'success'                       => true,
      'paymentIntentClientSecret'     => $client_secret,
      'customerEphemeralKeySecret'    => $ek_secret,
      'user_id'                       => $user_id,
      'user_login'                    => $user_login,
    ];
    vogo_error_log3("VOGO_LOG_END | create_payment_intent | USER=$user_id | IP=$ip");
    return new WP_REST_Response($resp, 200);

  } catch (\Stripe\Exception\ApiErrorException $e){
    vogo_error_log3("[ERROR] Stripe API | ".$e->getMessage()." | USER=? | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Stripe API error','detail'=>$e->getMessage()], 502);
  } catch (\Throwable $e){
    vogo_error_log3("[ERROR] General | ".$e->getMessage()." | USER=? | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Server error','detail'=>$e->getMessage()], 500);
  }
}

/* ---------- Helpers ---------- */
function stripe_assert_sdk_and_keys(){
  if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) throw new Exception('Stripe secret key not configured');
  if (!class_exists(\Stripe\Stripe::class)) throw new Exception('Stripe SDK missing');
  \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
  \Stripe\Stripe::setAppInfo('vogo.family','1.0.0',home_url());
}

function stripe_ensure_customer($user_id, $user_login, $email=null){
  $key='_stripe_customer_id'; $cid=get_user_meta($user_id,$key,true);
  if($cid) return $cid;
  $c=\Stripe\Customer::create(['metadata'=>['wp_user_id'=>$user_id,'wp_user_login'=>$user_login],'email'=>$email,'name'=>$user_login]);
  update_user_meta($user_id,$key,$c->id); return $c->id;
}

function stripe_min_amount_for_currency($currency){
  // minor units
  $map=['usd'=>50,'eur'=>50,'gbp'=>30,'ron'=>200,'pln'=>200,'huf'=>175,'czk'=>150];
  return $map[$currency] ?? 0;
}

/* ---------- 1) PaymentSheet bootstrap ---------- */
function stripe_paymentsheet_bootstrap(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | paymentsheet-bootstrap | ACTIVE DB: ".DB_NAME." | IP=$ip");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params()));
  try{
    // Auth
    $u=extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id=intval($u); $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
    vogo_error_log3("[STEP 1] Auth OK | user_id=$user_id | user_login=$user_login | IP=$ip");

    // Input
    $p=$request->get_json_params(); $amount=intval($p['amount']??0); $currency=strtolower(sanitize_text_field($p['currency']??''));
    if(!preg_match('/^[a-z]{3}$/',$currency)) return new WP_REST_Response(['success'=>false,'error'=>'Invalid currency','user_id'=>$user_id,'user_login'=>$user_login],400);
    $min=stripe_min_amount_for_currency($currency); if($amount<$min) $amount=$min; // auto-bump to min
    if($amount<=0) return new WP_REST_Response(['success'=>false,'error'=>'Invalid amount','user_id'=>$user_id,'user_login'=>$user_login],400);
    vogo_error_log3("[STEP 2] Input OK | amount=$amount | currency=$currency | USER=$user_id | IP=$ip");

    // Stripe init + customer
    stripe_assert_sdk_and_keys(); $email=$user?$user->user_email:null;
    $customer_id=stripe_ensure_customer($user_id,$user_login,$email);
    vogo_error_log3("[STEP 3] Customer OK | customer_id=$customer_id | USER=$user_id");

    // Create PaymentIntent
    $pi_params=['amount'=>$amount,'currency'=>$currency,'customer'=>$customer_id,'automatic_payment_methods'=>['enabled'=>true],
      'metadata'=>['wp_user_id'=>$user_id,'wp_user_login'=>$user_login,'site'=>home_url()]];
    vogo_error_log3("##############SQL: N/A (Stripe PI create) | ".json_encode($pi_params));
    $pi=\Stripe\PaymentIntent::create($pi_params);
    vogo_error_log3("[STEP 4] PaymentIntent created | id={$pi->id} | USER=$user_id");

    // Create Ephemeral Key
    $ek=\Stripe\EphemeralKey::create(['customer'=>$customer_id],['stripe_version'=>'2024-06-20']);
    vogo_error_log3("[STEP 5] EphemeralKey created | USER=$user_id");

    $resp=['success'=>true,
      'publishableKey'=>defined('STRIPE_PUBLISHABLE_KEY')?STRIPE_PUBLISHABLE_KEY:null,
      'customerId'=>$customer_id,
      'customerEphemeralKeySecret'=>$ek->secret,
      'paymentIntentClientSecret'=>$pi->client_secret,
      'amount'=>$amount,'currency'=>$currency,
      'user_id'=>$user_id,'user_login'=>$user_login];
    vogo_error_log3("VOGO_LOG_END | paymentsheet-bootstrap | USER=$user_id | IP=$ip");
    return new WP_REST_Response($resp,200);
  }catch(\Stripe\Exception\ApiErrorException $e){
    vogo_error_log3("[ERROR] Stripe API | ".$e->getMessage()." | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Stripe API error','detail'=>$e->getMessage()],502);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] General | ".$e->getMessage()." | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Server error','detail'=>$e->getMessage()],500);
  }
}

/* ---------- 2) Ephemeral Key refresh ---------- */
function stripe_ephemeral_key(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | ephemeral-key | ACTIVE DB: ".DB_NAME." | IP=$ip");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params()));
  try{
    $u=extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id=intval($u); $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
    stripe_assert_sdk_and_keys(); $customer_id=stripe_ensure_customer($user_id,$user_login,$user?$user->user_email:null);
    $ek=\Stripe\EphemeralKey::create(['customer'=>$customer_id],['stripe_version'=>'2024-06-20']);
    vogo_error_log3("[STEP 1] EK created | USER=$user_id | customer_id=$customer_id");
    vogo_error_log3("VOGO_LOG_END | ephemeral-key | USER=$user_id | IP=$ip");
    return new WP_REST_Response(['success'=>true,'customerId'=>$customer_id,'customerEphemeralKeySecret'=>$ek->secret,'user_id'=>$user_id,'user_login'=>$user_login],200);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] EK | ".$e->getMessage()." | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Server error','detail'=>$e->getMessage()],500);
  }
}

/* ---------- 3) Create SetupIntent (save card) ---------- */
function stripe_create_setup_intent(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | create-setup-intent | ACTIVE DB: ".DB_NAME." | IP=$ip");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params()));
  try{
    $u=extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id=intval($u); $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
    stripe_assert_sdk_and_keys(); $customer_id=stripe_ensure_customer($user_id,$user_login,$user?$user->user_email:null);
    $si=\Stripe\SetupIntent::create(['customer'=>$customer_id,'automatic_payment_methods'=>['enabled'=>true],
      'metadata'=>['wp_user_id'=>$user_id,'wp_user_login'=>$user_login]]);
    vogo_error_log3("[STEP 1] SetupIntent created | id={$si->id} | USER=$user_id");
    vogo_error_log3("VOGO_LOG_END | create-setup-intent | USER=$user_id | IP=$ip");
    return new WP_REST_Response(['success'=>true,'setupIntentClientSecret'=>$si->client_secret,'customerId'=>$customer_id,'user_id'=>$user_id,'user_login'=>$user_login],200);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] SetupIntent | ".$e->getMessage()." | IP=$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'Server error','detail'=>$e->getMessage()],500);
  }
}

/* ---------- 4) Webhook (Stripe -> server) ---------- */
function stripe_webhook_handler(WP_REST_Request $request){
  $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | webhook | ACTIVE DB: ".DB_NAME." | IP=$ip");
  $payload=$request->get_body(); $sig=$_SERVER['HTTP_STRIPE_SIGNATURE']??'';
  try{
    if(!defined('STRIPE_WEBHOOK_SECRET')||empty(STRIPE_WEBHOOK_SECRET)) throw new Exception('Webhook secret not configured');
    if(!class_exists(\Stripe\Webhook::class)) throw new Exception('Stripe SDK missing');
    $event=\Stripe\Webhook::constructEvent($payload,$sig,STRIPE_WEBHOOK_SECRET);
    $type=$event['type']??'unknown';
    vogo_error_log3("[STEP 1] Webhook received | type=$type");

    switch($type){
      case 'payment_intent.succeeded':
        $pi=$event['data']['object']; $pi_id=$pi['id']; $cust=$pi['customer']??null;
        // TODO: mark order paid by metadata/order mapping
        vogo_error_log3("[STEP 2] PI succeeded | id=$pi_id | customer=$cust");
        break;
      case 'payment_intent.payment_failed':
        $pi=$event['data']['object']; vogo_error_log3("[STEP 2] PI failed | id={$pi['id']} | reason=".($pi['last_payment_error']['message']??'n/a'));
        break;
      case 'setup_intent.succeeded':
        $si=$event['data']['object']; vogo_error_log3("[STEP 2] SI succeeded | id={$si['id']} | customer={$si['customer']}");
        break;
      case 'charge.refunded':
      case 'refund.created':
        $o=$event['data']['object']; vogo_error_log3("[STEP 2] Refund event | id=".($o['id']??'n/a'));
        break;
      default:
        vogo_error_log3("[STEP 2] Ignored event | $type");
    }
    vogo_error_log3("VOGO_LOG_END | webhook | 200 OK");
    return new WP_REST_Response(['received'=>true],200);
  }catch(\UnexpectedValueException $e){
    vogo_error_log3("[ERROR] Webhook JSON invalid | ".$e->getMessage()." | IP=$ip"); return new WP_REST_Response(null,400);
  }catch(\Stripe\Exception\SignatureVerificationException $e){
    vogo_error_log3("[ERROR] Webhook signature verify failed | ".$e->getMessage()." | IP=$ip"); return new WP_REST_Response(null,400);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] Webhook general | ".$e->getMessage()." | IP=$ip"); return new WP_REST_Response(null,500);
  }
}



  // 2025.10.31 update as stripe model with ABi

function create_stripe_payment_intent(WP_REST_Request $request){
  $ip=$_SERVER['REMOTE_ADDR']??'0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | create_stripe_payment_intent | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
  $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($p)." | IP:$ip");

  try{
    // Auth
    $u=extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id=intval($u); $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
    vogo_error_log3("[STEP 1] Auth OK | user_id=$user_id | user_login=$user_login | IP:$ip");

    // Stripe init + customer
    stripe_assert_sdk_and_keys(); $email=$user?$user->user_email:null;
    $customer_id=stripe_ensure_customer($user_id,$user_login,$email);
    vogo_error_log3("[STEP 2] Customer OK | customer_id=$customer_id | USER:$user_id | IP:$ip");

    $type=strtolower(sanitize_text_field($p['type']??'create_intent'));

    if($type==='create_intent'){
      // Create SetupIntent for saving a card
        // [ADI-ADD] REPLACE params for SetupIntent create
        $params = [
          'customer' => $customer_id,
          'usage' => 'off_session',
          // explicit for mobile SDKs:
          'payment_method_types' => ['card'],
          // nu combina cu automatic_payment_methods aici
          'metadata' => [
            'wp_user_id' => $user_id,
            'wp_user_login' => $user_login,
            'site' => home_url()
          ]
        ];
        vogo_error_log3("##############SQL: N/A (Stripe SetupIntent create) | ".json_encode($params)." | USER:$user_id");
        $si = \Stripe\SetupIntent::create($params);

      vogo_error_log3("[STEP 3] SetupIntent created | id={$si->id} | USER:$user_id");

      $resp=[
        'success'=>true,
        // alias cerut de Flutter:
        'client_secret'=>$si->client_secret,
        // păstrăm și cheie explicită:
        'setupIntentClientSecret'=>$si->client_secret,
        'setup_intent_id'=>$si->id,
        'publishableKey'=>defined('STRIPE_PUBLISHABLE_KEY')?STRIPE_PUBLISHABLE_KEY:null,
        'customerId'=>$customer_id,
        'user_id'=>$user_id,'user_login'=>$user_login
      ];
      vogo_error_log3("VOGO_LOG_END | create_stripe_payment_intent (create_intent) | USER:$user_id | IP:$ip");
      return new WP_REST_Response($resp,200);
    }

    if($type==='save_intent'){
      $intent_id=sanitize_text_field($p['intent_id']??'');
      if(!preg_match('/^seti_[A-Za-z0-9]+$/',$intent_id)){
        return new WP_REST_Response(['success'=>false,'error'=>'invalid_intent_id','user_id'=>$user_id,'user_login'=>$user_login],400);
      }
      vogo_error_log3("[STEP 3] Retrieve SetupIntent | id=$intent_id | USER:$user_id");
      $si=\Stripe\SetupIntent::retrieve($intent_id);

      // Validate ownership
      if(!empty($si->customer) && $si->customer!==$customer_id){
        vogo_error_log3("[ERROR] Customer mismatch | si.customer={$si->customer} | expected=$customer_id | USER:$user_id | IP:$ip");
        return new WP_REST_Response(['success'=>false,'error'=>'customer_mismatch','user_id'=>$user_id,'user_login'=>$user_login],403);
      }

      // Status must be succeeded after client confirmation
      if($si->status!=='succeeded'){
          $last = $si->last_setup_error;
          $detail = $last ? ['code'=>$last->code ?? null, 'message'=>$last->message ?? null, 'type'=>$last->type ?? null] : null;
          return new WP_REST_Response([
            'success'=>false,
            'error'=>'intent_not_succeeded',
            'status'=>$si->status,
            'last_setup_error'=>$detail,
            'user_id'=>$user_id,'user_login'=>$user_login
          ], 409);
      }

      // Extract payment_method and attach to customer if needed
      $pm_id=$si->payment_method ?? null;
      if(!$pm_id){
        vogo_error_log3("[ERROR] No payment_method on SetupIntent | id=$intent_id | USER:$user_id | IP:$ip");
        return new WP_REST_Response(['success'=>false,'error'=>'no_payment_method','user_id'=>$user_id,'user_login'=>$user_login],422);
      }

      try{
        vogo_error_log3("[STEP 4] Attach PM to customer | pm=$pm_id | customer=$customer_id | USER:$user_id");
        $pm=\Stripe\PaymentMethod::retrieve($pm_id);
        // If not attached, attach
        if(empty($pm->customer)){
          $pm->attach(['customer'=>$customer_id]);
        }
      }catch(\Throwable $e){
        // If already attached, continue
        vogo_error_log3("[WARN] PM attach skipped | ".$e->getMessage()." | USER:$user_id | IP:$ip");
      }

      // Optionally set as default
      try{
        \Stripe\Customer::update($customer_id,['invoice_settings'=>['default_payment_method'=>$pm_id]]);
      }catch(\Throwable $e){
        vogo_error_log3("[WARN] Set default PM failed | ".$e->getMessage()." | USER:$user_id | IP:$ip");
      }

      // Persist locally ca fallback simplu
      update_user_meta($user_id,'_stripe_default_pm',$pm_id);

      $resp=['success'=>true,'payment_method'=>$pm_id,'setup_intent_id'=>$intent_id,'customerId'=>$customer_id,'user_id'=>$user_id,'user_login'=>$user_login];
      vogo_error_log3("VOGO_LOG_END | create_stripe_payment_intent (save_intent) | USER:$user_id | IP:$ip");
      return new WP_REST_Response($resp,200);
    }

    // Unsupported type
    return new WP_REST_Response(['success'=>false,'error'=>'unsupported_type','type'=>$type,'user_id'=>$user_id,'user_login'=>$user_login],400);

  }catch(\Stripe\Exception\ApiErrorException $e){
    vogo_error_log3("[ERROR] Stripe API | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'stripe_api_error','detail'=>$e->getMessage()],502);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] General | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'server_error','detail'=>$e->getMessage()],500);
  }
}


// [ADI-ADD] saved_cards: include customer_id + customerId
function stripe_saved_cards_list(WP_REST_Request $request){
  $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | saved_cards | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params())." | IP:$ip");
  try{
    // Auth
    $u = extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id = (int)$u; $user = get_user_by('id',$user_id); $user_login = $user ? $user->user_login : 'unknown';
    vogo_error_log3("[STEP 1] Auth OK | user_id=$user_id | user_login=$user_login | IP:$ip");

    // Stripe init + customer
    stripe_assert_sdk_and_keys();
    $customer_id = stripe_ensure_customer($user_id,$user_login,$user?$user->user_email:null);
    vogo_error_log3("[STEP 2] Customer OK | customer_id=$customer_id | USER:$user_id");

    // Default PM
    $cust = \Stripe\Customer::retrieve($customer_id);
    $default_pm = $cust->invoice_settings->default_payment_method ?? null;

    // List cards
    $list = \Stripe\PaymentMethod::all(['customer'=>$customer_id,'type'=>'card','limit'=>20]);
    $cards = [];
    foreach($list->data as $pm){
      $c = $pm->card ?? null; if(!$c) continue;
      $cards[] = [
        'id'=>$pm->id,'brand'=>$c->brand,'last4'=>$c->last4,
        'exp_month'=>(int)$c->exp_month,'exp_year'=>(int)$c->exp_year,
        'funding'=>$c->funding,'is_default'=>($pm->id===$default_pm),
      ];
    }
    vogo_error_log3("[STEP 3] Cards listed | count=".count($cards)." | USER:$user_id | IP:$ip");

    $resp = [
      'success'=>true,
      'customer_id'=>$customer_id,        // requested
      'customerId'=>$customer_id,         // camelCase alias
      'default_payment_method'=>$default_pm,
      'cards'=>$cards,
      'user_id'=>$user_id,'user_login'=>$user_login,
    ];
    vogo_error_log3("VOGO_LOG_END | saved_cards | USER:$user_id | IP:$ip");
    return new WP_REST_Response($resp,200);

  }catch(\Stripe\Exception\ApiErrorException $e){
    vogo_error_log3("[ERROR] Stripe API | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'stripe_api_error','detail'=>$e->getMessage()],502);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] General | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'server_error','detail'=>$e->getMessage()],500);
  }
}


function stripe_delete_card(WP_REST_Request $request){
  $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
  vogo_error_log3("VOGO_LOG_START | delete_card | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($request->get_json_params())." | IP:$ip");

  try{
    // Auth
    $u = extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
    $user_id=(int)$u; $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
    vogo_error_log3("[STEP 1] Auth OK | user_id=$user_id | user_login=$user_login | IP:$ip");

    // Input
    $p=$request->get_json_params();
    $pm_id=sanitize_text_field($p['payment_method_id']??'');
    if(!preg_match('/^pm_[A-Za-z0-9]+$/',$pm_id)){
      return new WP_REST_Response(['success'=>false,'error'=>'invalid_payment_method_id','user_id'=>$user_id,'user_login'=>$user_login],400);
    }

    // Stripe init + customer
    stripe_assert_sdk_and_keys();
    $customer_id=stripe_ensure_customer($user_id,$user_login,$user?$user->user_email:null);
    vogo_error_log3("[STEP 2] Customer OK | customer_id=$customer_id | USER:$user_id");

    // Retrieve PM and validate ownership
    $pm=\Stripe\PaymentMethod::retrieve($pm_id);
    if(!empty($pm->customer) && $pm->customer!==$customer_id){
      vogo_error_log3("[ERROR] Customer mismatch | pm.customer={$pm->customer} | expected=$customer_id | USER:$user_id | IP:$ip");
      return new WP_REST_Response(['success'=>false,'error'=>'customer_mismatch','user_id'=>$user_id,'user_login'=>$user_login],403);
    }

    // Detach PM
    $pm->detach();
    vogo_error_log3("[STEP 3] PaymentMethod detached | id=$pm_id | USER:$user_id | IP:$ip");

    // Remove from default if needed
    $cust=\Stripe\Customer::retrieve($customer_id);
    if($cust->invoice_settings->default_payment_method===$pm_id){
      \Stripe\Customer::update($customer_id,['invoice_settings'=>['default_payment_method'=>null]]);
      vogo_error_log3("[STEP 4] Cleared default PM | USER:$user_id | IP:$ip");
    }

    // Local cleanup
    $local_default=get_user_meta($user_id,'_stripe_default_pm',true);
    if($local_default===$pm_id) delete_user_meta($user_id,'_stripe_default_pm');

    $resp=[
      'success'=>true,
      'payment_method_id'=>$pm_id,
      'customer_id'=>$customer_id,
      'user_id'=>$user_id,
      'user_login'=>$user_login,
    ];
    vogo_error_log3("VOGO_LOG_END | delete_card | USER:$user_id | IP:$ip");
    return new WP_REST_Response($resp,200);

  }catch(\Stripe\Exception\ApiErrorException $e){
    vogo_error_log3("[ERROR] Stripe API | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'stripe_api_error','detail'=>$e->getMessage()],502);
  }catch(\Throwable $e){
    vogo_error_log3("[ERROR] General | ".$e->getMessage()." | IP:$ip");
    return new WP_REST_Response(['success'=>false,'error'=>'server_error','detail'=>$e->getMessage()],500);
  }
}