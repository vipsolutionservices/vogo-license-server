<?php
$MODULE_PHP='all-social.php';
/**
 * VOGO API Endpoint Registration
 * All routes use standard JWT security check: vogo_permission_check
 * Adi-tehnic: clean, organized, secure, ergonomic structure.
 * // OLD
 */

use Twilio\Rest\Client;

add_action('rest_api_init', function () {

    // Social Login & Password
    register_rest_route('vogo/v1', '/Social_login', [
        'methods'             => 'POST',
        'callback'            => 'custom_social_login_register',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/change-password', [
        'methods'             => 'POST',
        'callback'            => 'custom_change_password',
        'permission_callback' => 'vogo_permission_check',
    ]);

});

/**
 * Register or login a user via social login (Google/Facebook/Apple)
 *
 * @return array JSON response
 */
function custom_social_login_register() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $social_id     = sanitize_text_field($data['social_id'] ?? '');
    $social_type   = sanitize_text_field($data['social_type'] ?? '');
    $user_email    = sanitize_email($data['user_email'] ?? '');
    $device_token  = sanitize_text_field($data['device_token'] ?? '');

    vogo_error_log2("STEP 1: Received social login request | social_id: {$social_id}");

    $response = [
        'status'  => false,
        'code'    => 400,
        'message' => 'Something went wrong.',
    ];

    if (empty($social_id)) {
        $response['message'] = 'Missing social ID.';
        vogo_error_log2("STEP 2: Social ID is missing.");
        return $response;
    }

    // Generate a unique username and fallback email if not provided
    $username = 'user_' . wp_generate_uuid4();
    if (empty($user_email)) {
        $user_email = sanitize_email($username . '@vogo.com');
    }

    vogo_error_log2("STEP 3: Generated username: {$username}, email: {$user_email}");

    // Try to find user by social ID
    $users_by_social = get_users([
        'meta_key'   => 'social_id',
        'meta_value' => $social_id
    ]);

    if (!empty($users_by_social)) {
        $user = $users_by_social[0];
        vogo_error_log2("STEP 4: User found by social ID.");
    } else {
        $user = get_user_by('email', $user_email);
        if ($user) {
            vogo_error_log2("STEP 4: User found by email.");
        }
    }

    // If no user found, register a new one
    if (!$user) {
        $random_password = wp_generate_password();
        $user_id = wp_create_user($username, $random_password, $user_email);

        if (is_wp_error($user_id)) {
            $response['message'] = 'User registration failed.';
            $response['code']    = 500;
            $response['error']   = $user_id->get_error_message();
            vogo_error_log2("STEP 5: User creation failed - " . $user_id->get_error_message());
            return $response;
        }

        update_user_meta($user_id, 'social_id', $social_id);
        update_user_meta($user_id, 'social_type', $social_type);
        update_user_meta($user_id, 'device_token', $device_token);

        $user = get_user_by('ID', $user_id);
        vogo_error_log2("STEP 5: New user created with ID {$user_id}");
    }

    // Prepare response
    $response['status']                = true;
    $response['code']                  = 200;
    $response['message']               = 'User login successfully.';
    $response['data']['token']        = (string) $user->ID;
    $response['data']['user_id']      = (string) $user->ID;
    $response['data']['user_name']    = $user->user_login;
    $response['data']['email']        = $user->user_email;
    $response['data']['name']         = $user->display_name;
    $response['data']['social_type']  = get_user_meta($user->ID, 'social_type', true);
    $response['data']['social_id']    = get_user_meta($user->ID, 'social_id', true);

    vogo_error_log2("STEP 6: User login/registration completed.");

    return $response;
}


/**
 * Change WooCommerce user password
 *
 * @return array JSON response
 */
function custom_change_password() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id          = isset($data['access_token']) ? intval($data['access_token']) : 0;
    $current_password = sanitize_text_field($data['current_password'] ?? '');
    $new_password     = sanitize_text_field($data['new_password'] ?? '');

    vogo_error_log2("STEP 1: Received password change request | user_id: {$user_id}");

    $response = [
        'status'  => false,
        'code'    => 400,
        'message' => 'Something went wrong.'
    ];

    if ($user_id <= 0) {
        $response['message'] = 'Invalid user ID.';
        vogo_error_log2("STEP 2: Missing or invalid user_id.");
        return $response;
    }

    if (empty($current_password) || empty($new_password)) {
        $response['message'] = 'Both current and new passwords are required.';
        vogo_error_log2("STEP 3: Missing password fields.");
        return $response;
    }

    $user = get_user_by('id', $user_id);
    if (!$user instanceof WP_User) {
        $response['message'] = 'User not found.';
        vogo_error_log2("STEP 4: User not found.");
        return $response;
    }

    // STEP 5: Try to authenticate with current password
    $creds = [
        'user_login'    => trim($user->user_login),
        'user_password' => $current_password,
    ];

    $user_old = wp_signon(apply_filters('woocommerce_login_credentials', $creds), is_ssl());

    if (is_wp_error($user_old)) {
        $response['message'] = 'Invalid current password.';
        vogo_error_log2("STEP 5: Authentication failed.");
        return $response;
    }

    // STEP 6: Change password
    wp_set_password($new_password, $user_id);
    vogo_error_log2("STEP 6: Password updated for user_id: {$user_id}");

    $response['status']  = true;
    $response['code']    = 200;
    $response['message'] = 'Password updated successfully.';
    return $response;
}

