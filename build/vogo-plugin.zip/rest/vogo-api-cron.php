<?php
// [ADI-ADD] Cron + REST: auto-geocode pending orders every minute and mark calculated_fields=2
add_filter('cron_schedules',fn($s)=>$s+['minute'=>['interval'=>60,'display'=>'Every Minute']]);
if(!wp_next_scheduled('vogo_orders_geocode_cron')) wp_schedule_event(time()+60,'minute','vogo_orders_geocode_cron');
add_action('vogo_orders_geocode_cron','vogo_orders_geocode_worker');


// REST-urile
add_action('rest_api_init',function(){
  register_rest_route('vogo/v1/map','/run_geocode_cron',[
    'methods'=>'GET',
    'permission_callback'=>'vogo_permission_check',
    'callback'=>'vogo_orders_geocode_worker_rest'
  ]);
});

// definitia functiilor
function vogo_orders_geocode_worker($limit=25){
  global $wpdb;
  $table=$wpdb->prefix.'orders';
  $ip=$_SERVER['REMOTE_ADDR']??'CRON'; $db=DB_NAME;
  vogo_error_log3("SCHEDULER - vogo_orders_geocode_worker | ACTIVE DB: $db | IP:$ip | FN:vogo_orders_geocode_worker");

  $ids=$wpdb->get_col($wpdb->prepare(
    "SELECT id FROM {$table} WHERE end_lat IS NULL AND calculated_fields=1 and address_end is not null ORDER BY id ASC LIMIT %d",
    (int)$limit
  ));
  vogo_error_log3("[STEP 1] Found ".count($ids)." pending orders | IP:$ip");
  if(empty($ids)){ vogo_error_log3("VOGO_LOG_END | No pending orders | IP:$ip"); return; }

  foreach($ids as $oid){
    $oid=(int)$oid;
    vogo_error_log3("[STEP 2] Geocoding order_id=$oid | IP:$ip");
    vogo_order_set_latlong($oid);
    $wpdb->query($wpdb->prepare("UPDATE {$table} SET calculated_fields=2 WHERE id=%d",$oid));
  }

  vogo_error_log3("[STEP 3] Batch completed=".count($ids)." | IP:$ip");
  vogo_error_log3("VOGO_LOG_END");
}

function vogo_orders_geocode_worker_rest(WP_REST_Request $r){
  $limit=(int)($r->get_param('limit')?:25);
  vogo_orders_geocode_worker($limit);
  return new WP_REST_Response(['success'=>true,'limit'=>$limit],200);
}
