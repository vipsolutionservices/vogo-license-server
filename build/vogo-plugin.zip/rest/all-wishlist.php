<?php
/**
 * VOGO API Endpoint Registration
 * All routes use standard JWT security check: vogo_permission_check
 * Adi-tehnic: clean, organized, secure, ergonomic structure.
 */

//use Twilio\Rest\Client;

add_action('rest_api_init', function () {

    // Wishlist Endpoints
    register_rest_route('vogo/v1', '/add-to-wishlist', [
        'methods'             => 'POST',
        'callback'            => 'custom_add_to_wishlist',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/showwishlist', [
        'methods'             => 'GET',
        'callback'            => 'custom_show_wishlist',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/product-remove-wishlist', [
        'methods'             => 'POST',
        'callback'            => 'custom_product_remove_wishlist',
        'permission_callback' => 'vogo_permission_check',
    ]);

});


/**
 * Add a product to the user's wishlist (if not already added)
 *
 * @return array JSON response with status and message
 */
function custom_add_to_wishlist() {
    global $wpdb;

    // STEP 1: Parse input
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id    = isset($data['access_token']) ? intval($data['access_token']) : 0;
    $product_id = isset($data['product_id']) ? intval($data['product_id']) : 0;

    vogo_error_log2("STEP 1: Received wishlist request - user_id: {$user_id}, product_id: {$product_id}");

    // STEP 2: Initialize response
    $response = [
        'status'  => false,
        'code'    => 400,
        'message' => 'Something went wrong.',
        'data'    => [],
    ];

    // STEP 3: Basic validation
    if ($user_id <= 0 || $product_id <= 0) {
        $response['message'] = 'User ID and Product ID are required.';
        vogo_error_log2("STEP 3: Validation failed - Missing user_id or product_id.");
        return $response;
    }

    // STEP 4: Check user existence
    $user = get_user_by('id', $user_id);
    if (!$user instanceof WP_User) {
        $response['message'] = 'Invalid user.';
        vogo_error_log2("STEP 4: Invalid user ID: {$user_id}");
        return $response;
    }

    $table = $wpdb->prefix . 'custom_wishlist';

    // STEP 5: Check if product already exists in wishlist
    $exists = $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND product_id = %d",
            $user_id,
            $product_id
        )
    );

    if ($exists > 0) {
        // STEP 6: Already exists
        vogo_error_log2("STEP 6: Product already in wishlist (user_id: {$user_id}, product_id: {$product_id})");
        return [
            'status'  => true,
            'code'    => 200,
            'message' => 'Product already in wishlist.',
            'data'    => ['product_id' => $product_id],
        ];
    }

    // STEP 7: Insert into wishlist
    $now = current_time('mysql');
    $inserted = $wpdb->insert(
        $table,
        [
            'user_id'      => $user_id,
            'product_id'   => $product_id,
            'created_date' => $now,
            'updated_date' => $now,
        ],
        ['%d', '%d', '%s', '%s']
    );

    if ($inserted !== false) {
        vogo_error_log2("STEP 7: Product added to wishlist successfully.");
        return [
            'status'  => true,
            'code'    => 200,
            'message' => 'Product added to wishlist.',
            'data'    => ['product_id' => $product_id],
        ];
    } else {
        vogo_error_log2("STEP 7: Failed to insert into wishlist (user_id: {$user_id}, product_id: {$product_id})");
        $response['message'] = 'Failed to add product to wishlist.';
        return $response;
    }
}


/**
 * Retrieve wishlist items for a specific user (paginated)
 *
 * @return array JSON response with wishlist products
 */
function custom_show_wishlist() {
    global $wpdb;

    // STEP 1: Read input data
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id  = isset($data['access_token']) ? intval($data['access_token']) : 0;
    $page     = isset($data['page']) ? max(1, intval($data['page'])) : 1;
    $per_page = isset($data['per_page']) ? max(1, intval($data['per_page'])) : 10;
    $offset   = ($page - 1) * $per_page;

    vogo_error_log2("STEP 1: Wishlist fetch requested - user_id: {$user_id}, page: {$page}, per_page: {$per_page}");

    // STEP 2: Initialize default response
    $response = [
        'status'        => false,
        'code'          => 400,
        'message'       => 'Something went wrong.',
        'total_record'  => 0,
        'data'          => []
    ];

    // STEP 3: Validate user ID
    if ($user_id <= 0) {
        $response['message'] = 'Invalid user.';
        vogo_error_log2("STEP 3: Invalid user_id provided.");
        return $response;
    }

    $user = get_user_by('id', $user_id);
    if (!$user instanceof WP_User) {
        $response['message'] = 'Invalid user.';
        vogo_error_log2("STEP 3.2: User ID not found in WordPress.");
        return $response;
    }

    $table = $wpdb->prefix . 'custom_wishlist';

    // STEP 4: Get total wishlist count
    $total_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d",
        $user_id
    ));

    if ($total_count == 0) {
        $response['code']    = 200;
        $response['message'] = 'No wishlist found.';
        vogo_error_log2("STEP 4: No wishlist entries found for user.");
        return $response;
    }

    vogo_error_log2("STEP 4: Wishlist contains {$total_count} items.");

    // STEP 5: Fetch paginated wishlist records
    $records = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_date DESC LIMIT %d OFFSET %d",
        $user_id, $per_page, $offset
    ), ARRAY_A);

    // STEP 6: Build product data
    $products = [];
    foreach ($records as $item) {
        $product = wc_get_product($item['product_id']);

        if ($product && $product->get_status() === 'publish') {
            $products[] = [
                'product_id'     => $item['product_id'],
                'title'          => $product->get_name(),
                'price'          => $product->get_price(),
                'regular_price'  => $product->get_regular_price() ?: '',
                'currency_symbol'=> html_entity_decode(get_woocommerce_currency_symbol()),
                'image'          => get_the_post_thumbnail_url($item['product_id'], 'full'),
            ];
        }
    }

    // STEP 7: Return final result
    $response['status']        = true;
    $response['code']          = 200;
    $response['message']       = "Total {$total_count} wishlist item(s) found.";
    $response['total_record']  = $total_count;
    $response['data']          = $products;

    vogo_error_log2("STEP 7: Returning " . count($products) . " product(s) from wishlist.");
    return $response;
}


/**
 * Remove a product from user's wishlist
 *
 * @return array JSON response
 */
function custom_product_remove_wishlist() {
    global $wpdb;

    // STEP 1: Parse input
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id    = isset($data['access_token']) ? intval($data['access_token']) : 0;
    $product_id = isset($data['product_id']) ? intval($data['product_id']) : 0;

    vogo_error_log2("STEP 1: Wishlist removal request received - user_id: {$user_id}, product_id: {$product_id}");

    // STEP 2: Prepare default response
    $response = [
        'status'  => false,
        'code'    => 400,
        'message'=> 'Something went wrong.',
        'data'    => []
    ];

    // STEP 3: Validate input
    if ($user_id <= 0 || $product_id <= 0) {
        $response['message'] = 'User ID and Product ID are required.';
        vogo_error_log2("STEP 3: Missing required parameters.");
        return $response;
    }

    $user = get_user_by('id', $user_id);
    if (!$user instanceof WP_User) {
        $response['message'] = 'Invalid user.';
        vogo_error_log2("STEP 3.2: Invalid user ID.");
        return $response;
    }

    $table = $wpdb->prefix . 'custom_wishlist';

    // STEP 4: Check if product is in wishlist
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND product_id = %d",
        $user_id, $product_id
    ));

    if ($exists <= 0) {
        $response['message'] = 'No record found.';
        vogo_error_log2("STEP 4: No wishlist entry for product_id {$product_id}");
        return $response;
    }

    // STEP 5: Perform deletion
    $deleted = $wpdb->delete(
        $table,
        ['user_id' => $user_id, 'product_id' => $product_id],
        ['%d', '%d']
    );

    if ($deleted !== false) {
        $response['status']  = true;
        $response['code']    = 200;
        $response['message'] = 'Product removed from wishlist.';
        $response['data']    = [
            'product_id' => $product_id
        ];
        vogo_error_log2("STEP 5: Wishlist item removed successfully.");
    } else {
        $response['message'] = 'Failed to remove product from wishlist.';
        vogo_error_log2("STEP 5: Deletion query failed.");
    }

    return $response;
}




