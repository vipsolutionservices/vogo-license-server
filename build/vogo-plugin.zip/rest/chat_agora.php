<?php
$MODULE_PHP='chat-agora.php';
/**
 * Plugin: Vogo API – Chat + Agora Calls
 * File: chat_agora.php
 * Description: Device token register (FCM) + initiate/close calls with Agora + push notifications.
 * Standards: adi-tehnic (English comments, vogo_error_log3 step logs, no ABSPATH guard).
 */

// === Agora token builders (oficial, fără Composer)
$base_from_plugin_root = dirname(__DIR__) . '/lib/agora/src'; // urcă din /rest/ la /vogo-api/
$base_from_this_dir    = plugin_dir_path(__FILE__) . 'lib/agora/src'; // fallback (dacă fișierul e mutat în rădăcina pluginului)


$agoraLib = is_file($base_from_plugin_root . '/AccessToken.php')
  ? $base_from_plugin_root
  : $base_from_this_dir;

if (!is_file($agoraLib . '/AccessToken.php')) {
  error_log('[AGORA INCLUDE] Files not found at: ' . $agoraLib);
  wp_die('Agora TokenBuilder files missing. Expecting: ' . $agoraLib);
}

require_once $agoraLib . '/AccessToken.php';
require_once $agoraLib . '/RtcTokenBuilder.php';
require_once $agoraLib . '/AccessToken2.php';
require_once $agoraLib . '/RtcTokenBuilder2.php';



/* ----------------------------- ROUTES ------------------------------------ */
add_action('rest_api_init', function () {
  register_rest_route('vogo/v1', '/my-account/register-device', [
    'methods'  => 'POST',
    'callback' => 'vogo_register_device_token_endpoint',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/support/call', [
    'methods'  => 'POST',
    'callback' => 'vogo_support_call_initiate',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/support/call/end', [
    'methods'  => 'POST',
    'callback' => 'vogo_support_call_end',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/support/call/decline', [
    'methods'  => 'POST',
    'callback' => 'vogo_support_call_decline',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/support/call/cancel', [
    'methods'  => 'POST',
    'callback' => 'vogo_support_call_cancel',
    'permission_callback' => 'vogo_permission_check'
  ]);


  register_rest_route('vogo/v1', '/support/call/status', [
    'methods'  => 'POST',
    'callback' => 'vogo_support_call_status',
    'permission_callback' => 'vogo_permission_check'
  ]);

  // New endpoint for refreshing Agora tokens
  register_rest_route('vogo/v1', '/support/call/refresh-token', [
    'methods'  => 'POST',
    'callback' => 'vogo_refresh_agora_token',
    'permission_callback' => 'vogo_permission_check'
  ]);  

});

/* ----------------------------- CONFIG HELPERS ---------------------------- */
function vogo_conf($key, $default=''){
  $opt = '';
  if(defined($key)) $opt = constant($key);
  if(!$opt) $opt = get_option($key, '');
  return $opt ?: $default;
}

/* ----------------------------- USER HELPER ------------------------------- */
function vogo_get_user_from_request(WP_REST_Request $request){
  if(function_exists('extract_user_from_jwt_token')){
    $res = extract_user_from_jwt_token($request); // returns user_id or WP_REST_Response error
    if($res instanceof WP_REST_Response){ return $res; }
    return (int)$res;
  }
  return (int)get_current_user_id();
}

function vogo_base64url_encode($data){
  return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

/* ----------------------------- DEVICE TOKENS ----------------------------- */
function vogo_register_device_token($user_id, $device_token, $platform='', $device_info=''){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME; $module='register-device-internal';
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] ACTIVE DB: $db | IP:$ip | USER:$user_id");

  if(!$user_id || !$device_token){
    vogo_error_log3("[$module] Missing user_id/device_token | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END"); return new WP_Error('bad_request','user_id and device_token required');
  }

  $table = $wpdb->prefix.'vogo_device_tokens';
  $exists = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE device_token=%s", $device_token));
  vogo_error_log3("##############SQL: SELECT id FROM $table WHERE device_token=%s | token=$device_token");

  if($wpdb->last_error){
    vogo_error_log3("[$module] SQL error on SELECT: ".$wpdb->last_error." | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END"); return new WP_Error('sql_error',$wpdb->last_error);
  }

  if($exists){
    $ok = $wpdb->update($table, [
      'user_id'=>$user_id, 'platform'=>$platform, 'device_info'=>$device_info, 'modified_by'=>$user_id
    ], ['id'=>$exists], ['%d','%s','%s','%d'], ['%d']);
    vogo_error_log3("[$module] UPDATE id=$exists | ok:".(int)$ok." | IP:$ip | USER:$user_id");
    if($wpdb->last_error){ vogo_error_log3("[$module] SQL error on UPDATE: ".$wpdb->last_error); vogo_error_log3("VOGO_LOG_END"); return new WP_Error('sql_error',$wpdb->last_error); }
    vogo_error_log3("VOGO_LOG_END"); return true;
  }else{
    $ok = $wpdb->insert($table, [
      'user_id'=>$user_id,'device_token'=>$device_token,'platform'=>$platform,'device_info'=>$device_info,'created_by'=>$user_id
    ], ['%d','%s','%s','%s','%d']);
    vogo_error_log3("[$module] INSERT token | ok:".(int)$ok." | IP:$ip | USER:$user_id");
    if($wpdb->last_error){ vogo_error_log3("[$module] SQL error on INSERT: ".$wpdb->last_error); vogo_error_log3("VOGO_LOG_END"); return new WP_Error('sql_error',$wpdb->last_error); }
    vogo_error_log3("VOGO_LOG_END"); return true;
  }
}

function vogo_register_device_token_endpoint(WP_REST_Request $request){
  $module='register-device'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] [STEP 0.1] Raw: ".file_get_contents('php://input')." | ACTIVE DB: $db | IP:$ip");

  $uid = vogo_get_user_from_request($request);
  if($uid instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $uid; }
  if(!$uid){ vogo_error_log3("[$module] No user from JWT | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  $p = $request->get_json_params();
  $device_token = sanitize_text_field($p['device_token'] ?? '');
  $platform     = sanitize_text_field($p['platform'] ?? '');
  $device_info  = sanitize_text_field($p['device_info'] ?? '');

  if(!$device_token){ vogo_error_log3("[$module] Missing device_token | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'device_token required'],400); }

  $ok = vogo_register_device_token($uid, $device_token, $platform, $device_info);
  if(is_wp_error($ok)){ vogo_error_log3("[$module] ERROR: ".$ok->get_error_message()); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_message'=>$ok->get_error_message()],500); }

  vogo_error_log3("[$module] Saved | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true], 200);
}
/* Obține Bearer OAuth2 din service account JSON (pentru FCM HTTP v1) */
function vogo_google_sa_bearer_v1(&$err_out = null){
  $err_out = null;
  $json_path = vogo_conf('GOOGLE_APPLICATION_CREDENTIALS','');
  if(!$json_path || !is_readable($json_path)){ $err_out = 'Service account JSON missing/unreadable'; return null; }
  $sa = json_decode(file_get_contents($json_path), true);
  if(!$sa || empty($sa['client_email']) || empty($sa['private_key'])){ $err_out='Invalid service account JSON'; return null; }

  $token_uri = $sa['token_uri'] ?? 'https://oauth2.googleapis.com/token';
  $now = time();
  $claims = [
    'iss'   => $sa['client_email'],
    'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
    'aud'   => $token_uri,
    'iat'   => $now,
    'exp'   => $now + 3600
  ];
  $header = ['alg'=>'RS256','typ'=>'JWT'];
  $jwt_unsigned = vogo_base64url_encode(json_encode($header)).'.'.vogo_base64url_encode(json_encode($claims));

  $signature = '';
  if(!openssl_sign($jwt_unsigned, $signature, $sa['private_key'], 'sha256')){
    $err_out='openssl_sign failed'; return null;
  }
  $assertion = $jwt_unsigned.'.'.vogo_base64url_encode($signature);

  $ch = curl_init();
  curl_setopt_array($ch, [
    CURLOPT_URL => $token_uri,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => http_build_query([
      'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
      'assertion'  => $assertion
    ]),
    CURLOPT_TIMEOUT => 20
  ]);
  $resp = curl_exec($ch);
  $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $cerr = curl_error($ch);
  curl_close($ch);

  if($http !== 200){ $err_out = "Token HTTP $http: $resp | curl:$cerr"; return null; }
  $obj = json_decode($resp, true);
  return $obj['access_token'] ?? null;
}

/**
 * Try to read project_id from option FCM_PROJECT_ID; if empty, fallback to service account JSON.
 */
function vogo_fcm_project_id(){
  $project = vogo_conf('FCM_PROJECT_ID','');
  if(!empty($project)) return $project;

  $json_path = vogo_conf('GOOGLE_APPLICATION_CREDENTIALS','');
  if($json_path && is_readable($json_path)){
    $sa = json_decode(file_get_contents($json_path), true);
    if(!empty($sa['project_id'])) return $sa['project_id'];
  }
  return '';
}

/**
 * Send push to ALL tokens of a user (per-token send). Strong logging and proper APNs/Android payload.
 */
function vogo_fcm_send_to_user($recipient_user_id, $title, $body, array $data){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $module='fcm-v1';
  $project = vogo_fcm_project_id();
  $json_ok = vogo_conf('GOOGLE_APPLICATION_CREDENTIALS','');
  $table = $wpdb->prefix.'vogo_device_tokens';

  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] to_user:$recipient_user_id | IP:$ip");
  if(!$project || !$json_ok){ vogo_error_log3("[$module] missing PROJECT_ID or JSON path"); vogo_error_log3("VOGO_LOG_END"); return ['success'=>false,'error'=>'config_missing']; }

  $tokens = $wpdb->get_col($wpdb->prepare("SELECT device_token FROM $table WHERE user_id=%d", $recipient_user_id));
  vogo_error_log3("##############SQL: SELECT device_token FROM $table WHERE user_id=%d | user_id=$recipient_user_id");
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL: ".$wpdb->last_error); }
  if(!$tokens){ vogo_error_log3("[$module] no device tokens"); vogo_error_log3("VOGO_LOG_END"); return ['success'=>false,'error'=>'no_tokens']; }

  $tokens = array_values(array_unique(array_filter($tokens))); // dedupe/sanitize

  $err = null; $bearer = vogo_google_sa_bearer_v1($err);
  if(!$bearer){ vogo_error_log3("[$module] bearer fail: $err"); vogo_error_log3("VOGO_LOG_END"); return ['success'=>false,'error'=>'v1_auth_failed','detail'=>$err]; }

  $url = "https://fcm.googleapis.com/v1/projects/$project/messages:send";
  $headers = ['Content-Type: application/json','Authorization: Bearer '.$bearer];

  $results = []; $ok_any=false;
  foreach($tokens as $tkn){
    $payload = [
      'message' => [
        'token' => $tkn,
        //'notification' => ['title'=>$title, 'body'=>$body],
        'data' => array_map('strval', $data), // HTTP v1 data must be strings
        'android' => [
          'priority' => 'HIGH',
          // add channel if you use one on client: 'notification'=>['channel_id'=>'vogo_default']
        ],
        'apns' => [
          'headers' => ['apns-priority' => '10'],
          'payload' => [
            'aps' => [
              'alert' => ['title'=>$title, 'body'=>$body],
              'sound' => 'default',
              // keep content-available for background data updates on iOS if app desires to handle silently
              'content-available' => 1
            ]
          ]
        ]
      ]
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
      CURLOPT_URL=>$url,
      CURLOPT_POST=>true,
      CURLOPT_HTTPHEADER=>$headers,
      CURLOPT_RETURNTRANSFER=>true,
      CURLOPT_POSTFIELDS=>json_encode($payload),
      CURLOPT_TIMEOUT=>20
    ]);
    $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $cerr = curl_error($ch); curl_close($ch);

    vogo_error_log3("[$module] v1 code:$code err:$cerr token_tail:".substr($tkn,-8));
    if($code>=200 && $code<300) $ok_any=true;

    $results[] = [
      'http'=>$code,
      'err'=>$cerr,
      'tail'=>substr($tkn,-8),
      'resp_raw'=>$resp,
      'resp_json'=>json_decode($resp, true)
    ];
  }

  // optional log (if table exists)
  $log_table = $wpdb->prefix.'vogo_push_log';
  // Try/catch style guard to avoid breaking if table missing
  $wpdb->suppress_errors(true);
  $wpdb->insert($log_table, [
    'user_id' => (int)($data['user_id'] ?? 0),
    'recipient_user_id' => (int)$recipient_user_id,
    'title' => $title, 'body' => $body,
    'payload' => wp_json_encode($data),
    'response_code' => $results[0]['http'] ?? null,
    'response_body' => wp_json_encode($results)
  ]);
  $wpdb->suppress_errors(false);

  vogo_error_log3("VOGO_LOG_END");
  return ['success'=>$ok_any,'results'=>$results];
}

/* ----------------------------- AGORA TOKEN ------------------------------- */
function vogo_generate_agora_token($channel_name, $uid, $expire_seconds = null){
  $appId  = vogo_conf('AGORA_APP_ID','');
  $appCer = vogo_conf('AGORA_APP_CERTIFICATE','');
  $ttl    = $expire_seconds ?: (int)vogo_conf('AGORA_TOKEN_TTL', 3600);

  if (!$appId || !$appCer) {
    return ['token' => null, 'expires_in' => 0];
  }

  $expire_ts = time() + $ttl;
  $token = null;

  if (class_exists('RtcTokenBuilder2')) {
    // 1 = Publisher
    $token = \RtcTokenBuilder2::buildTokenWithUid($appId, $appCer, $channel_name, (int)$uid, 1, $expire_ts);
  } elseif (class_exists('RtcTokenBuilder')) {
    $token = \RtcTokenBuilder::buildTokenWithUid($appId, $appCer, $channel_name, (int)$uid, 1, $expire_ts);
  }

  return $token ? ['token' => $token, 'expires_in' => $ttl]
                : ['token' => null,  'expires_in' => 0];
}


/* ----------------------------- CALL: INITIATE ---------------------------- */
function vogo_support_call_initiate(WP_REST_Request $request){
  global $wpdb; $module='support-call'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] [STEP 0.1] Raw: ".file_get_contents('php://input')." | ACTIVE DB:$db | IP:$ip");

  // auth
  $caller_id=vogo_get_user_from_request($request);
  if($caller_id instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $caller_id; }
  if(!$caller_id){ vogo_error_log3("[$module] No JWT user | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  // payload
  $p=$request->get_json_params();
  $receiver_id=(int)($p['chat_user_id']??0);
  $discussion_id=(int)($p['discussion_id']??0); // PARENT_ID_vogo_forum_post
  $is_video=!empty($p['video_call'])?1:0; $is_voice=!empty($p['voice_call'])?1:0;
  if(!$receiver_id||(!$is_video&&!$is_voice)){ vogo_error_log3("[$module] Missing receiver/call type | IP:$ip | USER:$caller_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'chat_user_id and one of video_call/voice_call required'],400); }

  // channel + tokens
  $min=min($caller_id,$receiver_id); $max=max($caller_id,$receiver_id); $ts=time();
  $channel_name="call_{$min}{$max}{$ts}"; $type=$is_video?'VIDEO':'VOICE';
  $caller_token=vogo_generate_agora_token($channel_name,$caller_id,3600);
  $receiver_token=vogo_generate_agora_token($channel_name,$receiver_id,3600);
  if(empty($caller_token['token'])||empty($receiver_token['token'])){ vogo_error_log3("[$module] Failed to generate Agora tokens | IP:$ip | USER:$caller_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Failed to generate Agora tokens'],500); }
  $expires_in=(int)($caller_token['expires_in']??3600);

  // insert in wp_thread_calls
  $calls=$wpdb->prefix.'thread_calls';
  $wpdb->insert($calls,[
    'channel_name'=>$channel_name,'UserId_From'=>$caller_id,'UserId_To'=>$receiver_id,'discussion_id'=>$discussion_id?:null,
    'type'=>$type,'is_video'=>$is_video,'is_voice'=>$is_voice,
    'caller_agora_token'=>$caller_token['token'],'receiver_agora_token'=>$receiver_token['token'],
    'token_expire_at'=>gmdate('Y-m-d H:i:s',time()+$expires_in),'status'=>'RINGING','created_by'=>$caller_id
  ]);
  vogo_error_log3("##############SQL: INSERT INTO $calls (...) VALUES (...) | channel=$channel_name | caller=$caller_id | receiver=$receiver_id");
  if($wpdb->last_error||!$wpdb->insert_id){ vogo_error_log3("[$module] SQL error on INSERT: ".$wpdb->last_error." | IP:$ip | USER:$caller_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_message'=>$wpdb->last_error],500); }
  $call_id=(int)$wpdb->insert_id;

  // === INSERT în tabela noastră de mesaje (unificat chat) CU TIP = VIDEO/VOICE ===
  if($discussion_id>0){
    $answers=$wpdb->prefix.'vogo_forum_post_answer'; $now=current_time('mysql');
    $wpdb->insert($answers,[
      'PARENT_ID_vogo_forum_post'=>$discussion_id,
      'post_author'=>$caller_id,'post_answer'=>'','post_status'=>'active','post_content'=>'','post_date'=>$now,'mesaj'=>'','comment_count'=>0,
      'post_image'=>'','post_mime_type'=>'',
      'created_at'=>$now,'created_user'=>$caller_id,'modified_at'=>$now,'modified_user'=>$caller_id,
      'message_type'=>$type,                 // VIDEO / VOICE
      'direction'=>'outgoing',
      'call_status'=>'RINGING',
      'missed_call'=>0,
      'call_id'=>$call_id,
      'channel_name'=>$channel_name,
      'video_audio_duration'=>0,
      'call_duration_seconds'=>0,
      'is_video'=>$is_video,
      'is_audio'=>$is_voice,
      'to_user_id'=>$receiver_id,
      'filename'=>'','file_mime'=>'','file_size'=>0,'file_url'=>'',
      'message_status'=>'SENT',
      'delivered_at'=>null,'read_at'=>null,
      'client_message_id'=>'','edited_at'=>null,'edited_by'=>0,'deleted_at'=>null,'deleted_by'=>0
    ]);
    $message_id=(int)$wpdb->insert_id; vogo_error_log3("[$module] Inserted chat-call row id=$message_id for discussion_id=$discussion_id (type=$type)");

    // update parent
    $parent=$wpdb->prefix.'vogo_forum_post';
    $wpdb->update($parent,['last_answer_datetime'=>$now,'post_modified_date'=>$now,'post_modified_user'=>$caller_id],['ID'=>$discussion_id],['%s','%s','%d'],['%d']);
    vogo_error_log3("##############SQL: UPDATE $parent SET last_answer_datetime='$now', post_modified_user=$caller_id WHERE ID=$discussion_id");

    // unread +1 pentru receiver
    $read_tbl=$wpdb->prefix.'vogo_forum_post_no_to_read';
    $inc_sql=$wpdb->prepare("INSERT INTO $read_tbl (post_id,user_id,nr_to_read,created_at,created_by) VALUES (%d,%d,1,NOW(),%d) ON DUPLICATE KEY UPDATE nr_to_read=nr_to_read+1, updated_at=NOW(), updated_by=VALUES(created_by)",$discussion_id,$receiver_id,$caller_id);
    vogo_error_log3("[$module] UPSERT READ (+1 receiver): $inc_sql"); $wpdb->query($inc_sql);
  }else{
    vogo_error_log3("[$module] discussion_id missing -> skip chat history insert (call record created).");
  }

  // push către receiver
  $caller=get_user_by('id',$caller_id); $callerName=$caller?($caller->display_name?:$caller->user_login):('User '.$caller_id);
  $title='Incoming Call'; $body=($is_video?'Video':'Voice')." call from $callerName";
  $data_payload=['title'=>$title,'body'=>$body,'user_id'=>$caller_id,'caller_name'=>$callerName,'discussion_id'=>$discussion_id?:0,'auto_answer'=>'0','user_image_url'=>get_avatar_url($caller_id)?:'','chat_user_id'=>$receiver_id,'is_video'=>$is_video?'1':'0','is_voice'=>$is_voice?'1':'0','channel_name'=>$channel_name,'agora_token'=>$receiver_token['token'],'call_type'=>$type, 'priority'=>'high'];
  $push_res=vogo_fcm_send_to_user($receiver_id,$title,$body,$data_payload); vogo_error_log3("[$module] Push -> ".json_encode($push_res)." | IP:$ip | USER:$caller_id");

  vogo_error_log3("[$module] SUCCESS | channel returned | IP:$ip | USER:$caller_id"); vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true,'channel_name'=>$channel_name,'token'=>$caller_token['token'],'expires_in'=>$expires_in,'call_id'=>$call_id],200);
}

/* ----------------------------- CALL: DECLINE ------------------------------ */
function vogo_support_call_decline(WP_REST_Request $request){
  global $wpdb; $module='call-decline'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] [STEP 0.1] Raw: ".file_get_contents('php://input')." | ACTIVE DB:$db | IP:$ip");

  $decliner=vogo_get_user_from_request($request);
  if($decliner instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $decliner; }
  if(!$decliner){ vogo_error_log3("[$module] No JWT user | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  // [ADI-ADD] payload extins: acceptam call_id sau channel_name (BC-safe) + flag-uri de skip
  $p=$request->get_json_params(); 
  $channel=sanitize_text_field($p['channel_name']??$request->get_param('channel_name')??'');
  $call_id=isset($p['call_id'])?(int)$p['call_id']:0;
  $skip_unread = !empty($p['skip_unread']) ? 1 : 0; // ex: caller e pe UI => skip
  $skip_push   = !empty($p['skip_push'])   ? 1 : 0; // ex: caller e pe UI => skip
  if(!$channel && !$call_id){ vogo_error_log3("[$module] Missing channel_name/call_id | IP:$ip | USER:$decliner"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel_name or call_id required','user_id'=>$decliner],400); }

  $calls=$wpdb->prefix.'thread_calls';
  if($channel){
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE channel_name=%s",$channel),ARRAY_A);
    vogo_error_log3("##############SQL: SELECT * FROM $calls WHERE channel_name='$channel'");
  } else {
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
    vogo_error_log3("##############SQL: SELECT * FROM $calls WHERE id=$call_id");
    $channel=$row? $row['channel_name'] : '';
  }
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL error on SELECT: ".$wpdb->last_error); }
  if(!$row){ vogo_error_log3("[$module] Channel not found | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel not found','user_id'=>$decliner],404); }

  $caller=(int)$row['UserId_From']; $receiver=(int)$row['UserId_To'];
  if($decliner!==$caller && $decliner!==$receiver){ vogo_error_log3("[$module] Not a participant | IP:$ip | USER:$decliner"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'not a participant','user_id'=>$decliner],403); }
  // [ADI-ADD] doar callee are voie sa decline (caller -> cancel)
  if($decliner===$caller){ vogo_error_log3("[$module] Caller cannot DECLINE (use cancel) | IP:$ip | USER:$decliner"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'caller_must_use_cancel'],403); }

  if($call_id<=0) $call_id=(int)$row['id'];
  $end_dt=current_time('mysql',1);
  // [ADI-ADD] guard pe starea RINGING (idempotent)
  $upd=$wpdb->query($wpdb->prepare(
    "UPDATE $calls SET `end`=%s, `status`='DECLINED', `ended_by_userid`=%d, `modified_by`=%d
     WHERE ".($channel?"channel_name=%s":"id=%d")." AND status='RINGING'",
    $end_dt,$decliner,$decliner, ($channel?:$call_id)
  ));
  vogo_error_log3("##############SQL: UPDATE $calls SET end='$end_dt', status='DECLINED', ended_by_userid=$decliner, modified_by=$decliner WHERE ".($channel?"channel_name='$channel'":"id=$call_id")." AND status='RINGING'");
  if($wpdb->last_error||$upd===false){ vogo_error_log3("[$module] SQL error on UPDATE: ".$wpdb->last_error); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_message'=>$wpdb->last_error,'user_id'=>$decliner],500); }

  // === Update și în tabela noastră de mesaje (unificat chat) ===
  $answers=$wpdb->prefix.'vogo_forum_post_answer'; $now=current_time('mysql'); $call_id=(int)$row['id'];
  $upd_msg=$wpdb->update($answers,[
    'call_status'=>'DECLINED','missed_call'=>0,'call_duration_seconds'=>0,'video_audio_duration'=>0,
    'post_modified_date'=>$now,'post_modified_user'=>$decliner,'modified_at'=>$now,'modified_user'=>$decliner
  ],['call_id'=>$call_id],['%s','%d','%d','%d','%s','%d','%s','%d'],['%d']);
  vogo_error_log3("##############SQL: UPDATE $answers SET call_status='DECLINED', missed_call=0, call_duration_seconds=0, video_audio_duration=0, post_modified_date='$now', post_modified_user=$decliner, modified_at='$now', modified_user=$decliner WHERE call_id=$call_id");
  if($upd_msg===false || $wpdb->rows_affected===0){
    $wpdb->update($answers,[
      'call_status'=>'DECLINED','missed_call'=>0,'call_duration_seconds'=>0,'video_audio_duration'=>0,
      'post_modified_date'=>$now,'post_modified_user'=>$decliner,'modified_at'=>$now,'modified_user'=>$decliner
    ],['channel_name'=>$channel],['%s','%d','%d','%d','%s','%d','%s','%d'],['%s']);
    vogo_error_log3("##############SQL: FALLBACK UPDATE $answers ... WHERE channel_name='$channel'");
  }

  // [ADI-ADD] Resolve post_id pentru UNREAD (simetric cu cancel)
  $row2=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
  $post_id=(int)($row2['discussion_id']??0);
  if($post_id<=0){
    $post_id=(int)$wpdb->get_var($wpdb->prepare("SELECT post_id FROM $answers WHERE call_id=%d ORDER BY id DESC LIMIT 1",$call_id));
    vogo_error_log3("[$module] resolve post_id via answers.call_id | post_id=$post_id | call_id=$call_id");
  }
  if($post_id<=0 && $channel){
    $post_id=(int)$wpdb->get_var($wpdb->prepare("SELECT post_id FROM $answers WHERE channel_name=%s ORDER BY id DESC LIMIT 1",$channel));
    vogo_error_log3("[$module] resolve post_id via answers.channel_name | post_id=$post_id | channel=$channel");
  }

  // [ADI-ADD] Adi-UNREAD-LOCK: decliner (callee) => other=caller -> +1 (decliner reset=0) — DOAR daca nu se cere skip
  if(!$skip_unread && $post_id>0 && function_exists('handle_chat_nr_to_read')){
    handle_chat_nr_to_read($decliner,$post_id);
    vogo_error_log3("[$module] UNREAD applied | post_id=$post_id | decliner=$decliner");
  } else {
    vogo_error_log3("[$module] UNREAD skipped | reason=".($skip_unread?'payload-skip':'n/a')." | post_id=$post_id | decliner=$decliner");
  }

  // Push către celălalt — DOAR daca nu se cere skip
  $other=($decliner===$caller)?$receiver:$caller; 
  if(!$skip_push){
    $who=get_user_by('id',$decliner);
    $whoName=$who?($who->display_name?:$who->user_login):('User '.$decliner);
    $title='Call Declined'; $body="Call declined by $whoName";
    $data=['title'=>$title,'body'=>$body,'channel_name'=>$channel,'status'=>'DECLINED','ended_by_userid'=>(string)$decliner, 'priority'=>'high','discussion_id'=>(string)($row['discussion_id']??0)];
    vogo_fcm_send_to_user($other,$title,$body,$data);
    vogo_error_log3("[$module] PUSH sent (CALL_DECLINED) | other=$other");
  } else {
    vogo_error_log3("[$module] PUSH skipped | reason=payload-skip");
  }

  $decliner_user=get_userdata($decliner); $decliner_login=$decliner_user?$decliner_user->user_login:'unknown';
  vogo_error_log3("[$module] SUCCESS decline | channel:$channel | IP:$ip | USER:$decliner/$decliner_login"); vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true,'channel_name'=>$channel,'status'=>'DECLINED','user_id'=>$decliner,'user_login'=>$decliner_login],200);
}




/* ----------------------------- CALL: END --------------------------------- */
function vogo_support_call_end(WP_REST_Request $request){
  global $wpdb; $module='call-end'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] ACTIVE DB:$db | IP:$ip");

  // auth
  $ender_id=vogo_get_user_from_request($request);
  if($ender_id instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid"); vogo_error_log3("VOGO_LOG_END"); return $ender_id; }
  if(!$ender_id){ vogo_error_log3("[$module] No JWT user"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  // payload
  $p=$request->get_json_params();
  $channel=sanitize_text_field($p['channel_name']??$request->get_param('channel_name')??'');
  $call_id=isset($p['call_id'])?(int)$p['call_id']:0;
  if(!$channel && !$call_id){ vogo_error_log3("[$module] Missing channel_name/call_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel_name or call_id required'],400); }

  $calls=$wpdb->prefix.'thread_calls';
  $answers=$wpdb->prefix.'vogo_forum_post_answer';

  // 1) Select call (by channel first, else by id)
  if($channel){
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE channel_name=%s",$channel),ARRAY_A);
  } else {
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
    $channel=$row? $row['channel_name'] : '';
  }
  if(!$row){ vogo_error_log3("[$module] Channel not found"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel not found'],404); }

  $caller=(int)$row['UserId_From']; $receiver=(int)$row['UserId_To'];
  if($ender_id!==$caller && $ender_id!==$receiver){ vogo_error_log3("[$module] Not a participant"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'not a participant'],403); }

  // 2) UPDATE call în DB cu NOW() (tz consistent cu start)
  if($call_id<=0) $call_id=(int)$row['id'];
  $upd_sql=$wpdb->prepare(
    "UPDATE $calls
       SET `end`=NOW(),
           `duration_seconds`=GREATEST(0, TIMESTAMPDIFF(SECOND, `start`, NOW())),
           `status`='ENDED',
           `ended_by_userid`=%d,
           `modified_by`=%d
     WHERE ".($channel?"channel_name=%s":"id=%d"),
    $ender_id,$ender_id, ($channel?:$call_id)
  );
  $wpdb->query($upd_sql);
  vogo_error_log3("[$module] SQL: $upd_sql");

  // [ADI-ADD] debug & fallback dacă primul UPDATE nu a afectat rânduri
  if($wpdb->last_error){ vogo_error_log3("[$module] UPDATE error: ".$wpdb->last_error); }
  vogo_error_log3("[$module] rows_affected(1st): ".(int)$wpdb->rows_affected);
  if((int)$wpdb->rows_affected===0){
    if($call_id>0){
      $upd_sql2=$wpdb->prepare(
        "UPDATE $calls
           SET `end`=NOW(),
               `duration_seconds`=GREATEST(0, TIMESTAMPDIFF(SECOND, `start`, NOW())),
               `status`='ENDED',
               `ended_by_userid`=%d,
               `modified_by`=%d
         WHERE id=%d",
        $ender_id,$ender_id,$call_id
      );
      $wpdb->query($upd_sql2);
      vogo_error_log3("[$module] SQL(fallback by id): $upd_sql2");
      vogo_error_log3("[$module] rows_affected(2nd): ".(int)$wpdb->rows_affected);
    } else if($channel){
      $upd_sql3=$wpdb->prepare(
        "UPDATE $calls
           SET `end`=NOW(),
               `duration_seconds`=GREATEST(0, TIMESTAMPDIFF(SECOND, `start`, NOW())),
               `status`='ENDED',
               `ended_by_userid`=%d,
               `modified_by`=%d
         WHERE channel_name=%s",
        $ender_id,$ender_id,$channel
      );
      $wpdb->query($upd_sql3);
      vogo_error_log3("[$module] SQL(fallback by channel): $upd_sql3");
      vogo_error_log3("[$module] rows_affected(3rd): ".(int)$wpdb->rows_affected);
    }
  }

  // reselect pentru valori finale
  $row2=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
  if(!$row2){ vogo_error_log3("[$module] Post-UPDATE select failed"); }
  $dur=(int)($row2['duration_seconds']??0);
  $disc_id=(int)($row2['discussion_id']??0);

  // 3) UPDATE mesajul din chat (mapat pe call_id; fallback pe channel_name)
  $now=current_time('mysql');
  $u1=$wpdb->update($answers,[
    'call_status'=>'ENDED','call_duration_seconds'=>$dur,'video_audio_duration'=>$dur,'missed_call'=>0,
    'post_modified_date'=>$now,'post_modified_user'=>$ender_id,'modified_at'=>$now,'modified_user'=>$ender_id
  ],['call_id'=>$call_id],['%s','%d','%d','%d','%s','%d','%s','%d'],['%d']);
  if($u1===false || $wpdb->rows_affected===0){
    $wpdb->update($answers,[
      'call_status'=>'ENDED','call_duration_seconds'=>$dur,'video_audio_duration'=>$dur,'missed_call'=>0,
      'post_modified_date'=>$now,'post_modified_user'=>$ender_id,'modified_at'=>$now,'modified_user'=>$ender_id
    ],['channel_name'=>$channel],['%s','%d','%d','%d','%s','%d','%s','%d'],['%s']);
  }

  // 4) Push către celălalt
  $other=($ender_id===$caller)?$receiver:$caller;
  $who=get_user_by('id',$ender_id); $whoName=$who?($who->display_name?:$who->user_login):('User '.$ender_id);
  $title='Call Ended'; $body="Call ended by $whoName";
  vogo_fcm_send_to_user($other,$title,$body,[
    'title'=>$title,'body'=>$body,'channel_name'=>$channel,'status'=>'ENDED', 'priority'=>'high', 
    'ended_by_userid'=>(string)$ender_id,'duration_seconds'=>(string)$dur,'discussion_id'=>(string)$disc_id
  ]);

  vogo_error_log3("[$module] SUCCESS | channel:$channel | dur:$dur | call_id:$call_id");
  vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true,'channel_name'=>$channel,'status'=>'ENDED','duration_seconds'=>$dur,'call_id'=>$call_id],200);
}



/* ----------------------------- CALL: STATUS ------------------------------- */
function vogo_support_call_status(WP_REST_Request $request){
  global $wpdb; $module='call-status'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] [STEP 0.1] Raw: ".file_get_contents('php://input')." | ACTIVE DB: $db | IP:$ip");

  $uid = vogo_get_user_from_request($request);
  if($uid instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $uid; }
  if(!$uid){ vogo_error_log3("[$module] No JWT user | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  $p = $request->get_json_params();
  $channel = sanitize_text_field($p['channel_name'] ?? '');
  if(!$channel){ vogo_error_log3("[$module] Missing channel_name | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel_name required'],400); }

  $calls = $wpdb->prefix.'thread_calls';
  $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE channel_name=%s", $channel), ARRAY_A);
  vogo_error_log3("##############SQL: SELECT * FROM $calls WHERE channel_name=%s | channel=$channel");
  if($wpdb->last_error){ vogo_error_log3("[$module] SQL error on SELECT: ".$wpdb->last_error); }

  if(!$row){ vogo_error_log3("[$module] Channel not found | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel not found'],404); }

  $caller=(int)$row['UserId_From']; $receiver=(int)$row['UserId_To'];
  if($uid !== $caller && $uid !== $receiver){
    vogo_error_log3("[$module] Not a participant | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'error'=>'not a participant'],403);
  }

vogo_error_log3("[$module] SUCCESS status | channel:$channel | status:{$row['status']} | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response([
    'success' => true,
    'channel_name' => $row['channel_name'],
    'status' => $row['status'],
    'UserId_From' => (int)$row['UserId_From'],
    'UserId_To' => (int)$row['UserId_To'],
    'start' => $row['start'],
    'end' => $row['end'],
    'duration_seconds' => isset($row['duration_seconds']) ? (int)$row['duration_seconds'] : null,
    'type' => $row['type'],
    'ended_by_userid' => isset($row['ended_by_userid']) ? (int)$row['ended_by_userid'] : null,
    // Include tokens in response for the requesting user
    'token' => ($uid === $caller) ? $row['caller_agora_token'] : $row['receiver_agora_token']
  ], 200);
}

/* ----------------------------- CALL: REFRESH TOKEN ----------------------- */
function vogo_refresh_agora_token(WP_REST_Request $request) {
  global $wpdb;
  $module = 'refresh-token';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
  $db = DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] Raw: ".file_get_contents('php://input')." | ACTIVE DB: $db | IP:$ip");

  $uid = vogo_get_user_from_request($request);
  if ($uid instanceof WP_REST_Response) { vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $uid; }
  if (!$uid) { vogo_error_log3("[$module] No JWT user | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  $p = $request->get_json_params();
  $channel = sanitize_text_field($p['channel_name'] ?? '');
  if (!$channel) { vogo_error_log3("[$module] Missing channel_name | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel_name required'],400); }

  $calls = $wpdb->prefix.'thread_calls';
  $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE channel_name=%s AND status='RINGING'", $channel), ARRAY_A);
  vogo_error_log3("##############SQL: SELECT * FROM $calls WHERE channel_name=%s AND status='RINGING' | channel=$channel");
  if ($wpdb->last_error) { vogo_error_log3("[$module] SQL error on SELECT: ".$wpdb->last_error); }

  if (!$row) { vogo_error_log3("[$module] Channel not found or not active | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel not found or not active'],404); }

  $caller = (int)$row['UserId_From']; $receiver = (int)$row['UserId_To'];
  if ($uid !== $caller && $uid !== $receiver) {
    vogo_error_log3("[$module] Not a participant | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'error'=>'not a participant'],403);
  }

  $new_token = vogo_generate_agora_token($channel, $uid, 3600);
  if (!$new_token['token']) { vogo_error_log3("[$module] Failed to generate token | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'token generation failed'],500); }

  // Update the appropriate token in the database
  $token_column = ($uid === $caller) ? 'caller_agora_token' : 'receiver_agora_token';
  $upd = $wpdb->update($calls, [
    $token_column => $new_token['token'],
    'token_expire_at' => gmdate('Y-m-d H:i:s', time() + $new_token['expires_in']),
    'modified_by' => $uid
  ], ['channel_name' => $channel], ['%s','%s','%d'], ['%s']);
  vogo_error_log3("##############SQL: UPDATE $calls SET $token_column=?, token_expire_at=?, modified_by=? WHERE channel_name=?");
  if ($wpdb->last_error || $upd === false) {
    vogo_error_log3("[$module] SQL error on UPDATE: ".$wpdb->last_error);
    vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_message'=>$wpdb->last_error],500);
  }

  vogo_error_log3("[$module] SUCCESS | token refreshed | channel:$channel | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");
return new WP_REST_Response([
  'success' => true,
  'channel_name' => $channel,
  'token' => $new_token['token'],
  'expires_in' => $new_token['expires_in']
  ], 200);
}

/* ----------------------------- CALL: CANCEL ------------------------------ */
/* ADI-ADD (BC-safe): endpoint separat pentru caller-cancel in faza RINGING.
   - Nu atinge vogo_support_call_decline (ramane pt callee -> DECLINED).
   - Trimite push cu event=CALL_CANCELLED pentru oprirea ringtone pe celalalt device.
*/
function vogo_support_call_cancel(WP_REST_Request $request){
  global $wpdb; $module='call-cancel'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] [STEP 0.1] Raw: ".file_get_contents('php://input')." | ACTIVE DB:$db | IP:$ip");

  // auth
  $canceller=vogo_get_user_from_request($request);
  if($canceller instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT invalid | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return $canceller; }
  if(!$canceller){ vogo_error_log3("[$module] No JWT user | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'Invalid token'],403); }

  // payload
  $p=$request->get_json_params();
  $channel=sanitize_text_field($p['channel_name']??$request->get_param('channel_name')??'');
  $call_id=isset($p['call_id'])?(int)$p['call_id']:0;
  if(!$channel && !$call_id){ vogo_error_log3("[$module] Missing channel_name/call_id | IP:$ip | USER:$canceller"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel_name or call_id required'],400); }

  $calls  = $wpdb->prefix.'thread_calls';
  $answers= $wpdb->prefix.'vogo_forum_post_answer';

  // 1) Select call (by channel first, else by id)
  if($channel){
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE channel_name=%s",$channel),ARRAY_A);
  } else {
    $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
    $channel=$row? $row['channel_name'] : '';
  }
  if(!$row){ vogo_error_log3("[$module] Channel not found | IP:$ip"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'error'=>'channel not found'],404); }

  $caller  =(int)$row['UserId_From']; 
  $receiver=(int)$row['UserId_To'];
  $status_now=(string)$row['status'];

  // doar caller are voie sa "cancel" (claritate de contract). Callee -> /support/call/decline
  if($canceller!==$caller){
    vogo_error_log3("[$module] Not caller -> use decline | IP:$ip | USER:$canceller");
    return new WP_REST_Response(['success'=>false,'error'=>'only_caller_can_cancel','hint'=>'use /support/call/decline as callee'],403);
  }

  // 2) UPDATE call: set CANCELLED (doar daca e inca RINGING; altfel idempotent no-op)
  if($call_id<=0) $call_id=(int)$row['id'];
  $upd_sql=$wpdb->prepare(
    "UPDATE $calls
       SET `end`=NOW(),
           `duration_seconds`=GREATEST(0, TIMESTAMPDIFF(SECOND, `start`, NOW())),
           `status`='CANCELLED',
           `ended_by_userid`=%d,
           `modified_by`=%d
     WHERE ".($channel?"channel_name=%s":"id=%d")." AND status='RINGING'",
    $canceller,$canceller, ($channel?:$call_id)
  );
  $wpdb->query($upd_sql);
  vogo_error_log3("[$module] SQL: $upd_sql");
  if($wpdb->last_error){ vogo_error_log3("[$module] UPDATE error: ".$wpdb->last_error); }

  // reselect pentru valori finale
  $row2=$wpdb->get_row($wpdb->prepare("SELECT * FROM $calls WHERE id=%d",$call_id),ARRAY_A);
  if(!$row2){ vogo_error_log3("[$module] Post-UPDATE select failed"); }
  $dur=(int)($row2['duration_seconds']??0);
  $disc_id=(int)($row2['discussion_id']??0);

  // 3) UPDATE mesajul din chat (mapat pe call_id; fallback pe channel_name) -> call_status=CANCELLED
  $now=current_time('mysql');
  $u1=$wpdb->update($answers,[
    'call_status'=>'CANCELLED','call_duration_seconds'=>0,'video_audio_duration'=>0,'missed_call'=>0,
    'post_modified_date'=>$now,'post_modified_user'=>$canceller,'modified_at'=>$now,'modified_user'=>$canceller
  ],['call_id'=>$call_id],['%s','%d','%d','%d','%s','%d','%s','%d'],['%d']);
  if($u1===false || $wpdb->rows_affected===0){
    $wpdb->update($answers,[
      'call_status'=>'CANCELLED','call_duration_seconds'=>0,'video_audio_duration'=>0,'missed_call'=>0,
      'post_modified_date'=>$now,'post_modified_user'=>$canceller,'modified_at'=>$now,'modified_user'=>$canceller
    ],['channel_name'=>$channel],['%s','%d','%d','%d','%s','%d','%s','%d'],['%s']);
  }

  // 4) Push către celălalt (oprește ringtone)
  $other=$receiver;
  $who=get_user_by('id',$canceller); $whoName=$who?($who->display_name?:$who->user_login):('User '.$canceller);
  $title='Call Cancelled'; $body="Call cancelled by $whoName";
  vogo_fcm_send_to_user($other,$title,$body,[
    'event'=>'CALL_CANCELLED',
    'title'=>$title,'body'=>$body,
    'channel_name'=>$channel,'status'=>'CANCELLED',
    'ended_by_userid'=>(string)$canceller,
    'duration_seconds'=>(string)$dur,
    'priority'=>'high',
    'discussion_id'=>(string)$disc_id
  ]);

 //ii arat cu celalalt ca are un mesaj necitit nou, provenit de la un missed call
// [ADI-ADD] Resolve post_id (discussion) pentru UNREAD
$post_id = (int)($row2['discussion_id'] ?? 0);
if ($post_id <= 0) {
  $post_id = (int)$wpdb->get_var($wpdb->prepare("SELECT post_id FROM $answers WHERE call_id=%d ORDER BY id DESC LIMIT 1", $call_id));
  vogo_error_log3("[$module] resolve post_id via answers.call_id | post_id=$post_id | call_id=$call_id");
}
if ($post_id <= 0 && $channel) {
  $post_id = (int)$wpdb->get_var($wpdb->prepare("SELECT post_id FROM $answers WHERE channel_name=%s ORDER BY id DESC LIMIT 1", $channel));
  vogo_error_log3("[$module] resolve post_id via answers.channel_name | post_id=$post_id | channel=$channel");
}

// [ADI-ADD] Adi-UNREAD-LOCK: caller reset=0, other +1 (centralizat)
if ($post_id > 0 && function_exists('handle_chat_nr_to_read')) {
  handle_chat_nr_to_read($caller, $post_id);
  vogo_error_log3("[$module] UNREAD applied | post_id=$post_id | caller=$caller");
} else {
  vogo_error_log3("[$module] UNREAD skipped | post_id=$post_id | caller=$caller");
}

  vogo_error_log3("[$module] SUCCESS cancel | channel:$channel | dur:$dur | call_id:$call_id | IP:$ip | USER:$canceller"); 
  vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true,'channel_name'=>$channel,'status'=>'CANCELLED','duration_seconds'=>$dur,'call_id'=>$call_id],200);
}


