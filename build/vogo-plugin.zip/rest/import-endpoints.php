<?php

// [ADI-ADD] Register route
add_action('rest_api_init', function(){
  register_rest_route('vogo/v1','/import/process_images',[
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'import_process_images',
  ]);

  register_rest_route('vogo/v1','/import/attach_categories_wp',[
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'vogo_import_attach_categories_wp',
  ]);  

  register_rest_route('vogo/v1','/import/publish',[
    'methods'  => 'POST',
    'permission_callback' => '__return_true',
    'callback' => 'vogo_import_publish',
  ]);  
});

/**
 * [ADI-ADD] Process images from imp_data by import_id.
 * JSON: { "import_id": 123, "limit": 150 }
 */
function import_process_images(WP_REST_Request $request){
  global $wpdb; 

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // ===== VOGO_LOG_START =====
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME; $user_id=0;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:$user_id",$module);

  // STEP 0: auth from JWT (for logs + audit)
  $uid_or_err = extract_user_from_jwt_token($request);
  if($uid_or_err instanceof WP_REST_Response){ vogo_error_log3("[STEP 0] JWT error",$module); vogo_error_log3("VOGO_LOG_END",$module); return $uid_or_err; }
  $user_id = (int)$uid_or_err;

  // STEP 0.1: payload
  $p = $request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p),$module);
  $import_id = (int)($p['import_id'] ?? 0);
  $limit     = (int)($p['limit'] ?? 150);
  if($import_id<=0){ vogo_error_log3("[STEP 1] import_id missing/invalid | IP:$ip | USER:$user_id",$module);
    vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'module' => $module.'-ES1','error'=>'import_id_required','user_id'=>$user_id],400); }
  if($limit<=0 || $limit>1000) $limit=150;

  // STEP 2: ensure media libs
  if(!function_exists('media_sideload_image')) require_once ABSPATH.'wp-admin/includes/media.php';
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/image.php';

  // STEP 3: query candidates
  $table = $wpdb->prefix.'imp_data';
  $rows = $wpdb->get_results($wpdb->prepare(
    "SELECT id,id_product,image_url FROM $table
     WHERE id_import=%d AND processed=1 AND id_product IS NOT NULL
       AND TRIM(COALESCE(image_url,''))<>'' 
       AND NOT EXISTS(
         SELECT 1 FROM {$wpdb->postmeta} pm 
         WHERE pm.post_id=$table.id_product AND pm.meta_key='_thumbnail_id' AND pm.meta_value<>'' )
     ORDER BY id ASC LIMIT %d",
    $import_id,$limit
  ));
  if(!is_array($rows)){ vogo_error_log3("[STEP 3] SQL error: ".$wpdb->last_error,$module);
    vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id],500); }

  // STEP 4: loop and sideload
  $ok=0; $fail=0; $skipped=0;
  foreach($rows as $r){
    $pid=(int)$r->id_product; $url=trim((string)$r->image_url);
    if(!$pid || !$url){ $skipped++; continue; }

    // Save source URL on product (traceability)
    update_post_meta($pid,'_external_image_url',$url);

    $att_id = media_sideload_image($url,$pid,null,'id');
    if(is_wp_error($att_id)){
      $fail++; $msg='IMG ERR: '.$att_id->get_error_message();
      vogo_error_log3("[STEP 4.ERR] row_id={$r->id} pid=$pid url=$url | $msg | IP:$ip | USER:$user_id",$module);
      // append error (keep previous)
      $wpdb->query($wpdb->prepare("UPDATE $table SET error_description=CONCAT(IFNULL(error_description,''), %s) WHERE id=%d", "\n".$msg, $r->id));
      continue;
    }

    set_post_thumbnail($pid,(int)$att_id);
    update_post_meta($pid,'_external_image_url_downloaded',1);
    vogo_error_log3("[STEP 4.OK] row_id={$r->id} pid=$pid attachment=$att_id | IP:$ip | USER:$user_id",$module);
    $ok++;
  }

  // STEP 5: response
  $resp = ['success'=>true,'import_id'=>$import_id,'processed_ok'=>$ok,'failed'=>$fail,'skipped'=>$skipped,'batch'=>count($rows),'user_id'=>$user_id];
  vogo_error_log3("[STEP 5] Response: ".json_encode($resp),$module);
  vogo_error_log3("VOGO_LOG_END",$module);

$resp = [
  'success'           => true,
  'import_id'         => $import_id,
  'processed_ok'      => $ok,          // (păstrat pentru compatibilitate)
  'module' => $module.'-ES1',
  'failed'            => $fail,
  'skipped'           => $skipped,
  'batch'             => count($rows),
  'user_id'           => $user_id
];
return new WP_REST_Response($resp, 200);

}

function vogo_import_attach_categories_wp(WP_REST_Request $request){
  global $wpdb;

  // [ADI-BC-GUARD] bufferize output ca să nu polueze JSON-ul (ex: warnings din pluginuri)
  $___ob_on = true; ob_start();

  $uid = extract_user_from_jwt_token($request);
  if ($uid instanceof WP_REST_Response) { if($___ob_on){ ob_end_clean(); } return $uid; }

  $p = $request->get_json_params();
  $import_id = (int)($p['import_id'] ?? 0);
  $limit     = (int)($p['limit'] ?? 500);
  if ($import_id<=0) { if($___ob_on){ ob_end_clean(); } return new WP_REST_Response(['success'=>false,'error'=>'import_id_required'],400); }
  if ($limit<=0 || $limit>2000) $limit=500;

  $table = $wpdb->prefix.'imp_data';

  $rows = $wpdb->get_results($wpdb->prepare(
    "SELECT id, id_product, cat, subcat1, subcat2
     FROM {$table}
     WHERE id_import=%d AND id_product IS NOT NULL
     ORDER BY id ASC LIMIT %d",
    $import_id, $limit
  ));

  $ok=0; $fail=0; $skipped=0;

  foreach($rows as $r){
    $pid = (int)$r->id_product;
    $cat  = trim((string)$r->cat);
    $s1   = trim((string)$r->subcat1);
    $s2   = trim((string)$r->subcat2);

    if (!$pid || $cat==='') { $skipped++; continue; }

    // create/lookup terms (parent using term_id)
    $t0 = vogo_ensure_term_product_cat($cat, 0);
    if (is_wp_error($t0)) { $fail++; continue; }
    $attach_id = (int)$t0['term_id'];
    $parent_id = $attach_id;

    $t1 = null; $t2 = null;
    if ($s1!==''){
      $t1 = vogo_ensure_term_product_cat($s1, $parent_id);
      if (!is_wp_error($t1)) { $attach_id=(int)$t1['term_id']; $parent_id=$attach_id; }
    }
    if ($s2!==''){
      $t2 = vogo_ensure_term_product_cat($s2, $parent_id);
      if (!is_wp_error($t2)) { $attach_id=(int)$t2['term_id']; }
    }

    // atașăm toată ierarhia (părinte+copii) ca să fie bifat corect în UI
    $term_ids = [];
    $term_ids[] = (int)$t0['term_id'];
    if ($t1 && !is_wp_error($t1)) $term_ids[] = (int)$t1['term_id'];
    if ($t2 && !is_wp_error($t2)) $term_ids[] = (int)$t2['term_id'];
    $term_ids = array_values(array_unique(array_filter($term_ids)));

    $res = wp_set_object_terms($pid, $term_ids, 'product_cat', true);
    if (is_wp_error($res)) { $fail++; continue; }

    // curățăm cache-ul de termeni pt. produs (string taxonomie, nu array)
    clean_object_term_cache($pid, 'product_cat'); // ✅ UI vede bifele imediat
    // optional: wc_delete_product_transients($pid);

    // sync cu wp_product_meta_action (doar dacă există rând)
    $has = (int)$wpdb->get_var($wpdb->prepare(
      "SELECT 1 FROM {$wpdb->prefix}product_meta_action WHERE product_id=%d LIMIT 1", $pid
    ));
    if ($has){
      $wpdb->update(
        $wpdb->prefix.'product_meta_action',
        ['product_main_category_id'=>$attach_id], // cel mai adânc nivel
        ['product_id'=>$pid],
        ['%d'], ['%d']
      );
    }

    $ok++;
  }

  if(isset($___ob_on) && $___ob_on){ ob_end_clean(); } // aruncăm orice warnings capturate

  return new WP_REST_Response([
    'success'=>true,
    'import_id'=>$import_id,
    'attached'=>$ok,
    'failed'=>$fail,
    'skipped'=>$skipped
  ],200);
}

/* helper: creează/returnează term_id pentru product_cat, cu părinte term_id */
function vogo_ensure_term_product_cat($name, $parent_term_id){
  $name = trim($name);
  $slug = sanitize_title($name);

  // căutăm direct după slug + părinte
  $exists = term_exists($slug, 'product_cat', (int)$parent_term_id);
  if ($exists && is_array($exists)) return ['term_id'=>(int)$exists['term_id']];
  if ($exists && is_int($exists))   return ['term_id'=>$exists];

  // nu există → inserăm cu parent corect
  $r = wp_insert_term($name, 'product_cat', ['slug'=>$slug, 'parent'=>(int)$parent_term_id]);
  if (is_wp_error($r)) return $r;
  return ['term_id'=>(int)$r['term_id']];
}
/* ✅ compatibilitate respectat, ✅ LOCK format respectat, ✅ SQL validat */


/**
 * JSON: { "import_id": 123, "limit": 500 }
 */
function vogo_import_publish(WP_REST_Request $request){
  global $wpdb;

  // [ADI-BC-GUARD] capturam orice warnings ca sa nu stricam JSON-ul
  $___ob_on = true; ob_start();

  $module='import_publish';
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:0",$module);

  // STEP 0: JWT
  $uid_or_err = extract_user_from_jwt_token($request);
  if($uid_or_err instanceof WP_REST_Response){ if($___ob_on){ ob_end_clean(); } vogo_error_log3("[STEP 0] JWT error",$module); vogo_error_log3("VOGO_LOG_END",$module); return $uid_or_err; }
  $user_id = (int)$uid_or_err;

  // STEP 1: input
  $p = $request->get_json_params();
  $import_id = (int)($p['import_id'] ?? 0);
  $limit     = (int)($p['limit'] ?? 500);
  if($import_id<=0){ if($___ob_on){ ob_end_clean(); } vogo_error_log3("[STEP 1] import_id missing",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'import_id_required','module'=>$module],400); }
  if($limit<=0 || $limit>5000) $limit=500;

  // STEP 2: candidates (distinct products, status draft)
  $table = $wpdb->prefix.'imp_data';
  $ids = $wpdb->get_col($wpdb->prepare(
    "SELECT DISTINCT d.id_product
     FROM {$table} d
     INNER JOIN {$wpdb->posts} p ON p.ID=d.id_product
     WHERE d.id_import=%d
       AND d.id_product IS NOT NULL
       AND p.post_type='product'
       AND p.post_status='draft'
     LIMIT %d",
    $import_id, $limit
  ));
  if($wpdb->last_error){ if($___ob_on){ ob_end_clean(); } return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error,'module'=>$module],500); }

  // STEP 3: publish loop
  $ok=0; $fail=0; $skipped=0;
  foreach($ids as $pid){
    $pid=(int)$pid;
    if(!$pid){ $skipped++; continue; }

    $res = wp_update_post(['ID'=>$pid,'post_status'=>'publish'], true);
    if(is_wp_error($res)){ $fail++; continue; }

    clean_post_cache($pid);
    wc_delete_product_transients($pid);
    $ok++;
  }

  // STEP 4: response
  if($___ob_on){ ob_end_clean(); }
  $resp = [
    'success'      => true,
    'import_id'    => $import_id,
    'to_publish'   => is_array($ids) ? count($ids) : 0,
    'published_ok' => $ok,
    'failed'       => $fail,
    'skipped'      => $skipped,
    'module'       => $module,
    'user_id'      => $user_id
  ];
  vogo_error_log3("[STEP 4] Response: ".json_encode($resp),$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response($resp,200);
}
/* ✅ compatibilitate respectat, ✅ LOCK format respectat, ✅ SQL validat */
