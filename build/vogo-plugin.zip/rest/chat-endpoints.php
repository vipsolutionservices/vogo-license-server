<?php
$MODULE_PHP='chat-endpoints.php';

clear_debug_log_file();

add_action('rest_api_init', function () {

register_rest_route('vogo/v1', '/support/get-random-user', [
  'methods' => 'POST',
  'callback' => 'support_get_random_user',
  'permission_callback' => 'vogo_permission_check'
]);

//upload documents
register_rest_route('vogo/v1', '/chat-upload-document/(?P<module>[a-zA-Z0-9_-]+)/(?P<submodule>[a-zA-Z0-9_-]+)/(?P<reference_id>\d+)', [
    'methods'             => 'POST',
    'callback'            => 'vogo_chat_upload_document',
    'permission_callback' => 'vogo_permission_check'
]); 

register_rest_route('vogo/v1', '/forum-chat/start_or_update_chat_thread', [
  'methods' => 'POST',
  'callback' => 'vogo_start_or_update_chat_thread',
  'permission_callback' => 'vogo_permission_check'
]);    

register_rest_route('vogo/v1', '/forum-chat/get_forum_discussions_by_user', [
  'methods' => 'POST',
  'callback' => 'vogo_get_forum_discussions_by_user',
  'permission_callback' => 'vogo_permission_check'
]);    

register_rest_route('vogo/v1', '/forum-chat/get_forum_chat_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_get_forum_chat_by_id',
  'permission_callback' => 'vogo_permission_check'
]);    

//forum post get one
register_rest_route('vogo/v1', '/forum-chat/get_forum_discussion_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_get_forum_discussion_by_id',
  'permission_callback' => 'vogo_permission_check'
]);  

//post edit
register_rest_route('vogo/v1/forum-chat', '/edit_forum_discussion_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_edit_forum_discussion_by_id',
  'permission_callback' => 'vogo_permission_check'
]);

    //forum answers - add
    register_rest_route('vogo/v1', '/forum-chat/forum_post_answer', [
        'methods' => 'POST',
        'callback' => 'vogo_insert_forum_post_answer',
        'permission_callback' => 'vogo_permission_check'
    ]);

    //get discussions inclusing video and voice calls
    register_rest_route('vogo/v1', '/forum-chat/get_answers_by_post_id', [
        'methods' => 'POST',
        'callback' => 'chat_get_answers_by_post_id',
        'permission_callback' => 'vogo_permission_check'
    ]);        

});  

// helpere

function vogo_get_forum_chat_by_id(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'vogo_forum_post';
  $ip = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id = extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data = json_decode($raw_input, true);
  $id = (int)($data['id'] ?? 0);
  if (!$id) return new WP_REST_Response(['success' => false, 'error' => 'Missing discussion ID'], 400);

  $sql = "
    SELECT *, 
      CASE 
        WHEN chat_user_id IS NOT NULL THEN 'CHAT'
        ELSE 'FORUM'
      END AS type
    FROM $table
    WHERE ID = %d AND post_status = 'active'
    LIMIT 1
  ";

  $row = $wpdb->get_row($wpdb->prepare($sql, $id), ARRAY_A);

  vogo_error_log3("##############SQL: $sql");
  if (!$row) {
    vogo_error_log3("[STEP 9] Discussion not found or inactive | ID: $id | USER: $user_id");
    vogo_error_log3("############ END ########################################");
    return new WP_REST_Response(['success' => false, 'error' => 'Discussion not found'], 404);
  }

  vogo_error_log3("[STEP 9] Discussion fetched successfully | ID: $id | Type: " . $row['type'] . " | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response([
    'success' => true,
    'discussion' => $row
  ], 200);
}

function handle_chat_nr_to_read($p_user_id, $p_post_id){
  global $wpdb; 
  $table_read = $wpdb->prefix.'vogo_forum_post_no_to_read';
  $parent_table = $wpdb->prefix.'vogo_forum_post';

  // [ADI-ADD] guard
  $uid = intval($p_user_id); $pid = intval($p_post_id);
  if($uid<=0 || $pid<=0){ vogo_error_log3("[UNREAD] Invalid params | post_id=$pid | user=$uid"); return false; }

  // [ADI-ADD] resolve other user from parent
  $row = $wpdb->get_row($wpdb->prepare("SELECT post_author, chat_user_id FROM $parent_table WHERE ID=%d",$pid), ARRAY_A);
  if(!$row){ vogo_error_log3("[UNREAD] Parent not found | post_id=$pid"); return false; }
  $pa = (int)$row['post_author']; $cu = (int)$row['chat_user_id'];
  $oid = ($uid===$pa) ? $cu : $pa;

  // [ADI-ADD] sender reset = 0
  $sql_sender_reset = $wpdb->prepare(
    "INSERT INTO $table_read (post_id, user_id, nr_to_read, created_at, created_by)
     VALUES (%d,%d,0,NOW(),%d)
     ON DUPLICATE KEY UPDATE nr_to_read=0, updated_at=NOW(), updated_by=VALUES(created_by)",
    $pid,$uid,$uid
  );
  vogo_error_log3("##############SQL UPSERT READ (sender=0): $sql_sender_reset");
  $wpdb->query($sql_sender_reset);

  // [ADI-ADD] recipient +1
  if($oid>0 && $oid!==$uid){
    $inc_sql = $wpdb->prepare(
      "INSERT INTO $table_read (post_id, user_id, nr_to_read, created_at, created_by)
       VALUES (%d,%d,1,NOW(),%d)
       ON DUPLICATE KEY UPDATE nr_to_read=nr_to_read+1, updated_at=NOW(), updated_by=VALUES(created_by)",
      $pid,$oid,$uid
    );
    vogo_error_log3("##############SQL UPSERT READ (+1 other): $inc_sql");
    $wpdb->query($inc_sql);
  } else {
    vogo_error_log3("[UNREAD] Skip +1 other | post_id=$pid | user=$uid | other=$oid");
  }

  vogo_error_log3("[UNREAD] END handle_chat_nr_to_read | post_id=$pid");
  return true;
}


function vogo_start_or_update_chat_thread(WP_REST_Request $request) {
  global $wpdb;
  $table       = $wpdb->prefix . 'vogo_forum_post';
  $table_read  = $wpdb->prefix . 'vogo_forum_post_no_to_read';

  $ip        = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id   = (int) extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data         = json_decode($raw_input, true);
  $chat_user_id = (int)($data['chat_user_id'] ?? 0);
  $product_id   = (int)($data['product_id'] ?? 0);
  $order_id     = (int)($data['order_id'] ?? 0);
  $mesaj        = sanitize_text_field($data['mesaj'] ?? '');

  if (!$chat_user_id || !$mesaj) {
    return new WP_REST_Response(['success' => false, 'error' => 'Missing chat_user_id or mesaj'], 400);
  }

  // no update, just insert - 1=0 face mereu insert
  $existing = $wpdb->get_var($wpdb->prepare("
    SELECT ID FROM $table 
    WHERE 1=0 AND post_author = %d AND chat_user_id = %d AND order_id = %d AND product_id = %d
    LIMIT 1
  ", $user_id, $chat_user_id, $order_id, $product_id));

  if ($existing) {
    $result = $wpdb->update($table, [
      'mesaj'              => $mesaj,
      'post_modified_date' => current_time('mysql'),
      'post_modified_user' => $user_id
    ], ['ID' => $existing], null, ['%d']);
    $final_id = (int)$existing;
    vogo_error_log3("##############SQL: UPDATE $table SET mesaj='$mesaj' WHERE ID = $existing");
  } else {
    $fields = [
      'post_author'        => $user_id,
      'chat_user_id'       => $chat_user_id,
      'order_id'           => $order_id,
      'product_id'         => $product_id,
      'post_title'         => $mesaj,
      'post_content'       => $mesaj,
      'mesaj'              => $mesaj,
      'post_status'        => 'active',
      'post_date'          => current_time('mysql'),
      'post_modified_date' => current_time('mysql'),
      'post_modified_user' => $user_id
    ];
    $result   = $wpdb->insert($table, $fields);
    $final_id = (int)$wpdb->insert_id;
    vogo_error_log3("##############SQL: INSERT INTO $table (...) VALUES (...)");
  }

  // -- [ADD] Inserăm în tabela per-user unread pentru ambii useri
  if ($final_id > 0) {
    // Sender (post_author / current user) → 0 to read (a trimis)
    $sql_sender = $wpdb->prepare(
      "INSERT INTO $table_read (post_id, user_id, nr_to_read, created_at, created_by)
       VALUES (%d, %d, 0, NOW(), %d)
       ON DUPLICATE KEY UPDATE
         nr_to_read = 0,
         updated_at = NOW(),
         updated_by = VALUES(created_by)",
      $final_id, $user_id, $user_id
    );
    vogo_error_log3("##############SQL UPSERT READ (sender=0): $sql_sender");
    $wpdb->query($sql_sender);

    // Recipient (chat_user_id) → 1 to read (încă nu a văzut)
    $sql_rcpt = $wpdb->prepare(
      "INSERT INTO $table_read (post_id, user_id, nr_to_read, created_at, created_by)
       VALUES (%d, %d, 1, NOW(), %d)
       ON DUPLICATE KEY UPDATE
         nr_to_read = 1,
         updated_at = NOW(),
         updated_by = VALUES(created_by)",
      $final_id, $chat_user_id, $user_id
    );
    vogo_error_log3("##############SQL UPSERT READ (rcpt=1): $sql_rcpt");
    $wpdb->query($sql_rcpt);
  }

  vogo_error_log3("[STEP 9] Thread start/update result: $result | ID: $final_id | IP: $ip | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response(['success' => $result !== false, 'thread_id' => $final_id], 200);
}

function vogo_get_forum_discussions_by_user(WP_REST_Request $request){
  global $wpdb;
  $table=$wpdb->prefix.'vogo_forum_post'; $table_read=$wpdb->prefix.'vogo_forum_post_no_to_read';
  $raw=file_get_contents('php://input'); $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id; $user_id=(int)$user_id;
  $d=json_decode($raw,true)??[]; $type=strtoupper(trim($d['POST_TYPE']??'CHAT'));
  $page=max(1,(int)($d['current_page']??($d['page']??1))); $per=max(1,(int)($d['per_page']??($d['limit']??20))); $off=($page-1)*$per;

  if($type==='CHAT'){
    $qInner="
      SELECT p.ID,p.post_author,p.chat_user_id,p.post_title,p.post_content,p.post_status,p.post_date,
             COALESCE(p.last_answer_datetime,p.post_date) last_answer_datetime,
             r.nr_to_read my_nr_to_read,
             CASE WHEN p.post_author=%d THEN p.chat_user_id
                  WHEN p.chat_user_id=%d THEN p.post_author
                  ELSE NULL END other_user_id
      FROM $table p
      LEFT JOIN $table_read r ON r.post_id=p.ID AND r.user_id=%d
      WHERE p.post_status='active' AND p.chat_user_id IS NOT NULL AND (p.post_author=%d OR p.chat_user_id=%d)
    ";
    $sqlTotal=$wpdb->prepare("SELECT COUNT(*) FROM ($qInner) x WHERE x.other_user_id IS NOT NULL",$user_id,$user_id,$user_id,$user_id,$user_id);
    $sqlData =$wpdb->prepare("SELECT x.*, 'CHAT' type FROM ($qInner) x WHERE x.other_user_id IS NOT NULL ORDER BY x.last_answer_datetime DESC LIMIT %d OFFSET %d",$user_id,$user_id,$user_id,$user_id,$user_id,$per,$off);
  } elseif($type==='FORUM'){
    $sqlTotal=$wpdb->prepare("SELECT COUNT(*) FROM $table p WHERE p.post_status='active' AND p.chat_user_id IS NULL AND p.post_author=%d",$user_id);
    $sqlData =$wpdb->prepare("
      SELECT p.ID,p.post_author,p.chat_user_id,p.post_title,p.post_content,p.post_status,p.post_date,
             COALESCE(p.last_answer_datetime,p.post_date) last_answer_datetime,
             r.nr_to_read my_nr_to_read,NULL other_user_id,'FORUM' type
      FROM $table p
      LEFT JOIN $table_read r ON r.post_id=p.ID AND r.user_id=%d
      WHERE p.post_status='active' AND p.chat_user_id IS NULL AND p.post_author=%d
      ORDER BY COALESCE(p.last_answer_datetime,p.post_date) DESC
      LIMIT %d OFFSET %d",$user_id,$user_id,$per,$off);
  } else return new WP_REST_Response(['success'=>false,'error'=>'POST_TYPE must be CHAT or FORUM'],400);

  $total=(int)$wpdb->get_var($sqlTotal); if($wpdb->last_error) return new WP_REST_Response(['success'=>false,'error'=>'SQL error (total)','sql_error'=>$wpdb->last_error],500);
  $rows=$wpdb->get_results($sqlData,ARRAY_A); if($wpdb->last_error) return new WP_REST_Response(['success'=>false,'error'=>'SQL error (data)','sql_error'=>$wpdb->last_error],500);

  $out=[]; foreach($rows as $r){
    $other_id=(int)($r['other_user_id']??0);
    if($type==='CHAT'){
      if($other_id===0||$other_id===$user_id){
        $pa=(int)$r['post_author']; $cu=(int)$r['chat_user_id'];
        $other_id=($pa===$user_id)?$cu:(($cu===$user_id)?$pa:0);
        if($other_id===0||$other_id===$user_id) continue;
      }
    }

    $other_name=''; $other_avatar='';
    if($type==='CHAT'){ $u=get_userdata($other_id); if($u){ $other_name=$u->user_login; $other_avatar=get_avatar_url($other_id); } }

    $nr_to_read=(int)($r['my_nr_to_read']??0);
    // chat_show_title: first 10 chars from username_chat, add "..." if longer, then " - " + post_title
    if($type==='CHAT'){
      $uname=$other_name?:''; $uname_short=mb_substr($uname,0,10,'UTF-8');
      $ellipsis = (mb_strlen($uname,'UTF-8')>10)?'...':'';
      $chat_show_title = trim($uname_short.$ellipsis.' - '.(string)$r['post_title']);
    } else {
      $chat_show_title = mb_substr((string)$r['post_title'],0,10,'UTF-8'); // FORUM fallback
    }

    $out[]=[
      'id'                   => (int)$r['ID'],
      'type'                 => $r['type'],
      'post_status'          => $r['post_status'],
      'post_title'           => $r['post_title'],
      'post_content'         => $r['post_content'],
      'post_date'            => $r['post_date'],
      'last_answer_datetime' => $r['last_answer_datetime'],
      'nr_to_read'           => $nr_to_read,
      'user_chat_id'         => ($type==='CHAT')? $other_id : null,
      'username_chat'        => ($type==='CHAT')? $other_name : null,
      'user_chat_avatar'     => ($type==='CHAT')? $other_avatar : null,
      'chat_show_title'      => $chat_show_title
    ];
  }

  return new WP_REST_Response([
    'success'=>true,
    'userId'=>$user_id,
    'current_page'=>$page,
    'per_page'=>$per,
    'total_pages'=> ($per>0)?(int)ceil($total/$per):0,
    'total_items'=>$total,
    'discussions'=>$out
  ],200);
}


function support_get_random_user(WP_REST_Request $request){
  global $wpdb; $table=$wpdb->prefix.'support_users';
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $raw_input=file_get_contents('php://input');
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id))return $user_id;
  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: ".DB_NAME);

  $sql="SELECT user_id,nickname FROM $table WHERE available=1 and nickname like '%mihai%' ORDER BY RAND() LIMIT 1";
  vogo_error_log3("##############SQL: $sql");
  $row=$wpdb->get_row($sql,ARRAY_A);

  if($wpdb->last_error){
    vogo_error_log3("[STEP 1] SQL error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'SQL error','sql_error'=>$wpdb->last_error],500);
  }
  if(!$row){
    vogo_error_log3("[STEP 2] No available support user found | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'No available support user found'],404);
  }

  $caller=get_userdata($user_id); $caller_name=$caller?$caller->user_login:'';
  vogo_error_log3("[STEP 3] Random support user fetched | support_user_id={$row['user_id']} | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'success'=>true,
    'userId'=>$user_id,
    'userName'=>$caller_name,
    'support_user'=>['user_id'=>intval($row['user_id']),'nickname'=>$row['nickname']]
  ],200);
}

// get discussion details by id (with per-user nr_to_read)
function vogo_get_forum_discussion_by_id(WP_REST_Request $request) {
  global $wpdb;

  // STEP 1: Extract IP, user and DB
  $ip      = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  $db = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db | IP: $ip | User: $user_id | Start get_forum_discussion_by_id");

  // STEP 2: Extract discussion ID
  $params        = $request->get_json_params();
  $discussion_id = intval($params['id'] ?? 0);
  if ($discussion_id <= 0) {
    vogo_error_log3("[STEP 2] Invalid discussion_id received: $discussion_id | IP: $ip | User: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid discussion_id'], 400);
  }

  // STEP 3: Query forum post by ID + JOIN per-user read table
  $table_post = $wpdb->prefix . "vogo_forum_post";
  $table_read = $wpdb->prefix . "vogo_forum_post_no_to_read";

  $sql = $wpdb->prepare("
    SELECT p.*,
           r.nr_to_read AS my_nr_to_read
      FROM $table_post p
 LEFT JOIN $table_read r
        ON r.post_id = p.ID
       AND r.user_id = %d
     WHERE p.ID = %d
     LIMIT 1
  ", $user_id, $discussion_id);

  $discussion = $wpdb->get_row($sql, ARRAY_A);
  vogo_error_log3("[STEP 3] SQL executed: $sql | IP: $ip | User: $user_id");
  vogo_error_log3("[STEP 4] SQL result: " . json_encode($discussion) . " | IP: $ip | User: $user_id");

  if (!$discussion || !isset($discussion['ID'])) {
    vogo_error_log3("[STEP 5] No discussion found for ID: $discussion_id | IP: $ip | User: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid discussion_id'], 400);
  }

  // STEP 5.1: Normalize per-user nr_to_read (fallback 0 if null)
  $nr_to_read = isset($discussion['my_nr_to_read']) ? intval($discussion['my_nr_to_read']) : 0;

  // STEP 6: Add username and avatar info (author)
  $user = get_user_by('id', intval($discussion['post_author'] ?? 0));
  $post_username       = $user ? $user->user_login : 'unknown';
  $post_username_short = substr($post_username, 0, 10);
  $first_letter        = strtolower(substr($post_username, 0, 1));
  $color_list          = ['red', 'blue', 'green', 'orange', 'purple', 'teal', 'cyan', 'yellow'];
  $post_icon_color     = $color_list[ord($first_letter) % count($color_list)];

  $discussion['post_username']       = $post_username;
  $discussion['post_username_short'] = $post_username_short;
  $discussion['post_icon_letter']    = $first_letter;
  $discussion['post_icon_color']     = $post_icon_color;

  // (optional) include și per-user unread în obiectul rezultat
  $discussion['nr_to_read'] = $nr_to_read;

  // STEP 7: Return result (include per-user nr_to_read la top level)
  return new WP_REST_Response([
    'success'        => true,
    'user_id'        => $user_id,
    'discussion_id'  => $discussion_id,
    'nr_to_read'     => $nr_to_read,   // ← per-user unread din tabela nouă
    'result'         => $discussion
  ], 200);
}

function vogo_edit_forum_discussion_by_id(WP_REST_Request $request) {
    clear_debug_log_file();
  global $wpdb; $table = $wpdb->prefix . 'vogo_forum_post';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $active_db = DB_NAME;

  $user_id_result = extract_user_from_jwt_token($request);
  if ($user_id_result instanceof WP_REST_Response) return $user_id_result;
  $user_id = $user_id_result;

  vogo_error_log3("[STEP 1] ACTIVE DB: $active_db | IP: $ip | USER: $user_id | Edit forum discussion");

  $data = $request->get_json_params();
  $discussion_id = intval($data['discussion_id'] ?? 0);
  $post_title = sanitize_text_field($data['post_title'] ?? '');
  $post_status = sanitize_text_field($data['post_status'] ?? '');
  $post_content = sanitize_textarea_field($data['post_content'] ?? '');
  $mesaj = sanitize_textarea_field($data['mesaj'] ?? '');  

  if ($discussion_id <= 0 || !$post_title || !$post_content) {
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid or missing fields'], 400);
  }

  $sql = $wpdb->prepare("SELECT post_author FROM $table WHERE ID = %d LIMIT 1", $discussion_id);
  $existing_author = $wpdb->get_var($sql);
  if (!$existing_author || (int)$existing_author !== $user_id) {
     vogo_error_log3("[STEP 1.5] Discussion ID $discussion_id SECURITY - Access denied | existing_author: $existing_author | USER: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Access denied'], 403);
  }

    $now = current_time('mysql');
    $update_result = $wpdb->update(
    $table,
    [
        'post_title'         => $post_title,
        'post_content'       => $post_content,
        'post_status'       => $post_status,
        'mesaj'              => $mesaj,      
        'post_modified_date' => $now,
        'post_modified_user' => $user_id
    ],
    ['ID' => $discussion_id],
    ['%s', '%s', '%s', '%s', '%d'], // 🛠️ 4 stringuri + 1 integer
    ['%d']
    );

  if ($update_result === false) {
    return new WP_REST_Response(['success' => false, 'error' => 'DB update failed', 'details' => $wpdb->last_error], 500);
  }

  vogo_error_log3("[STEP 2] Discussion ID $discussion_id updated successfully | IP: $ip | USER: $user_id");
  return new WP_REST_Response(['success' => true, 'discussion_id' => $discussion_id], 200);
}

function vogo_insert_forum_post_answer(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $module='forum_post_answer';
  $ip=$_SERVER['REMOTE_ADDR']??'unknown';
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  $user=get_userdata($user_id); $user_login=$user? $user->user_login:'unknown';
  vogo_error_log3("VOGO_LOG_START | [$module]");
  vogo_error_log3("[STEP 1] ACTIVE DB:$active_db | IP:$ip | USER:$user_id/$user_login | Start insert answer",$module);

  // [ADI-ADD] Rate limit guard (non-breaking)
  if(function_exists('vogo_rate_limit') && vogo_rate_limit('forum_post_answer')){
    vogo_error_log3("[STEP 2] Rate limit exceeded | IP:$ip | USER:$user_id",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'Rate limit exceeded','user_id'=>$user_id,'user_login'=>$user_login],429);
  }

  $data=$request->get_json_params(); vogo_error_log3("[STEP 2] Raw JSON payload: ".wp_json_encode($data),$module);

  $parent_id=intval($data['PARENT_ID_vogo_forum_post'] ?? 0);
  $post_status=sanitize_text_field($data['post_status'] ?? 'active');
  $post_answer=sanitize_textarea_field($data['post_answer'] ?? '');
  $post_content=sanitize_textarea_field($data['post_content'] ?? '');
  $mesaj=sanitize_textarea_field($data['mesaj'] ?? '');
  $post_image=sanitize_text_field($data['post_image'] ?? '');
  $post_mime=sanitize_text_field($data['post_mime_type'] ?? '');
  $client_msg_id=sanitize_text_field($data['client_message_id'] ?? '');

  // acceptăm orice payload cu parent_id > 0
  if($parent_id<=0){
    vogo_error_log3("[STEP 2.1] Invalid parent_id=$parent_id | IP:$ip | USER:$user_id",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'Invalid parent_id','user_id'=>$user_id,'user_login'=>$user_login],400);
  }
  // [ADI-ADD] Extra payload validation (non-breaking): require at least mesaj OR post_answer OR post_image
  if($mesaj==='' && $post_answer==='' && $post_image===''){
    vogo_error_log3("[STEP 2.1] Invalid payload content (empty message) | parent_id=$parent_id | IP:$ip | USER:$user_id",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'Invalid payload content','user_id'=>$user_id,'user_login'=>$user_login],400);
  }

  // load parent
  $table_parent=$wpdb->prefix.'vogo_forum_post';
  $parent=$wpdb->get_row($wpdb->prepare("SELECT ID, post_author, chat_user_id FROM $table_parent WHERE ID=%d",$parent_id),ARRAY_A);
  vogo_error_log3("##############SQL: SELECT ID, post_author, chat_user_id FROM $table_parent WHERE ID=$parent_id",$module);
  if(!$parent){
    vogo_error_log3("[STEP 2.2] Parent not found | parent_id=$parent_id",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'Parent not found','user_id'=>$user_id,'user_login'=>$user_login],404);
  }

  $post_author=(int)$parent['post_author']; $chat_user_id=(int)$parent['chat_user_id'];
  // [ADI-ADD] Permission check (non-breaking): only participants can post
  if($user_id!==$post_author && $user_id!==$chat_user_id){
    vogo_error_log3("[STEP 2.4] Permission denied | parent_id=$parent_id | user=$user_id",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'permission_denied','user_id'=>$user_id,'user_login'=>$user_login],403);
  }
  $to_user_id=($user_id===$post_author)?$chat_user_id:$post_author;

  $now=current_time('mysql');
  $table=$wpdb->prefix.'vogo_forum_post_answer';
  $insert=[
    'PARENT_ID_vogo_forum_post'=>$parent_id,
    'post_author'=>$user_id,
    'post_answer'=>$post_answer,
    'post_status'=>$post_status,
    'post_content'=>$post_content,
    'post_date'=>$now,
    'mesaj'=>$mesaj,
    'comment_count'=>0,
    'post_image'=>$post_image,
    'post_mime_type'=>$post_mime,
    'created_at'=>$now,
    'created_user'=>$user_id,
    'modified_at'=>$now,
    'modified_user'=>$user_id,
    'message_type'=>'CHAT',
    'direction'=>'outgoing',
    'call_status'=>'',
    'missed_call'=>0,
    'call_id'=>0,
    'channel_name'=>'',
    'video_audio_duration'=>0,
    'call_duration_seconds'=>0,
    'is_video'=>0,
    'is_audio'=>0,
    'to_user_id'=>$to_user_id,
    'filename'=>'',
    'file_mime'=>'',
    'file_size'=>0,
    'file_url'=>'',
    'message_status'=>'SENT',
    'delivered_at'=>null,
    'read_at'=>null,
    'client_message_id'=>$client_msg_id,
    'edited_at'=>null,
    'edited_by'=>0,
    'deleted_at'=>null,
    'deleted_by'=>0
  ];

  $res=$wpdb->insert($table,$insert);
  if(!$res){
    vogo_error_log3("[STEP 3] DB insert failed | Error: {$wpdb->last_error}",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'DB insert failed','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
  }
  $inserted_id=$wpdb->insert_id;
  vogo_error_log3("[STEP 4] Insert OK | ID:$inserted_id",$module);

  // update parent last_answer_datetime
  $wpdb->update($table_parent,
    ['last_answer_datetime'=>$now,'post_modified_date'=>$now,'post_modified_user'=>$user_id],
    ['ID'=>$parent_id],
    ['%s','%s','%d'],['%d']
  );
  vogo_error_log3("##############SQL: UPDATE $table_parent SET last_answer_datetime='$now' WHERE ID=$parent_id",$module);

  // [ADI-ADD] Unread counters (centralized)
  handle_chat_nr_to_read($user_id, $parent_id);

  vogo_error_log3("VOGO_LOG_END | [$module]");
  return new WP_REST_Response(['success'=>true,'insert_id'=>$inserted_id,'user_id'=>$user_id,'user_login'=>$user_login],201);
}


// with video calls (duration from wp_thread_calls, fallback to post_date)
function chat_get_answers_by_post_id(WP_REST_Request $request){
  global $wpdb;
  $tA = $wpdb->prefix.'vogo_forum_post_answer';
  $tP = $wpdb->prefix.'vogo_forum_post';
  $tR = $wpdb->prefix.'vogo_forum_post_no_to_read';
  $tC = $wpdb->prefix.'thread_calls';

  $user_id = extract_user_from_jwt_token($request); if (is_wp_error($user_id)) return $user_id; $user_id = (int)$user_id;

  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  $post_id = (int)($data['post_id'] ?? $request->get_param('post_id') ?? 0);
  if (!$post_id || !$user_id) return new WP_REST_Response(['success'=>false,'error'=>'Missing post_id or auth'],400);

  $parent = $wpdb->get_row($wpdb->prepare("SELECT ID, post_author, chat_user_id FROM $tP WHERE ID=%d",$post_id), ARRAY_A);
  if (!$parent) return new WP_REST_Response(['success'=>false,'error'=>'Thread not found'],404);

  $from_id = (int)$parent['post_author'];
  $to_id   = (int)$parent['chat_user_id'];
  if ($user_id !== $from_id && $user_id !== $to_id) return new WP_REST_Response(['success'=>false,'error'=>'permission_denied'],403);

  $wpdb->query($wpdb->prepare(
    "INSERT INTO $tR (post_id,user_id,nr_to_read,created_at,created_by)
     VALUES (%d,%d,0,NOW(),%d)
     ON DUPLICATE KEY UPDATE nr_to_read=0,updated_at=NOW(),updated_by=VALUES(created_by)",
    $post_id,$user_id,$user_id
  ));
  $my_nr_to_read = (int)($wpdb->get_var($wpdb->prepare(
    "SELECT nr_to_read FROM $tR WHERE post_id=%d AND user_id=%d LIMIT 1",$post_id,$user_id
  )) ?? 0);

  $sql = "
    SELECT
      CAST(a.ID AS CHAR)                                        AS ID,
      a.PARENT_ID_vogo_forum_post                               AS PARENT_ID_vogo_forum_post,
      CAST(a.post_author AS CHAR)                               AS post_author,
      a.post_answer, a.post_status, a.post_content, a.post_date, a.mesaj, a.comment_count,
      a.created_at, a.created_user, a.modified_at, a.modified_user,
      a.post_image, a.post_mime_type, a.post_modified_date, a.post_modified_user,
      CASE 
        WHEN a.message_type='VIDEO' THEN 'Video call'
        WHEN a.message_type='VOICE' THEN 'Voice call'
        WHEN a.message_type='FILE'  THEN 'FILE'
        WHEN a.message_type='SYSTEM' THEN 'SYSTEM'
        ELSE 'ANSWER'
      END                                                       AS type,
      CASE 
        WHEN a.message_type IN ('VIDEO','VOICE') THEN COALESCE(c.status, a.call_status, '')
        ELSE COALESCE(a.message_status, '')
      END                                                       AS status,
      COALESCE(a.direction,'')                                  AS direction,
      CAST(
        CASE 
          WHEN a.message_type IN ('VIDEO','VOICE') THEN
            GREATEST(
              0,
              COALESCE(
                UNIX_TIMESTAMP(COALESCE(c.end, NOW())) - UNIX_TIMESTAMP(c.start),
                UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(a.post_date),
                0
              )
            )
          ELSE 0
        END
      AS CHAR)                                                  AS duration_seconds,
      CASE WHEN a.message_type='VIDEO' THEN '1' ELSE '0' END    AS is_video,
      CASE WHEN a.message_type='VOICE' THEN '1' ELSE '0' END    AS is_audio,
      a.filename, a.file_mime, a.file_size, a.file_url,
      a.to_user_id, a.delivered_at, a.read_at, a.client_message_id,
      a.call_id, a.channel_name, a.missed_call
    FROM $tA a
    LEFT JOIN $tC c ON c.id = a.call_id
    WHERE a.PARENT_ID_vogo_forum_post = %d
      AND a.post_status = 'active'
    ORDER BY a.post_date ASC
  ";
  $items = $wpdb->get_results($wpdb->prepare($sql,$post_id), ARRAY_A);
  if ($wpdb->last_error) return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500);

  return new WP_REST_Response([
    'success'      => true,
    'nr_to_read'   => $my_nr_to_read,
    'answers'      => $items,
    'from_user_id' => $from_id,
    'to_user_id'   => $to_id,
  ], 200);
}


function vogo_chat_upload_document(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'unknown';
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: (multipart upload) | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: $active_db");

  // [STEP 1] Route params validation
  $module=sanitize_key($request['module']??''); $submodule=sanitize_key($request['submodule']??''); $reference_id=intval($request['reference_id']??0);
  vogo_error_log3("[STEP 1.1] Route params: module=$module, submodule=$submodule, reference_id=$reference_id | IP: $ip | USER: $user_id");

  if(!$module||!$submodule||$reference_id<=0){ vogo_error_log3("[STEP 1] Invalid route params: module=$module, submodule=$submodule, reference_id=$reference_id | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'Invalid route parameters'],400);
  }

  // [STEP 2] File presence & meta
  if(!isset($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK){
    vogo_error_log3("[STEP 2] No file or upload error code: ".($_FILES['file']['error']??'N/A')." | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'No file uploaded or error'],400);
  }
  $file=$_FILES['file']; $original_file_name=$file['name']; $filename=sanitize_file_name($file['name']); $file_mime_type=$file['type']??''; $filesize=intval($file['size']??0);
  vogo_error_log3("[STEP 2.1] FILE meta: name=$original_file_name, type=$file_mime_type, size=$filesize | IP: $ip | USER: $user_id");

  // [STEP 3] Build target paths (unique name)
  $upload_dir=wp_upload_dir(); $basedir=trailingslashit($upload_dir['basedir']); $baseurl=trailingslashit($upload_dir['baseurl']);
  $base_dir=$basedir."vogo-documents/$module/$submodule/$user_id/"; if(!wp_mkdir_p($base_dir)){ vogo_error_log3("[STEP 3] Failed to create folder $base_dir | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Could not create folder'],500); }
  $filename=wp_unique_filename($base_dir,$filename); $server_path="vogo-documents/$module/$submodule/$user_id/$filename"; $target_path=$base_dir.$filename; $upload_url=$baseurl.$server_path;

  // [STEP 4] Move uploaded file
  if(!move_uploaded_file($file['tmp_name'],$target_path)){ vogo_error_log3("[STEP 4] File move failed to $target_path | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Upload failed'],500); }

  // [STEP 5] Insert into documents table
  $docs_table=$wpdb->prefix.'vogo_documents';
  $now=current_time('mysql');
  $ins=$wpdb->insert($docs_table,[
    'module'=>$module,'submodule'=>$submodule,'reference_id'=>$reference_id,'user_id'=>$user_id,'server_path'=>$server_path,'file_name'=>$filename,'file_type'=>$file_mime_type,'file_size'=>$filesize,'created_at'=>$now,'created_user'=>$user_id,'modified_at'=>$now,'modified_user'=>$user_id
  ],['%s','%s','%d','%d','%s','%s','%s','%d','%s','%d','%s','%d']);
  vogo_error_log3("##############SQL: INSERT INTO $docs_table (module,submodule,reference_id,...) VALUES ('$module','$submodule',$reference_id,...)");
  if(!$ins){ vogo_error_log3("[STEP 5.1] DB insert failed: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB insert failed','sql_error'=>$wpdb->last_error],500);
  }
  $doc_id=$wpdb->insert_id; vogo_error_log3("[STEP 5.2] Document inserted | doc_id=$doc_id | IP: $ip | USER: $user_id");

  // [STEP 6] Mirror into forum thread as an answer message when route is /forum/post
$forum_answer_id=null;
if($module==='forum' && $submodule==='post'){
  $forum_table=$wpdb->prefix.'vogo_forum_post_answer';
  $ins2=$wpdb->insert($forum_table,[
    'PARENT_ID_vogo_forum_post'=>$reference_id,'post_author'=>$user_id,'post_answer'=>'','post_status'=>'active','post_content'=>'#FILE#:'.$upload_url,'post_date'=>$now,'mesaj'=>$original_file_name,'comment_count'=>0,'post_image'=>$upload_url,'post_mime_type'=>$file_mime_type,'created_at'=>$now,'created_user'=>$user_id,'modified_at'=>$now,'modified_user'=>$user_id
  ],['%d','%d','%s','%s','%s','%s','%s','%d','%s','%s','%s','%d','%s','%d']);
  vogo_error_log3("##############SQL: INSERT INTO $forum_table (PARENT_ID_vogo_forum_post,post_author,post_content,post_date,mesaj,post_image,post_mime_type,...) VALUES ($reference_id,$user_id,'#FILE#:{$upload_url}','$now','$original_file_name','$upload_url','$file_mime_type',...)");
  if($ins2===false){ vogo_error_log3("[STEP 6.1] Insert forum_post_answer failed: {$wpdb->last_error} | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Insert forum answer failed','sql_error'=>$wpdb->last_error],500); }
  $forum_answer_id=$wpdb->insert_id; vogo_error_log3("[STEP 6.2] Forum answer inserted | answer_id=$forum_answer_id | thread_id=$reference_id | IP: $ip | USER: $user_id");

  // [STEP 6.3] Update parent thread last_answer_datetime
  $parent_table=$wpdb->prefix.'vogo_forum_post';
  $upd=$wpdb->update($parent_table,['last_answer_datetime'=>$now,'post_modified_date'=>$now,'post_modified_user'=>$user_id],['ID'=>$reference_id],['%s','%s','%d'],['%d']);
  vogo_error_log3("##############SQL: UPDATE $parent_table SET last_answer_datetime='$now', post_modified_date='$now', post_modified_user=$user_id WHERE ID=$reference_id");
  if($upd===false){ vogo_error_log3("[STEP 6.4] Parent update failed: {$wpdb->last_error} | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Failed to update parent last_answer_datetime','sql_error'=>$wpdb->last_error],500); }
}

// [ADI-ADD] Unread counters (centralized)
handle_chat_nr_to_read($user_id, $reference_id);


  // [STEP 7] Build response
  $caller=get_userdata($user_id); $caller_name=$caller?$caller->user_login:'';
  vogo_error_log3("[STEP 7] Upload OK | doc_id=$doc_id | forum_answer_id=".($forum_answer_id??'NULL')." | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'success'=>true,
    'userId'=>$user_id,
    'userName'=>$caller_name,
    'inserted_id'=>$doc_id,
    'forum_answer_id'=>$forum_answer_id,
    'module'=>$module,
    'submodule'=>$submodule,
    'reference_id'=>$reference_id,
    'server_path'=>$server_path,
    'file_url'=>$upload_url,
    'file_name'=>$original_file_name,
    'file_type'=>$file_mime_type,
    'file_size'=>$filesize
  ],200);
}
