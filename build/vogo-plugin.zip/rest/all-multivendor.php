<?php
$MODULE_PHP='all-multivendor.php';
/**
 * VOGO API MULTIVENDOR
 * All routes use JWT security via vogo_permission_check
 * Rules: POST only, compact code, ergonomic, SQL preference where possible
 */

// ===================== Register routes =====================
add_action('rest_api_init', function(){
  register_rest_route('vogo/v1','/provider/my-orders',[
    'methods'=>'POST','callback'=>'provider_my_orders','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/provider/my-order-items',[
    'methods'=>'POST','callback'=>'provider_my_order_items','permission_callback'=>'vogo_permission_check'
  ]);
});

/**
 * provider_my_orders
 * Returns paginated list of vendor summaries for the current provider user.
 */
function provider_my_orders(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP:$ip | USER:unknown"); vogo_error_log3("ACTIVE DB: $active_db");
  $raw=file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw | IP:$ip | USER:unknown");

  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  $user = get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
  $vendor_id = get_vendor_id_for_user($user_id);
  if(!$vendor_id) return new WP_REST_Response(['success'=>false,'error'=>'No vendor mapped to this user','user_id'=>$user_id,'user_login'=>$user_login],403);

  $p = $request->get_json_params() ?: [];
  $page = max(1, intval($p['page'] ?? 1)); $per = min(100, max(1, intval($p['per_page'] ?? 20)));
  $offset = ($page-1)*$per;

  $table = $wpdb->prefix.'order_vendor';
  $sql = $wpdb->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM $table WHERE vendor_id=%d AND status='active' ORDER BY id DESC LIMIT %d OFFSET %d", $vendor_id, $per, $offset);
  vogo_error_log3("##############SQL: $sql"); $rows = $wpdb->get_results($sql, ARRAY_A);
  $total = (int)$wpdb->get_var("SELECT FOUND_ROWS()");
  if($wpdb->last_error){ vogo_error_log3("[STEP ERR] SQL error: ".$wpdb->last_error." | IP:$ip | USER:$user_id"); }

  $resp = ['success'=>true,'user_id'=>$user_id,'user_login'=>$user_login,'vendor_id'=>$vendor_id,'page'=>$page,'per_page'=>$per,'total'=>$total,'data'=>$rows];
  vogo_error_log3("VOGO_LOG_END | IP:$ip | USER:$user_id"); return new WP_REST_Response($resp,200);
}

/**
 * provider_my_order_items
 * Returns the order items belonging to the current vendor for a given order_id.
 */
function provider_my_order_items(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP:$ip | USER:unknown"); vogo_error_log3("ACTIVE DB: $active_db");
  $raw=file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw | IP:$ip | USER:unknown");

  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  $user = get_user_by('id',$user_id); $user_login=$user?$user->user_login:'unknown';
  $vendor_id = get_vendor_id_for_user($user_id);
  if(!$vendor_id) return new WP_REST_Response(['success'=>false,'error'=>'No vendor mapped to this user','user_id'=>$user_id,'user_login'=>$user_login],403);

  $p = $request->get_json_params() ?: []; $order_id = intval($p['order_id'] ?? 0);
  if($order_id<=0) return new WP_REST_Response(['success'=>false,'error'=>'order_id is required','user_id'=>$user_id,'user_login'=>$user_login],400);

  $order = wc_get_order($order_id); if(!$order) return new WP_REST_Response(['success'=>false,'error'=>'Order not found','user_id'=>$user_id,'user_login'=>$user_login],404);

  $items = [];
  foreach($order->get_items() as $item_id=>$item){
    $vid = intval($item->get_meta('_vendor_id'));
    if($vid === $vendor_id){
      $product = $item->get_product();
      $items[] = [
        'item_id'      => $item_id,
        'product_id'   => $product ? $product->get_id() : 0,
        'name'         => $item->get_name(),
        'qty'          => (int)$item->get_quantity(),
        'subtotal'     => (float)$item->get_subtotal(),
        'total'        => (float)$item->get_total(),
        'tax'          => (float)$item->get_total_tax(),
        'meta'         => $item->get_meta_data(), // optional
      ];
    }
  }

  $resp = ['success'=>true,'user_id'=>$user_id,'user_login'=>$user_login,'vendor_id'=>$vendor_id,'order_id'=>$order_id,'items'=>$items];
  vogo_error_log3("VOGO_LOG_END | IP:$ip | USER:$user_id"); return new WP_REST_Response($resp,200);
}
