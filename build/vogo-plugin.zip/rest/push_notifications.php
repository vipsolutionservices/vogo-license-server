<?php

// ======================
// PUSH NOTIFICATIONS (Firebase FCM)
// ======================

// Custom user order notifications
function custom_order_push_notification($order_id = '', $user_id, $message = '') {
    global $wpdb;
    try {
        if (get_user_meta($user_id, 'device_token', true) != '') {
            $token  = get_user_meta($user_id, 'device_token', true); 
            $order_id = $order_id;

            if (!empty($order_id)) {
                // Check for duplicate notifications
                $sql = "SELECT * FROM custom_notification WHERE user_id='" . $user_id . "' AND order_id='" . $order_id . "'";
                $checkorder_data = $wpdb->get_results($sql, ARRAY_A);
                $count = $wpdb->num_rows;

                if ($count == 0) {
                    $jsonString = sendPushNotification($token, $message, $order_id, '');

                    if (isset($jsonString['status']) && $jsonString['status'] === true) {
                        $add_date = date('Y-m-d H:i:s');
                        $query5 = $wpdb->prepare(
                            "INSERT INTO `custom_notification`(`user_id`, `order_id`, `order_status`,`message`, `add_date`) VALUES (%d,%s,'Processing',%s,%s)", 
                            $user_id, $order_id, $message, $add_date
                        );
                        $wpdb->query($query5);
                    }
                }
            } else {
                // For notifications without order_id
                $jsonString = sendPushNotification($token, $message, '', '');
            }
        }
    } catch (Exception $e) {
        // Fail silently
    }
    return true;
}

// Custom Send Push notifications message
function sendPushNotification($token, $message, $order_id, $accessToken = NULL) {
    try {
        $url = "https://fcm.googleapis.com/v1/projects/vogo-family/messages:send";
        if (empty($accessToken)) {
            $accessToken = getFirebaseAccessToken();
        }      

        if (!$accessToken) {
            return ['status' => false, 'error' => 'Failed to obtain access token'];
        }

        $fields = [
            'message' => [
                'token' => $token,
                'notification' => [
                    'title' => 'Vogofamily',
                    'body' => $message,
                ],
                'data' => [
                    'order_id' => (string) $order_id,
                ],
                'android' => [
                    'priority' => 'high',
                ],
                'apns' => [
                    'payload' => [
                        'aps' => [
                            'alert' => [
                                'title' => 'Vogofamily',
                                'body' => $message,
                            ],
                            'content_available' => true,
                            'sound' => 'default',
                        ],
                    ],
                ],
            ],
        ];
        
        $responses = makePostRequest($url, $fields, $accessToken);
        return $responses;
    } catch (Exception $e) {
        return ['status' => false, 'error' => $e->getMessage()];
    }
}

// Custom Firebase Access Token functions
function getFirebaseAccessToken() {
    try {
        $serviceAccountFile = WP_CONTENT_DIR . '/notification/vogo-testing-firebase.json';
        if (!file_exists($serviceAccountFile)) {
            return false;
        }
        
        $credentials = json_decode(file_get_contents($serviceAccountFile), true);     
        $now = time();
        $payload = [
            "iss" => $credentials['client_email'],
            "scope" => "https://www.googleapis.com/auth/cloud-platform",
            "aud" => "https://oauth2.googleapis.com/token",
            "iat" => $now,
            "exp" => $now + 3600 // 1 hour
        ];

        $jwt = encodeJWT($payload, $credentials['private_key']);
        $tokenUrl = "https://oauth2.googleapis.com/token";
        $tokenResponse = makePostRequest($tokenUrl, [
            "grant_type" => "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion" => $jwt
        ], null);

        if (!$tokenResponse['status'] || !isset($tokenResponse['response']['access_token'])) {
            return false;
        }
        return $tokenResponse['response']['access_token'];
    } catch (Exception $e) {
        return false;
    }
}

function encodeJWT($payload, $privateKey) {    
    $header = ["alg" => "RS256", "typ" => "JWT"];
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($header)));
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));
    $signature = '';
    openssl_sign($base64UrlHeader . "." . $base64UrlPayload, $signature, $privateKey, OPENSSL_ALGO_SHA256);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

function makePostRequest($url, $data, $accessToken) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    if (curl_errno($ch)) {
        return ['status' => false, 'error' => curl_error($ch)];
    }
    curl_close($ch);

    $responseData = json_decode($response, true);
    return ['status' => true, 'response' => $responseData];
}

	function custom_notification_dynamic_log($data, $prefix = 'debug') {
		// Get the child theme directory
		$theme_dir = get_stylesheet_directory();
		
		// Create a dynamic filename with prefix, timestamp, and random number
		$filename = $prefix . '-' . time() . '-' . rand(1000, 9999) . '.txt';
		
		// Full path for the log file in the child theme directory
		$log_file = $theme_dir . '/' . $filename;
		
		// Get current time in WordPress format
		$time = current_time('mysql'); // e.g., 2025-04-08 12:34:56
		
		// Format the log entry with the provided data
		$log_entry = '[' . $time . '] Data: ' . print_r($data, true) . PHP_EOL;
		
		// Write the log entry to the file (append if it exists)
		if (file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX) === false) {
			// Fallback to PHP error log if writing fails
			error_log('Failed to write to dynamic log file: ' . $log_file);
		}
		
		// Set file permissions (optional, for security/readability)
		if (file_exists($log_file)) {
			chmod($log_file, 0644); // Readable by owner and group, writable by owner
		}
		
		return $log_file; // Return the file path for reference if needed
	}