<?php

$MODULE_PHP='all-checkout.php';

add_action('rest_api_init', function () {
    register_rest_route('vogo/v1', '/checkout/options', ['methods'=>'POST','callback'=>'custom_checkout_options','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/totals', ['methods'=>'POST','callback'=>'custom_checkout_totals','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/apply-coupon', ['methods'=>'POST','callback'=>'custom_checkout_apply_coupon','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/remove-coupon', ['methods'=>'POST','callback'=>'custom_checkout_remove_coupon','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/save_order_shipment', ['methods'=>'POST','callback'=>'save_order_shipment','permission_callback'=>'is_user_customer_connected']);
 
});

function custom_checkout_totals(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 0 – JWT (hard)
  $user_id = extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;
  if(is_wp_error($user_id)){ return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR0.JWT','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name]; }

  // STEP 1 – Cart
  if(is_null(WC()->cart)) wc_load_cart();
  reset_cart($user_id);
  $cart_count = WC()->cart->get_cart_contents_count(); $module=$module.'.cart_items:'.$cart_count;
  if(!$cart_count){
    return ['success'=>false,'error'=>'Cart empty','user_id'=>$user_id,'module'=>$module.'-ERR1.CART_EMPTY','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 2 – Input
  $p = $request->get_json_params();
  $addr_in = isset($p['address']) && is_array($p['address']) ? $p['address'] : [];
  $rate_id = sanitize_text_field($p['shipping_rate_id'] ?? '');
  $country = $addr_in['country']  ?? (get_user_meta($user_id,'billing_country',true) ?: 'RO');
  $state   = $addr_in['state']    ?? get_user_meta($user_id,'billing_state',true);
  $postcode= $addr_in['postcode'] ?? get_user_meta($user_id,'billing_postcode',true);
  $city    = $addr_in['city']     ?? get_user_meta($user_id,'billing_city',true);
  $module=$module.'.ctry:'.$country.'.state:'.$state.'.pc:'.$postcode.'.city:'.$city.'.rate:'.$rate_id;

  // STEP 3 – Set customer location + calc shipping
  WC()->customer->set_billing_location($country,$state,$postcode,$city);
  WC()->customer->set_shipping_location($country,$state,$postcode,$city);
  WC()->customer->save();
  WC()->cart->calculate_totals();
  $packages = WC()->cart->get_shipping_packages();
  WC()->shipping()->calculate_shipping($packages);

  // STEP 4 – Apply chosen shipping (safe fallback)
  $chosen = WC()->session->get('chosen_shipping_methods',[]);
  if(!is_array($chosen)) $chosen=[];
  $found=false;
  foreach(WC()->shipping()->get_packages() as $pi=>$pkg){
    if($rate_id && isset($pkg['rates'][$rate_id])){ $chosen[$pi]=$rate_id; $found=true; }
    else { $prev = isset($chosen[$pi]) ? $chosen[$pi] : ''; $chosen[$pi]=$prev; }
  }
  WC()->session->set('chosen_shipping_methods',$chosen);
  WC()->cart->calculate_totals();

  // STEP 5 – Build totals
  $totals = WC()->cart->get_totals();
  $resp_totals = [
    'subtotal'        => wc_format_decimal($totals['subtotal'],2),
    'shipping_total'  => wc_format_decimal($totals['shipping_total'],2),
    'discount_total'  => wc_format_decimal($totals['discount_total'],2),
    'total_tax'       => wc_format_decimal($totals['total_tax'],2),
    'total'           => wc_format_decimal($totals['total'],2),
    'currency'        => get_woocommerce_currency()
  ];
  $module=$module.'.found_rate:'.($found?'1':'0').'.grand:'.$resp_totals['total'];

  // STEP 6 – Response
  return [
    'success'                => true,
    'module'                 => $module.'.TEND',
    'jwt_user_id'            => $jwt_user_id,
    'jwt_user_name'          => $jwt_user_name,
    'user_id'                => $user_id,
    'rate_applied'           => $found ? $rate_id : null,
    'chosen_shipping_methods'=> WC()->session->get('chosen_shipping_methods',[]),
    'totals'                 => $resp_totals
  ];
}


function custom_checkout_options(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;

  // STEP 0.0
  $jwt_user_id=null; $jwt_user_name='unknown';
  try{
    $jwt_candidate=extract_user_from_jwt_token($request);
    if(!($jwt_candidate instanceof WP_REST_Response)){
      $jwt_id=(int)$jwt_candidate; if($jwt_id>0){ $ju=get_userdata($jwt_id); if($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  }catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  // STEP 1
  $user_id=extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;
  if(is_wp_error($user_id)){ return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR']; }

  // STEP 2
  if(is_null(WC()->cart)) wc_load_cart();
  $cart_count=WC()->cart->get_cart_contents_count(); $module=$module.'.cart_items:'.$cart_count;
  if(!$cart_count){ return ['success'=>false,'error'=>'Cart empty','user_id'=>$user_id,'jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name,'module'=>$module.'-ERR']; }

  // STEP 3
  $u=get_user_by('id',$user_id); $email=$u?$u->user_email:'';
  $addr=[
    'first_name'=>get_user_meta($user_id,'billing_first_name',true),
    'last_name'=>get_user_meta($user_id,'billing_last_name',true),
    'email'=>$email,
    'phone'=>get_user_meta($user_id,'billing_phone',true),
    'address_1'=>get_user_meta($user_id,'billing_address_1',true),
    'address_2'=>get_user_meta($user_id,'billing_address_2',true),
    'city'=>get_user_meta($user_id,'billing_city',true),
    'state'=>get_user_meta($user_id,'billing_state',true),
    'postcode'=>get_user_meta($user_id,'billing_postcode',true),
    'country'=>get_user_meta($user_id,'billing_country',true)?:'RO'
  ];
  $module=$module.'.ctry:'.$addr['country'].'.state:'.$addr['state'].'.pc:'.$addr['postcode'].'.city:'.$addr['city'];
  $address_ok=!empty($addr['first_name'])&&!empty($addr['address_1'])&&!empty($addr['city'])&&!empty($addr['postcode'])&&!empty($addr['country']);

  // STEP 4
  WC()->customer->set_billing_location($addr['country'],$addr['state'],$addr['postcode'],$addr['city']);
  WC()->customer->set_shipping_location($addr['country'],$addr['state'],$addr['postcode'],$addr['city']);
  WC()->customer->save();
  WC()->cart->calculate_totals();
  WC()->shipping()->calculate_shipping(WC()->cart->get_shipping_packages());

  // STEP 5
  $packages=WC()->shipping()->get_packages();
  $shipping_options=[]; $pkg_count=is_array($packages)?count($packages):0; $module=$module.'.pkg:'.$pkg_count;
  foreach($packages as $pi=>$pkg){
    $rates=isset($pkg['rates'])?$pkg['rates']:[];
    $rlist=[];
    foreach($rates as $rid=>$rate){
      $rlist[]=[
        'rate_id'=>$rid,
        'method_id'=>$rate->method_id,
        'instance_id'=>isset($rate->instance_id)?(int)$rate->instance_id:0,
        'label'=>$rate->get_label(),
        'cost'=>wc_format_decimal($rate->cost,2),
        'taxes'=>array_map(function($t){return wc_format_decimal($t,2);},(array)$rate->taxes),
        'meta_data'=>$rate->get_meta_data()
      ];
    }
    $shipping_options[]=[
      'package_id'=>$pi,
      'contents_cost'=>wc_format_decimal(isset($pkg['contents_cost'])?$pkg['contents_cost']:0,2),
      'destination'=>$pkg['destination'],
      'rates'=>$rlist
    ];
    $module=$module.'.pkg'.$pi.'_rates:'.count($rlist);
  }
  $shipping_options[]=[
    'package_id'=>'manual',
    'contents_cost'=>'0.00',
    'destination'=>$addr,
    'rates'=>[
      ['rate_id'=>'direct','method_id'=>'direct','instance_id'=>0,'label'=>'Direct','cost'=>'10.00','taxes'=>[],'meta_data'=>[]],
      ['rate_id'=>'fan','method_id'=>'fan','instance_id'=>0,'label'=>'FAN Curier','cost'=>'19.00','taxes'=>[],'meta_data'=>[]],
      ['rate_id'=>'sameday','method_id'=>'sameday','instance_id'=>0,'label'=>'SameDay Curier','cost'=>'20.00','taxes'=>[],'meta_data'=>[]],
      ['rate_id'=>'urgent','method_id'=>'urgent','instance_id'=>0,'label'=>'Urgent','cost'=>'50.00','taxes'=>[],'meta_data'=>[]],
      ['rate_id'=>'intercity','method_id'=>'intercity','instance_id'=>0,'label'=>'InterCity','cost'=>'80.00','taxes'=>[],'meta_data'=>[]],
      ['rate_id'=>'electronic','method_id'=>'electronic','instance_id'=>0,'label'=>'Electronic','cost'=>'0.00','taxes'=>[],'meta_data'=>[]]
    ]
  ];

  // STEP 6
  $payments=[]; $all=WC()->payment_gateways()->payment_gateways(); $available=[];
  foreach($all as $id=>$gw){ if(($gw->enabled==='yes') && $gw->is_available()){ $available[$id]=$gw; } }
  foreach($available as $id=>$gw){
    $desc_raw=(string)$gw->get_option('description',''); $icon_raw=$gw->get_icon(); $icon_url='';
    if(is_string($icon_raw)){
      if(preg_match('/src=["\']([^"\']+)["\']/', $icon_raw, $m)){ $icon_url=$m[1]; }
      elseif(filter_var($icon_raw,FILTER_VALIDATE_URL)){ $icon_url=$icon_raw; }
    }
    $payments[]=[
      'id'=>(string)$id,
      'title'=>(string)$gw->get_title(),
      'description'=>$desc_raw?wp_strip_all_tags($desc_raw):'',
      'icon'=>$icon_url,
      'has_fields'=>(bool)$gw->has_fields,
      'supports'=>is_array($gw->supports)?array_values($gw->supports):[],
      'enabled'=>true,
      'is_available'=>true,
      'order_button_text'=>$gw->order_button_text??'Place order'
    ];
  }
  $module=$module.'.payments:'.count($payments);

  // STEP 7
  return [
    'success'=>true,
    'module'=>$module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,
    'jwt_user_name'=>$jwt_user_name,
    'user_id'=>$user_id,
    'address_ok'=>$address_ok,
    'address'=>$addr,
    'shipping_packages'=>$shipping_options,
    'payment_methods'=>$payments
  ];
}


function custom_checkout_apply_coupon(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 0 – JWT (hard)
  $user_id = extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;
  if(is_wp_error($user_id)){ return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR0.JWT','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name]; }

  // STEP 1 – Cart
  if(is_null(WC()->cart)) wc_load_cart();
  reset_cart($user_id);
  $cart_count = WC()->cart->get_cart_contents_count(); $module=$module.'.cart_items:'.$cart_count;
  if(!$cart_count){
    return ['success'=>false,'error'=>'Cart empty','user_id'=>$user_id,'module'=>$module.'-ERR1.CART_EMPTY','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 2 – Input
  $p = $request->get_json_params();
  $code = isset($p['coupon_code']) ? wc_format_coupon_code(wp_strip_all_tags($p['coupon_code'])) : '';
  $addr_in = isset($p['address']) && is_array($p['address']) ? $p['address'] : [];
  $rate_id = sanitize_text_field($p['shipping_rate_id'] ?? '');
  $module=$module.'.coupon:'.($code?:'NONE').'.rate:'.$rate_id;

  if(!$code){
    return ['success'=>false,'error'=>'coupon_code required','user_id'=>$user_id,'module'=>$module.'-ERR2.NOCODE','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 3 – Set customer location (opțional, dacă e furnizată adresă)
  $country = $addr_in['country']  ?? (get_user_meta($user_id,'billing_country',true) ?: 'RO');
  $state   = $addr_in['state']    ?? get_user_meta($user_id,'billing_state',true);
  $postcode= $addr_in['postcode'] ?? get_user_meta($user_id,'billing_postcode',true);
  $city    = $addr_in['city']     ?? get_user_meta($user_id,'billing_city',true);
  WC()->customer->set_billing_location($country,$state,$postcode,$city);
  WC()->customer->set_shipping_location($country,$state,$postcode,$city);
  WC()->customer->save();

  // STEP 4 – Apply coupon (safe idempotent)
  $already = WC()->cart->get_applied_coupons();
  if(!in_array($code,$already,true)){
    $ok = WC()->cart->apply_coupon($code);
    // dacă $ok==false, Woo a pus notice intern; considerăm eroare generică
    if(!$ok){
      // încercăm să detectăm existent dar invalid/expirat
      return ['success'=>false,'error'=>'Coupon not applicable','user_id'=>$user_id,'module'=>$module.'-ERR3.APPLY_FAIL','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name,'applied_coupons'=>$already];
    }
  }

  // STEP 5 – Recalc shipping (dacă rate_id furnizat) + totals
  WC()->cart->calculate_totals();
  $packages = WC()->cart->get_shipping_packages();
  WC()->shipping()->calculate_shipping($packages);
  $chosen = WC()->session->get('chosen_shipping_methods',[]);
  if(!is_array($chosen)) $chosen=[];
  $found=false;
  foreach(WC()->shipping()->get_packages() as $pi=>$pkg){
    if($rate_id && isset($pkg['rates'][$rate_id])){ $chosen[$pi]=$rate_id; $found=true; }
    else { $prev = isset($chosen[$pi]) ? $chosen[$pi] : ''; $chosen[$pi]=$prev; }
  }
  WC()->session->set('chosen_shipping_methods',$chosen);
  WC()->cart->calculate_totals();

  // STEP 6 – Totals + coupons list
  $totals = WC()->cart->get_totals();
  $resp_totals = [
    'subtotal'        => wc_format_decimal($totals['subtotal'],2),
    'shipping_total'  => wc_format_decimal($totals['shipping_total'],2),
    'discount_total'  => wc_format_decimal($totals['discount_total'],2),
    'total_tax'       => wc_format_decimal($totals['total_tax'],2),
    'total'           => wc_format_decimal($totals['total'],2),
    'currency'        => get_woocommerce_currency()
  ];
  $applied = WC()->cart->get_applied_coupons();
  $module=$module.'.found_rate:'.($found?'1':'0').'.grand:'.$resp_totals['total'].'.applied:'.count($applied);

  // STEP 7 – Response
  return [
    'success'                 => true,
    'module'                  => $module.'.TEND',
    'jwt_user_id'             => $jwt_user_id,
    'jwt_user_name'           => $jwt_user_name,
    'user_id'                 => $user_id,
    'applied_coupons'         => $applied,
    'chosen_shipping_methods' => WC()->session->get('chosen_shipping_methods',[]),
    'totals'                  => $resp_totals
  ];
}

function custom_checkout_remove_coupon(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 0 – JWT (hard)
  $user_id = extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;
  if(is_wp_error($user_id)){ return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR0.JWT','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name]; }

  // STEP 1 – Cart
  if(is_null(WC()->cart)) wc_load_cart();
  reset_cart($user_id);
  $cart_count = WC()->cart->get_cart_contents_count(); $module=$module.'.cart_items:'.$cart_count;
  if(!$cart_count){
    return ['success'=>false,'error'=>'Cart empty','user_id'=>$user_id,'module'=>$module.'-ERR1.CART_EMPTY','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 2 – Input
  $p = $request->get_json_params();
  $code = isset($p['coupon_code']) ? wc_format_coupon_code(wp_strip_all_tags($p['coupon_code'])) : '';
  $module=$module.'.coupon:'.($code?:'NONE');
  if(!$code){
    return ['success'=>false,'error'=>'coupon_code required','user_id'=>$user_id,'module'=>$module.'-ERR2.NOCODE','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 3 – Remove coupon (safe idempotent)
  $applied_before = WC()->cart->get_applied_coupons();
  if(in_array($code,$applied_before,true)){
    $ok = WC()->cart->remove_coupon($code);
    if(!$ok){
      return ['success'=>false,'error'=>'Failed removing coupon','user_id'=>$user_id,'module'=>$module.'-ERR3.REMOVE_FAIL','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name,'applied_coupons'=>$applied_before];
    }
  }

  // STEP 4 – Recalculate totals
  WC()->cart->calculate_totals();

  // STEP 5 – Totals + coupons list
  $totals = WC()->cart->get_totals();
  $resp_totals = [
    'subtotal'        => wc_format_decimal($totals['subtotal'],2),
    'shipping_total'  => wc_format_decimal($totals['shipping_total'],2),
    'discount_total'  => wc_format_decimal($totals['discount_total'],2),
    'total_tax'       => wc_format_decimal($totals['total_tax'],2),
    'total'           => wc_format_decimal($totals['total'],2),
    'currency'        => get_woocommerce_currency()
  ];
  $applied = WC()->cart->get_applied_coupons();
  $module=$module.'.grand:'.$resp_totals['total'].'.applied:'.count($applied);

  // STEP 6 – Response
  return [
    'success'         => true,
    'module'          => $module.'.TEND',
    'jwt_user_id'     => $jwt_user_id,
    'jwt_user_name'   => $jwt_user_name,
    'user_id'         => $user_id,
    'applied_coupons' => $applied,
    'totals'          => $resp_totals
  ];
}


function save_order_shipment(WP_REST_Request $request){
  global $wpdb;

  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;  

  // Extract JWT user
  $p = $request->get_json_params();
  $user_id = extract_user_from_jwt_token($request);
  if (is_wp_error($user_id)) return $user_id;
  $user = get_user_by('ID', $user_id);
  $user_login = $user ? $user->user_login : '';

  //audit for response
  $module=$module.'.jwt_user_id:'.$user_id.'.jwt_username:'.$user_login;   

  // Validate input
  $order_id = intval($p['order_id'] ?? 0);
  $addr_id  = intval($p['shipment_address_id'] ?? 0);
  $module=$module.'.addr_id:'.$addr_id;
  $module=$module.'.order_id:'.$order_id;  
  if ($order_id <= 0 || $addr_id <= 0) {
    return new WP_REST_Response([
      'success'=>false,'error'=>'missing_or_invalid_params', 'module' => $module.'-ES1',
      'user_id'=>$user_id,'user_login'=>$user_login
    ],400);
  }

// STEP 1.1 – Validate Woo order exists and belongs to JWT user
$po = $wpdb->prefix.'posts';
$pm = $wpdb->prefix.'postmeta';
$sqlOrder = $wpdb->prepare("
  SELECT p.ID
  FROM `$po` p
  LEFT JOIN `$pm` m ON m.post_id=p.ID AND m.meta_key='_customer_user'
  WHERE p.ID=%d
    AND p.post_type in ('shop_order','shop_order_placehold')
    AND p.post_status NOT IN('trash','auto-draft')
    AND (CAST(m.meta_value AS UNSIGNED)=%d OR p.post_author=%d)
  LIMIT 1
", $order_id, $user_id, $user_id);
$order_row = $wpdb->get_var($sqlOrder);

if (!$order_row) {
  return new WP_REST_Response([
    'success'=>false,
    'error'=>'order_not_found_or_forbidden',
    'module'=>$module.'-ES1'.$sqlOrder,
    'user_id'=>$user_id,'user_login'=>$user_login
  ],404);
}

  

// Load address owned by current user (safe: no unknown columns in SQL)
$ta = $wpdb->prefix.'user_addresses';
$sqlA = $wpdb->prepare("
  SELECT * FROM `$ta`
  WHERE id=%d AND user_id=%d
    AND (status IS NULL OR TRIM(LOWER(status))='active')
  LIMIT 1
", $addr_id, $user_id);

$row = $wpdb->get_row($sqlA, ARRAY_A);
if (!$row) {
  return new WP_REST_Response([
    'success'=>false,'error'=>'address_not_found','module'=>$module.'-ES1',
    'user_id'=>$user_id,'user_login'=>$user_login
  ],404);
}
if (intval($row['user_id']) !== $user_id) {
  return new WP_REST_Response([
    'success'=>false,'error'=>'forbidden_address','module'=>$module.'-ES1',
    'user_id'=>$user_id,'user_login'=>$user_login
  ],403);
}

// Normalize fields to snapshot schema
$addr = [
  'first_name'  => $row['first_name']  ?? '',
  'last_name'   => $row['last_name']   ?? '',
  'company'     => $row['company']     ?? '',
  'address_1'   => $row['address_1']   ?? ($row['street_address']   ?? ''),
  'address_2'   => $row['address_2']   ?? ($row['street_address_2'] ?? ''),
  'city'        => $row['city']        ?? '',
  'state_name'  => $row['state_name']  ?? ($row['county'] ?? ''),
  'postcode'    => $row['postcode']    ?? ($row['address_code'] ?? ''),
  'country_name'=> $row['country_name']?? ($row['country'] ?? ''),
  'phone'       => $row['phone']       ?? '',
  'email'       => $row['email']       ?? '',
  'lat'         => $row['lat']         ?? ($row['latitude']  ?? null),
  'long'        => $row['long']        ?? ($row['longitude'] ?? null),
];


  // Upsert shipment snapshot
  $t = $wpdb->prefix.'vogo_order_shipment_tbl';
  $data = [
    'order_id'=>$order_id,'shipment_address_id'=>$addr_id,
    'first_name'=>$addr['first_name']??null,'last_name'=>$addr['last_name']??null,'company'=>$addr['company']??null,
    'address_1'=>$addr['address_1']??null,'address_2'=>$addr['address_2']??null,'city'=>$addr['city']??null,
    'state_name'=>$addr['state_name']??null,'postcode'=>$addr['postcode']??null,'country_name'=>$addr['country_name']??null,
    'phone'=>$addr['phone']??null,'email'=>$addr['email']??null,'lat'=>$addr['lat']??null,'long'=>$addr['long']??null,
    'modified_by'=>$user_id
  ];
  $cols = array_keys($data);
  $placeholders = array_fill(0, count($cols), '%s');
  $types = ['order_id'=>'%d','shipment_address_id'=>'%d','lat'=>'%f','long'=>'%f','modified_by'=>'%d'];
  foreach($cols as $i=>$c){ if(isset($types[$c])) $placeholders[$i]=$types[$c]; }
  $insert_cols = '`'.implode('`,`',$cols).'`';
  $insert_vals = $wpdb->prepare('('.implode(',', $placeholders).')', array_values($data));
  $updates = [];
  foreach($cols as $c){ if($c==='order_id') continue; $updates[]="`$c`=VALUES(`$c`)"; }
  $sqlUp = "INSERT INTO `$t` ($insert_cols) VALUES $insert_vals ON DUPLICATE KEY UPDATE ".implode(',', $updates).", modified_at=CURRENT_TIMESTAMP";

  $ok = $wpdb->query($sqlUp);
  if ($ok === false) {
    return new WP_REST_Response([
      'success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'module' => $module.'-ES1',
      'user_id'=>$user_id,'user_login'=>$user_login
    ],500);
  }

  // Return insert_id or modified_id
  $insert_id = $wpdb->insert_id;
  if (!$insert_id){
    $row = $wpdb->get_row($wpdb->prepare("SELECT id FROM `$t` WHERE order_id=%d",$order_id));
    $modified_id = $row ? intval($row->id) : 0;
    return ['success'=>true,'modified_id'=>$modified_id,'user_id'=>$user_id,'module' => $module.'OK','user_login'=>$user_login];
  }
  return ['success'=>true,'insert_id'=>intval($insert_id),'user_id'=>$user_id,'module' => $module.'OK','user_login'=>$user_login];
}


