<?php
/**
 * VOGO API Endpoint Registration (Adi-tehnic style)
 * All routes use JWT security via vogo_permission_check
 * Rules: POST only, compact code, ergonomic, SQL preference where possible
 */

$MODULE_PHP='all-cart.php';

add_action('rest_api_init', function () {
    register_rest_route('vogo/v1', '/cart/addtocart', ['methods'=>'POST','callback'=>'custom_addtocart','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/cartlist', ['methods'=>'POST','callback'=>'custom_cartlist','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/cartlist_count', ['methods'=>'POST','callback'=>'cartlist_count','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/remove-product-cart', ['methods'=>'POST','callback'=>'custom_remove_product_cart','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/update-cart', ['methods'=>'POST','callback'=>'custom_update_cart','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/empty-cart', ['methods'=>'POST','callback'=>'custom_empty_cart','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/checkout', ['methods'=>'POST','callback'=>'custom_checkout','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1', '/cart/coupons', ['methods'=>'POST','callback'=>'get_woocommerce_coupons','permission_callback'=>'vogo_permission_check']);
    register_rest_route('vogo/v1','/cart/complementary_products',['methods'=>'POST','callback'=>'cart_complementary_products','permission_callback'=>'vogo_permission_check']);    
});

/**
 * Add product to cart
 */
function custom_addtocart(WP_REST_Request $request){
    global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
    $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");
    $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
    $product_id=intval($p['product_id']??0); $qty=intval($p['quantity']??1); if($qty<=0)$qty=1;
    if($product_id<=0) return ['success'=>false,'error'=>'Invalid product_id','user_id'=>$user_id];
    $product=wc_get_product($product_id); if(!$product||!$product->is_in_stock()) return ['success'=>false,'error'=>'Product not available','user_id'=>$user_id];
    include_once WC_ABSPATH.'includes/wc-cart-functions.php'; include_once WC_ABSPATH.'includes/class-wc-cart.php'; if(is_null(WC()->cart)) wc_load_cart();
    reset_cart($user_id); $cart_key=WC()->cart->add_to_cart($product_id,$qty,0,[]); if(empty($cart_key)) return ['success'=>false,'error'=>'Could not add product','user_id'=>$user_id];
    vogo_sync_persistent_cart($user_id);
    vogo_error_log3("[STEP 1] Product $product_id added successfully | cart_key:$cart_key | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END");
    return ['success'=>true,'message'=>'Product added','user_id'=>$user_id,'user_login'=>wp_get_current_user()->user_login,'insert_id'=>$cart_key];
}

/**
 * Get user cart list
 */
function custom_cartlist(WP_REST_Request $request){
    global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
    $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");
    $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
    if(is_null(WC()->cart)) wc_load_cart(); reset_cart($user_id); $cart=WC()->cart->get_cart();
    $cart_data=[]; $using_fallback=false;
    if(empty($cart)){ $cart_data=vogo_get_persistent_cart_data($user_id); if(!empty($cart_data['cart'])){$cart=$cart_data['cart']; $using_fallback=true;} }
    if(empty($cart)) return ['success'=>false,'message'=>'Cart empty','user_id'=>$user_id];
    $products=[]; $fallback_subtotal=0; $fallback_qty=0;
    foreach($cart as $key=>$item){$pid=intval($item['product_id']??0); if($pid<=0){ vogo_error_log3("[STEP 1.1] Skipping cart item with invalid product_id | key:$key | raw:".json_encode($item)); continue; } $prod=wc_get_product($pid); if(!$prod){ vogo_error_log3("[STEP 1.2] Skipping cart item with missing product | product_id:$pid | key:$key"); continue; } $qty=intval($item['quantity']??1); if($qty<=0)$qty=1;
        // --- vendor lookup (by product_id) ---
        $t_pv = $wpdb->prefix.'product_vendor';
        $t_vp = $wpdb->prefix.'vogo_providers';
        $sql_vendor = "SELECT pv.vendor_id, vp.provider_name FROM $t_pv pv LEFT JOIN $t_vp vp ON vp.id=pv.vendor_id WHERE pv.product_id=%d LIMIT 1";
        $q_vendor = $wpdb->prepare($sql_vendor, $pid);
        vogo_error_log3("##############SQL: $q_vendor");
        $vend = $wpdb->get_row($q_vendor, ARRAY_A);
        $vendor_id = $vend ? (int)$vend['vendor_id'] : null;
        $vendor_name = ($vend && !empty($vend['provider_name'])) ? $vend['provider_name'] : 'vogo';
        // -------------------------------------
        $price=$prod->get_price(); $fallback_subtotal+=((float)$price*$qty); $fallback_qty+=$qty;
        $products[]=['title'=>$prod->get_name(),'cart_key'=>$item['key']??$key,'product_id'=>$pid,'quantity'=>$qty,'price'=>$price,'regular_price'=>$prod->get_regular_price(),'sale_price'=>$prod->get_sale_price(),'image'=>get_the_post_thumbnail_url($pid,'full')?:'','vendor_id'=>$vendor_id,'vendor_name'=>$vendor_name];
    }
    vogo_error_log3("[STEP 1] Cart list built with ".count($products)." items | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END");
    $cart_subtotal=$using_fallback?number_format((float)$fallback_subtotal,2,'.',''):WC()->cart->subtotal_ex_tax;
    $shipping_total=$using_fallback?0:WC()->cart->get_shipping_total();
    $discount_amount=$using_fallback?0:WC()->cart->get_discount_total();
    $vat=$using_fallback?0:WC()->cart->get_taxes_total();
    $cart_total=$using_fallback?number_format((float)$fallback_subtotal,2,'.',''):WC()->cart->total;
    $total_qty=$using_fallback?$fallback_qty:WC()->cart->get_cart_contents_count();
    if(!$using_fallback && $total_qty !== $fallback_qty){
        vogo_error_log3("[STEP 1.3] Qty mismatch in cart list | items:".count($products)." | list_qty:$fallback_qty | wc_qty:$total_qty | raw_count:".count($cart)." | IP:$ip | USER:$user_id");
    }
    return ['success'=>true,'message'=>'Cart retrieved','user_id'=>$user_id,'user_login'=>wp_get_current_user()->user_login,'data'=>$products,'cart_subtotal'=>$cart_subtotal,'shipping_total'=>$shipping_total,'discount_amount'=>$discount_amount,'vat'=>$vat,'cart_total'=>$cart_total,'total_cart_qty'=>$total_qty];
}


/**
 * Remove product from cart
 */
function custom_remove_product_cart(WP_REST_Request $request){
    global $wpdb; 
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; 
    vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");

    $p=$request->get_json_params(); 
    vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");

    $user_id=extract_user_from_jwt_token($request); 
    if(is_wp_error($user_id)) return $user_id;

    $cart_key=sanitize_text_field($p['cart_key']??''); 
    $product_id=intval($p['product_id']??0);

    if(empty($cart_key) && $product_id<=0){
        vogo_error_log3("[STEP 1] Missing cart_key/product_id | IP:$ip | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return ['success'=>false,'error'=>'Missing cart_key or product_id','user_id'=>$user_id];
    }

    if(is_null(WC()->cart)) wc_load_cart(); reset_cart($user_id);
    $removed=false;

    // STEP 2: Try by cart_key
    if(!empty($cart_key) && isset(WC()->cart->cart_contents[$cart_key])){
        $removed=WC()->cart->remove_cart_item($cart_key);
        vogo_error_log3("[STEP 2] Attempt remove by cart_key=$cart_key | IP:$ip | USER:$user_id");
    }

    // STEP 3: Fallback by product_id
    if(!$removed && $product_id>0){
        foreach(WC()->cart->get_cart() as $key=>$item){
            if($item['product_id']==$product_id){
                $removed=WC()->cart->remove_cart_item($key);
                $cart_key=$key;
                vogo_error_log3("[STEP 3] Attempt remove by product_id=$product_id with key=$key | IP:$ip | USER:$user_id");
                break;
            }
        }
    }

    if(!$removed){
        vogo_error_log3("[STEP 4] Remove failed | prod:$product_id key:$cart_key | IP:$ip | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return ['success'=>false,'error'=>'Remove failed','user_id'=>$user_id];
    }

    do_action('woocommerce_cart_updated'); 
    vogo_sync_persistent_cart($user_id);
    vogo_error_log3("[STEP 5] Cart item removed successfully | prod:$product_id key:$cart_key | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");

    return ['success'=>true,'message'=>'Item removed','user_id'=>$user_id,'user_login'=>wp_get_current_user()->user_login,'modified_id'=>$cart_key];
}

/**
 * Update cart quantity
 */
function custom_update_cart(WP_REST_Request $request){
    global $wpdb; 
    $MODULE_PHP=basename(__FILE__);
    $module = $MODULE_PHP . '.'.__FUNCTION__;
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; 
    vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");

    $p=$request->get_json_params(); 
    vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");

    $user_id=extract_user_from_jwt_token($request); 
    if(is_wp_error($user_id)) return $user_id;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response        

    $product_id=intval($p['product_id']??0); 
    $cart_key=sanitize_text_field($p['cart_key']??''); 
    $qty=intval($p['quantity']??1);

    $module=$module.'.product_id:'.$product_id;
    $module=$module.'.cart_key:'.$cart_key;
    $module=$module.'.qty:'.$qty;

    if($product_id<=0) 
        return ['success'=>false,'error'=>'Missing product_id','user_id'=>$user_id];

    if(is_null(WC()->cart)) wc_load_cart();

    $updated=false;
    // STEP 1: Try with given cart_key
    if(!empty($cart_key) && isset(WC()->cart->cart_contents[$cart_key])){
        $updated=WC()->cart->set_quantity($cart_key,$qty,true)!==false;
        vogo_error_log3("[STEP 1] Update attempted by cart_key=$cart_key | IP:$ip | USER:$user_id");
    }

    // STEP 2: Fallback by product_id if cart_key failed
    if(!$updated){
        foreach(WC()->cart->get_cart() as $key=>$item){
            if($item['product_id']==$product_id){
                $updated=WC()->cart->set_quantity($key,$qty,true)!==false;
                $cart_key=$key;
                vogo_error_log3("[STEP 2] Update attempted by product_id=$product_id with key=$key | IP:$ip | USER:$user_id");
                break;
            }
        }
    }

    if(!$updated){
        vogo_error_log3("[STEP 3] Update failed | prod:$product_id qty:$qty | IP:$ip | USER:$user_id");
        vogo_error_log3("VOGO_LOG_END");
        return ['success'=>false,'module' => $module.'-ES1','error'=>'Update failed','user_id'=>$user_id];
    }

    do_action('woocommerce_cart_updated'); 
    vogo_sync_persistent_cart($user_id);
    vogo_error_log3("[STEP 4] Cart updated successfully | prod:$product_id qty:$qty | key:$cart_key | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");

    $cartlist_payload = custom_cartlist($request);
    if($cartlist_payload instanceof WP_REST_Response){ $cartlist_payload = $cartlist_payload->get_data(); }
    $cartcount_payload = cartlist_count($request);
    if($cartcount_payload instanceof WP_REST_Response){ $cartcount_payload = $cartcount_payload->get_data(); }
    if(function_exists('custom_checkout_totals')){
        $totals_payload = custom_checkout_totals($request);
        if($totals_payload instanceof WP_REST_Response){ $totals_payload = $totals_payload->get_data(); }
    } else {
        WC()->cart->calculate_totals();
        $totals = WC()->cart->get_totals();
        $totals_payload = [
            'success'=>true,
            'user_id'=>$user_id,
            'totals'=>[
                'subtotal'=>wc_format_decimal($totals['subtotal'],2),
                'shipping_total'=>wc_format_decimal($totals['shipping_total'],2),
                'discount_total'=>wc_format_decimal($totals['discount_total'],2),
                'total_tax'=>wc_format_decimal($totals['total_tax'],2),
                'total'=>wc_format_decimal($totals['total'],2),
                'currency'=>get_woocommerce_currency()
            ]
        ];
    }

    return [
        'success'=>true,
        'module' => $module.'.TEND',
        'message'=>'Cart updated',
        'user_id'=>$user_id,
        'user_login'=>wp_get_current_user()->user_login,
        'modified_id'=>$cart_key,
        'cart'=>$cartlist_payload,
        'checkout_totals'=>$totals_payload,
        'cartlist_count'=>$cartcount_payload
    ];
}

/**
 * Empty cart
 */
function custom_empty_cart(WP_REST_Request $request){
    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  
  
  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    

    global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
    $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");
    $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
    if(is_null(WC()->cart)) wc_load_cart(); delete_user_meta($user_id,'applied_coupons'); WC()->cart->empty_cart(true); vogo_clear_persistent_cart($user_id);
    vogo_error_log3("[STEP 1] Cart emptied | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END");
    return ['success'=>true,'module' => $module.'.TEND','message'=>'Cart emptied','user_id'=>$user_id,'user_login'=>wp_get_current_user()->user_login];
}

function custom_checkout(WP_REST_Request $request){
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;

  $jwt_user_id=null; $jwt_user_name='unknown';
  try{ $jwt_candidate=extract_user_from_jwt_token($request); if(!($jwt_candidate instanceof WP_REST_Response)){ $jwt_id=(int)$jwt_candidate; if($jwt_id>0){ $ju=get_userdata($jwt_id); if($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } } } }catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';

  $p=$request->get_json_params();
  $shipping_address_id=isset($p['shipping_address_id'])?(int)$p['shipping_address_id']:0;
  $delivery_option_id=isset($p['delivery_option_id'])?sanitize_text_field($p['delivery_option_id']):'';
  $module=$module.'.shipAddr:'.$shipping_address_id.'.deliv:'.$delivery_option_id;

  $user_raw=extract_user_from_jwt_token($request);
  if($user_raw instanceof WP_REST_Response){ $data=$user_raw->get_data(); $msg=is_array($data)?($data['error']??($data['message']??'jwt_invalid')):'jwt_invalid'; return ['success'=>false,'error'=>'jwt_invalid','error_detail'=>$msg,'user_id'=>null,'user_login'=>null]; }
  if(is_wp_error($user_raw)){ $msg=$user_raw->get_error_message(); return ['success'=>false,'error'=>'jwt_invalid','error_detail'=>$msg,'user_id'=>null,'user_login'=>null]; }
  $user_id=(int)$user_raw; if($user_id<=0){ return ['success'=>false,'error'=>'jwt_missing','user_id'=>null,'user_login'=>null]; }

  $payment_type=sanitize_text_field($p['payment_type']??''); if(empty($payment_type)){ return ['success'=>false,'error'=>'Missing payment_type','user_id'=>$user_id]; }

  if(is_null(WC()->cart)) wc_load_cart(); reset_cart($user_id); if(!WC()->cart->get_cart_contents_count()){ return ['success'=>false,'error'=>'Cart empty','user_id'=>$user_id]; }

  $billing_first_name=get_user_meta($user_id,'billing_first_name',true); if(empty($billing_first_name)){ return ['success'=>false,'error'=>'No billing address','user_id'=>$user_id]; }

  $addr=[
    'first_name'=>$billing_first_name,
    'last_name'=>get_user_meta($user_id,'billing_last_name',true),
    'email'=>wp_get_current_user()->user_email,
    'phone'=>get_user_meta($user_id,'billing_phone',true),
    'address_1'=>get_user_meta($user_id,'billing_address_1',true),
    'address_2'=>get_user_meta($user_id,'billing_address_2',true),
    'city'=>get_user_meta($user_id,'billing_city',true),
    'state'=>get_user_meta($user_id,'billing_state',true),
    'postcode'=>get_user_meta($user_id,'billing_postcode',true),
    'country'=>get_user_meta($user_id,'billing_country',true)?:'RO'
  ];

  $order=wc_create_order(['status'=>'pending','customer_id'=>$user_id]);
  foreach(WC()->cart->get_cart() as $v){
    $order->add_product($v['data'],$v['quantity'],[
      'variation'=>$v['variation'],
      'totals'=>[
        'subtotal'=>$v['line_subtotal'],
        'subtotal_tax'=>$v['line_subtotal_tax'],
        'total'=>$v['line_total'],
        'tax'=>$v['line_tax'],
        'tax_data'=>$v['line_tax_data']
      ]
    ]);
  }

  $order->set_address($addr,'billing'); 
  $order->set_address($addr,'shipping');

  if($shipping_address_id>0){ $order->add_meta_data('_vogo_shipping_address_id',$shipping_address_id,true); }
  if($delivery_option_id!==''){ $order->add_meta_data('_vogo_delivery_option_id',$delivery_option_id,true); }

  $gateways=WC()->payment_gateways->payment_gateways();
  if(isset($gateways[$payment_type])){ $order->set_payment_method($gateways[$payment_type]); } else { return ['success'=>false,'error'=>'Unsupported payment_type','user_id'=>$user_id]; }

  $order->save(); 
  $order->calculate_totals(true);

  vogo_split_order_into_vendor_suborders($order);

  $parent_id=$order->get_id();
  $orders=$wpdb->prefix.'wc_orders';
  $ordmeta=$wpdb->prefix.'wc_orders_meta';
  $providers=$wpdb->prefix.'vogo_providers';

  $children=$wpdb->get_results(
    $wpdb->prepare(
      "SELECT o.id AS child_id, CAST(om.meta_value AS UNSIGNED) AS vendor_id, vp.provider_name AS vendor_name, o.total_amount, o.currency, o.status
       FROM {$orders} o
       INNER JOIN {$ordmeta} om ON om.order_id=o.id AND om.meta_key='_vogo_vendor_id'
       LEFT JOIN {$providers} vp ON vp.id=CAST(om.meta_value AS UNSIGNED)
       WHERE o.parent_order_id=%d
       ORDER BY o.id ASC", $parent_id
    ), ARRAY_A
  );

  vogo_split_order_into_vendor_suborders($order);

  WC()->cart->empty_cart(true);
  WC()->session && WC()->session->set('cart', []);
  delete_user_meta($user_id,'_woocommerce_persistent_cart_'.get_current_blog_id());
  delete_user_meta($user_id,'applied_coupons');

  if($payment_type==='cod'){ $order->update_status('processing','Order placed via mobile app'); custom_order_push_notification($order->get_id(),$user_id); }

  $parent=[
    'id'=>$parent_id,
    'status'=>$order->get_status(),
    'total_amount'=>(float)$order->get_total(),
    'currency'=>strtoupper($order->get_currency()),
    'payment_method'=>(string)$order->get_payment_method(),
    'payment_method_title'=>(string)$order->get_payment_method_title(),
    'shipping_address_id'=>$shipping_address_id,
    'delivery_option_id'=>$delivery_option_id
  ];

  $data=[
    'success'=>true,
    'module'=>$module.'.TEND',
    'message'=>'Order placed',
    'user_id'=>$user_id,
    'user_login'=>wp_get_current_user()->user_login,
    'parent'=>$parent,
    'children'=>$children
  ];

  return new WP_REST_Response($data,200);
}

/**
 * Get active coupons
 */
function get_woocommerce_coupons(WP_REST_Request $request){
    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  
  
  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    


    global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
    $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");
    $coupons=get_posts(['posts_per_page'=>-1,'post_type'=>'shop_coupon','post_status'=>'publish']); $result=[];
    foreach($coupons as $cp){$c=new WC_Coupon($cp->ID); $exp=$c->get_date_expires(); if($exp&&$exp->getTimestamp()<current_time('timestamp')) continue;
        $result[]=['id'=>$c->get_id(),'code'=>$c->get_code(),'amount'=>$c->get_amount(),'discount_type'=>$c->get_discount_type(),'description'=>$c->get_description(),'expiry_date'=>$exp?$exp->date('Y-m-d'):null];}
    vogo_error_log3("[STEP 1] Coupons count=".count($result)." | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END");
    return ['success'=>true,'module' => $module.'.TEND','message'=>'Coupons retrieved','data'=>$result];
}

/**
 * Reset cart helper
 */
function reset_cart($user_id){
    if(!WC()->session){WC()->session=new WC_Session_Handler(); WC()->session->init();}
    if(is_null(WC()->cart)) wc_load_cart();
    $cart_data=vogo_get_persistent_cart_data($user_id); if(empty($cart_data['cart'])) return;
    // Reuse the last synced persistent cart for this user to avoid rebuilding on every request.
    $cart_hash=md5(wp_json_encode($cart_data['cart']));
    $session_user=WC()->session?WC()->session->get('vogo_persistent_cart_user_id'):null;
    $session_hash=WC()->session?WC()->session->get('vogo_persistent_cart_hash'):null;
    // Skip re-sync only when the session already has cart contents for this user and the persistent cart hash matches.
    if($session_user && (int)$session_user===(int)$user_id && $session_hash===$cart_hash && WC()->cart->get_cart_contents_count()>0){
      vogo_error_log3("[STEP 0.2] Cart sync skipped (hash match, session cart present) | USER:$user_id");
      return;
    }
    WC()->cart->empty_cart(true); foreach($cart_data['cart'] as $c){WC()->cart->add_to_cart($c['product_id'],$c['quantity'],$c['variation_id'],$c['variation']??[]);}
    do_action('woocommerce_cart_updated'); WC()->cart->calculate_totals();
    if(WC()->session){WC()->session->set('vogo_persistent_cart_user_id',(int)$user_id); WC()->session->set('vogo_persistent_cart_hash',$cart_hash);}
}

/**
 * Fetch WooCommerce persistent cart data using current blog id, with fallback to blog 1.
 */
function vogo_get_persistent_cart_data($user_id){
    $blog_id=get_current_blog_id();
    $cart_data=get_user_meta($user_id,'_woocommerce_persistent_cart_'.$blog_id,true);
    if(empty($cart_data['cart']) && (int)$blog_id!==1){ $cart_data=get_user_meta($user_id,'_woocommerce_persistent_cart_1',true); }
    return is_array($cart_data)?$cart_data:[];
}

/**
 * Sync WooCommerce persistent cart to user meta (JWT/stateless API support).
 */
function vogo_sync_persistent_cart($user_id){
    if(is_null(WC()->cart)) wc_load_cart();
    if(!WC()->session){WC()->session=new WC_Session_Handler(); WC()->session->init();}
    if(method_exists(WC()->cart,'persistent_cart_update')){ WC()->cart->persistent_cart_update($user_id); }
    $cart_hash=md5(wp_json_encode(WC()->cart->get_cart()));
    if(WC()->session){ WC()->session->set('vogo_persistent_cart_user_id',(int)$user_id); WC()->session->set('vogo_persistent_cart_hash',$cart_hash); }
}

/**
 * Clear WooCommerce persistent cart for user.
 */
function vogo_clear_persistent_cart($user_id){
    delete_user_meta($user_id,'_woocommerce_persistent_cart_'.get_current_blog_id());
    if(WC()->session){ WC()->session->set('vogo_persistent_cart_user_id',null); WC()->session->set('vogo_persistent_cart_hash',null); }
}

/**
 * Split a parent order into vendor suborders (one child per vendor).
 * - Groups items by vendor (wp_product_vendor.product_id -> vendor_id).
 * - Creates child shop_order with post_parent = parent_id.
 * - Copies billing/shipping, payment method, currency, status.
 * - Adds only that vendor's items (preserving line totals & taxes).
 * - Sets child meta: _vogo_vendor_id, and item meta: _vendor_id (compat).
 * - Upserts wp_order_vendor summary (adds column child_order_id if missing).
 */
function vogo_split_order_into_vendor_suborders( WC_Order $parent ){
  if ( ! $parent instanceof WC_Order ) return;



  // Guard: dacă există deja copii, ieșire
global $wpdb;
$has_children = (int) $wpdb->get_var(
  $wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}wc_orders WHERE parent_order_id = %d",
    $parent->get_id()
  )
);
if ($has_children > 0) {
  $parent->update_meta_data('_vogo_split_done', 1); // opțional
  $parent->save();                                  // opțional
  return;
}


  $parent_id   = $parent->get_id();
  $customer_id = $parent->get_customer_id();
  $currency    = $parent->get_currency();
  $status      = $parent->get_status();
  $pay_method  = $parent->get_payment_method();

  // Map product -> vendor
  $map_tbl  = $wpdb->prefix . 'product_vendor';
  $prov_tbl = $wpdb->prefix . 'vogo_providers';

  // Build groups: vendor_id => array of WC_Order_Item_Product
  $groups = [];
  foreach ( $parent->get_items( 'line_item' ) as $item ) {
    $pid = (int) $item->get_product_id();
    $vid = (int) $item->get_variation_id();
    $lookup_id = $vid ?: $pid;

    $vendor_id = (int) $wpdb->get_var( $wpdb->prepare(
      "SELECT vendor_id FROM {$map_tbl} WHERE product_id=%d LIMIT 1", $lookup_id
    ) );
    if ( ! $vendor_id && $vid ) {
      // fallback pe părinte
      $vendor_id = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT vendor_id FROM {$map_tbl} WHERE product_id=%d LIMIT 1", $pid
      ) );
    }
    if ( ! $vendor_id ) {
      // fără vendor mapping => rămâne doar în comanda părinte
      continue;
    }
    $groups[ $vendor_id ][] = $item;
  }

  if ( empty( $groups ) ) return;

  // Ensure wp_order_vendor has child_order_id
  $ov_tbl = $wpdb->prefix . 'order_vendor';
  $has_child_col = (int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema=DATABASE() AND table_name=%s AND column_name='child_order_id'", $ov_tbl
  ));
  if ( ! $has_child_col ) {
    $wpdb->query("ALTER TABLE {$ov_tbl} ADD COLUMN `child_order_id` BIGINT(20) UNSIGNED NULL DEFAULT NULL AFTER `order_id`");
    $wpdb->query("ALTER TABLE {$ov_tbl} ADD INDEX `idx_child` (`child_order_id`)");
  }

  // Optional: detect active column on providers (for logging/name)
  $has_active = (int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns
     WHERE table_schema=DATABASE() AND table_name=%s AND column_name='active'", $prov_tbl
  ));
  $where_active = $has_active ? "status='active' AND active=1" : "status='active'";

  foreach ( $groups as $vendor_id => $items ) {

    // Create child order
    $child = wc_create_order( [ 'status' => $status, 'customer_id' => $customer_id ] );
    // parent linkage
    wp_update_post( [ 'ID' => $child->get_id(), 'post_parent' => $parent_id ] );
    // SI pentru HPOS
    $child->set_parent_id( $parent_id );   // <- HPOS populates wp_wc_orders.parent_order_id


    // Copy addresses
    $child->set_address( $parent->get_address( 'billing' ),  'billing'  );
    $child->set_address( $parent->get_address( 'shipping' ), 'shipping' );

    // Copy payment & currency
    $child->set_currency( $currency );
    if ( $pay_method ) {
      $gateways = WC()->payment_gateways->payment_gateways();
      if ( isset( $gateways[ $pay_method ] ) ) {
        $child->set_payment_method( $gateways[ $pay_method ] );
      }
    }

    // Vendor meta on child
    $child->update_meta_data( '_vogo_vendor_id', $vendor_id );

    // Add items for this vendor
    $subtotal = 0.0; $total = 0.0; $tax_total = 0.0; $count = 0;

    foreach ( $items as $item ) {
      $product = $item->get_product();
      $qty     = (int) $item->get_quantity();

      // Clone item keeping totals
      $child_item = new WC_Order_Item_Product();
      $child_item->set_product( $product );
      $child_item->set_name( $item->get_name() );
      $child_item->set_quantity( $qty );

      // Preserve totals & taxes
      $child_item->set_subtotal( (float)$item->get_subtotal() );
      $child_item->set_total( (float)$item->get_total() );
      $child_item->set_subtotal_tax( (float)$item->get_subtotal_tax() );
      $child_item->set_total_tax( (float)$item->get_total_tax() );
      $child_item->set_taxes( $item->get_taxes() );

      // Compat: keep vendor id on each child line
      $child_item->add_meta_data( '_vendor_id', $vendor_id, true );

      $child->add_item( $child_item );

      // sums
      $subtotal  += (float)$item->get_subtotal();
      $total     += (float)$item->get_total();
      $tax_total += (float)$item->get_total_tax();
      $count     += $qty;
    }

    $child->set_shipping_total(0);
    $child->calculate_totals(false);
    $child->update_meta_data('_vogo_vendor_id', $vendor_id);
    $child->save(); // scrie în wp_wc_orders + wp_wc_orders_meta

    
    $child->save();    

    // Order note with vendor name
    $vendor_name = $wpdb->get_var( $wpdb->prepare(
      "SELECT provider_name FROM {$prov_tbl} WHERE id=%d AND {$where_active} LIMIT 1", $vendor_id
    ) );
    if ( $vendor_name ) {
      $child->add_order_note( sprintf( 'Vendor sub-order for: %s (ID %d)', $vendor_name, $vendor_id ), false, true );
    } else {
      $child->add_order_note( sprintf( 'Vendor sub-order (ID %d)', $vendor_id ), false, true );
    }

        // Upsert summary in wp_order_vendor (per parent order + vendor)
    $items_total_with_tax = $total + $tax_total;
    $sql = $wpdb->prepare(
      "INSERT INTO {$ov_tbl}
      (order_id, child_order_id, vendor_id, items_count, items_subtotal, items_total, tax_total, shipping_total, status, created_by)
      VALUES (%d, %d, %d, %d, %f, %f, %f, %f, 'active', %d)
      ON DUPLICATE KEY UPDATE
        child_order_id=VALUES(child_order_id),
        items_count=VALUES(items_count),
        items_subtotal=VALUES(items_subtotal),
        items_total=VALUES(items_total),
        tax_total=VALUES(tax_total),
        shipping_total=VALUES(shipping_total),
        status='active'",
      $parent_id,
      $child->get_id(),
      $vendor_id,
      $count,
      $subtotal,
      $items_total_with_tax,
      $tax_total,
      0.0,
      (int)($customer_id ?: 0)
    );
    $wpdb->query($sql);
    if (!empty($wpdb->last_error)) {
      error_log('[VOGO][order_vendor][ERR] ' . $wpdb->last_error . ' | SQL: ' . $sql);
    }

 //syn orders and set address to vogo woo orders tables
    $res = $wpdb->query( $wpdb->prepare("CALL proc_sync_vogo_parent_order(%d)", $parent_id) );

    /* 
    -- mutat in job separat pentru performanta la checkout
    vogo_order_set_latlong ($parent_id);
    vogo_set_latlong_for_children ($parent_id);
    */


    if ($res === false || !empty($wpdb->last_error)) {
      return new WP_REST_Response([
        'success' => false,
        'module'  => $module.'.SYNC_ERR'.$parent_id,
        'error'   => 'proc_sync_vogo_parent_order failed',
        'sql_err' => $wpdb->last_error ?: 'unknown'
      ], 500);
    }    

    //add shipping and delivery items

    $res = $wpdb->query( $wpdb->prepare("CALL proc_order_sync_shippment(%d)", $parent_id) );


    if ($res === false || !empty($wpdb->last_error)) {
      return new WP_REST_Response([
        'success' => false,
        'module'  => $module.'.SYNC_ERR'.$parent_id,
        'error'   => 'proc_sync_vogo_parent_order failed',
        'sql_err' => $wpdb->last_error ?: 'unknown'
      ], 500);
    }        

    // Small log
    if ( function_exists('vogo_error_log3') ) {
      vogo_error_log3(sprintf('[SPLIT] child #%d for vendor %d (total=%0.2f tax=%0.2f) parent #%d',
        $child->get_id(), $vendor_id, $items_total_with_tax, $tax_total, $parent_id
      ));
    }
  }
}

//si split si pentru web
// WEB checkout: split per vendor (idempotent, doar pentru comanda părinte)
 add_action('woocommerce_checkout_order_processed', 'vogo_maybe_split_vendor_suborders_checkout', 999, 3);
 add_action('woocommerce_order_status_changed',      'vogo_maybe_split_vendor_suborders_status', 10, 4);

//hook pentru web
add_action('woocommerce_checkout_order_processed','vogo_maybe_split_vendor_suborders_checkout',999,3);


function vogo_maybe_split_vendor_suborders_checkout($order_id, $posted, $order){
  vogo_maybe_split_vendor_suborders_core($order ?? wc_get_order($order_id));
}

function vogo_maybe_split_vendor_suborders_status($order_id, $from, $to, $order){
  // rulează când devine relevant pentru fulfilment (ex: COD sau plăți capturate)
  if (!in_array($to, ['processing','completed','on-hold','pending'], true)) return;
  vogo_maybe_split_vendor_suborders_core($order ?? wc_get_order($order_id));
}

function vogo_maybe_split_vendor_suborders_core($order){
  if (!$order instanceof WC_Order) return;
  $parent_id = $order->get_id();
  if (wp_get_post_parent_id($parent_id)) return;              // nu splităm subcomenzi
  if ($order->get_meta('_vogo_split_done')) return;           // deja făcut
  if (get_posts(['post_type'=>'shop_order','post_parent'=>$parent_id,'numberposts'=>1])) {
    $order->update_meta_data('_vogo_split_done', 1); $order->save(); return; // copii există deja
  }

  // helperul tău existent care face efectiv split-ul
  if (function_exists('vogo_split_order_into_vendor_suborders')) {
    vogo_split_order_into_vendor_suborders($order);
    $order->update_meta_data('_vogo_split_done', 1);
    $order->save();
  }
}

function cartlist_count(WP_REST_Request $request){ 
    global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
    $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");
    $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
    if(is_null(WC()->cart)) wc_load_cart();
    // Load the user's persistent cart into the session cart so counts are based on their saved cart, not the current visitor session.
    // reset_cart() now skips work when the persistent cart hash matches the last synced session snapshot.
    vogo_error_log3("[STEP 0.2] Cart sync requested for counts | IP:$ip | USER:$user_id");
    reset_cart($user_id); $cart=WC()->cart->get_cart();
    $using_fallback=false; $fallback_count=0; $fallback_qty=0; $fallback_subtotal=0;
    if(empty($cart)){ $cart_data=vogo_get_persistent_cart_data($user_id); if(!empty($cart_data['cart'])){$cart=$cart_data['cart']; $using_fallback=true;} }
    if(empty($cart)) { vogo_error_log3("[STEP 1] Cart empty | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return ['success'=>false,'message'=>'Cart empty','user_id'=>$user_id]; }
    if($using_fallback){
      foreach($cart as $item){$pid=intval($item['product_id']??0); if($pid<=0) continue; $qty=intval($item['quantity']??1); if($qty<=0)$qty=1; $fallback_count++; $fallback_qty+=$qty; $prod=wc_get_product($pid); if($prod){$fallback_subtotal+=((float)$prod->get_price()*$qty);} }
    } else {
      foreach($cart as $key=>$item){$pid=intval($item['product_id']??0); if($pid<=0){ vogo_error_log3("[STEP 1.1] Count skip invalid product_id | key:$key | raw:".json_encode($item)); continue; } $prod=wc_get_product($pid); if(!$prod){ vogo_error_log3("[STEP 1.2] Count skip missing product | product_id:$pid | key:$key"); continue; } $qty=intval($item['quantity']??1); if($qty<=0)$qty=1; $fallback_count++; $fallback_qty+=$qty; }
    }
    $items_count = $using_fallback?$fallback_count:count($cart);
    $total_qty   = $using_fallback?$fallback_qty:WC()->cart->get_cart_contents_count();
    if(!$using_fallback && ($total_qty !== $fallback_qty || $items_count !== $fallback_count)){
      vogo_error_log3("[STEP 1.3] Count mismatch | raw_items:".count($cart)." | wc_items:$items_count | wc_qty:$total_qty | filtered_items:$fallback_count | filtered_qty:$fallback_qty | IP:$ip | USER:$user_id");
    }
    vogo_error_log3("[STEP 1] Cart count computed | items:$items_count | qty:$total_qty | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END");
    return [
        'success'=>true,
        'message'=>'Cart counts retrieved',
        'user_id'=>$user_id,
        'user_login'=>wp_get_current_user()->user_login,
        'items_count'=>$items_count,
        'total_cart_qty'=>$total_qty,
        'cart_subtotal'=>$using_fallback?number_format((float)$fallback_subtotal,2,'.',''):WC()->cart->subtotal_ex_tax,
        'shipping_total'=>$using_fallback?0:WC()->cart->get_shipping_total(),
        'discount_amount'=>$using_fallback?0:WC()->cart->get_discount_total(),
        'vat'=>$using_fallback?0:WC()->cart->get_taxes_total(),
        'cart_total'=>$using_fallback?number_format((float)$fallback_subtotal,2,'.',''):WC()->cart->total
    ];
}

function cart_complementary_products(WP_REST_Request $request){
  global $wpdb; $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;

  // Auth
  $u=extract_user_from_jwt_token($request); if($u instanceof WP_REST_Response) return $u;
  $user_id=(int)$u; $user=get_user_by('id',$user_id); $user_login=$user?$user->user_login:'';
  $module=$module.'.user_id:'.$user_id.'.user_login:'.$user_login;

  // Woo cart as source
  if(is_null(WC()->cart)) wc_load_cart(); if(function_exists('reset_cart')) reset_cart($user_id);
  $cart=WC()->cart->get_cart(); if(empty($cart)) return new WP_REST_Response(['success'=>false,'error'=>'empty cart','module'=>$module],200);

  // Collect product ids from cart
  $pids=[]; foreach($cart as $it){ $qty=(float)($it['quantity']??0); $pid=(int)($it['product_id']??0); if($pid>0 && $qty>0) $pids[$pid]=1; }
  if(!$pids) return new WP_REST_Response(['success'=>false,'error'=>'empty cart','module'=>$module],200);
  $in_cart=implode(',',array_map('intval',array_keys($pids)));

  // Categories of cart items
  $cat_ids=$wpdb->get_col("
    SELECT DISTINCT tt.term_id
    FROM {$wpdb->term_relationships} tr
    JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id AND tt.taxonomy='product_cat'
    WHERE tr.object_id IN ($in_cart)
  ");

  // Complementary by categories
  $ids=[];
  if($cat_ids){
    $in_cats=implode(',',array_map('intval',$cat_ids));
    $ids=$wpdb->get_col("
      SELECT p.ID
      FROM {$wpdb->posts} p
      JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID
      JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id AND tt.taxonomy='product_cat' AND tt.term_id IN ($in_cats)
      LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup l ON l.product_id=p.ID
      WHERE p.post_type='product' AND p.post_status='publish'
        AND p.ID NOT IN ($in_cart)
        AND (l.stock_status IS NULL OR l.stock_status='instock')
      GROUP BY p.ID
      ORDER BY COALESCE(l.total_sales,0) DESC, p.post_date DESC
      LIMIT 4
    ");
  }

  // Fallback: sitewide best-sellers not in cart
  if(!$ids){
    $ids=$wpdb->get_col("
      SELECT p.ID
      FROM {$wpdb->posts} p
      LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup l ON l.product_id=p.ID
      WHERE p.post_type='product' AND p.post_status='publish'
        AND p.ID NOT IN ($in_cart)
        AND (l.stock_status IS NULL OR l.stock_status='instock')
      ORDER BY COALESCE(l.total_sales,0) DESC, p.post_date DESC
      LIMIT 4
    ");
  }

 
  // Build response items (attachments only)
  $items=[];
  foreach($ids as $pid){
    $pid=(int)$pid; $thumb_id=get_post_thumbnail_id($pid);

    //iau preturile prin mecanisme wc
    $pobj = wc_get_product($pid);
    if($pobj){
      $price   = $pobj->get_price();           // exact ca în product-detail (calcul Woo, corect și pt. variabile)
      $regular = $pobj->get_regular_price();
      $sale    = $pobj->get_sale_price();
    } else {
      $price = $regular = $sale = null;
    }



    $img_full=$thumb_id?wp_get_attachment_url($thumb_id):null;
    $img_med =$thumb_id?wp_get_attachment_image_src($thumb_id,'medium'):null;
    
    $pr = $price_map[$pid] ?? ['price'=>null,'regular_price'=>null,'sale_price'=>null];

    $items[]=[
      'product_id'=>$pid,
      'title'=>get_the_title($pid),
      'permalink'=>get_permalink($pid),
      'image_url'=>$img_full,
      'image_src'=>$img_med?$img_med[0]:null,
      'price'         => ($price   !== '' ? $price   : null),
      'regular_price' => ($regular !== '' ? $regular : null),
      'sale_price' => ($sale !== '' && $sale !== null ? $sale : $regular)
    ];
  }

  return new WP_REST_Response(['success'=>true,'count'=>count($items),'items'=>$items,
  'module'=>$module],200);
}
