<?php

//clear_debug_log_file();
$MODULE_PHP='providers.php';

add_action('rest_api_init', function () {

  register_rest_route('vogo/v1', '/provider/product_update', [
    'methods'             => 'POST',
    'callback'            => 'provider_product_update',
    'permission_callback' => 'vogo_permission_check',
  ]);    

  register_rest_route('vogo/v1/provider', '/add-or-update', [
    'methods' => 'POST',
    'callback' => 'provider_add_or_update',
    'permission_callback' => 'vogo_permission_check',
  ]);  

    register_rest_route('vogo/v1', '/provider/category-list', [
        'methods'             => 'POST',
        'callback'            => 'vendor_category_list',
        'permission_callback' => 'vogo_permission_check',
    ]);  

  register_rest_route('vogo/v1', '/provider/provider-product-detail', [
    'methods'             => 'POST',
    'callback'            => 'provider_product_detail',
    'permission_callback' => 'vogo_permission_check',
  ]);    

  register_rest_route('vogo/v1', '/provider/provider-product-detail-edit', [
    'methods'             => 'POST',
    'callback'            => 'provider_product_detail_edit',
    'permission_callback' => 'vogo_permission_check',
  ]);  

  register_rest_route('vogo/v1', 'provider/product-list-in-category', [
    'methods' => 'POST',
    'callback' => 'provider_product_list_get',
    'permission_callback' => 'vogo_permission_check',
  ]);        

  // POST /vogo/v1/provider/get-vendor-list
  register_rest_route('vogo/v1/provider', '/get-vendor-list', [
    'methods'  => 'POST',
    'callback' => 'get_vendor_list',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // POST /vogo/v1/provider/get-vendor-info-by-jwt  (replaces get-my-vendor-id)
  register_rest_route('vogo/v1/provider', '/get-vendor-info-by-jwt', [
    'methods'  => 'POST',
    'callback' => 'get_vendor_info_by_jwt',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // POST /vogo/v1/provider/get-vendor-info-by-id
  register_rest_route('vogo/v1/provider', '/get-vendor-info-by-id', [
    'methods'  => 'POST',
    'callback' => 'get_vendor_info_by_id',
    'permission_callback' => 'vogo_permission_check',
  ]);

  register_rest_route('vogo/v1/provider', '/set-accepting-order/(?P<status>[01])', [
    'methods'             => 'POST',
    'callback'            => 'provider_set_accepting_order_status',
    'permission_callback' => 'vogo_permission_check',
  ]);

register_rest_route('vogo/v1/provider', '/get-earnings-summary', [
  'methods'             => 'POST',
  'callback'            => 'provider_get_earnings_summary',
  'permission_callback' => 'vogo_permission_check'
]);  

register_rest_route('vogo/v1/provider', '/get-customer-interactions', [
  'methods' => 'POST',
  'callback' => 'provider_get_customer_interactions',
  'permission_callback' => 'vogo_permission_check'
]);

register_rest_route('vogo/v1/provider', '/get-my-products', [
  'methods'             => 'POST',
  'callback'            => 'get_my_products',
  'permission_callback' => 'vogo_permission_check'
]);

});  


// HANDLER FUNCTION
function provider_set_accepting_order_status(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'provider_feeds';
  $db_name = DB_NAME;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[provider-accepting-orders] [STEP 0] ACTIVE DB: $db_name");

  $user_id = extract_user_from_jwt_token($request);
  if (is_wp_error($user_id)) return $user_id;

  $user = get_user_by('id', $user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  $status = intval($request->get_param('status'));

  vogo_error_log3("[STEP 0.1] Raw PARAM: status=$status | IP: $ip | USER: $user_id");

  if (!in_array($status, [0, 1])) {
    vogo_error_log3("[STEP 1] Invalid status value received: $status | USER: $user_id | IP: $ip");
    return new WP_REST_Response([
      'success' => false,
      'error' => 'Invalid status: must be 0 or 1',
      'user_id' => $user_id,
      'user_login' => $user_login
    ], 400);
  }

  $result = $wpdb->update($table, ['accepting_orders' => $status, 'modified_by' => $user_id], ['id_user' => $user_id]);

  if ($result === false) {
    vogo_error_log3("[STEP 2] SQL ERROR on update: {$wpdb->last_error} | USER: $user_id | IP: $ip");
    vogo_error_log3("############ END ########################################");
    return new WP_REST_Response([
      'success' => false,
      'error' => 'Database UPDATE error: ' . $wpdb->last_error,
      'user_id' => $user_id,
      'user_login' => $user_login
    ], 500);
  }

  vogo_error_log3("[STEP 3] accepting_orders updated to $status | Affected rows: $result | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response([
    'success' => true,
    'status' => $status,
    'user_id' => $user_id,
    'user_login' => $user_login
  ], 200);
}

function provider_add_or_update(WP_REST_Request $request) {
  global $wpdb;
  vogo_error_log3("VOGO_LOG_START", 0, 'provider-feed');

  // STEP 0: Init + user + DB
  $db_name = $wpdb->get_var("SELECT DATABASE()");
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user = get_user_by('ID', $user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("ACTIVE DB: $db_name", "$user_id|$user_login", 'provider-feed');

  // STEP 0.1: Raw JSON
  $data = $request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: " . json_encode($data), "$user_id|$user_login", 'provider-feed');

  // STEP 1: Extract & validate
  $provider_name = sanitize_text_field($data['provider_name'] ?? '');
  $feed_url = esc_url_raw($data['feed_url'] ?? '');
  $accepting_orders = intval($data['accepting_orders'] ?? 0);
  if (empty($provider_name) || empty($feed_url)) {
    vogo_error_log3("[STEP 1] Missing provider_name or feed_url", "$user_id|$user_login", 'provider-feed');
    return new WP_REST_Response(['success' => false, 'error' => 'Missing provider_name or feed_url', 'user_id' => $user_id, 'user_login' => $user_login], 400);
  }

  // STEP 2: Insert or get taxonomy term
  $term_id = $wpdb->get_var($wpdb->prepare("SELECT term_id FROM {$wpdb->prefix}terms WHERE name = %s", $provider_name));
  if (!$term_id) {
    $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->prefix}terms (name, slug) VALUES (%s, %s)", $provider_name, sanitize_title($provider_name)));
    $term_id = $wpdb->insert_id;
    $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->prefix}term_taxonomy (term_id, taxonomy) VALUES (%d, %s)", $term_id, 'product_provider'));
    $taxonomy_id = $wpdb->insert_id;
    $wpdb->query($wpdb->prepare("INSERT INTO {$wpdb->prefix}termmeta (term_id, meta_key, meta_value) VALUES (%d, %s, %s)", $term_id, 'created_by', $user_id));
    vogo_error_log3("[STEP 2] Taxonomy created: term_id=$term_id, taxonomy_id=$taxonomy_id", "$user_id|$user_login", 'provider-feed');
  } else {
    vogo_error_log3("[STEP 2] Existing taxonomy: term_id=$term_id", "$user_id|$user_login", 'provider-feed');
  }

  // STEP 3: Insert or update feed
  $table = $wpdb->prefix . 'provider_feeds';
  $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE id_user = %d", $user_id));
  if ($exists) {
    $query = $wpdb->prepare("UPDATE $table SET provider_name = %s, feed_url = %s, accepting_orders = %d, term_id = %d, modified_at = NOW(), modified_by = %d WHERE id = %d", $provider_name, $feed_url, $accepting_orders, $term_id, $user_id, $exists);
    $result = $wpdb->query($query);
    vogo_error_log3("##############SQL: $query", "$user_id|$user_login", 'provider-feed');
    if ($result === false) {
      $error = $wpdb->last_error;
      vogo_error_log3("[STEP 3] DB error on UPDATE: $error", "$user_id|$user_login", 'provider-feed');
      return new WP_REST_Response(['success' => false, 'error' => "Database UPDATE error: $error", 'details' => $error, 'user_id' => $user_id, 'user_login' => $user_login], 500);
    }
    vogo_error_log3("[STEP 3] Feed updated", "$user_id|$user_login", 'provider-feed');
    return new WP_REST_Response(['success' => true, 'modified_id' => $exists, 'term_id' => $term_id, 'user_id' => $user_id, 'user_login' => $user_login], 200);
  } else {
    $query = $wpdb->prepare("INSERT INTO $table (provider_name, feed_url, accepting_orders, id_user, last_processed_at, created_by, term_id) VALUES (%s, %s, %d, %d, NOW(), %d, %d)", $provider_name, $feed_url, $accepting_orders, $user_id, $user_id, $term_id);
    $result = $wpdb->query($query);
    $insert_id = $wpdb->insert_id;
    vogo_error_log3("##############SQL: $query", "$user_id|$user_login", 'provider-feed');
    if ($result === false) {
      $error = $wpdb->last_error;
      vogo_error_log3("[STEP 3] DB error on INSERT: $error", "$user_id|$user_login", 'provider-feed');
      return new WP_REST_Response(['success' => false, 'error' => "Database INSERT error: $error", 'details' => $error, 'user_id' => $user_id, 'user_login' => $user_login], 500);
    }
    vogo_error_log3("[STEP 3] Feed inserted: ID $insert_id", "$user_id|$user_login", 'provider-feed');
    return new WP_REST_Response(['success' => true, 'insert_id' => $insert_id, 'term_id' => $term_id, 'user_id' => $user_id, 'user_login' => $user_login], 200);
  }
}


function provider_get_earnings_summary(WP_REST_Request $request) {
  vogo_error_log3("############ START ########################################");
  global $wpdb;
  $raw_input = file_get_contents("php://input");
  $ip = $_SERVER['REMOTE_ADDR'];
  $user_id = extract_user_from_jwt_token($request);
  $user = get_user_by('ID', $user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("ACTIVE DB: {$wpdb->dbname}");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");

  $data = json_decode($raw_input, true);
  $from_date = !empty($data['from_date']) ? sanitize_text_field($data['from_date']) : date('Y-m-d', strtotime('-10 days'));
  $to_date   = !empty($data['to_date']) ? sanitize_text_field($data['to_date']) : date('Y-m-d');

  vogo_error_log3("[STEP 1] Date range used: FROM $from_date TO $to_date");

  // === Earnings in range
  $query_range = "
    SELECT SUM(meta.meta_value) FROM {$wpdb->prefix}posts AS p
    JOIN {$wpdb->prefix}postmeta AS meta ON p.ID = meta.post_id
    WHERE p.post_type = 'shop_order'
      AND p.post_status IN ('wc-completed', 'wc-processing')
      AND meta.meta_key = '_order_total'
      AND DATE(p.post_date) BETWEEN '$from_date' AND '$to_date'
  ";
  $total_range = $wpdb->get_var($query_range);
  vogo_error_log3("##############SQL: $query_range");

  // === Today + Week (standard reference)
  $today = date('Y-m-d');
  $monday = date('Y-m-d', strtotime('monday this week'));

  $revenue_today = $wpdb->get_var("
    SELECT SUM(meta.meta_value) FROM {$wpdb->prefix}posts AS p
    JOIN {$wpdb->prefix}postmeta AS meta ON p.ID = meta.post_id
    WHERE p.post_type = 'shop_order'
      AND p.post_status IN ('wc-completed', 'wc-processing')
      AND meta.meta_key = '_order_total'
      AND DATE(p.post_date) = '$today'
  ");

  $revenue_week = $wpdb->get_var("
    SELECT SUM(meta.meta_value) FROM {$wpdb->prefix}posts AS p
    JOIN {$wpdb->prefix}postmeta AS meta ON p.ID = meta.post_id
    WHERE p.post_type = 'shop_order'
      AND p.post_status IN ('wc-completed', 'wc-processing')
      AND meta.meta_key = '_order_total'
      AND DATE(p.post_date) >= '$monday'
  ");

  // === Orders by status
  $completed  = $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-completed'");
  $processing = $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-processing'");
  $confirmed  = $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->prefix}posts WHERE post_type = 'shop_order' AND post_status = 'wc-confirmed'");

  // === Products
  $active_products = $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->prefix}posts WHERE post_type = 'product' AND post_status = 'publish'");
  $out_of_stock    = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = '_stock' AND CAST(meta_value AS SIGNED) <= 0");
  $low_stock       = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = '_stock' AND CAST(meta_value AS SIGNED) > 0 AND CAST(meta_value AS SIGNED) <= 2");

  $response = [
    'success' => true,
    'user_id' => $user_id,
    'user_login' => $user_login,
    'date_range' => ['from' => $from_date, 'to' => $to_date],
    'earnings_summary' => [
      'today_revenue' => [
        'amount' => '$' . number_format((float)$revenue_today, 2, '.', ','),
        'change' => '+8%' // Placeholder
      ],
      'week_revenue' => [
        'amount' => '$' . number_format((float)$revenue_week, 2, '.', ','),
        'change' => '+12%' // Placeholder
      ],
      'custom_range_total' => [
        'amount' => '$' . number_format((float)$total_range, 2, '.', ','),
        'note' => "Sum between $from_date and $to_date"
      ]
    ],
    'order_activity' => [
      'completed' => (int)$completed,
      'in_processing' => (int)$processing,
      'confirmed' => (int)$confirmed
    ],
    'product_status' => [
      'active' => (int)$active_products,
      'low_stock' => (int)$low_stock,
      'out_of_stock' => (int)$out_of_stock
    ]
  ];

  vogo_error_log3("[STEP 2] Returning earnings summary with custom date range");
  vogo_error_log3("############ END ########################################");
  return new WP_REST_Response($response, 200);
}


function provider_get_customer_interactions(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'provider_feeds';
  $db_name = DB_NAME;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[provider-get-customer-interactions] [STEP 0] ACTIVE DB: $db_name");
  
  $user_id = extract_user_from_jwt_token($request);
  if (is_wp_error($user_id)) return $user_id;

  $user = get_user_by('id', $user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  $raw_input = file_get_contents('php://input');
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");

  $response = [
    'success' => true,
    'user_id' => $user_id,
    'user_login' => $user_login,
    'customer_interactions' => [
      'messages' => [
        'unread_count' => 7,
        'label' => 'Messages',
        'action' => 'View All'
      ],
      'reviews' => [
        'unread_count' => 3,
        'label' => 'Reviews',
        'action' => 'Respond'
      ]
    ]
  ];

  vogo_error_log3("[STEP 1] Returning hardcoded customer interaction data for user $user_id");
  vogo_error_log3("############ END ########################################");
  return new WP_REST_Response($response, 200);
}

//get produs dupa id. city si mall sunt tratate separat - tabele woo native
function get_my_products_from_direct_sql(WP_REST_Request $request) {
  global $wpdb;

  vogo_error_log3("VOGO_LOG_START [GET MY PRODUCTS EXTENDED]");
  vogo_error_log3("[STEP 1] ACTIVE DB: " . DB_NAME);

  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user_login = get_userdata($user_id)->user_login ?? '';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("[STEP 2] User ID: $user_id | IP: $ip");

  $sql = "
    SELECT 
      p.ID AS product_id,
      p.post_title,
      p.post_status,
      p.post_date AS published_date,
      p.post_excerpt AS product_short_description,
      p.post_content AS product_description,
      p.post_name AS slug,
      p.menu_order AS position,

      lookup.sku,
      lookup.stock_quantity,
      lookup.stock_status,
      lookup.min_price AS price,

      pm_seo.meta_value AS seo_title,
      pm_desc.meta_value AS seo_description,
      pm_vis.meta_value AS visibility,
      img.guid AS product_image_url,

      GROUP_CONCAT(DISTINCT cat_terms.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT tag_terms.name SEPARATOR ', ') AS tags,
      GROUP_CONCAT(DISTINCT brand_terms.name SEPARATOR ', ') AS brand

    FROM {$wpdb->prefix}posts p

    INNER JOIN {$wpdb->prefix}term_relationships rel_provider ON rel_provider.object_id = p.ID
    INNER JOIN {$wpdb->prefix}term_taxonomy tax_provider ON rel_provider.term_taxonomy_id = tax_provider.term_taxonomy_id
    INNER JOIN {$wpdb->prefix}termmeta tm ON tax_provider.term_id = tm.term_id

    LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup lookup ON p.ID = lookup.product_id
    LEFT JOIN {$wpdb->prefix}postmeta pm_seo  ON p.ID = pm_seo.post_id AND pm_seo.meta_key = '_yoast_wpseo_title'
    LEFT JOIN {$wpdb->prefix}postmeta pm_desc ON p.ID = pm_desc.post_id AND pm_desc.meta_key = '_yoast_wpseo_metadesc'
    LEFT JOIN {$wpdb->prefix}postmeta pm_vis ON p.ID = pm_vis.post_id AND pm_vis.meta_key = '_visibility'
    LEFT JOIN {$wpdb->prefix}postmeta pm_img ON p.ID = pm_img.post_id AND pm_img.meta_key = '_thumbnail_id'
    LEFT JOIN {$wpdb->prefix}posts img ON img.ID = pm_img.meta_value

    LEFT JOIN {$wpdb->prefix}term_relationships rel_cat ON rel_cat.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_cat ON rel_cat.term_taxonomy_id = tax_cat.term_taxonomy_id AND tax_cat.taxonomy = 'product_cat'
    LEFT JOIN {$wpdb->prefix}terms cat_terms ON cat_terms.term_id = tax_cat.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_tag ON rel_tag.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_tag ON rel_tag.term_taxonomy_id = tax_tag.term_taxonomy_id AND tax_tag.taxonomy = 'product_tag'
    LEFT JOIN {$wpdb->prefix}terms tag_terms ON tag_terms.term_id = tax_tag.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_brand ON rel_brand.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_brand ON rel_brand.term_taxonomy_id = tax_brand.term_taxonomy_id AND tax_brand.taxonomy = 'product_brand'
    LEFT JOIN {$wpdb->prefix}terms brand_terms ON brand_terms.term_id = tax_brand.term_id

    WHERE tax_provider.taxonomy = 'product_provider'
      AND tm.meta_key = 'created_by'
      AND tm.meta_value = $user_id
      AND p.post_type = 'product'
      AND p.post_status IN ('publish', 'draft', 'pending')

    GROUP BY p.ID
    ORDER BY p.ID DESC
    LIMIT 100;
  ";

  vogo_error_log3("##############SQL: $sql");

  $results = $wpdb->get_results($sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] SQL Error: {$wpdb->last_error} | User: $user_id | IP: $ip");
    return new WP_REST_Response([
      'success'    => false,
      'error'      => 'SQL error',
      'sql_error'  => $wpdb->last_error
    ], 500);
  }

  // STEP 4: Process meta per product
  foreach ($results as &$product) {
    $pid = (int)$product['product_id'];

    // Cities
    $cities = get_post_meta($pid, '_available_cities', true);
    $product['cities'] = is_serialized($cities) ? maybe_unserialize($cities) : (is_array($cities) ? $cities : []);

    // Malls
    $malls = get_post_meta($pid, '_available_malls', true);
    $mall_names = [];
    if (is_serialized($malls)) $malls = maybe_unserialize($malls);
    if (is_array($malls)) {
    foreach ($malls as $mall_id) {
      $name = $wpdb->get_var("SELECT mall_name FROM wp_mall_locations WHERE id = " . intval($mall_id));
      if ($name) $mall_names[] = $name;
    }
    }
    $product['mall_locations'] = $mall_names;
  }

  vogo_error_log3("[STEP 4] Products enriched: " . count($results));
  vogo_error_log3("VOGO_LOG_END [GET MY PRODUCTS EXTENDED]");

  return new WP_REST_Response([
    'success'      => true,
    'user_id'      => $user_id,
    'user_login'   => $user_login,
    'products'     => $results
  ], 200);
}

//get produs dupa id. city si mall sunt tratate separat - tabele optimizate
function get_my_products_from_direct_sql_aaa2(WP_REST_Request $request) {
  global $wpdb;

  vogo_error_log3("VOGO_LOG_START [GET MY PRODUCTS EXTENDED]");
  vogo_error_log3("[STEP 1] ACTIVE DB: " . DB_NAME);

  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user_login = get_userdata($user_id)->user_login ?? '';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("[STEP 2] User ID: $user_id | IP: $ip");

  $sql = "
    SELECT 
      p.ID AS product_id,
      p.post_title,
      p.post_status,
      p.post_date AS published_date,
      p.post_excerpt AS product_short_description,
      p.post_content AS product_description,
      p.post_name AS slug,
      p.menu_order AS position,

      lookup.sku,
      lookup.stock_quantity,
      lookup.stock_status,
      lookup.min_price AS price,

      img.guid AS product_image_url,

      GROUP_CONCAT(DISTINCT cat_terms.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT tag_terms.name SEPARATOR ', ') AS tags,
      GROUP_CONCAT(DISTINCT brand_terms.name SEPARATOR ', ') AS brand

    FROM {$wpdb->prefix}posts p

    INNER JOIN {$wpdb->prefix}term_relationships rel_provider ON rel_provider.object_id = p.ID
    INNER JOIN {$wpdb->prefix}term_taxonomy tax_provider ON rel_provider.term_taxonomy_id = tax_provider.term_taxonomy_id
    INNER JOIN {$wpdb->prefix}termmeta tm ON tax_provider.term_id = tm.term_id

    LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup lookup ON p.ID = lookup.product_id
    LEFT JOIN {$wpdb->prefix}postmeta pm_img ON p.ID = pm_img.post_id AND pm_img.meta_key = '_thumbnail_id'
    LEFT JOIN {$wpdb->prefix}posts img ON img.ID = pm_img.meta_value

    LEFT JOIN {$wpdb->prefix}term_relationships rel_cat ON rel_cat.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_cat ON rel_cat.term_taxonomy_id = tax_cat.term_taxonomy_id AND tax_cat.taxonomy = 'product_cat'
    LEFT JOIN {$wpdb->prefix}terms cat_terms ON cat_terms.term_id = tax_cat.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_tag ON rel_tag.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_tag ON rel_tag.term_taxonomy_id = tax_tag.term_taxonomy_id AND tax_tag.taxonomy = 'product_tag'
    LEFT JOIN {$wpdb->prefix}terms tag_terms ON tag_terms.term_id = tax_tag.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_brand ON rel_brand.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_brand ON rel_brand.term_taxonomy_id = tax_brand.term_taxonomy_id AND tax_brand.taxonomy = 'product_brand'
    LEFT JOIN {$wpdb->prefix}terms brand_terms ON brand_terms.term_id = tax_brand.term_id

    WHERE tax_provider.taxonomy = 'product_provider'
      AND tm.meta_key = 'created_by'
      AND tm.meta_value = $user_id
      AND p.post_type = 'product'
      AND p.post_status IN ('publish', 'draft', 'pending')

    GROUP BY p.ID
    ORDER BY p.ID DESC
    LIMIT 100;
  ";

  vogo_error_log3("##############SQL: $sql");

  $results = $wpdb->get_results($sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] SQL Error: {$wpdb->last_error} | User: $user_id | IP: $ip");
    return new WP_REST_Response([
      'success'    => false,
      'error'      => 'SQL error',
      'sql_error'  => $wpdb->last_error
    ], 500);
  }

  vogo_error_log3("[STEP 3] Retrieved " . count($results) . " products from DB");

  // STEP 4: Load cities and malls from optimized tables
  foreach ($results as &$product) {
    $pid = (int)$product['product_id'];

    // Cities
    $city_sql = $wpdb->prepare("
      SELECT c.city_name 
      FROM {$wpdb->prefix}product_cities pc
      INNER JOIN {$wpdb->prefix}cities c ON pc.city_id = c.id
      WHERE pc.product_id = %d
    ", $pid);
    $product['cities'] = $wpdb->get_col($city_sql);

    // Malls
    $mall_sql = $wpdb->prepare("
      SELECT m.mall_name 
      FROM {$wpdb->prefix}product_malls pm
      INNER JOIN {$wpdb->prefix}mall_locations m ON pm.mall_id = m.id
      WHERE pm.product_id = %d
    ", $pid);
    $product['mall_locations'] = $wpdb->get_col($mall_sql);
  }

  vogo_error_log3("[STEP 4] Products enriched with cities and malls: " . count($results), 'product-load');
  vogo_error_log3("VOGO_LOG_END [GET MY PRODUCTS EXTENDED]");

  return new WP_REST_Response([
    'success'      => true,
    'user_id'      => $user_id,
    'user_login'   => $user_login,
    'products'     => $results
  ], 200);
}

//get produs dupa id. city si mall sunt tratate in acelasi SQL - tabele optimizate
function get_my_products_from_direct_sql_2B(WP_REST_Request $request) {
  global $wpdb;

  vogo_error_log3("VOGO_LOG_START [GET MY PRODUCTS EXTENDED]");
  vogo_error_log3("[STEP 0.1] ACTIVE DB: " . DB_NAME);

  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user_login = get_userdata($user_id)->user_login ?? '';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("[STEP 1] User ID: $user_id | IP: $ip");

  $table_product_cities = $wpdb->prefix . "product_cities";
  $table_product_malls = $wpdb->prefix . "product_malls";
  $table_cities = $wpdb->prefix . "cities";
  $table_malls = $wpdb->prefix . "malls";

  $sql = "
    SELECT 
      p.ID AS product_id,
      p.post_title,
      p.post_status,
      p.post_date AS published_date,
      p.post_excerpt AS product_short_description,
      p.post_content AS product_description,
      p.post_name AS slug,
      p.menu_order AS position,

      lookup.sku,
      lookup.stock_quantity,
      lookup.stock_status,
      lookup.min_price AS price,

      img.guid AS product_image_url,

      GROUP_CONCAT(DISTINCT cat_terms.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT tag_terms.name SEPARATOR ', ') AS tags,
      GROUP_CONCAT(DISTINCT brand_terms.name SEPARATOR ', ') AS brand,
      GROUP_CONCAT(DISTINCT c.city_name SEPARATOR ', ') AS cities,
      GROUP_CONCAT(DISTINCT m.mall_name SEPARATOR ', ') AS mall_locations

    FROM {$wpdb->prefix}posts p

    INNER JOIN {$wpdb->prefix}term_relationships rel_provider ON rel_provider.object_id = p.ID
    INNER JOIN {$wpdb->prefix}term_taxonomy tax_provider ON rel_provider.term_taxonomy_id = tax_provider.term_taxonomy_id
    INNER JOIN {$wpdb->prefix}termmeta tm ON tax_provider.term_id = tm.term_id

    LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup lookup ON p.ID = lookup.product_id
    LEFT JOIN {$wpdb->prefix}postmeta pm_img ON p.ID = pm_img.post_id AND pm_img.meta_key = '_thumbnail_id'
    LEFT JOIN {$wpdb->prefix}posts img ON img.ID = pm_img.meta_value

    LEFT JOIN {$wpdb->prefix}term_relationships rel_cat ON rel_cat.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_cat ON rel_cat.term_taxonomy_id = tax_cat.term_taxonomy_id AND tax_cat.taxonomy = 'product_cat'
    LEFT JOIN {$wpdb->prefix}terms cat_terms ON cat_terms.term_id = tax_cat.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_tag ON rel_tag.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_tag ON rel_tag.term_taxonomy_id = tax_tag.term_taxonomy_id AND tax_tag.taxonomy = 'product_tag'
    LEFT JOIN {$wpdb->prefix}terms tag_terms ON tag_terms.term_id = tax_tag.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_brand ON rel_brand.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_brand ON rel_brand.term_taxonomy_id = tax_brand.term_taxonomy_id AND tax_brand.taxonomy = 'product_brand'
    LEFT JOIN {$wpdb->prefix}terms brand_terms ON brand_terms.term_id = tax_brand.term_id

    LEFT JOIN $table_product_cities pc ON pc.product_id = p.ID
    LEFT JOIN $table_cities c ON c.city_id = pc.city_id

    LEFT JOIN $table_product_malls pm ON pm.product_id = p.ID
    LEFT JOIN $table_malls m ON m.mall_id = pm.mall_id

    WHERE tax_provider.taxonomy = 'product_provider'
      AND tm.meta_key = 'created_by'
      AND tm.meta_value = $user_id
      AND p.post_type = 'product'
      AND p.post_status IN ('publish', 'draft', 'pending')

    GROUP BY p.ID
    ORDER BY p.ID DESC
    LIMIT 100
  ";

  vogo_error_log3("##############SQL: $sql");

  $results = $wpdb->get_results($sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] SQL ERROR: {$wpdb->last_error}");
    return new WP_REST_Response([
      'success' => false,
      'error' => 'SQL error',
      'sql_error' => $wpdb->last_error
    ], 500);
  }

  vogo_error_log3("[STEP 2] Retrieved products count: " . count($results));
  vogo_error_log3("VOGO_LOG_END");

  return new WP_REST_Response([
    'success' => true,
    'user_id' => $user_id,
    'user_login' => $user_login,
    'products' => $results
  ], 200);
}

function get_my_products_old(WP_REST_Request $request) {
  global $wpdb;

  vogo_error_log3("VOGO_LOG_START [GET MY PRODUCTS EXTENDED]");
  vogo_error_log3("[STEP 0.1.AB] ACTIVE DB: " . DB_NAME);

  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user_login = get_userdata($user_id)->user_login ?? '';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("[STEP 1] User ID: $user_id | IP: $ip");

  // Define table names using prefix
  $table_product_cities = $wpdb->prefix . "product_cities";
  $table_product_malls  = $wpdb->prefix . "product_malls";
  $table_cities         = $wpdb->prefix . "cities";
  $table_malls          = $wpdb->prefix . "mall_locations";

  $sql = "
    SELECT 
      p.ID AS product_id,
      p.post_title,
      p.post_status,
      p.post_date AS published_date,
      p.post_excerpt AS product_short_description,
      p.post_content AS product_description,
      p.post_name AS slug,
      p.menu_order AS position,

      lookup.sku,
      lookup.stock_quantity,
      lookup.stock_status,
      lookup.min_price AS price,

      img.guid AS product_image_url,

      GROUP_CONCAT(DISTINCT cat_terms.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT tag_terms.name SEPARATOR ', ') AS tags,
      GROUP_CONCAT(DISTINCT brand_terms.name SEPARATOR ', ') AS brand,
      GROUP_CONCAT(DISTINCT c.city_name SEPARATOR ', ') AS cities,
      GROUP_CONCAT(DISTINCT m.mall_name SEPARATOR ', ') AS mall_locations

    FROM {$wpdb->prefix}posts p

    INNER JOIN {$wpdb->prefix}term_relationships rel_provider ON rel_provider.object_id = p.ID
    INNER JOIN {$wpdb->prefix}term_taxonomy tax_provider ON rel_provider.term_taxonomy_id = tax_provider.term_taxonomy_id
    INNER JOIN {$wpdb->prefix}termmeta tm ON tax_provider.term_id = tm.term_id

    LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup lookup ON p.ID = lookup.product_id
    LEFT JOIN {$wpdb->prefix}postmeta pm_img ON p.ID = pm_img.post_id AND pm_img.meta_key = '_thumbnail_id'
    LEFT JOIN {$wpdb->prefix}posts img ON img.ID = pm_img.meta_value

    LEFT JOIN {$wpdb->prefix}term_relationships rel_cat ON rel_cat.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_cat ON rel_cat.term_taxonomy_id = tax_cat.term_taxonomy_id AND tax_cat.taxonomy = 'product_cat'
    LEFT JOIN {$wpdb->prefix}terms cat_terms ON cat_terms.term_id = tax_cat.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_tag ON rel_tag.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_tag ON rel_tag.term_taxonomy_id = tax_tag.term_taxonomy_id AND tax_tag.taxonomy = 'product_tag'
    LEFT JOIN {$wpdb->prefix}terms tag_terms ON tag_terms.term_id = tax_tag.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_brand ON rel_brand.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_brand ON rel_brand.term_taxonomy_id = tax_brand.term_taxonomy_id AND tax_brand.taxonomy = 'product_brand'
    LEFT JOIN {$wpdb->prefix}terms brand_terms ON brand_terms.term_id = tax_brand.term_id

    LEFT JOIN $table_product_cities pc ON pc.product_id = p.ID
    LEFT JOIN $table_cities c ON c.id = pc.city_id

    LEFT JOIN $table_product_malls pm ON pm.product_id = p.ID
    LEFT JOIN $table_malls m ON m.id = pm.mall_id

    WHERE tax_provider.taxonomy = 'product_provider'
      AND tm.meta_key = 'created_by'
      AND tm.meta_value = $user_id
      AND p.post_type = 'product'
      AND p.post_status IN ('publish', 'draft', 'pending')

    GROUP BY p.ID
    ORDER BY p.ID DESC
    LIMIT 100
  ";

  vogo_error_log3("##############SQL: $sql");

  $results = $wpdb->get_results($sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] SQL ERROR: {$wpdb->last_error}");
    vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response([
      'success'   => false,
      'error'     => 'SQL error',
      'sql_error' => $wpdb->last_error
    ], 500);
  }

  vogo_error_log3("[STEP 2] Retrieved products count: " . count($results));
  vogo_error_log3("VOGO_LOG_END");

  return new WP_REST_Response([
    'success'     => true,
    'user_id'     => $user_id,
    'user_login'  => $user_login,
    'products'    => $results
  ], 200);
}
//real - tabele in sql city si mall
function get_my_products(WP_REST_Request $request) {
  global $wpdb;

  vogo_error_log3("VOGO_LOG_START [GET MY PRODUCTS EXTENDED]");
  vogo_error_log3("[STEP 0.1] ACTIVE DB: " . DB_NAME);

  $user_result = extract_user_from_jwt_token($request);
  if ($user_result instanceof WP_REST_Response) return $user_result;
  $user_id = $user_result;
  $user_login = get_userdata($user_id)->user_login ?? '';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("[STEP 1] User ID: $user_id | IP: $ip");

  // Define table names using prefix
  $table_product_cities = $wpdb->prefix . "product_cities";
  $table_product_malls  = $wpdb->prefix . "product_malls";
  $table_cities         = $wpdb->prefix . "cities";
  $table_malls          = $wpdb->prefix . "mall_locations";

  $sql = "
    SELECT 
      p.ID AS product_id,
      p.post_title,
      p.post_status,
      p.post_date AS published_date,
      p.post_excerpt AS product_short_description,
      p.post_content AS product_description,
      p.post_name AS slug,
      p.menu_order AS position,

      lookup.sku,
      lookup.stock_quantity,
      lookup.stock_status,
      lookup.min_price AS price,

      img.guid AS product_image_url,

      GROUP_CONCAT(DISTINCT cat_terms.name SEPARATOR ', ') AS categories,
      GROUP_CONCAT(DISTINCT tag_terms.name SEPARATOR ', ') AS tags,
      GROUP_CONCAT(DISTINCT brand_terms.name SEPARATOR ', ') AS brand,
      GROUP_CONCAT(DISTINCT c.city_name SEPARATOR ', ') AS cities,
      GROUP_CONCAT(DISTINCT m.mall_name SEPARATOR ', ') AS mall_locations

    FROM {$wpdb->prefix}posts p

    INNER JOIN {$wpdb->prefix}term_relationships rel_provider ON rel_provider.object_id = p.ID
    INNER JOIN {$wpdb->prefix}term_taxonomy tax_provider ON rel_provider.term_taxonomy_id = tax_provider.term_taxonomy_id
    INNER JOIN {$wpdb->prefix}termmeta tm ON tax_provider.term_id = tm.term_id

    LEFT JOIN {$wpdb->prefix}wc_product_meta_lookup lookup ON p.ID = lookup.product_id
    LEFT JOIN {$wpdb->prefix}postmeta pm_img ON p.ID = pm_img.post_id AND pm_img.meta_key = '_thumbnail_id'
    LEFT JOIN {$wpdb->prefix}posts img ON img.ID = pm_img.meta_value

    LEFT JOIN {$wpdb->prefix}term_relationships rel_cat ON rel_cat.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_cat ON rel_cat.term_taxonomy_id = tax_cat.term_taxonomy_id AND tax_cat.taxonomy = 'product_cat'
    LEFT JOIN {$wpdb->prefix}terms cat_terms ON cat_terms.term_id = tax_cat.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_tag ON rel_tag.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_tag ON rel_tag.term_taxonomy_id = tax_tag.term_taxonomy_id AND tax_tag.taxonomy = 'product_tag'
    LEFT JOIN {$wpdb->prefix}terms tag_terms ON tag_terms.term_id = tax_tag.term_id

    LEFT JOIN {$wpdb->prefix}term_relationships rel_brand ON rel_brand.object_id = p.ID
    LEFT JOIN {$wpdb->prefix}term_taxonomy tax_brand ON rel_brand.term_taxonomy_id = tax_brand.term_taxonomy_id AND tax_brand.taxonomy = 'product_brand'
    LEFT JOIN {$wpdb->prefix}terms brand_terms ON brand_terms.term_id = tax_brand.term_id

    LEFT JOIN $table_product_cities pc ON pc.product_id = p.ID
    LEFT JOIN $table_cities c ON c.id = pc.city_id

    LEFT JOIN $table_product_malls pm ON pm.product_id = p.ID
    LEFT JOIN $table_malls m ON m.id = pm.mall_id

    WHERE tax_provider.taxonomy = 'product_provider'
      AND tm.meta_key = 'created_by'
      AND tm.meta_value = $user_id
      AND p.post_type = 'product'
      AND p.post_status IN ('publish', 'draft', 'pending')

    GROUP BY p.ID
    ORDER BY p.ID DESC
    LIMIT 100
  ";

  vogo_error_log3("##############SQL: $sql");

  $results = $wpdb->get_results($sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] SQL ERROR: {$wpdb->last_error}");
    vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response([
      'success'   => false,
      'error'     => 'SQL error',
      'sql_error' => $wpdb->last_error
    ], 500);
  }

  vogo_error_log3("[STEP 2] Retrieved products count: " . count($results));
  vogo_error_log3("VOGO_LOG_END");

  return new WP_REST_Response([
    'success'     => true,
    'user_id'     => $user_id,
    'user_login'  => $user_login,
    'products'    => $results
  ], 200);
}

/**
 * get_vendor_list
 * Returns paginated list of active providers (status='active' AND active=1 when present).
 * Filters: search (by provider_name/provider_slug), page, per_page.
 */
function get_vendor_list(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START [get_vendor_list] | IP:$ip | USER:0");
  vogo_error_log3("ACTIVE DB: ".DB_NAME);

  // [STEP 0.1] Parse input
  $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($p)." | IP:$ip | USER:0");
  $search=trim(sanitize_text_field($p['search']??'')); 
  $page=max(1,(int)($p['page']??1)); 
  $per=max(1,min(100,(int)($p['per_page']??20))); 
  $offset=($page-1)*$per;

  // [STEP 0.2] JWT
  $user_id=extract_user_from_jwt_token($request); if($user_id instanceof WP_REST_Response) return $user_id;
  $user=get_userdata($user_id); $user_login=$user?$user->user_login:'unknown';
  vogo_error_log3("[STEP 0.2] JWT OK | IP:$ip | USER:$user_id");

  // [STEP 1] Table + column existence
  $table=$wpdb->prefix.'vogo_providers';
  $has_active=(int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name='active'", DB_NAME, $table
  ));
  if($wpdb->last_error) vogo_error_log3("[STEP 1][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  // [STEP 2] WHERE base (only active providers)
  $where="WHERE status='active'"; $args=[];
  if($has_active){ $where.=" AND active=1"; }

  // [STEP 3] Search filter
  if($search!==''){
    $like='%'.$wpdb->esc_like($search).'%';
    $where.=" AND (provider_name LIKE %s OR provider_slug LIKE %s)";
    array_push($args,$like,$like);
  }

  // [STEP 4] Total count
  $sql_total=$wpdb->prepare("SELECT COUNT(*) FROM {$table} {$where}", ...$args);
  vogo_error_log3("##############SQL: ".preg_replace('/\s+/',' ',$sql_total)." | IP:$ip | USER:$user_id");
  $total=(int)$wpdb->get_var($sql_total);
  if($wpdb->last_error) vogo_error_log3("[STEP 4][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  // [STEP 5] Data page
  $sql=$wpdb->prepare("
    SELECT id AS vendor_id, provider_name, provider_slug, term_id, user_id, accepting_orders, status
    ".($has_active?", active":"")."
    FROM {$table} {$where}
    ORDER BY provider_name ASC
    LIMIT %d OFFSET %d
  ", ...array_merge($args,[$per,$offset]));
  vogo_error_log3("##############SQL: ".preg_replace('/\s+/',' ',$sql)." | IP:$ip | USER:$user_id");
  $items=$wpdb->get_results($sql,ARRAY_A);
  if($wpdb->last_error) vogo_error_log3("[STEP 5][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  // [STEP 6] Response
  vogo_error_log3("VOGO_LOG_END [get_vendor_list] | IP:$ip | USER:$user_id");
  return new WP_REST_Response([
    'success'=>true,
    'message'=>'Vendors fetched successfully',
    'current_page'=>$page,
    'per_page'=>$per,
    'total_items'=>$total,
    'total_pages'=>$per?ceil($total/$per):1,
    'data'=>$items,
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
}

/**
 * get_my_vendor_id
 * Resolves current user's vendor_id from wp_vogo_providers (only active providers).
 */
function get_my_vendor_id(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START [get_my_vendor_id] | IP:$ip | USER:0");
  vogo_error_log3("ACTIVE DB: ".DB_NAME);

  // [STEP 0.1] JWT
  $user_id=extract_user_from_jwt_token($request); if($user_id instanceof WP_REST_Response) return $user_id;
  $user=get_userdata($user_id); $user_login=$user?$user->user_login:'unknown';
  vogo_error_log3("[STEP 0.1] JWT OK | IP:$ip | USER:$user_id");

  $table=$wpdb->prefix.'vogo_providers';
  $has_active=(int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name='active'", DB_NAME, $table
  ));

  // [STEP 1] Find provider by user_id (only active)
  $where="WHERE user_id=%d AND status='active'"; $params=[$user_id];
  if($has_active){ $where.=" AND active=1"; }
  $sql=$wpdb->prepare("SELECT id FROM {$table} {$where} LIMIT 1", ...$params);
  vogo_error_log3("##############SQL: ".preg_replace('/\s+/',' ',$sql)." | IP:$ip | USER:$user_id");
  $vendor_id=$wpdb->get_var($sql);
  if($wpdb->last_error) vogo_error_log3("[STEP 1][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  vogo_error_log3("VOGO_LOG_END [get_my_vendor_id] | IP:$ip | USER:$user_id");
  return new WP_REST_Response([
    'success'=>true,
    'message'=>'Vendor resolved',
    'vendor_id'=>$vendor_id!==null?(int)$vendor_id:null,
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
}

/**
 * get_vendor_info_by_id
 * Returns provider profile by vendor_id from wp_vogo_providers (only active providers).
 */
function get_vendor_info_by_id(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START [get_vendor_info_by_id] | IP:$ip | USER:0");
  vogo_error_log3("ACTIVE DB: ".DB_NAME);

  // [STEP 0.1] Parse + JWT
  $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($p)." | IP:$ip | USER:0");
  $vendor_id=(int)($p['vendor_id']??0);
  $user_id=extract_user_from_jwt_token($request); if($user_id instanceof WP_REST_Response) return $user_id;
  $user=get_userdata($user_id); $user_login=$user?$user->user_login:'unknown';

  if($vendor_id<=0){
    vogo_error_log3("[STEP 0.2] Invalid vendor_id | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'vendor_id is required','user_id'=>$user_id,'user_login'=>$user_login],400);
  }

  $table=$wpdb->prefix.'vogo_providers';
  $has_active=(int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name='active'", DB_NAME, $table
  ));

  // [STEP 1] Fetch provider (active only)
  $where="WHERE id=%d AND status='active'"; $params=[$vendor_id];
  if($has_active){ $where.=" AND active=1"; }

  $sql=$wpdb->prepare("
    SELECT id AS vendor_id, provider_name, provider_slug, term_id, user_id, accepting_orders, status
    ".($has_active?", active":"").",
    created_at, created_by, modified_at, modified_by
    FROM {$table} {$where}
    LIMIT 1
  ", ...$params);
  vogo_error_log3("##############SQL: ".preg_replace('/\s+/',' ',$sql)." | IP:$ip | USER:$user_id");
  $info=$wpdb->get_row($sql,ARRAY_A);
  if($wpdb->last_error) vogo_error_log3("[STEP 1][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  if(!$info){
    vogo_error_log3("[STEP 2] Vendor not found or inactive | vendor_id=$vendor_id | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'Vendor not found','user_id'=>$user_id,'user_login'=>$user_login],404);
  }

  vogo_error_log3("VOGO_LOG_END [get_vendor_info_by_id] | IP:$ip | USER:$user_id");
  return new WP_REST_Response([
    'success'=>true,
    'message'=>'Vendor info fetched',
    'data'=>$info,
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
}

/**
 * get_vendor_info_by_jwt
 * Resolve current user's provider (vendor) and return its profile (only active providers).
 * Source: wp_vogo_providers; filter status='active' AND active=1 (if column exists).
 */
function get_vendor_info_by_jwt(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START [get_vendor_info_by_jwt] | IP:$ip | USER:0");
  vogo_error_log3("ACTIVE DB: ".DB_NAME);

  // [STEP 0.1] Parse raw payload (for trace only)
  $raw=file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".($raw!==''?$raw:'{}')." | IP:$ip | USER:0");

  // [STEP 0.2] JWT → user
  $user_id=extract_user_from_jwt_token($request); if($user_id instanceof WP_REST_Response) return $user_id;
  $usr=get_userdata($user_id); $user_login=$usr?$usr->user_login:'unknown';
  vogo_error_log3("[STEP 0.2] JWT OK | USER:$user_id ($user_login) | IP:$ip");

  // [STEP 1] Table + 'active' column existence
  $table=$wpdb->prefix.'vogo_providers';
  $has_active=(int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=%s AND table_name=%s AND column_name='active'", DB_NAME, $table
  ));
  if($wpdb->last_error) vogo_error_log3("[STEP 1][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

  // [STEP 2] Query provider by user_id (active only)
  $where="WHERE user_id=%d AND status='active'"; $params=[$user_id];
  if($has_active){ $where.=" AND active=1"; }
  $sql=$wpdb->prepare("
    SELECT id AS vendor_id, provider_name, provider_slug, term_id, user_id, accepting_orders, status
    ".($has_active?", active":"").",
    created_at, created_by, modified_at, modified_by
    FROM {$table} {$where}
    LIMIT 1
  ", ...$params);
  vogo_error_log3("##############SQL: ".preg_replace('/\s+/',' ',$sql)." | IP:$ip | USER:$user_id");
  $info=$wpdb->get_row($sql,ARRAY_A);
  if($wpdb->last_error){
    vogo_error_log3("[STEP 2][SQL ERR] {$wpdb->last_error} | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END [get_vendor_info_by_jwt] | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'SQL error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
  }

  // [STEP 3] Not found / inactive
  if(!$info){
    vogo_error_log3("[STEP 3] Vendor not found or inactive for USER:$user_id | IP:$ip");
    vogo_error_log3("VOGO_LOG_END [get_vendor_info_by_jwt] | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'Vendor not found for current user','user_id'=>$user_id,'user_login'=>$user_login],404);
  }

  // [STEP 4] OK
  vogo_error_log3("VOGO_LOG_END [get_vendor_info_by_jwt] | IP:$ip | USER:$user_id");
  return new WP_REST_Response([
    'success'=>true,
    'message'=>'Vendor info resolved',
    'data'=>$info,
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
}

/**
 * Returns up to 100 mobile-enabled product categories using SQL and JSON_OBJECT()
 */
function vendor_category_list (WP_REST_Request $request) {
  global $wpdb;

  // ─────────────────────────────────────────────────────────────────────────────
  // VOGO_LOG_START + initial debug context
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP: $ip | USER: 0");
  $raw_input = file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: 0");
  $db_name = $wpdb->get_var("SELECT DATABASE()"); vogo_error_log3("ACTIVE DB: $db_name | IP: $ip | USER: 0");

  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 1] Security: extract user from JWT (mandatory in adi-tehnic)
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) { vogo_error_log3("[STEP 1] JWT validation failed | IP: $ip | USER: 0"); return $user_id; }
  $wp_user = get_user_by('id', (int)$user_id); $user_login = $wp_user ? $wp_user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] JWT validated | IP: $ip | USER: $user_id");

  $request_user_id   = (int)$user_id;
  $request_user_name = $user_login;  

  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 2] Parse & sanitize pagination params (defaults + caps)
  $p = $request->get_json_params();
  $current_page = max(1, intval($p['current_page'] ?? 1));
  $per_page_raw = intval($p['per_page'] ?? 20);
  $per_page = ($per_page_raw > 0 && $per_page_raw <= 100) ? $per_page_raw : 20; // cap at 100 for safety
  $offset = ($current_page - 1) * $per_page;
  vogo_error_log3("[STEP 2] Pagination resolved: current_page=$current_page, per_page=$per_page, offset=$offset | IP: $ip | USER: $user_id");


  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 3] Table names with WP prefix (adi-tehnic rule)
  $t_terms = $wpdb->prefix . 'terms';
  $t_term_tax = $wpdb->prefix . 'term_taxonomy';
  $t_termmeta = $wpdb->prefix . 'termmeta';
  $t_posts = $wpdb->prefix . 'posts';

  try {
    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 4] COUNT total_items (filters identical to data query)
    $sql_count = "
      SELECT COUNT(1)
      FROM {$t_terms} t
      INNER JOIN {$t_term_tax} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'
      LEFT JOIN {$t_termmeta} m ON m.term_id = t.term_id AND m.meta_key = 'mobile_category'
      WHERE m.meta_value = '1'
    ";
    vogo_error_log3("##############SQL: $sql_count | IP: $ip | USER: $user_id");
    $total_items = (int)$wpdb->get_var($sql_count);
    if (!empty($wpdb->last_error)) { vogo_error_log3("[STEP 4] SQL Error (count): {$wpdb->last_error} | IP: $ip | USER: $user_id"); }

    $total_pages = ($per_page > 0) ? (int)ceil($total_items / $per_page) : 0;
    vogo_error_log3("[STEP 4.1] Totals computed: total_items=$total_items, total_pages=$total_pages | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 5] DATA query with JSON_OBJECT + ORDER + LIMIT/OFFSET
    $sql_data = "
      SELECT JSON_OBJECT(
        'id', t.term_id,
        'name', t.name,
        'slug', t.slug,
        'description', COALESCE(tt.description, ''),
        'image', IFNULL(p.guid, ''),
        'position', t.term_order,
        'has_children', (
          SELECT IF(COUNT(*) > 0, TRUE, FALSE)
          FROM {$t_terms} c
          INNER JOIN {$t_term_tax} ct ON ct.term_id = c.term_id AND ct.taxonomy = 'product_cat'
          LEFT JOIN {$t_termmeta} cm ON cm.term_id = c.term_id AND cm.meta_key = 'mobile_category'
          WHERE ct.parent = t.term_id AND cm.meta_value = '1'
        )
      ) AS json_data
      FROM {$t_terms} t
      INNER JOIN {$t_term_tax} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'
      LEFT JOIN {$t_termmeta} m  ON m.term_id  = t.term_id AND m.meta_key = 'mobile_category'
      LEFT JOIN {$t_termmeta} mt ON mt.term_id = t.term_id AND mt.meta_key = 'thumbnail_id'
      LEFT JOIN {$t_posts} p     ON p.ID       = mt.meta_value
      WHERE m.meta_value = '1'
      ORDER BY t.term_order ASC
      LIMIT %d OFFSET %d
    ";
    $sql_data = $wpdb->prepare($sql_data, $per_page, $offset);
    vogo_error_log3("##############SQL: $sql_data | IP: $ip | USER: $user_id");

    $raw = $wpdb->get_col($sql_data);
    if (!empty($wpdb->last_error)) { vogo_error_log3("[STEP 5] SQL Error (data): {$wpdb->last_error} | IP: $ip | USER: $user_id"); }

    vogo_error_log3("[STEP 5.1] RAW SQL JSON rows: " . print_r($raw, true) . " | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 6] Decode JSON rows safely
    $results = array_map(static function($r){ return json_decode($r, true); }, $raw ?? []);
    vogo_error_log3("[STEP 6] Decoded " . count($results) . " categories | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 7] Build response with pagination meta + user
    $response = array(
      'status'        => true,
      'code'          => 200,
      'message'       => 'Category list fetched successfully.',
      'request_user_id'   => $request_user_id,
      'request_user_name' => $request_user_name,         
      'current_page'  => $current_page,
      'per_page'      => $per_page,
      'total_pages'   => $total_pages,
      'total_items'   => $total_items,
      'data'          => $results,
      'user_id'       => (int)$user_id,
      'user_login'    => $user_login,
   
    );
    vogo_error_log3("VOGO_LOG_END | IP: $ip | USER: $user_id");
    return new WP_REST_Response($response, 200);

  } catch (Throwable $e) {
    // ───────────────────────────────────────────────────────────────────────────
    vogo_error_log3("[STEP ERR] Exception: " . $e->getMessage() . " | IP: $ip | USER: $user_id");
    vogo_error_log3("VOGO_LOG_END | IP: $ip | USER: $user_id");
    return new WP_REST_Response(array(
      'status'     => false,
      'code'       => 500,
      'message'    => 'Server error. Please try again.',
      'request_user_id'   => $request_user_id,
      'request_user_name' => $request_user_name,        
      'error'      => $e->getMessage(),
      'sql_error'  => $wpdb->last_error ?? null,
      'user_id'    => (int)$user_id,
      'user_login' => $user_login ?? 'unknown',    
    ), 500);
  }
}

// =====================================================================
// PRODUCT LIST (provider-scoped) — returns only products for JWT's provider
// Route example: /wp-json/vogo/v1/provider/get-my-products  (POST)
// =====================================================================
function provider_product_list_get_0918(WP_REST_Request $request) {
  global $wpdb;

  // ---------- Logging & context ----------
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START | [STEP 0] START product_list | IP:$ip");
  vogo_error_log3("[STEP 0.1] ACTIVE DB: " . DB_NAME . " | Raw payload: " . json_encode($request->get_params()));

  // ---------- Auth ----------
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) return $user_or_err;
  $user_id    = (int)$user_or_err;
  $user       = get_userdata($user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] JWT user_id=$user_id, user_login=$user_login | IP:$ip");

  // ---------- Provider(s) for this user ----------
  $vp = $wpdb->prefix . 'vogo_providers';     // id, provider_name, term_id, user_id
  $vendor_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$vp} WHERE user_id = %d", $user_id));
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] STEP 1.1 providers SQL: {$wpdb->last_error} | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'SQL error','sql_error'=>$wpdb->last_error],500);
  }
  if (empty($vendor_ids)) {
    vogo_error_log3("[STEP 1.2] No providers for user_id=$user_id => 0 products | IP:$ip");
    return new WP_REST_Response([
      'success'         => true,
      'code'            => 200,
      'message'         => 'No records found',
      'current_page'    => 1,
      'per_page'        => 0,
      'total_pages'     => 0,
      'total_items'     => 0,
      'currency_code'   => get_woocommerce_currency(),
      'currency_symbol' => html_entity_decode(get_woocommerce_currency_symbol()),
      'data'            => [],
      'user_id'         => $user_id,
      'user_login'      => $user_login
    ], 200);
  }

  // ---------- Payload ----------
  $p        = $wpdb->posts;
  $lk       = $wpdb->prefix . 'wc_product_meta_lookup';
  $pv       = $wpdb->prefix . 'product_vendor'; // product_id, vendor_id
  $tr       = $wpdb->term_relationships;
  $tt       = $wpdb->term_taxonomy;

  $params = $request->get_params();
  $orderby  = isset($params['orderby']) ? sanitize_text_field($params['orderby']) : 'ID';
  $order    = strtoupper(isset($params['order']) ? sanitize_text_field($params['order']) : 'DESC');
  $order    = in_array($order, ['ASC','DESC'], true) ? $order : 'DESC';
  $per_page = isset($params['per_page']) ? max(1, min(100, (int)$params['per_page'])) : 50;
  $page     = isset($params['page']) ? max(1, (int)$params['page']) : 1;
  $offset   = ($page - 1) * $per_page;
  $search   = isset($params['search']) ? trim((string)$params['search']) : '';
  $cat_id   = isset($params['id_categorie']) ? (int)$params['id_categorie'] : 0;

  vogo_error_log3("[STEP 2] parsed params | orderby=$orderby | order=$order | per_page=$per_page | page=$page | search='".esc_sql($search)."' | id_categorie=$cat_id | IP:$ip | USER:$user_id");

  // ---------- WHERE (scoped to provider -> vendor_ids) ----------
  $where_parts = ["p.post_type='product'", "p.post_status IN ('publish','draft','pending')"];
  $prep = [];

  // vendor IN (...)
  $vendor_ids = array_map('intval', $vendor_ids);
  $ph_vendors = implode(',', array_fill(0, count($vendor_ids), '%d'));
  $where_parts[] = "pv.vendor_id IN ($ph_vendors)";
  $prep = array_merge($prep, $vendor_ids);

  // search by title
  if ($search !== '') { $where_parts[] = "p.post_title LIKE %s"; $prep[] = '%'.$wpdb->esc_like($search).'%'; }

  // optional category filter
  if ($cat_id > 0) {
    $where_parts[] = "
      EXISTS (
        SELECT 1 FROM {$tr} trc
        JOIN {$tt} ttc ON ttc.term_taxonomy_id = trc.term_taxonomy_id
        WHERE trc.object_id = p.ID
          AND ttc.taxonomy = 'product_cat'
          AND ttc.term_id = %d
      )";
    $prep[] = $cat_id;
  }

  $where_sql = implode(' AND ', $where_parts);

  // ---------- ORDER BY ----------
  $order_col = "p.ID";
  if ($orderby === 'price')        $order_col = "l.min_price";
  elseif ($orderby === 'rating')   $order_col = "l.average_rating";
  elseif ($orderby === 'popularity') $order_col = "l.total_sales";
  elseif ($orderby === 'date')     $order_col = "p.post_date";
  elseif ($orderby === 'title')    $order_col = "p.post_title";
  elseif ($orderby === 'position') $order_col = "p.menu_order";

  // ---------- COUNT ----------
  $count_sql_base = "
    SELECT COUNT(DISTINCT p.ID)
    FROM {$p} p
    JOIN {$lk} l  ON l.product_id = p.ID
    JOIN {$pv} pv ON pv.product_id = p.ID
    WHERE {$where_sql}
  ";
  $sql_count = $wpdb->prepare($count_sql_base, $prep);
  vogo_error_log3("##############SQL COUNT: " . preg_replace('/\s+/', ' ', $sql_count) . " | IP:$ip | USER:$user_id");
  $total_count = (int)$wpdb->get_var($sql_count);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] COUNT SQL: {$wpdb->last_error} | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB error on count','sql_error'=>$wpdb->last_error],500);
  }

  // ---------- MAIN ----------
  $select = "
    p.ID,
    p.post_title,
    p.post_name  AS slug,
    p.menu_order AS position,
    l.min_price      AS price,
    l.max_price      AS max_price,
    l.onsale         AS onsale,
    l.stock_quantity,
    l.stock_status,
    l.average_rating AS rating,
    l.total_sales    AS popularity,
    -- vendor info (current provider)
    MIN(pv.vendor_id)              AS vendor_id,
    MAX(vp.provider_name)          AS vendor_name
  ";

  $main_sql_base = "
    SELECT {$select}
    FROM {$p} p
    JOIN {$lk} l   ON l.product_id = p.ID
    JOIN {$pv} pv  ON pv.product_id = p.ID
    JOIN {$vp} vp  ON vp.id = pv.vendor_id
    WHERE {$where_sql}
    GROUP BY p.ID
    ORDER BY {$order_col} {$order}
    LIMIT %d OFFSET %d
  ";
  $sql_main = $wpdb->prepare($main_sql_base, array_merge($prep, [$per_page, $offset]));
  vogo_error_log3("##############SQL MAIN: " . preg_replace('/\s+/', ' ', $sql_main) . " | IP:$ip | USER:$user_id");
  $rows = $wpdb->get_results($sql_main, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] MAIN SQL: {$wpdb->last_error} | IP:$ip | USER:$user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB error on fetch','sql_error'=>$wpdb->last_error],500);
  }

  // ---------- Currency ----------
  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  // ---------- Hydrate response items (same fields) ----------
  $data = [];
  foreach ($rows as $r) {
    $pid = (int)$r['ID'];

    // image
    $thumb_id = (int)get_post_thumbnail_id($pid);
    $img = $thumb_id ? wp_get_attachment_url($thumb_id) : '';

    // categories
    $cats = [];
    $terms = get_the_terms($pid, 'product_cat');
    if ($terms && !is_wp_error($terms)) {
      foreach ($terms as $t) { $cats[] = ['id'=>$t->term_id, 'name'=>$t->name]; }
    }

    $vendor = !empty($r['vendor_id'])
      ? ['id' => (int)$r['vendor_id'], 'name' => (string)$r['vendor_name']]
      : null;

    $data[] = [
      'id'              => $pid,
      'name'            => (string)$r['post_title'],
      'slug'            => (string)$r['slug'],
      'position'        => isset($r['position']) ? (int)$r['position'] : 0,
      'price'           => isset($r['price']) ? (string)$r['price'] : null,
      'max_price'       => isset($r['max_price']) ? (string)$r['max_price'] : null,
      'onsale'          => isset($r['onsale']) ? (int)$r['onsale'] : 0,
      'stock_quantity'  => isset($r['stock_quantity']) ? (int)$r['stock_quantity'] : null,
      'stock_status'    => (string)$r['stock_status'],
      'rating'          => isset($r['rating']) ? (float)$r['rating'] : null,
      'popularity'      => isset($r['popularity']) ? (int)$r['popularity'] : 0,
      'currency_symbol' => $currency_symbol,
      'currency_code'   => $currency_code,
      'image'           => $img,
      'post_status'     => 'active',
      'categories'      => $cats,
      'vendor'          => $vendor
    ];
  }

  vogo_error_log3("[STEP 3] items=" . count($data) . " | total_count=$total_count | IP:$ip | USER:$user_id");
  vogo_error_log3("VOGO_LOG_END | product_list");

  return new WP_REST_Response([
    'success'         => true,
    'code'            => 200,
    'message'         => $total_count > 0 ? 'Products fetched successfully' : 'No records found',
    'current_page'    => $page,
    'per_page'        => $per_page,
    'total_pages'     => $per_page > 0 ? (int)ceil($total_count / $per_page) : 0,
    'total_items'     => $total_count,
    'currency_code'   => $currency_code,
    'currency_symbol' => $currency_symbol,
    'data'            => $data,
    'user_id'         => $user_id,
    'user_login'      => $user_login
  ], 200);
}

function provider_product_list_get(WP_REST_Request $request){
  global $wpdb; 
  $module='provider-product-list-get'; 
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; 
  $db=DB_NAME;

  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:jwt",$module);

  // STEP 0 – JWT → vendor_id (fără payload)
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $uid = (int)$user_or_err;
  $vendor_id = $uid; // folosim ID-ul din JWT ca vendor_id

  $wp_user = get_user_by('id', (int)$uid); 
  $user_login = $wp_user ? $wp_user->user_login : 'unknown';
  $jwt_user_id   = (int)$uid;
  $jwt_user_name = $user_login;    

  // STEP 0.1 – Input
  $p = $request->get_json_params();
  $per_page = max(1, min(1000, (int)($p['per_page'] ?? 50)));
  $page     = max(1, (int)($p['page'] ?? 1));
  $offset   = ($page-1)*$per_page;

  $orderby  = strtolower(trim((string)($p['orderby'] ?? 'position')));   // 'position' | 'price'
  $order    = strtoupper(trim((string)($p['order'] ?? 'ASC')));          // 'ASC' | 'DESC'
  $search   = trim((string)($p['search'] ?? ''));                        // 'pizza'
  $cities   = trim((string)($p['cities'] ?? ''));                        // "1,2"
  $brand    = trim((string)($p['product_brand'] ?? ''));                 // TODO
  $malls    = trim((string)($p['malls'] ?? ''));                         // TODO

  // category (CSV sau array)
  $category_param = $p['category'] ?? '';
  if(is_array($category_param)){ $category_param = implode(',', array_map('trim',$category_param)); }
  $category = trim((string)$category_param); // ex: "544,73,542"

  // STEP 1 – Whitelist ORDER BY
  $orderby = in_array($orderby, ['position','price'], true) ? $orderby : 'position';
  $order   = in_array($order, ['ASC','DESC'], true) ? $order : 'ASC';
  $order_by_sql = ($orderby==='position')
    ? " ORDER BY p.menu_order $order, p.post_title ASC "
    : " ORDER BY CAST(MAX(CASE WHEN pm.meta_key='_price' THEN pm.meta_value END) AS DECIMAL(18,6)) $order, p.menu_order ASC ";

  // STEP 2 – Filters
  $where=[]; $args=[];
  $where[]="p.post_type IN ('product')";
  $where[]="p.post_status IN ('publish','draft')";

  if($search!==''){ $where[]="p.post_title LIKE %s"; $args[]='%'.$wpdb->esc_like($search).'%'; }

  $cities_str='';
  if($cities!==''){
    $cities_str = implode(',', array_filter(array_map('trim', explode(',', $cities)), fn($x)=>$x!==''));
    if($cities_str!==''){
      $where[]="EXISTS(SELECT 1 FROM wp_product_cities pcw WHERE pcw.product_id=p.ID AND FIND_IN_SET(pcw.city_id,%s))";
      $args[]=$cities_str;
    }
  }

  if($vendor_id>0){
    $where[]="EXISTS(SELECT 1 FROM wp_product_vendor pvx WHERE pvx.product_id=p.ID AND pvx.vendor_id=%d AND pvx.status='active')";
    $args[]=$vendor_id;
  }

  if($category!==''){
    $category_str = implode(',', array_filter(array_map('trim', explode(',', $category)), fn($x)=>$x!==''));
    if($category_str!==''){
      $where[]="(
        EXISTS (
          SELECT 1
          FROM wp_term_relationships tr
          INNER JOIN wp_term_taxonomy tt
                  ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 AND tt.taxonomy = 'product_cat'
          WHERE tr.object_id = p.ID
            AND FIND_IN_SET(tt.term_id, %s)
        )
        OR
        EXISTS (
          SELECT 1
          FROM wp_product_meta_action pmaf
          WHERE pmaf.product_id = p.ID
            AND FIND_IN_SET(pmaf.product_main_category_id, %s)
        )
      )";
      $args[]=$category_str; // pt. tt.term_id
      $args[]=$category_str; // pt. pmaf.product_main_category_id
    }
  }

  // STEP 3 – SQL (vendor_obj cu filtru condițional pe vendor; HEREDOC safe pentru WHERE)
  $pcc_city_clause = ($cities_str!=='') ? " AND FIND_IN_SET(pcc.city_id,%s) " : "";
  $where_sql = implode(' AND ', $where);
  $vendor_filter_subq = ($vendor_id>0) ? " AND pv2.vendor_id = %d" : "";

   // STEP 3 – SQL (stil Vogo: string + placeholders)
  $pcc_city_clause     = ($cities_str!=='') ? " AND FIND_IN_SET(pcc.city_id,%s) " : "";
  $where_sql           = implode(' AND ', $where);
  $vendor_filter_subq  = ($vendor_id>0) ? " AND pv2.vendor_id = %d" : "";

  $sql =
"SELECT
  p.ID AS product_id,
  p.post_title AS product_title,
  MAX(CASE WHEN pm.meta_key = '_price'         THEN pm.meta_value END) AS price,
  MAX(CASE WHEN pm.meta_key = '_regular_price' THEN pm.meta_value END) AS regular_price,
  MAX(CASE WHEN pm.meta_key = '_sale_price'    THEN pm.meta_value END) AS sale_price,
  MAX(CASE WHEN pm.meta_key = '_sku'           THEN pm.meta_value END) AS sku,
  p.menu_order AS position,

  /* vendor_obj (fara audit; include vendor_id; fara product_id) */
  (
    SELECT JSON_OBJECT(
      'id', pv2.id,
      'vendor_id', pv2.vendor_id,
      'status', pv2.status
    )
    FROM wp_product_vendor pv2
    WHERE pv2.product_id = p.ID".$vendor_filter_subq."
      AND pv2.status = 'active'
    LIMIT 1
  ) AS vendor_obj,

  /* product_meta_action_obj (fara audit) */
  (
    SELECT JSON_OBJECT(
      'product_id', pma.product_id,
      'product_main_category_id', pma.product_main_category_id,
      'camera_broadcast_url', pma.camera_broadcast_url,
      'zoom_live_call_link', pma.zoom_live_call_link,
      'whatsapp_contact_url', pma.whatsapp_contact_url,
      'suggest_service_link', pma.suggest_service_link,
      'action_whatsapp_label', pma.action_whatsapp_label,
      'action_whatsapp_number', pma.action_whatsapp_number,
      'action_whatsapp_message', pma.action_whatsapp_message,
      'action_url_label', pma.action_url_label,
      'action_url_link', pma.action_url_link
    )
    FROM wp_product_meta_action pma
    WHERE pma.product_id = p.ID
    LIMIT 1
  ) AS product_meta_action_obj,

  /* category_meta_action_obj (fara audit) */
  (
    SELECT JSON_OBJECT(
      'category_id', cma.category_id,
      'camera_broadcast_url', cma.camera_broadcast_url,
      'zoom_live_call_link', cma.zoom_live_call_link,
      'whatsapp_contact_url', cma.whatsapp_contact_url,
      'suggest_service_link', cma.suggest_service_link,
      'action_whatsapp_label', cma.action_whatsapp_label,
      'action_whatsapp_number', cma.action_whatsapp_number,
      'action_whatsapp_message', cma.action_whatsapp_message,
      'action_url_label', cma.action_url_label,
      'action_url_link', cma.action_url_link
    )
    FROM wp_category_meta_action cma
    WHERE cma.category_id = (SELECT pma2.product_main_category_id FROM wp_product_meta_action pma2 WHERE pma2.product_id = p.ID LIMIT 1)
    LIMIT 1
  ) AS category_meta_action_obj,

  /* product_categories (Woo product_cat: id + name) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'id', t.term_id,
      'name', t.name
    )), JSON_ARRAY())
    FROM wp_term_relationships tr
    INNER JOIN wp_term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'product_cat'
    INNER JOIN wp_terms t         ON t.term_id = tt.term_id
    WHERE tr.object_id = p.ID
  ) AS product_categories,

  /* product_cities (array JSON, city object fara audit) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'product_id', pc.product_id,
      'city_id', pc.city_id,
      'city', (SELECT JSON_OBJECT('id', c.id, 'city_name', c.city_name, 'status', c.status, 'position', c.position) FROM wp_cities c WHERE c.id = pc.city_id LIMIT 1)
    )), JSON_ARRAY())
    FROM wp_product_cities pc
    WHERE pc.product_id = p.ID
  ) AS product_cities,

  /* product_category_cities (array JSON, fara audit) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'category_id', pcc.category_id,
      'city_id', pcc.city_id
    )), JSON_ARRAY())
    FROM wp_product_category_cities pcc
    WHERE pcc.category_id = (SELECT pma3.product_main_category_id FROM wp_product_meta_action pma3 WHERE pma3.product_id = p.ID LIMIT 1)".$pcc_city_clause."
  ) AS product_category_cities

FROM wp_posts p
LEFT  JOIN wp_product_vendor pv ON pv.product_id=p.ID AND pv.status='active'
LEFT  JOIN wp_postmeta pm ON pm.post_id=p.ID AND pm.meta_key IN('_price','_regular_price','_sale_price','_sku')
WHERE ".$where_sql."
GROUP BY p.ID, p.menu_order
".$order_by_sql."
LIMIT %d OFFSET %d";

  // STEP 3.1 – Bind args în ordinea placeholderelor
  $args2 = [];
  if($vendor_id>0){ $args2[] = $vendor_id; }      // %d pentru $vendor_filter_subq
  $args2 = array_merge($args2, $args);            // WHERE args (search, cities, vendor EXISTS, category EXISTS x2)
  if($cities_str!==''){ $args2[] = $cities_str; } // %s pentru $pcc_city_clause (dacă e cazul)
  $args2[] = $per_page; 
  $args2[] = $offset;

  $query = $wpdb->prepare($sql, ...$args2);
  vogo_error_log3("##############SQL: $query",$module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat (PHP-only change) */


  // STEP 3.1 – Bind args (în ordinea placeholderelor)
  $args2=[];
  if($vendor_id>0){ $args2[]=$vendor_id; }           // %d pentru {$vendor_filter_subq}
  $args2=array_merge($args2,$args);                  // WHERE args (search, cities, vendor EXISTS, category EXISTS x2)
  if($cities_str!==''){ $args2[]=$cities_str; }      // pcc city clause
  $args2[]=$per_page; $args2[]=$offset;              // pagination

  $query=$wpdb->prepare($sql, ...$args2);
  vogo_error_log3("##############SQL: $query",$module);

  // ==== NEW: COUNT total items (pentru total_pages) ====
  $count_sql = "SELECT COUNT(DISTINCT p.ID) FROM wp_posts p WHERE ".$where_sql;
  $count_query = $wpdb->prepare($count_sql, ...$args);
  vogo_error_log3("##############SQL COUNT: $count_query",$module);
  $total_items = (int)$wpdb->get_var($count_query);
  if($wpdb->last_error){ 
    vogo_error_log3("[$module] SQL COUNT ERROR: ".$wpdb->last_error,$module); 
    vogo_error_log3("VOGO_LOG_END",$module); 
    return new WP_REST_Response(['success'=>false,'error'=>'sql-count','sql_error'=>$wpdb->last_error,'vendor_id'=>($vendor_id?:null)],500); 
  }

  $rows=$wpdb->get_results($query, ARRAY_A);
  if($wpdb->last_error){ 
    vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error,$module); 
    vogo_error_log3("VOGO_LOG_END",$module); 
    return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error,'vendor_id'=>($vendor_id?:null)],500); 
  }

  // STEP 4 – Decode JSON fields to real objects/arrays + add images
  $json_object_keys=['vendor_obj','product_meta_action_obj','category_meta_action_obj'];
  $json_array_keys=['product_categories','product_cities','product_category_cities'];
  foreach($rows as &$r){
    foreach($json_object_keys as $k){
      if(array_key_exists($k,$r)){
        $v=$r[$k];
        if($v===null||$v===''){ $r[$k]=null; }
        elseif(is_string($v)){ $d=json_decode($v,true); $r[$k]=(json_last_error()===JSON_ERROR_NONE&&is_array($d))?$d:null; }
      }
    }
    foreach($json_array_keys as $k){
      if(array_key_exists($k,$r)){
        $v=$r[$k];
        if($v===null||$v===''){ $r[$k]=[]; }
        elseif(is_string($v)){ $d=json_decode($v,true); $r[$k]=(json_last_error()===JSON_ERROR_NONE&&is_array($d))?$d:[]; }
        elseif(!is_array($v)){ $r[$k]=[]; }
      }
    }
    unset($r['vendor_id']);

    // ==== NEW: product images (thumbnail + gallery) ====
    $pid = isset($r['product_id']) ? (int)$r['product_id'] : 0;
    if($pid>0){
      // main image
      $thumb_id = (int)get_post_thumbnail_id($pid);
      $main_img = $thumb_id ? wp_get_attachment_url($thumb_id) : '';

      // gallery images
      $images = [];
      if($main_img!==''){ $images[] = $main_img; }
      $gallery_ids = (string)get_post_meta($pid,'_product_image_gallery',true);
      if($gallery_ids!==''){
        foreach(array_filter(array_map('trim', explode(',', $gallery_ids))) as $gid){
          $url = wp_get_attachment_url((int)$gid);
          if($url){ $images[] = $url; }
        }
      }
      $r['image']  = $main_img;   // for quick use
      $r['images'] = $images;     // full list
    }
  } unset($r);

  // STEP 5 – Response (ADD: current_page, total_pages, total_items)
  $resp=[
    'success'=>true,
    'vendor_id'=>$vendor_id,
    'jwt_user_id'=> $jwt_user_id,
    'jwt_user_name'=> $jwt_user_name,	    
    'page'=>$page,
    'per_page'=>$per_page,
    'count'=>count($rows),
    'current_page'=>$page,                                        // NEW
    'total_pages'=> ($per_page>0 ? (int)ceil($total_items/$per_page) : 0), // NEW
    'total_items'=> $total_items,                                  // NEW
    'orderby'=>$orderby,
    'order'=>$order,
    'filters'=>[
      'search'=>$search,
      'cities'=>$cities,
      'category'=>$category,
      'product_brand'=>$brand, // TODO
      'malls'=>$malls          // TODO
    ],
    'items'=>$rows
  ];

  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response($resp,200);
}
/* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */


function provider_product_detail(WP_REST_Request $request) {
  global $wpdb;
    $MODULE_PHP="providers.php";
    $module = $MODULE_PHP . '.provider_product_detail';	  

  // ────────────────────────────────────────────────
  // Logs bootstrap
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START [PROVIDER PRODUCT DETAIL] | IP:$ip");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  // ────────────────────────────────────────────────
  // JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) {
    vogo_error_log3("[STEP 0] JWT extraction failed | IP:$ip");
    return $user_or_err;
  }
  $user_id    = (int)$user_or_err;
  $user       = get_userdata($user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] user_id=$user_id user_login=$user_login | IP:$ip");

  $wp_user = get_user_by('id', (int)$user_id); 
  $user_login = $wp_user ? $wp_user->user_login : 'unknown';
  $jwt_user_id   = (int)$user_id;
  $jwt_user_name = $user_login;  
  $module=$module.'.jwt_user_id:'.$jwt_user_id;   
  

  // ────────────────────────────────────────────────
  // Parametru
  $payload = $request->get_params();
  $product_id = isset($payload['product_id']) ? (int)$payload['product_id'] : 0;

  if ($product_id <= 0) {
    vogo_error_log3("[STEP 2] Invalid product_id | IP:$ip | USER:$user_id");
    $module=$module.'.product_id_null';
    return new WP_REST_Response([
      'status'      => false,
      'module' => $module.'-ES2',
      'jwt_user_id'=> $jwt_user_id,
      'jwt_user_name'=> $jwt_user_name,	
      'message'     => 'product_id is required',
      'user_id'     => $user_id,
      'user_login'  => $user_login,
    ], 400);
  }

  $module=$module.'.product_id:'.$product_id;

  // ────────────────────────────────────────────────
  // Providerii legați de user (vendor_ids)
  $vp_table = $wpdb->prefix . 'vogo_providers';   // id, provider_name, user_id
  $pv_table = $wpdb->prefix . 'product_vendor';   // product_id, vendor_id
  $lk_table = $wpdb->prefix . 'wc_product_meta_lookup';
  $posts    = $wpdb->posts;

  $vendor_ids = $wpdb->get_col($wpdb->prepare(
    "SELECT id FROM {$vp_table} WHERE user_id = %d", $user_id
  ));
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] STEP 3 providers SQL: {$wpdb->last_error}");
    return new WP_REST_Response(['status'=>false,'module' => $module.'ES3','error'=>'SQL error','sql_error'=>$wpdb->last_error], 500);
  }
  if (empty($vendor_ids)) {
    vogo_error_log3("[STEP 3.1] No providers for user_id=$user_id → 403");
    return new WP_REST_Response([
      'status'  => false,
      'module' => $module.'-E3.1',      
      'message' => 'No provider account for current user',
    ], 403);
  }

  // ────────────────────────────────────────────────
  // Securitate: produsul trebuie să aparțină unuia dintre vendor-ii userului
  $placeholders = implode(',', array_fill(0, count($vendor_ids), '%d'));
  $params_check = array_merge([$product_id], array_map('intval',$vendor_ids));
  $belongs_sql = $wpdb->prepare(
    "SELECT COUNT(*) FROM {$pv_table} WHERE product_id = %d AND vendor_id IN ($placeholders)",
    $params_check
  );
  vogo_error_log3("##############SQL BELONGS: " . preg_replace('/\s+/', ' ', $belongs_sql));
  $belongs = (int)$wpdb->get_var($belongs_sql);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] STEP 4 belongs SQL: {$wpdb->last_error}");
    return new WP_REST_Response(['status'=>false,'module' => $module,'error'=>'SQL error','sql_error'=>$wpdb->last_error], 500);
  }
  if ($belongs === 0) {
    vogo_error_log3("[STEP 4.1] Product $product_id not owned by provider(s) of user $user_id → 403");
    return new WP_REST_Response([
      'status'  => false,
      'module' => $module.'ES4.1',
      'message' => 'Unauthorized: product '.$product_id .' does not belong to your provider account '.$user_id.', jwt_user_name:'.$jwt_user_name,
    ], 403);
  }

  // ────────────────────────────────────────────────
  // Product core (publish/draft/pending pentru provider)
  $detail_sql = $wpdb->prepare("
    SELECT p.ID, p.post_title, p.post_name AS slug, p.post_excerpt, p.post_content,
           l.min_price, l.max_price, l.onsale, l.stock_quantity, l.stock_status,
           l.average_rating, l.total_sales,
           pv.vendor_id, vp.provider_name
    FROM {$posts} p
    JOIN {$lk_table} l ON l.product_id = p.ID
    JOIN {$pv_table} pv ON pv.product_id = p.ID
    JOIN {$vp_table} vp ON vp.id = pv.vendor_id
    WHERE p.ID = %d
      AND p.post_type = 'product'
      AND p.post_status IN ('publish','draft','pending')
      AND vp.id IN ($placeholders)
    LIMIT 1
  ", array_merge([$product_id], array_map('intval',$vendor_ids)));

  vogo_error_log3("##############SQL DETAIL: " . preg_replace('/\s+/', ' ', $detail_sql));
  $row = $wpdb->get_row($detail_sql, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[ERROR] STEP 5 detail SQL: {$wpdb->last_error}");
    return new WP_REST_Response(['status'=>false,'error'=>'SQL error','sql_error'=>$wpdb->last_error], 500);
  }
  if (!$row) {
    vogo_error_log3("[STEP 5.1] Product not found (or not visible) | product_id=$product_id");
    return new WP_REST_Response(['status'=>false,'message'=>'Product not found'], 404);
  }

  // ────────────────────────────────────────────────
  // Hydrate (aceleași câmpuri ca la product_detail-ul tău)
  $thumb_id = (int)get_post_thumbnail_id($product_id);
  $image    = $thumb_id ? wp_get_attachment_url($thumb_id) : '';

  // categorii
  $cats=[]; 
  $terms = get_the_terms($product_id,'product_cat');
  if ($terms && !is_wp_error($terms)) {
    foreach($terms as $t){ $cats[]=['id'=>(int)$t->term_id, 'name'=>(string)$t->name, 'parent'=>(int)$t->parent]; }
  }
  // main category id (top-level dacă există)
  $main_cat_id = 0;
  if (!empty($cats)) {
    foreach($cats as $c){ if((int)$c['parent']===0){ $main_cat_id=(int)$c['id']; break; } }
    if ($main_cat_id===0) $main_cat_id=(int)$cats[0]['id'];
  }

  // Woo product type & explicit prices
  $wc_product    = wc_get_product($product_id);
  $product_type  = $wc_product ? $wc_product->get_type() : '';
  $regular_price = $wc_product ? (string)$wc_product->get_regular_price() : (string)get_post_meta($product_id,'_regular_price',true);
  $sale_price    = $wc_product ? (string)$wc_product->get_sale_price()    : (string)get_post_meta($product_id,'_sale_price',true);
  if ($regular_price === '') $regular_price = null;
  if ($sale_price    === '') $sale_price    = null;

  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  $product_data = [
    'id'                => (int)$row['ID'],
    'name'              => (string)$row['post_title'],
    'slug'              => (string)$row['slug'],
    'short_description' => wp_trim_words(strip_tags($row['post_excerpt']), 20),
    'description'       => (string)$row['post_content'],
    'price'             => isset($row['min_price']) ? (string)$row['min_price'] : null,
    'max_price'         => isset($row['max_price']) ? (string)$row['max_price'] : null,
    'onsale'            => (int)$row['onsale'],
    'stock_quantity'    => isset($row['stock_quantity']) ? (int)$row['stock_quantity'] : null,
    'stock_status'      => (string)$row['stock_status'],
    'rating'            => isset($row['average_rating']) ? (float)$row['average_rating'] : 0.0,
    'average_rating'    => isset($row['average_rating']) ? (float)$row['average_rating'] : 0.0,
    'popularity'        => isset($row['total_sales']) ? (int)$row['total_sales'] : 0,
    'currency_symbol'   => $currency_symbol,
    'currency_code'     => $currency_code,
    'image'             => $image,
    'categories'        => $cats,
    'wishlist'          => false,
    'url'               => get_permalink($product_id),
    'product_type'      => $product_type,
    'regular_price'     => $regular_price,
    'sale_price'        => $sale_price,
    'vendor_id'         => (int)$row['vendor_id'],
    'vendor_name'       => (string)$row['provider_name'],
  ];

  // ────────────────────────────────────────────────
  // Merge Product/Category Meta Actions (product first, then category fallback)
  $pfx = $wpdb->prefix;

  $pma = $wpdb->get_row($wpdb->prepare("
    SELECT product_id, product_main_category_id,
           camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
           action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
           action_url_label, action_url_link
    FROM {$pfx}product_meta_action
    WHERE product_id = %d
    LIMIT 1
  ", $product_id), ARRAY_A);
  if ($wpdb->last_error) vogo_error_log3("[PMA SQL ERROR] {$wpdb->last_error}");

  if ($pma && !empty($pma['product_main_category_id'])) $main_cat_id = (int)$pma['product_main_category_id'];

  $cma = null;
  if ($main_cat_id > 0) {
    $cma = $wpdb->get_row($wpdb->prepare("
      SELECT category_id,
             camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
             action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
             action_url_label, action_url_link
      FROM {$pfx}category_meta_action
      WHERE category_id = %d
      LIMIT 1
    ", $main_cat_id), ARRAY_A);
    if ($wpdb->last_error) vogo_error_log3("[CMA SQL ERROR] {$wpdb->last_error}");
  }

  $pick = function($key) use ($pma,$cma){
    $pv = $pma[$key] ?? null; if (isset($pv) && $pv !== '') return $pv;
    $cv = $cma[$key] ?? null; return isset($cv) ? $cv : null;
  };

  $product_data['camera_broadcast_url'] = $pick('camera_broadcast_url');
  $product_data['zoom_live_call_link']  = $pick('zoom_live_call_link');
  $product_data['whatsapp_contact_url'] = $pick('whatsapp_contact_url');
  $product_data['suggest_service_link'] = $pick('suggest_service_link');
  $product_data['action_whatsapp_label']   = $pick('action_whatsapp_label');
  $product_data['action_whatsapp_number']  = $pick('action_whatsapp_number');
  $product_data['action_whatsapp_message'] = $pick('action_whatsapp_message');
  $product_data['action_url_label']        = $pick('action_url_label');
  $product_data['action_url_link']         = $pick('action_url_link');

  // ────────────────────────────────────────────────
  // Wishlist (pentru userul curent)
  $exists = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}custom_wishlist WHERE user_id=%d AND product_id=%d",
    $user_id, $product_id
  ));
  if ((int)$exists > 0) $product_data['wishlist'] = true;

  // Gallery
  $gallery_ids = get_post_meta($product_id, '_product_image_gallery', true);
  $gallery_arr = [];
  if (!empty($gallery_ids)) {
    $ids = array_filter(array_map('intval', explode(',', $gallery_ids)));
    foreach ($ids as $gid) {
      $gallery_arr[] = [
        'product_original_image' => wp_get_attachment_url($gid),
        'product_full_image'     => wp_get_attachment_image_src($gid, 'full')[0] ?? '',
        'product_medium_image'   => wp_get_attachment_image_src($gid, 'medium')[0] ?? '',
        'product_thumbnail_image'=> wp_get_attachment_image_src($gid, 'thumbnail')[0] ?? '',
      ];
    }
  }
  $product_data['product_gallery_images'] = $gallery_arr;

  // Reviews
  $comment_count = wp_count_comments($product_id);

  // ────────────────────────────────────────────────
  // Response
  vogo_error_log3("VOGO_LOG_END [PROVIDER PRODUCT DETAIL] | product_id=$product_id | USER:$user_id");
  return new WP_REST_Response([
    'status'      => true,
    'message'     => 'Data Successfully provided.',
    'module' => $module.'.TSEND200',
    'user_id'     => $user_id,
    'user_login'  => $user_login,    
    'data'        => [
      'product_data' => $product_data,
      'total_review' => $comment_count->total_comments
    ]
  ], 200);
}

function provider_product_detail_edit(WP_REST_Request $request) {
  global $wpdb;

  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START [PROVIDER PRODUCT EDIT] | IP:$ip");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  // 1) Auth
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) return $user_or_err;
  $user_id    = (int)$user_or_err;
  $user_login = (get_userdata($user_id)->user_login) ?? 'unknown';
  vogo_error_log3("[STEP 1] user_id=$user_id user_login=$user_login | IP:$ip");

  // 2) Payload
  $p = $request->get_params();
  $product_id = isset($p['product_id']) ? (int)$p['product_id'] : 0;
  if ($product_id <= 0) {
    return new WP_REST_Response(['status'=>false,'message'=>'product_id is required'], 400);
  }

  // 3) Check ownership: product must belong to one of user’s vendors (no term_id)
  $vp_table = $wpdb->prefix . 'vogo_providers';   // id, provider_name, user_id
  $pv_table = $wpdb->prefix . 'product_vendor';   // product_id, vendor_id
  $vendor_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$vp_table} WHERE user_id=%d", $user_id));
  if ($wpdb->last_error) return new WP_REST_Response(['status'=>false,'error'=>'SQL error','sql_error'=>$wpdb->last_error], 500);
  if (empty($vendor_ids)) return new WP_REST_Response(['status'=>false,'message'=>'No provider account for current user'], 403);

  $place = implode(',', array_fill(0, count($vendor_ids), '%d'));
  $check_sql = $wpdb->prepare("SELECT COUNT(*) FROM {$pv_table} WHERE product_id=%d AND vendor_id IN ($place)", array_merge([$product_id], $vendor_ids));
  vogo_error_log3("##############SQL BELONGS: ".preg_replace('/\s+/', ' ', $check_sql));
  if ((int)$wpdb->get_var($check_sql) === 0) {
    return new WP_REST_Response(['status'=>false,'message'=>'Unauthorized: product does not belong to your provider account'], 403);
  }

  // 4) Load WC product
  $product = wc_get_product($product_id);
  if (!$product) return new WP_REST_Response(['status'=>false,'message'=>'Invalid product'], 404);

  // 5) Apply edits (whitelist)
  $changed = false;

  if (isset($p['name'])) {
    $name = sanitize_text_field($p['name']);
    if ($name !== '') { $product->set_name($name); $changed = true; }
  }

  if (isset($p['short_description'])) {
    $sd = wp_kses_post($p['short_description']);
    $product->set_short_description($sd); $changed = true;
  }

  if (isset($p['description'])) {
    $desc = wp_kses_post($p['description']);
    $product->set_description($desc); $changed = true;
  }

  if (isset($p['position'])) {
    $menu_order = (int)$p['position'];
    wp_update_post(['ID'=>$product_id,'menu_order'=>$menu_order]);
    $changed = true;
  }

  // Prices
  $regular_price = array_key_exists('regular_price', $p) ? (string)$p['regular_price'] : null;
  $sale_price    = array_key_exists('sale_price',    $p) ? (string)$p['sale_price']    : null;

  if ($regular_price !== null) {
    $rp = $regular_price === '' ? null : wc_format_decimal($regular_price);
    $product->set_regular_price($rp);
    // dacă nu se trimite sale_price, nu-l schimbăm aici; mai jos îl aplicăm dacă e setat
    $changed = true;
  }
  if ($sale_price !== null) {
    $sp = $sale_price === '' ? '' : wc_format_decimal($sale_price);
    // validare simplă: nu mai mare decât regular (dacă avem)
    $rp_now = $product->get_regular_price();
    if ($sp !== '' && $rp_now !== '' && (float)$sp > (float)$rp_now) {
      return new WP_REST_Response(['status'=>false,'message'=>'sale_price cannot exceed regular_price'], 400);
    }
    $product->set_sale_price($sp);
    $changed = true;
  }
  // setează price efectiv
  if ($regular_price !== null || $sale_price !== null) {
    $sp_now = $product->get_sale_price();
    $rp_now = $product->get_regular_price();
    $product->set_price($sp_now !== '' && $sp_now !== null ? $sp_now : $rp_now);
  }

  // Stock
  if (isset($p['stock_quantity'])) {
    $qty = max(0, (int)$p['stock_quantity']);
    $product->set_manage_stock(true);
    $product->set_stock_quantity($qty);
    $changed = true;
  }
  if (isset($p['stock_status'])) {
    $ss = sanitize_text_field($p['stock_status']);
    if (!in_array($ss, ['instock','outofstock','onbackorder'], true)) {
      return new WP_REST_Response(['status'=>false,'message'=>'Invalid stock_status'], 400);
    }
    $product->set_stock_status($ss);
    $changed = true;
  }

  // Image & Gallery
  if (isset($p['image_id'])) {
    $img_id = (int)$p['image_id'];
    if ($img_id > 0) { $product->set_image_id($img_id); $changed = true; }
  }
  if (isset($p['gallery_image_ids']) && is_array($p['gallery_image_ids'])) {
    $gids = array_values(array_filter(array_map('intval', $p['gallery_image_ids']), fn($x)=>$x>0));
    $product->set_gallery_image_ids($gids);
    $changed = true;
  }

  // Categories
  if (isset($p['categories'])) {
    $cat_ids = is_array($p['categories']) ? $p['categories'] : [];
    $cat_ids = array_values(array_filter(array_map('intval', $cat_ids), fn($x)=>$x>0));
    if (!empty($cat_ids)) {
      wp_set_object_terms($product_id, $cat_ids, 'product_cat', false);
      $changed = true;
    }
  }

  // 6) Save if changed
  if ($changed) {
    $product->save();
    wc_delete_product_transients($product_id);
  }

  // 7) Return updated detail (reuse same shape as provider_product_detail)
  // Refolosim SQL-ul de detail + hidratarea
  $lk_table = $wpdb->prefix . 'wc_product_meta_lookup';
  $posts    = $wpdb->posts;

  $detail_sql = $wpdb->prepare("
    SELECT p.ID, p.post_title, p.post_name AS slug, p.post_excerpt, p.post_content,
           l.min_price, l.max_price, l.onsale, l.stock_quantity, l.stock_status,
           l.average_rating, l.total_sales,
           pv.vendor_id, vp.provider_name
    FROM {$posts} p
    JOIN {$lk_table} l ON l.product_id = p.ID
    JOIN {$pv_table} pv ON pv.product_id = p.ID
    JOIN {$vp_table} vp ON vp.id = pv.vendor_id
    WHERE p.ID = %d
      AND p.post_type = 'product'
      AND p.post_status IN ('publish','draft','pending')
      AND vp.id IN ($place)
    LIMIT 1
  ", array_merge([$product_id], $vendor_ids));

  vogo_error_log3("##############SQL DETAIL AFTER SAVE: ".preg_replace('/\s+/', ' ', $detail_sql));
  $row = $wpdb->get_row($detail_sql, ARRAY_A);
  if (!$row) return new WP_REST_Response(['status'=>false,'message'=>'Product not found after update'], 404);

  // Build same response fields
  $thumb_id = (int)get_post_thumbnail_id($product_id);
  $image    = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
  $cats=[]; $terms=get_the_terms($product_id,'product_cat');
  if ($terms && !is_wp_error($terms)) foreach ($terms as $t) $cats[]=['id'=>$t->term_id,'name'=>$t->name,'parent'=>$t->parent];

  $wc_p = wc_get_product($product_id);
  $product_type  = $wc_p ? $wc_p->get_type() : '';
  $regular_price = $wc_p ? (string)$wc_p->get_regular_price() : (string)get_post_meta($product_id,'_regular_price',true);
  $sale_price    = $wc_p ? (string)$wc_p->get_sale_price()    : (string)get_post_meta($product_id,'_sale_price',true);
  if ($regular_price === '') $regular_price = null;
  if ($sale_price === '')    $sale_price    = null;

  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  // gallery
  $gallery_ids = get_post_meta($product_id, '_product_image_gallery', true);
  $gallery_arr=[];
  if (!empty($gallery_ids)) {
    $ids=array_filter(array_map('intval', explode(',',$gallery_ids)));
    foreach ($ids as $gid) {
      $gallery_arr[]=[
        'product_original_image'=>wp_get_attachment_url($gid),
        'product_full_image'=>wp_get_attachment_image_src($gid,'full')[0]??'',
        'product_medium_image'=>wp_get_attachment_image_src($gid,'medium')[0]??'',
        'product_thumbnail_image'=>wp_get_attachment_image_src($gid,'thumbnail')[0]??'',
      ];
    }
  }

  $comment_count = wp_count_comments($product_id);

  $product_data = [
    'id'                => (int)$row['ID'],
    'name'              => (string)$row['post_title'],
    'slug'              => (string)$row['slug'],
    'short_description' => wp_trim_words(strip_tags($row['post_excerpt']), 20),
    'description'       => (string)$row['post_content'],
    'price'             => isset($row['min_price']) ? (string)$row['min_price'] : null,
    'max_price'         => isset($row['max_price']) ? (string)$row['max_price'] : null,
    'onsale'            => (int)$row['onsale'],
    'stock_quantity'    => isset($row['stock_quantity']) ? (int)$row['stock_quantity'] : null,
    'stock_status'      => (string)$row['stock_status'],
    'rating'            => isset($row['average_rating']) ? (float)$row['average_rating'] : 0.0,
    'average_rating'    => isset($row['average_rating']) ? (float)$row['average_rating'] : 0.0,
    'popularity'        => isset($row['total_sales']) ? (int)$row['total_sales'] : 0,
    'currency_symbol'   => $currency_symbol,
    'currency_code'     => $currency_code,
    'image'             => $image,
    'categories'        => $cats,
    'wishlist'          => false,
    'url'               => get_permalink($product_id),
    'product_type'      => $product_type,
    'regular_price'     => $regular_price,
    'sale_price'        => $sale_price,
    'vendor_id'         => (int)$row['vendor_id'],
    'vendor_name'       => (string)$row['provider_name'],
    'product_gallery_images' => $gallery_arr
  ];

  vogo_error_log3("VOGO_LOG_END [PROVIDER PRODUCT EDIT] | product_id=$product_id | USER:$user_id");
  return new WP_REST_Response([
    'status'      => true,
    'message'     => 'Product updated successfully',
    'data'        => [
      'product_data' => $product_data,
      'total_review' => $comment_count->total_comments
    ],
    'user_id'     => $user_id,
    'user_login'  => $user_login
  ], 200);
}

function provider_product_update(WP_REST_Request $request){
  global $wpdb; $module='provider-product-update'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | DB:$db | IP:$ip | USER:jwt", $module);

  // STEP 1 — JWT (vendor_id = user din token)
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip", $module); vogo_error_log3("VOGO_LOG_END", $module); return $user_or_err; }
  $vendor_id = (int)$user_or_err;

  // STEP 2 — Payload (doar câmpuri suportate)
  $p = $request->get_json_params();
  $product_id    = (int)($p['product_id'] ?? 0);
  if($product_id<=0){ vogo_error_log3("[$module] product_id required | IP:$ip", $module); vogo_error_log3("VOGO_LOG_END", $module); return new WP_REST_Response(['success'=>false,'error'=>'product_id_required','vendor_id'=>$vendor_id],400); }

  $post_title    = array_key_exists('post_title',   $p) ? (string)$p['post_title'] : null;
  $post_status   = array_key_exists('post_status',  $p) ? strtolower(trim((string)$p['post_status'])) : null;
  if($post_status !== null && !vogo_valid_status($post_status)){ $post_status = null; } // ignore invalid

  $menu_order    = array_key_exists('menu_order',   $p) ? (int)$p['menu_order'] : null;

  $price         = array_key_exists('price',         $p) ? (string)$p['price']         : null;
  $regular_price = array_key_exists('regular_price', $p) ? (string)$p['regular_price'] : null;
  $sale_price    = array_key_exists('sale_price',    $p) ? (string)$p['sale_price']    : null;
  $sku           = array_key_exists('sku',           $p) ? (string)$p['sku']           : null;

  // STEP 3 — Ownership guard
  $sql_own = "SELECT EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=%d AND pv.vendor_id=%d AND pv.status='active') AS is_owner";
  $is_owner = (int)$wpdb->get_var($wpdb->prepare($sql_own, $product_id, $vendor_id));
  if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR own] ".$wpdb->last_error, $module); vogo_error_log3("VOGO_LOG_END", $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  if($is_owner!==1){ vogo_error_log3("[$module] not_owner | product:$product_id | vendor:$vendor_id", $module); vogo_error_log3("VOGO_LOG_END", $module); return new WP_REST_Response(['success'=>false,'error'=>'not_owner','product_id'=>$product_id,'vendor_id'=>$vendor_id],403); }

  // STEP 4 — UPDATE wp_posts (doar câmpurile primite)
  $sets=[]; $params=[];
  if($post_title!==null){  $sets[]="p.post_title=%s";  $params[]=$post_title; }
  if($post_status!==null){ $sets[]="p.post_status=%s"; $params[]=$post_status; }
  if($menu_order!==null){  $sets[]="p.menu_order=%d";  $params[]=$menu_order; }

  if(!empty($sets)){
    $sets[]="p.post_modified=UTC_TIMESTAMP()";
    $sets[]="p.post_modified_gmt=UTC_TIMESTAMP()";
    $sql_up  = "UPDATE wp_posts p JOIN wp_product_vendor pv ON pv.product_id=p.ID AND pv.vendor_id=%d AND pv.status='active' SET ".implode(',', $sets)." WHERE p.ID=%d";
    $args_up = array_merge([$vendor_id], $params, [$product_id]); // atenție la ordine: %d(vendor) + fields + %d(product)
    // corectăm ordinea: vendor_id e în JOIN înaintea SET param; mutăm vendor la finalul listei de params de prepare:
    // reconstruim corect:
    $sql_up  = "UPDATE wp_posts p JOIN wp_product_vendor pv ON pv.product_id=p.ID AND pv.vendor_id=%d AND pv.status='active' SET ".implode(',', $sets)." WHERE p.ID=%d";
    $args_up = array_merge([$vendor_id], $params, [$product_id]);
    $q = $wpdb->prepare($sql_up, ...$args_up);
    $wpdb->query($q);
    if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR posts] ".$wpdb->last_error, $module); vogo_error_log3("VOGO_LOG_END", $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  }

  // STEP 5 — Upsert postmeta doar dacă parametrii sunt furnizați
  if($price!==null){
    $sql = "UPDATE wp_postmeta pm JOIN wp_product_vendor pv ON pv.product_id=pm.post_id AND pv.vendor_id=%d AND pv.status='active' SET pm.meta_value=%s WHERE pm.post_id=%d AND pm.meta_key='_price'";
    $wpdb->query($wpdb->prepare($sql, $vendor_id, $price, $product_id));
    if($wpdb->rows_affected===0){
      $sql = "INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
              SELECT %d, '_price', %s
              WHERE EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=%d AND pv.vendor_id=%d AND pv.status='active')
                AND NOT EXISTS(SELECT 1 FROM wp_postmeta pm WHERE pm.post_id=%d AND pm.meta_key='_price')";
      $wpdb->query($wpdb->prepare($sql, $product_id, $price, $product_id, $vendor_id, $product_id));
    }
    if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR _price] ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  }

  if($regular_price!==null){
    $sql = "UPDATE wp_postmeta pm JOIN wp_product_vendor pv ON pv.product_id=pm.post_id AND pv.vendor_id=%d AND pv.status='active' SET pm.meta_value=%s WHERE pm.post_id=%d AND pm.meta_key='_regular_price'";
    $wpdb->query($wpdb->prepare($sql, $vendor_id, $regular_price, $product_id));
    if($wpdb->rows_affected===0){
      $sql = "INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
              SELECT %d, '_regular_price', %s
              WHERE EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=%d AND pv.vendor_id=%d AND pv.status='active')
                AND NOT EXISTS(SELECT 1 FROM wp_postmeta pm WHERE pm.post_id=%d AND pm.meta_key='_regular_price')";
      $wpdb->query($wpdb->prepare($sql, $product_id, $regular_price, $product_id, $vendor_id, $product_id));
    }
    if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR _regular_price] ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  }

  if($sale_price!==null){
    $sql = "UPDATE wp_postmeta pm JOIN wp_product_vendor pv ON pv.product_id=pm.post_id AND pv.vendor_id=%d AND pv.status='active' SET pm.meta_value=%s WHERE pm.post_id=%d AND pm.meta_key='_sale_price'";
    $wpdb->query($wpdb->prepare($sql, $vendor_id, $sale_price, $product_id));
    if($wpdb->rows_affected===0){
      $sql = "INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
              SELECT %d, '_sale_price', %s
              WHERE EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=%d AND pv.vendor_id=%d AND pv.status='active')
                AND NOT EXISTS(SELECT 1 FROM wp_postmeta pm WHERE pm.post_id=%d AND pm.meta_key='_sale_price')";
      $wpdb->query($wpdb->prepare($sql, $product_id, $sale_price, $product_id, $vendor_id, $product_id));
    }
    if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR _sale_price] ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  }

  if($sku!==null){
    $sql = "UPDATE wp_postmeta pm JOIN wp_product_vendor pv ON pv.product_id=pm.post_id AND pv.vendor_id=%d AND pv.status='active' SET pm.meta_value=%s WHERE pm.post_id=%d AND pm.meta_key='_sku'";
    $wpdb->query($wpdb->prepare($sql, $vendor_id, $sku, $product_id));
    if($wpdb->rows_affected===0){
      $sql = "INSERT INTO wp_postmeta(post_id, meta_key, meta_value)
              SELECT %d, '_sku', %s
              WHERE EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=%d AND pv.vendor_id=%d AND pv.status='active')
                AND NOT EXISTS(SELECT 1 FROM wp_postmeta pm WHERE pm.post_id=%d AND pm.meta_key='_sku')";
      $wpdb->query($wpdb->prepare($sql, $product_id, $sku, $product_id, $vendor_id, $product_id));
    }
    if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR _sku] ".$wpdb->last_error, $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }
  }

  // STEP 6 — Snapshot (read-only, return)
  $sql = 
"SELECT 
  p.ID AS product_id,
  p.post_title,
  p.post_status,
  p.menu_order,
  (SELECT pm.meta_value FROM wp_postmeta pm WHERE pm.post_id=p.ID AND pm.meta_key='_price'         LIMIT 1) AS price,
  (SELECT pm.meta_value FROM wp_postmeta pm WHERE pm.post_id=p.ID AND pm.meta_key='_regular_price' LIMIT 1) AS regular_price,
  (SELECT pm.meta_value FROM wp_postmeta pm WHERE pm.post_id=p.ID AND pm.meta_key='_sale_price'    LIMIT 1) AS sale_price,
  (SELECT pm.meta_value FROM wp_postmeta pm WHERE pm.post_id=p.ID AND pm.meta_key='_sku'           LIMIT 1) AS sku
FROM wp_posts p
WHERE p.ID=%d
  AND EXISTS(SELECT 1 FROM wp_product_vendor pv WHERE pv.product_id=p.ID AND pv.vendor_id=%d AND pv.status='active')";
  $snapshot = $wpdb->get_row($wpdb->prepare($sql, $product_id, $vendor_id), ARRAY_A);
  if($wpdb->last_error){ vogo_error_log3("[$module][SQL ERROR snapshot] ".$wpdb->last_error, $module); vogo_error_log3("VOGO_LOG_END", $module); return new WP_REST_Response(['success'=>false,'error'=>'sql','sql_error'=>$wpdb->last_error],500); }

  $resp = [
    'success'   => true,
    'vendor_id' => $vendor_id,
    'product'   => $snapshot,
  ];
  vogo_error_log3("[$module] OK | product:$product_id | vendor:$vendor_id | IP:$ip", $module);
  vogo_error_log3("VOGO_LOG_END", $module);
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response($resp,200);
}