<?php
/**
 * VOGO API Endpoint Registration
 * All routes use standard JWT security check: vogo_permission_check
 * Adi-tehnic: clean, organized, secure, ergonomic structure.
 */

//use Twilio\Rest\Client;
$MODULE_PHP='all-products.php';

add_action('rest_api_init', function () {

    // Brands & Products
    register_rest_route('vogo/v1', '/brands', [
        'methods'             => 'GET',
        'callback'            => 'brands_listing',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/product-list2', [
        'methods'             => 'GET',
        'callback'            => 'custom_products',
        'permission_callback' => 'vogo_permission_check',
    ]);

  register_rest_route('vogo/v1', '/client/product-list', [
    'methods' => 'POST',
    'callback' => 'client_product_list',
    'permission_callback' => 'vogo_permission_check',
  ]);    

    register_rest_route('vogo/v1', '/product/product-detail', [
        'methods'             => 'POST',
        'callback'            => 'custom_product_detail',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/product/product_set_image', [
        'methods'             => 'POST',
        'callback'            => 'vogo_product_set_image',
        'permission_callback' => 'vogo_permission_check',
    ]);    

    // Product & Order Reviews
    register_rest_route('vogo/v1', '/product-rate-and-review', [
        'methods'             => 'POST',
        'callback'            => 'custom_product_rate_and_review',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/product-review', [
        'methods'             => 'GET',
        'callback'            => 'custom_product_review',
        'permission_callback' => 'vogo_permission_check',
    ]);

}); // ✅ END of rest_api_init

/**
 * Get paginated list of product brands (taxonomy: product_brand)
 *
 * @return array JSON response with list of brands
 */
function brands_listing() {
    // STEP 1: Extract and sanitize input
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $page     = isset($data['page']) ? max(1, intval($data['page'])) : 1;
    $per_page = isset($data['per_page']) ? max(1, intval($data['per_page'])) : 10;

    vogo_error_log2("STEP 1: Input received for brands_listing - page: {$page}, per_page: {$per_page}");

    try {
        // STEP 2: Setup query arguments for get_terms
        $offset = ($page - 1) * $per_page;
        $args = [
            'taxonomy' => 'product_brand',
            'number'   => $per_page,
            'offset'   => $offset,
        ];

        vogo_error_log2("STEP 2: Fetching terms with offset {$offset}");

        // STEP 3: Retrieve terms
        $terms = get_terms($args);
        $total_terms = wp_count_terms('product_brand');
        $total_pages = ceil($total_terms / $per_page);

        // STEP 4: Build response
        $response = [
            'status'     => true,
            'code'       => 200,
            'message'    => 'Brands fetched successfully!',
            'page'       => $page,
            'total'      => $total_terms,
            'pages'      => $total_pages,
            'data'       => [],
        ];

        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $response['data'][] = [
                    'id'   => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                    'src'  => get_term_meta($term->term_id, 'image', true),
                ];
            }
            vogo_error_log2("STEP 4: Retrieved " . count($terms) . " terms.");
        } else {
            vogo_error_log2("STEP 4: No terms found or get_terms returned error.");
        }

        return $response;

    } catch (Throwable $e) {
        vogo_error_log2("STEP 5: Exception caught - " . $e->getMessage());
        return [
            'status'  => false,
            'code'    => 500,
            'message' => 'Internal server error: ' . $e->getMessage(),
            'data'    => [],
        ];
    }
}

function custom_product_review(WP_REST_Request $request) {
    // STEP 1: Parse and validate input
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $product_id = isset($data['product_id']) ? intval($data['product_id']) : 0;

    if (!$product_id) {
        vogo_error_log2("STEP 1: Missing or invalid product_id.");
        return new WP_REST_Response([
            'status'  => false,
            'message' => 'Product ID is required.',
            'comment_count' => 0,
            'data'    => []
        ], 400);
    }

    // STEP 2: Retrieve total comment count
    $total_count = wp_count_comments($product_id);
    vogo_error_log2("STEP 2: Total comment count: " . $total_count->total_comments);

    // STEP 3: Calculate pagination offset
    $offset = 0;
    if (!empty($data['page'])) {
        $offset = intval($data['page']) * 10;
    }
    vogo_error_log2("STEP 3: Offset set to $offset");

    // STEP 4: Build query for comments
    $args = [
        'number'      => 10,
        'status'      => 'approve',
        'post_status' => 'publish',
        'post_type'   => 'product',
        'offset'      => $offset,
        'post_id'     => $product_id
    ];

    $comments = get_comments($args);
    $comment_data = [];

    // STEP 5: Process comment results
    if (!empty($comments)) {
        foreach ($comments as $comment_record) {
            $comment_data[] = [
                'comment_id'           => $comment_record->comment_ID,
                'comment_author'       => $comment_record->comment_author,
                'comment_author_email' => $comment_record->comment_author_email,
                'comment_content'      => $comment_record->comment_content,
                'rating'               => get_comment_meta($comment_record->comment_ID, 'rating', true),
                'comment_date'         => date('F jS, Y', strtotime($comment_record->comment_date)),
            ];
        }

        vogo_error_log2("STEP 5: Comments found: " . count($comment_data));
        return new WP_REST_Response([
            'status'        => true,
            'message'       => 'Total ' . $total_count->total_comments . ' reviews found.',
            'comment_count' => $total_count->total_comments,
            'data'          => $comment_data
        ], 200);
    } else {
        vogo_error_log2("STEP 5: No comments found for product_id=$product_id");
        return new WP_REST_Response([
            'status'        => false,
            'message'       => 'No comment found.',
            'comment_count' => 0,
            'data'          => []
        ], 200);
    }
}

function custom_product_rate_and_review(WP_REST_Request $request) {
    try {
        // STEP 1: Parse input
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $_REQUEST;
        }

        $product_id       = isset($data['product_id']) ? intval($data['product_id']) : 0;
        $rating           = isset($data['rating']) ? intval($data['rating']) : 0;
        $comment          = isset($data['comment']) ? sanitize_text_field($data['comment']) : '';
        $user_id          = isset($data['access_token']) ? intval($data['access_token']) : 0;
        $comment_date     = isset($data['comment_date']) ? sanitize_text_field($data['comment_date']) : '';
        $comment_date_gmt = isset($data['comment_date_gmt']) ? sanitize_text_field($data['comment_date_gmt']) : '';

        // STEP 2: Validate required fields
        if (!$product_id || !$rating || !$comment || !$user_id) {
            vogo_error_log2("STEP 2: Missing required fields");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'Please fill all required fields.'
            ], 400);
        }

        // STEP 3: Load user by ID
        $user = get_user_by('id', $user_id);
        if (!$user || !is_a($user, 'WP_User')) {
            vogo_error_log2("STEP 3: Invalid user with ID $user_id");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'Invalid user.'
            ], 403);
        }

        // STEP 4: Authenticate user
        wp_set_current_user($user->ID, $user->user_login);
        if (!is_user_logged_in()) {
            vogo_error_log2("STEP 4: User not logged in");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'User authentication failed.'
            ], 401);
        }

        // STEP 5: Prepare comment data
        $current_user = wp_get_current_user();
        $comment_data = [
            'comment_post_ID'      => $product_id,
            'comment_author'       => $current_user->display_name,
            'comment_author_email' => $current_user->user_email,
            'comment_content'      => $comment,
            'comment_type'         => '',
            'user_id'              => $user_id,
            'comment_date'         => $comment_date,
            'comment_date_gmt'     => $comment_date_gmt,
            'comment_approved'     => 1,
        ];

        // STEP 6: Insert comment
        $comment_id = wp_insert_comment($comment_data);
        if (!$comment_id) {
            vogo_error_log2("STEP 6: Failed to insert comment for product_id=$product_id");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'Failed to insert comment.'
            ], 500);
        }

        // STEP 7: Add metadata (rating, verified)
        add_comment_meta($comment_id, 'rating', $rating);
        add_comment_meta($comment_id, 'verified', '1');
        vogo_error_log2("STEP 7: Metadata added to comment ID $comment_id");

        // STEP 8: Update product rating info
        $product     = wc_get_product($product_id);
        $data_store  = $product->get_data_store();
        $data_store->update_visibility($product, true);

        update_post_meta($product_id, '_wc_rating_count', $product->get_rating_counts('edit') ?: 1);
        update_post_meta($product_id, '_wc_average_rating', $product->get_average_rating('edit') ?: $rating);
        update_post_meta($product_id, '_wc_review_count', $product->get_review_count('edit') ?: 1);

        vogo_error_log2("STEP 8: Product rating updated for product_id=$product_id");

        // STEP 9: Return success response
        return new WP_REST_Response([
            'status'  => true,
            'message' => 'Product review and rating added successfully.'
        ], 200);

    } catch (Exception $e) {
        vogo_error_log2("EXCEPTION: " . $e->getMessage());
        return new WP_REST_Response([
            'status'  => false,
            'message' => 'An error occurred: ' . $e->getMessage()
        ], 500);
    }
}

function custom_product_detail0911(WP_REST_Request $request) {
  global $wpdb;

  // ────────────────────────────────────────────────
  // Logs bootstrap
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START [PRODUCT DETAIL] | IP: $ip | USER: ?");
  $active_db = $wpdb->get_var("SELECT DATABASE()");
  vogo_error_log3("ACTIVE DB: {$active_db} | IP: $ip | USER: ?");
  $raw_input = file_get_contents('php://input');
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: ?");

  // ────────────────────────────────────────────────
  // JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) {
    vogo_error_log3("[STEP 0.2] JWT extraction failed | IP: $ip | USER: ?");
    return $user_or_err;
  }
  $user_id = (int)$user_or_err;
  $user = get_userdata($user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] User resolved: user_id=$user_id, user_login=$user_login | IP: $ip | USER: $user_id");


  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response      
  // ────────────────────────────────────────────────
  // Payload
  $data = json_decode($raw_input, true);
  if (empty($data)) $data = $request->get_params();
  $product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

  $module=$module.'.product_id:'.$product_id;

  if ($product_id <= 0) {
    vogo_error_log3("[STEP 2] Invalid or missing product_id | IP: $ip | USER: $user_id");
    return new WP_REST_Response([
      'status'  => false,
      'message' => 'Product id is required.',
      'user_id' => $user_id,
      'user_login' => $user_login
    ], 400);
  }

  // ────────────────────────────────────────────────
  // SQL product query (adi-tehnic: direct SQL, no wc_get_product) + enrich with WC for type
  $p  = $wpdb->posts;
  $lk = $wpdb->prefix . 'wc_product_meta_lookup';

  $sql = $wpdb->prepare("
    SELECT p.ID, p.post_title, p.post_name AS slug, p.post_excerpt, p.post_content,
           l.min_price, l.max_price, l.onsale, l.stock_quantity, l.stock_status,
           l.average_rating, l.total_sales
    FROM {$p} p
    JOIN {$lk} l ON l.product_id = p.ID
    WHERE p.ID = %d AND p.post_type = 'product' AND p.post_status = 'publish'
    LIMIT 1
  ", $product_id);

  vogo_error_log3("##############SQL: " . preg_replace('/\s+/', ' ', $sql) . " | IP: $ip | USER: $user_id");
  $row = $wpdb->get_row($sql, ARRAY_A);

  if ($wpdb->last_error) {
    vogo_error_log3("[STEP 3.E] SQL error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['status'=>false,'module' => $module.'-ES1','error'=>'SQL error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login], 500);
  }
  if (!$row) {
    vogo_error_log3("[STEP 3] Product not found | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['status'=>false,'message'=>'Product not found 2.','user_id'=>$user_id,'user_login'=>$user_login], 404);
  }

  // ────────────────────────────────────────────────
  // Hydrate product
  $thumb_id = (int)get_post_thumbnail_id($product_id);
  $image = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
  $cats=[]; 
  $terms=get_the_terms($product_id,'product_cat'); 
  if ($terms && !is_wp_error($terms)) { foreach($terms as $t){ $cats[]=['id'=>$t->term_id,'name'=>$t->name, 'parent'=>$t->parent]; } }

  // Determine main category id (prefer top-level; else first term)
  $main_cat_id = 0;
  if (!empty($cats)) {
    // a) try top-level
    foreach($cats as $c){ if((int)$c['parent']===0){ $main_cat_id=(int)$c['id']; break; } }
    // b) fallback first
    if($main_cat_id===0){ $main_cat_id = (int)$cats[0]['id']; }
  }

  // product type via WC (safe call just for type)
  $wc_product = wc_get_product($product_id);
  $product_type = $wc_product ? $wc_product->get_type() : '';

  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  $product_data = [
    'id'               => $row['ID'],
    'name'             => $row['post_title'],
    'slug'             => $row['slug'],
    'short_description'=> wp_trim_words(strip_tags($row['post_excerpt']), 20),
    'description'      => $row['post_content'],
    'price'            => (string)$row['min_price'],
    'max_price'        => (string)$row['max_price'],
    'onsale'           => (int)$row['onsale'],
    'stock_quantity'   => isset($row['stock_quantity']) ? (int)$row['stock_quantity'] : null,
    'stock_status'     => $row['stock_status'],
    'rating'           => (float)$row['average_rating'],
    'average_rating'   => (float)$row['average_rating'],   // <— requested key
    'popularity'       => (int)$row['total_sales'],
    'currency_symbol'  => $currency_symbol,
    'currency_code'    => $currency_code,
    'image'            => $image,
    'categories'       => $cats,
    'wishlist'         => false,
    'url'              => get_permalink($product_id),       // <— requested key
    'product_type'     => $product_type                     // <— requested key
  ];

  // ────────────────────────────────────────────────
  // Merge Product/Category Meta Actions (product first, then category fallback)
  $pfx = $wpdb->prefix;

  // 1) Product-level meta action
  $pma = $wpdb->get_row($wpdb->prepare("
    SELECT product_id, product_main_category_id,
           camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
           action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
           action_url_label, action_url_link
    FROM {$pfx}product_meta_action
    WHERE product_id = %d
    LIMIT 1
  ", $product_id), ARRAY_A);
  if ($wpdb->last_error) vogo_error_log3("[STEP 4][PMA SQL ERROR] {$wpdb->last_error} | IP: $ip | USER: $user_id");

  // if product meta specifies a main category id, prefer it as main for fallback
  if ($pma && !empty($pma['product_main_category_id'])) {
    $main_cat_id = (int)$pma['product_main_category_id'];
  }

  // 2) Category-level meta action (fallback)
  $cma = null;
  if ($main_cat_id > 0) {
    $cma = $wpdb->get_row($wpdb->prepare("
      SELECT category_id,
             camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
             action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
             action_url_label, action_url_link
      FROM {$pfx}category_meta_action
      WHERE category_id = %d
      LIMIT 1
    ", $main_cat_id), ARRAY_A);
    if ($wpdb->last_error) vogo_error_log3("[STEP 4][CMA SQL ERROR] {$wpdb->last_error} | IP: $ip | USER: $user_id");
  }

  // helper to pick value: product first, then category
  $pick = function($key) use ($pma,$cma){
    $pv = $pma[$key] ?? null;
    if (isset($pv) && $pv !== '') return $pv;
    $cv = $cma[$key] ?? null;
    return isset($cv) ? $cv : null;
  };

  // attach requested action fields
  $product_data['camera_broadcast_url'] = $pick('camera_broadcast_url');
  $product_data['zoom_live_call_link']  = $pick('zoom_live_call_link');
  $product_data['whatsapp_contact_url'] = $pick('whatsapp_contact_url');
  $product_data['suggest_service_link'] = $pick('suggest_service_link');

  // (opțional dar util: extra action fields dacă vrei să le expui)
  $product_data['action_whatsapp_label']   = $pick('action_whatsapp_label');
  $product_data['action_whatsapp_number']  = $pick('action_whatsapp_number');
  $product_data['action_whatsapp_message'] = $pick('action_whatsapp_message');
  $product_data['action_url_label']        = $pick('action_url_label');
  $product_data['action_url_link']         = $pick('action_url_link');

  // ────────────────────────────────────────────────
  // Wishlist check
  $exists = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}custom_wishlist WHERE user_id=%d AND product_id=%d",
    $user_id,$product_id
  ));
  if ((int)$exists > 0) $product_data['wishlist']=true;

  // Gallery
  $gallery_ids = get_post_meta($product_id, '_product_image_gallery', true);
  $gallery_arr=[];
  if (!empty($gallery_ids)) {
    $ids=array_filter(array_map('intval', explode(',',$gallery_ids)));
    foreach ($ids as $gid) {
      $gallery_arr[]=[
        'product_original_image'=>wp_get_attachment_url($gid),
        'product_full_image'=>wp_get_attachment_image_src($gid,'full')[0]??'',
        'product_medium_image'=>wp_get_attachment_image_src($gid,'medium')[0]??'',
        'product_thumbnail_image'=>wp_get_attachment_image_src($gid,'thumbnail')[0]??'',
      ];
    }
  }
  $product_data['product_gallery_images']=$gallery_arr;

  // Total reviews
  $comment_count = wp_count_comments($product_id);

  // ────────────────────────────────────────────────
  // Response
  vogo_error_log3("VOGO_LOG_END [PRODUCT DETAIL] | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'status'  => true,
    'module' => $module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,          // ✅ new
    'jwt_user_name'=>$jwt_user_name,      // ✅ new
    'message' => 'Data Successfully provided.',
    'data'    => [
      'product_data' => $product_data,
      'total_review' => $comment_count->total_comments
    ],
    'user_id'    => $user_id,
    'user_login' => $user_login
  ],200);
}

function custom_product_detail(WP_REST_Request $request) {
  global $wpdb;
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;  

  // ────────────────────────────────────────────────
  // Logs bootstrap
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START [PRODUCT DETAIL] | IP: $ip | USER: ?");
  $active_db = $wpdb->get_var("SELECT DATABASE()");
  vogo_error_log3("ACTIVE DB: {$active_db} | IP: $ip | USER: ?");
  $raw_input = file_get_contents('php://input');
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: ?");

  // ────────────────────────────────────────────────
  // JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) {
    vogo_error_log3("[STEP 0.2] JWT extraction failed | IP: $ip | USER: ?");
    return $user_or_err;
  }
  $user_id = (int)$user_or_err;
  $user = get_userdata($user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] User resolved: user_id=$user_id, user_login=$user_login | IP: $ip | USER: $user_id");

  // ────────────────────────────────────────────────

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

    //audit for response

  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    
  
  
  // Payload
  $data = json_decode($raw_input, true);
  if (empty($data)) $data = $request->get_params();
  $product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;

  $module=$module.'.product_id:'.$product_id;
  if(($r=product_check_status($product_id))!==true) return $r;


  if ($product_id <= 0) {
    vogo_error_log3("[STEP 2] Invalid or missing product_id | IP: $ip | USER: $user_id");
    return new WP_REST_Response([
      'status'  => false,
      'module' => $module.'-ES1',
      'message' => 'Product id is required.',
      'user_id' => $user_id,
      'user_login' => $user_login
    ], 400);
  }

  // ────────────────────────────────────────────────
  // SQL product query (adi-tehnic: direct SQL, no wc_get_product) + enrich with WC for type
  $p  = $wpdb->posts;
  $lk = $wpdb->prefix . 'wc_product_meta_lookup';

  $sql = $wpdb->prepare("
    SELECT product_id AS ID, post_title, slug, product_short_description as post_excerpt, product_description as post_content,price as min_price, 
    max_price, 0 AS onsale, stock_quantity, stock_status,5 as average_rating, 9999 as total_sales    
    FROM wp_vogo_products2 p
    WHERE p.product_id = %d
    LIMIT 1
  ", $product_id);

  vogo_error_log3("##############SQL: " . preg_replace('/\s+/', ' ', $sql) . " | IP: $ip | USER: $user_id");
  $row = $wpdb->get_row($sql, ARRAY_A);

  if ($wpdb->last_error) {
    vogo_error_log3("[STEP 3.E] SQL error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['status'=>false,'module' => $module.'-ES2','error'=>'SQL error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login], 500);
  }
  if (!$row) {
    vogo_error_log3("[STEP 3] Product not found | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['status'=>false,'module' => $module.'-ES3','message'=>'Product not found 3.'.$sql,'user_id'=>$user_id,'user_login'=>$user_login], 404);
  }

  // ────────────────────────────────────────────────
  // Hydrate product
  $thumb_id = (int)get_post_thumbnail_id($product_id);
  $image = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
  $cats=[]; 
  $terms=get_the_terms($product_id,'product_cat'); 
  if ($terms && !is_wp_error($terms)) { foreach($terms as $t){ $cats[]=['id'=>$t->term_id,'name'=>$t->name, 'parent'=>$t->parent]; } }

  // Determine main category id (prefer top-level; else first term)
  $main_cat_id = 0;
  if (!empty($cats)) {
    foreach($cats as $c){ if((int)$c['parent']===0){ $main_cat_id=(int)$c['id']; break; } }
    if($main_cat_id===0){ $main_cat_id = (int)$cats[0]['id']; }
  }

  // Product type + Woo explicit prices
  $wc_product    = wc_get_product($product_id);
  $product_type  = $wc_product ? $wc_product->get_type() : '';
  $regular_price = $wc_product ? (string)$wc_product->get_regular_price() : (string)get_post_meta($product_id,'_regular_price',true);
  $sale_price    = $wc_product ? (string)$wc_product->get_sale_price()    : (string)get_post_meta($product_id,'_sale_price',true);
  if ($regular_price === '') $regular_price = null;
  if ($sale_price === '')    $sale_price    = null;

  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  $product_data = [
    'id'               => $row['ID'],
    'name'             => $row['post_title'],
    'slug'             => $row['slug'],
    'short_description'=> wp_trim_words(strip_tags($row['post_excerpt']), 20),
    'description'      => $row['post_content'],
    'price'            => (string)$row['min_price'],
    'max_price'        => (string)$row['max_price'],
    'onsale'           => (int)$row['onsale'],
    'stock_quantity'   => isset($row['stock_quantity']) ? (int)$row['stock_quantity'] : null,
    'stock_status'     => $row['stock_status'],
    'rating'           => (float)$row['average_rating'],
    'average_rating'   => (float)$row['average_rating'],
    'popularity'       => (int)$row['total_sales'],
    'currency_symbol'  => $currency_symbol,
    'currency_code'    => $currency_code,
    'image'            => $image,
    'categories'       => $cats,
    'wishlist'         => false,
    'url'              => get_permalink($product_id),
    'product_type'     => $product_type,

    // NEW: explicit Woo prices
    'regular_price'    => $regular_price,
    'sale_price'       => $sale_price
  ];

  // ────────────────────────────────────────────────
  // NEW: vendor_id from wp_product_vendor (single numeric)
  $vendor_table = $wpdb->prefix . 'product_vendor';
  $sql_vendor = $wpdb->prepare("SELECT vendor_id FROM {$vendor_table} WHERE product_id = %d LIMIT 1", $product_id);
  vogo_error_log3("##############SQL: " . preg_replace('/\s+/', ' ', $sql_vendor) . " | IP: $ip | USER: $user_id");
  $vendor_id = $wpdb->get_var($sql_vendor);
  if ($wpdb->last_error) vogo_error_log3("[STEP 3.VENDOR.E] SQL error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
  $product_data['vendor_id'] = $vendor_id !== null ? (int)$vendor_id : null;

  // ────────────────────────────────────────────────
  // Merge Product/Category Meta Actions (product first, then category fallback)
  $pfx = $wpdb->prefix;

  $pma = $wpdb->get_row($wpdb->prepare("
    SELECT product_id, product_main_category_id,
           camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
           action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
           action_url_label, action_url_link
    FROM {$pfx}product_meta_action
    WHERE product_id = %d
    LIMIT 1
  ", $product_id), ARRAY_A);
  if ($wpdb->last_error) vogo_error_log3("[STEP 4][PMA SQL ERROR] {$wpdb->last_error} | IP: $ip | USER: $user_id");

  if ($pma && !empty($pma['product_main_category_id'])) $main_cat_id = (int)$pma['product_main_category_id'];

  $cma = null;
  if ($main_cat_id > 0) {
    $cma = $wpdb->get_row($wpdb->prepare("
      SELECT category_id,
             camera_broadcast_url, zoom_live_call_link, whatsapp_contact_url, suggest_service_link,
             action_whatsapp_label, action_whatsapp_number, action_whatsapp_message,
             action_url_label, action_url_link
      FROM {$pfx}category_meta_action
      WHERE category_id = %d
      LIMIT 1
    ", $main_cat_id), ARRAY_A);
    if ($wpdb->last_error) vogo_error_log3("[STEP 4][CMA SQL ERROR] {$wpdb->last_error} | IP: $ip | USER: $user_id");
  }

  $pick = function($key) use ($pma,$cma){
    $pv = $pma[$key] ?? null; if (isset($pv) && $pv !== '') return $pv;
    $cv = $cma[$key] ?? null; return isset($cv) ? $cv : null;
  };

$default_camera   = 'https://www.youtube.com/watch?v=z7SiAaN4ogw';
$default_meet     = 'https://meet.google.com/wqk-pwmg-kox';
$default_whatsapp = 'https://wa.me/40786854023?text=' . rawurlencode('Hello, I contact you from vogo.family. I need info related to ');

$product_data['camera_broadcast_url'] = ($tmp = $pick('camera_broadcast_url')) ? $tmp : $default_camera;
$product_data['zoom_live_call_link']  = ($tmp = $pick('zoom_live_call_link'))  ? $tmp : $default_meet;
$product_data['whatsapp_contact_url'] = ($tmp = $pick('whatsapp_contact_url')) ? $tmp : $default_whatsapp;


  $product_data['suggest_service_link'] = $pick('suggest_service_link');

$product_data['action_whatsapp_label']   = ($t = $pick('action_whatsapp_label'))   ? $t : 'Request info';
$product_data['action_whatsapp_number']  = ($t = $pick('action_whatsapp_number'))  ? $t : '40786854023';
$product_data['action_whatsapp_message'] = ($t = $pick('action_whatsapp_message')) ? $t : 'Hello, I contact you from vogo.family. I need infor related to';


  $product_data['action_url_label']        = $pick('action_url_label');
  $product_data['action_url_link']         = $pick('action_url_link');

  // ────────────────────────────────────────────────
  // Wishlist check
  $exists = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}custom_wishlist WHERE user_id=%d AND product_id=%d",
    $user_id,$product_id
  ));
  if ((int)$exists > 0) $product_data['wishlist']=true;

  // Gallery
  $gallery_ids = get_post_meta($product_id, '_product_image_gallery', true);
  $gallery_arr=[];
  if (!empty($gallery_ids)) {
    $ids=array_filter(array_map('intval', explode(',',$gallery_ids)));
    foreach ($ids as $gid) {
      $gallery_arr[]=[
        'product_original_image'=>wp_get_attachment_url($gid),
        'product_full_image'=>wp_get_attachment_image_src($gid,'full')[0]??'',
        'product_medium_image'=>wp_get_attachment_image_src($gid,'medium')[0]??'',
        'product_thumbnail_image'=>wp_get_attachment_image_src($gid,'thumbnail')[0]??'',
      ];
    }
  }
  $product_data['product_gallery_images']=$gallery_arr;

  // Total reviews
  $comment_count = wp_count_comments($product_id);

  // ────────────────────────────────────────────────
  // Response
  vogo_error_log3("VOGO_LOG_END [PRODUCT DETAIL] | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'status'  => true,
    'module' => $module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,          // ✅ new
    'jwt_user_name'=>$jwt_user_name,      // ✅ new
    'message' => 'Data Successfully provided.',
    'data'    => [
      'product_data' => $product_data,
      'total_review' => $comment_count->total_comments
    ],
    'user_id'    => $user_id,
    'user_login' => $user_login
  ],200);
}


/* --daca vreau si cities si mall locations

// ... codul de mai sus rămâne neschimbat până la // Total reviews

  // Total reviews
  $comment_count = wp_count_comments($product_id);

  // ────────────────────────────────────────────────
  // [STEP 5] Product Cities & Malls via category relations
  $product_city_list=[];
  $product_mall_list=[];

  if($main_cat_id>0){
    // cities
    $city_ids = $wpdb->get_col($wpdb->prepare("
      SELECT DISTINCT city_id FROM {$pfx}product_category_cities WHERE category_id=%d
    ", $main_cat_id));
    if($wpdb->last_error) vogo_error_log3("[STEP 5][CITY SQL ERROR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

    if($city_ids){
      // map city id -> name
      $cities_all = function_exists('get_cities_list') ? get_cities_list() : [];
      $map=[]; foreach($cities_all as $c){ $map[(int)$c['id']]=$c['name']; }
      foreach($city_ids as $cid){
        $cid=(int)$cid;
        $product_city_list[]=[
          'id'=>$cid,
          'name'=>$map[$cid]??''
        ];
      }
    }

    // malls
    $mall_rows = $wpdb->get_results($wpdb->prepare("
      SELECT m.id, m.mall_name
      FROM {$pfx}category_malls cm
      INNER JOIN {$pfx}mall_locations m ON cm.mall_id=m.id
      WHERE cm.category_id=%d AND m.status='active'
      ORDER BY m.position ASC, m.mall_name ASC
    ", $main_cat_id), ARRAY_A);
    if($wpdb->last_error) vogo_error_log3("[STEP 5][MALL SQL ERROR] {$wpdb->last_error} | IP:$ip | USER:$user_id");

    foreach(($mall_rows?:[]) as $mr){
      $product_mall_list[]=[
        'id'=>(int)$mr['id'],
        'name'=>$mr['mall_name']
      ];
    }
  }

  $product_data['product_cities']=$product_city_list;
  $product_data['product_malls']=$product_mall_list;

  // ────────────────────────────────────────────────
  // Response
  vogo_error_log3("VOGO_LOG_END [PRODUCT DETAIL] | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'status'  => true,
    'message' => 'Data Successfully provided.',
    'data'    => [
      'product_data' => $product_data,
      'total_review' => $comment_count->total_comments
    ],
    'user_id'    => $user_id,
    'user_login' => $user_login
  ],200);
}


*/

function custom_products($request) {
    // STEP 1: Parse input data
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    global $wpdb;

    // STEP 2: Initialize query parts
    $tax_query  = [];
    $meta_query = [];
    $orderby    = isset($data['orderby']) ? $data['orderby'] : 'ID';
    $order      = isset($data['order']) ? $data['order'] : 'DESC';
    $per_page   = isset($data['per_page']) ? intval($data['per_page']) : 10;
    $paged      = isset($data['page']) ? intval($data['page']) : 1;

    // STEP 3: Filter by category
    if (!empty($data['category'])) {
        $cat_ids = is_array($data['category']) ? $data['category'] : explode(',', $data['category']);
        $tax_query[] = [
            'taxonomy' => 'product_cat',
            'field'    => 'term_id',
            'terms'    => $cat_ids,
            'operator' => 'IN',
        ];
    }

    // STEP 4: Filter by brand
    if (!empty($data['product_brand'])) {
        $brand_ids = is_array($data['product_brand']) ? $data['product_brand'] : explode(',', $data['product_brand']);
        $tax_query[] = [
            'taxonomy'         => 'product_brand',
            'field'            => 'term_id',
            'terms'            => $brand_ids,
            'operator'         => 'IN',
            'include_children' => false,
        ];
    }

    // STEP 5: Handle search by product title
    if (!empty($data['search'])) {
        add_filter('posts_where', function ($where, $query) use ($data) {
            global $wpdb;
            $search_term = esc_sql($data['search']);
            $where .= " AND {$wpdb->posts}.post_title LIKE '%{$search_term}%'";
            return $where;
        }, 10, 2);
    }

    // STEP 6: Build query args
    $args = [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $paged,
        'tax_query'      => $tax_query,
        'meta_query'     => $meta_query,
        'orderby'        => $orderby,
        'order'          => $order,
    ];

    // STEP 7: Special ordering cases
    if ($orderby === 'price') {
        $args['meta_key'] = '_price';
        $args['orderby']  = 'meta_value_num';
    } elseif ($orderby === 'rating') {
        $args['meta_key'] = '_wc_average_rating';
        $args['orderby']  = 'meta_value_num';
    } elseif ($orderby === 'popularity') {
        $args['meta_key'] = 'total_sales';
        $args['orderby']  = 'meta_value_num';
    }

    // STEP 8: Execute query
    $loop = new WP_Query($args);
    $products = [];
    $currency_symbol = get_woocommerce_currency_symbol();
    $currency_code   = get_woocommerce_currency();

    // STEP 9: Loop through results
    if ($loop->have_posts()) {
        while ($loop->have_posts()) : $loop->the_post();
            $product = wc_get_product(get_the_ID());

            $products[] = [
                'id'              => $product->get_id(),
                'name'            => $product->get_name(),
                'slug'            => $product->get_slug(),
                'price'           => $product->get_price(),
                'regular_price'   => $product->get_regular_price(),
                'sale_price'      => $product->get_sale_price(),
                'currency_symbol' => html_entity_decode($currency_symbol),
                'currency_code'   => $currency_code,
                'image'           => wp_get_attachment_url($product->get_image_id()),
                'categories'      => array_map(function ($id) {
                    $term = get_term($id, 'product_cat');
                    return ['id' => $term->term_id, 'name' => $term->name];
                }, $product->get_category_ids())
            ];
        endwhile;
        wp_reset_postdata();

        // STEP 10: Append optional extra fields
        $request_new_product = (!empty($data['category']) && defined('REQUEST_NEW_PRODUCT')) ? REQUEST_NEW_PRODUCT : '';
        $new_service         = (!empty($data['category']) && defined('NEW_SERVICES')) ? NEW_SERVICES : '';

        vogo_error_log2("STEP 10: Fetched " . count($products) . " products.");

        return [
            'status'             => true,
            'code'               => 200,
            'message'            => 'Products fetched successfully',
            'currentPage'        => $paged,
            'total_count'        => $loop->found_posts,
            'currency_code'      => $currency_code,
            'currency_symbol'    => html_entity_decode($currency_symbol),
            'data'               => $products,
            'request_new_product'=> $request_new_product,
            'new_service'        => $new_service,
        ];
    }

    // STEP 11: No products found
    vogo_error_log2("STEP 11: No products found for current query.");
    return [
        'status'             => false,
        'code'               => 400,
        'message'            => 'No records found',
        'currentPage'        => $paged,
        'total_count'        => 0,
        'currency_code'      => $currency_code,
        'currency_symbol'    => html_entity_decode($currency_symbol),
        'data'               => [],
        'request_new_product'=> '',
        'new_service'        => '',
    ];
}

function custom_order_review(WP_REST_Request $request) {
    try {
        // STEP 1: Read and decode JSON input
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $_REQUEST;
        }

        // STEP 2: Extract and sanitize input fields
        $order_id = isset($data['order_id']) ? intval($data['order_id']) : 0;
        $rating   = isset($data['rating']) ? intval($data['rating']) : 0;
        $comment  = isset($data['comment']) ? sanitize_text_field($data['comment']) : '';
        $user_id  = isset($data['access_token']) ? intval($data['access_token']) : 0;

        // STEP 3: Validate required fields
        if (!$order_id || !$rating || !$comment || !$user_id) {
            vogo_error_log2("STEP 3: Missing required fields. order_id={$order_id}, rating={$rating}, user_id={$user_id}");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'Missing required fields.'
            ], 400);
        }

        // STEP 4: Prepare database table and check for duplicates
        global $wpdb;
        $table = $wpdb->prefix . 'order_reviews';

        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE order_id = %d AND user_id = %d",
            $order_id, $user_id
        ));

        if ($existing) {
            vogo_error_log2("STEP 4: Duplicate review found for order_id={$order_id}, user_id={$user_id}");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'You have already submitted a review for this order.'
            ], 409);
        }

        // STEP 5: Insert the new review into the database
        $inserted = $wpdb->insert($table, [
            'order_id' => $order_id,
            'user_id'  => $user_id,
            'rating'   => $rating,
            'comment'  => $comment
        ]);

        if ($inserted) {
            vogo_error_log2("STEP 5: Review inserted successfully for order_id={$order_id}, user_id={$user_id}");
            return new WP_REST_Response([
                'status'  => true,
                'message' => 'Review submitted successfully.'
            ], 200);
        } else {
            vogo_error_log2("STEP 5: Failed to insert review. order_id={$order_id}, user_id={$user_id}");
            return new WP_REST_Response([
                'status'  => false,
                'message' => 'Failed to submit review. Please try again later.'
            ], 500);
        }

    } catch (Exception $e) {
        // STEP 6: Log unexpected exception
        vogo_error_log2("STEP 6: Exception - " . $e->getMessage());
        return new WP_REST_Response([
            'status'  => false,
            'message' => 'An unexpected error occurred: ' . $e->getMessage()
        ], 500);
    }
}

function client_product_list(WP_REST_Request $request){
  global $wpdb; $module='provider-product-list-get'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response      

  // STEP 0 – Input
  $p = $request->get_json_params();
  $vendor_id = isset($p['vendor_id']) ? (int)$p['vendor_id'] : 0; // optional
  $module=$module.'.vendor_id:'.$vendor_id;

  $per_page = max(1, min(1000, (int)($p['per_page'] ?? 50)));
  $page     = max(1, (int)($p['page'] ?? 1));
  $offset   = ($page-1)*$per_page;

  $orderby  = strtolower(trim((string)($p['orderby'] ?? 'position')));   // 'position' | 'price'
  $order    = strtoupper(trim((string)($p['order'] ?? 'ASC')));          // 'ASC' | 'DESC'
  $search   = trim((string)($p['search'] ?? ''));                        // 'pizza'
  $cities   = trim((string)($p['cities'] ?? ''));                        // "1,2"

  $brand    = trim((string)($p['product_brand'] ?? ''));                 // TODO
  $malls    = trim((string)($p['malls'] ?? ''));                         // TODO

  $module=$module.'.cities:'.$cities;
  $module=$module.'.brand:'.$brand;
  $module=$module.'.malls:'.$malls;

  // category (CSV sau array)
  $category_param = $p['category'] ?? '';
  if(is_array($category_param)){ $category_param = implode(',', array_map('trim',$category_param)); }
  $category = trim((string)$category_param); // ex: "544,73,542"
  $module=$module.'.category:'.$category;

  // STEP 1 – Whitelist ORDER BY
  $orderby = in_array($orderby, ['position','price'], true) ? $orderby : 'position';
  $order   = in_array($order, ['ASC','DESC'], true) ? $order : 'ASC';
  $order_by_sql = ($orderby==='position')
    ? " ORDER BY p.menu_order $order, p.post_title ASC "
    : " ORDER BY CAST(MAX(CASE WHEN pm.meta_key='_price' THEN pm.meta_value END) AS DECIMAL(18,6)) $order, p.menu_order ASC ";

  // STEP 2 – Filters
  $where=[]; $args=[];
  $where[]="p.post_type IN ('product')";
  $where[]="p.post_status IN ('publish','draft')";

  if($search!==''){ $where[]="p.post_title LIKE %s"; $args[]='%'.$wpdb->esc_like($search).'%'; }

  $cities_str='';
  if($cities!==''){
    $cities_str = implode(',', array_filter(array_map('trim', explode(',', $cities)), fn($x)=>$x!==''));
    if($cities_str!==''){
      $where[]="EXISTS(SELECT 1 FROM wp_product_cities pcw WHERE pcw.product_id=p.ID AND FIND_IN_SET(pcw.city_id,%s))";
      $args[]=$cities_str;
    }
  }

  if($vendor_id>0){
    $where[]="EXISTS(SELECT 1 FROM wp_product_vendor pvx WHERE pvx.product_id=p.ID AND pvx.vendor_id=%d AND pvx.status='active')";
    $args[]=$vendor_id;
  }

  if($category!==''){
    $category_str = implode(',', array_filter(array_map('trim', explode(',', $category)), fn($x)=>$x!==''));
    if($category_str!==''){
      $where[]="(
        EXISTS (
          SELECT 1
          FROM wp_term_relationships tr
          INNER JOIN wp_term_taxonomy tt
                  ON tt.term_taxonomy_id = tr.term_taxonomy_id
                 AND tt.taxonomy = 'product_cat'
          WHERE tr.object_id = p.ID
            AND FIND_IN_SET(tt.term_id, %s)
        )
        OR
        EXISTS (
          SELECT 1
          FROM wp_product_meta_action pmaf
          WHERE pmaf.product_id = p.ID
            AND FIND_IN_SET(pmaf.product_main_category_id, %s)
        )
      )";
      $args[]=$category_str; // pt. tt.term_id
      $args[]=$category_str; // pt. pmaf.product_main_category_id
    }
  }

  // STEP 3 – SQL (adăugat: product_image)
  $pcc_city_clause = ($cities_str!=='') ? " AND FIND_IN_SET(pcc.city_id,%s) " : "";
  $sql =
"SELECT
  p.ID AS product_id,
  p.post_title AS product_title,
  MAX(CASE WHEN pm.meta_key = '_price'         THEN pm.meta_value END) AS price,
  MAX(CASE WHEN pm.meta_key = '_regular_price' THEN pm.meta_value END) AS regular_price,
  MAX(CASE WHEN pm.meta_key = '_sale_price'    THEN pm.meta_value END) AS sale_price,
  MAX(CASE WHEN pm.meta_key = '_sku'           THEN pm.meta_value END) AS sku,
  p.menu_order AS position,

  /* product_image (thumbnail id + url din wp_posts.guid) */
  (
    SELECT JSON_OBJECT(
      'id', pmimg.meta_value,
      'url', (SELECT pimg.guid FROM wp_posts pimg WHERE pimg.ID = pmimg.meta_value LIMIT 1)
    )
    FROM wp_postmeta pmimg
    WHERE pmimg.post_id = p.ID AND pmimg.meta_key = '_thumbnail_id'
    LIMIT 1
  ) AS product_image,

  /* vendor_obj (fara audit; include vendor_id; fara product_id) */
  (
    SELECT JSON_OBJECT(
      'id', pv2.id,
      'vendor_id', pv2.vendor_id,
      'status', pv2.status
    )
    FROM wp_product_vendor pv2
    WHERE pv2.product_id = p.ID".($vendor_id>0?" AND pv2.vendor_id = %d":"")."
      AND pv2.status = 'active'
    LIMIT 1
  ) AS vendor_obj,

  /* product_meta_action_obj (fara audit) */
  (
    SELECT JSON_OBJECT(
      'product_id', pma.product_id,
      'product_main_category_id', pma.product_main_category_id,
      'camera_broadcast_url', pma.camera_broadcast_url,
      'zoom_live_call_link', pma.zoom_live_call_link,
      'whatsapp_contact_url', pma.whatsapp_contact_url,
      'suggest_service_link', pma.suggest_service_link,
      'action_whatsapp_label', pma.action_whatsapp_label,
      'action_whatsapp_number', pma.action_whatsapp_number,
      'action_whatsapp_message', pma.action_whatsapp_message,
      'action_url_label', pma.action_url_label,
      'action_url_link', pma.action_url_link
    )
    FROM wp_product_meta_action pma
    WHERE pma.product_id = p.ID
    LIMIT 1
  ) AS product_meta_action_obj,

  /* category_meta_action_obj (fara audit) */
  (
    SELECT JSON_OBJECT(
      'category_id', cma.category_id,
      'camera_broadcast_url', cma.camera_broadcast_url,
      'zoom_live_call_link', cma.zoom_live_call_link,
      'whatsapp_contact_url', cma.whatsapp_contact_url,
      'suggest_service_link', cma.suggest_service_link,
      'action_whatsapp_label', cma.action_whatsapp_label,
      'action_whatsapp_number', cma.action_whatsapp_number,
      'action_whatsapp_message', cma.action_whatsapp_message,
      'action_url_label', cma.action_url_label,
      'action_url_link', cma.action_url_link
    )
    FROM wp_category_meta_action cma
    WHERE cma.category_id = (SELECT pma2.product_main_category_id FROM wp_product_meta_action pma2 WHERE pma2.product_id = p.ID LIMIT 1)
    LIMIT 1
  ) AS category_meta_action_obj,

  /* product_categories (Woo product_cat: id + name) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'id', t.term_id,
      'name', t.name
    )), JSON_ARRAY())
    FROM wp_term_relationships tr
    INNER JOIN wp_term_taxonomy tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'product_cat'
    INNER JOIN wp_terms t         ON t.term_id = tt.term_id
    WHERE tr.object_id = p.ID
  ) AS product_categories,

  /* product_cities (array JSON, city object fara audit) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'product_id', pc.product_id,
      'city_id', pc.city_id,
      'city', (SELECT JSON_OBJECT('id', c.id, 'city_name', c.city_name, 'status', c.status, 'position', c.position) FROM wp_cities c WHERE c.id = pc.city_id LIMIT 1)
    )), JSON_ARRAY())
    FROM wp_product_cities pc
    WHERE pc.product_id = p.ID
  ) AS product_cities,

  /* product_category_cities (array JSON, fara audit) */
  (
    SELECT IFNULL(JSON_ARRAYAGG(JSON_OBJECT(
      'category_id', pcc.category_id,
      'city_id', pcc.city_id
    )), JSON_ARRAY())
    FROM wp_product_category_cities pcc
    WHERE pcc.category_id = (SELECT pma3.product_main_category_id FROM wp_product_meta_action pma3 WHERE pma3.product_id = p.ID LIMIT 1)".$pcc_city_clause."
  ) AS product_category_cities

FROM wp_posts p
LEFT  JOIN wp_product_vendor pv ON pv.product_id=p.ID AND pv.status='active'
LEFT  JOIN wp_postmeta pm ON pm.post_id=p.ID AND pm.meta_key IN('_price','_regular_price','_sale_price','_sku')
WHERE ".implode(' AND ',$where)."
GROUP BY p.ID, p.menu_order
".$order_by_sql."
LIMIT %d OFFSET %d";

  // STEP 3.1 – Bind args (în ordinea placeholderelor)
  $args2=[];
  if($vendor_id>0){ $args2[]=$vendor_id; }           // vendor_obj subquery (%d)
  $args2=array_merge($args2,$args);                  // WHERE args
  if($cities_str!==''){ $args2[]=$cities_str; }      // pcc city clause
  $args2[]=$per_page; $args2[]=$offset;              // pagination

  $query=$wpdb->prepare($sql, ...$args2);
  vogo_error_log3("##############SQL: $query",$module);

  $rows=$wpdb->get_results($query, ARRAY_A);
  if($wpdb->last_error){
    vogo_error_log3("[$module] SQL ERROR: ".$wpdb->last_error,$module);
    vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'-ES3.1','error'=>'sql','sql_error'=>$wpdb->last_error,'vendor_id'=>($vendor_id?:null)],500);
  }

 // STEP 4 – Decode JSON fields to real objects/arrays
$json_object_keys=['product_image','vendor_obj','product_meta_action_obj','category_meta_action_obj'];
$json_array_keys=['product_categories','product_cities','product_category_cities'];
foreach($rows as &$r){
  foreach($json_object_keys as $k){
    if(array_key_exists($k,$r)){
      $v=$r[$k];
      if($v===null||$v===''){ $r[$k]=null; }
      elseif(is_string($v)){ $d=json_decode($v,true); $r[$k]=(json_last_error()===JSON_ERROR_NONE&&is_array($d))?$d:null; }
    }
  }
  foreach($json_array_keys as $k){
    if(array_key_exists($k,$r)){
      $v=$r[$k];
      if($v===null||$v===''){ $r[$k]=[]; }
      elseif(is_string($v)){ $d=json_decode($v,true); $r[$k]=(json_last_error()===JSON_ERROR_NONE&&is_array($d))?$d:[]; }
      elseif(!is_array($v)){ $r[$k]=[]; }
    }
  }
  unset($r['vendor_id']);

  /* [ADI-ADD] Enrich product_image with original and cached URLs + keep GUID */
  if(isset($r['product_image']) && is_array($r['product_image']) && !empty($r['product_image']['id'])){
    $att_id = (int)$r['product_image']['id'];

    // keep GUID URL from SQL as legacy reference
    if(isset($r['product_image']['url']) && $r['product_image']['url']!==''){
      $r['product_image']['guid_url'] = $r['product_image']['url'];
    }

    // original file URL via WP core (env-aware)
    $orig = wp_get_attachment_url($att_id);
    if($orig){ $r['product_image']['original_url'] = $orig; }

    if ($orig) {
      // forțează url și guid_url să fie identice cu original_url
      $r['product_image']['url'] = $orig;
      $r['product_image']['guid_url'] = $orig;
    }    

    // cached/resized URL for listings (WooCommerce)
    $thumb = wp_get_attachment_image_src($att_id, 'woocommerce_thumbnail'); // shop/thumb size
    if(is_array($thumb)){
      $r['product_image']['thumb_url'] = $thumb[0];
      $r['product_image']['thumb_w']   = (int)$thumb[1];
      $r['product_image']['thumb_h']   = (int)$thumb[2];
    }

    // optional: responsive sources
    $srcset = wp_get_attachment_image_srcset($att_id, 'woocommerce_thumbnail');
    if($srcset){ $r['product_image']['srcset'] = $srcset; }
    $sizes  = wp_get_attachment_image_sizes($att_id, 'woocommerce_thumbnail');
    if($sizes){ $r['product_image']['sizes']  = $sizes; }
  }
} unset($r);



  // STEP 5 – Response (inclus jwt_user_id + jwt_user_name)
  $resp=[
    'success'=>true,
    'vendor_id'=>($vendor_id?:null),
    'module' => $module.'-TEND',
    'page'=>$page,
    'per_page'=>$per_page,
    'count'=>count($rows),
    'orderby'=>$orderby,
    'order'=>$order,
    'jwt_user_id'=>$jwt_user_id,          // ✅ nou
    'jwt_user_name'=>$jwt_user_name,      // ✅ nou
    'filters'=>[
      'search'=>$search,
      'cities'=>$cities,
      'category'=>$category,
      'product_brand'=>$brand, // TODO
      'malls'=>$malls          // TODO
    ],
    'items'=>$rows
  ];

  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response($resp,200);
}


/**
 * Set WooCommerce product featured image from a single multipart file field: "imagine".
 * - Auth via JWT (extract_user_from_jwt_token)
 * - Saves to Media Library as attachment (attached to product)
 * - Sets product featured image (no gallery writes)
 * - Returns URLs for common sizes
 *
 * POST (multipart/form-data):
 *   product_id: <int>  // required
 *   imagine:    <file> // required (accepts also "file")
 */
function vogo_product_set_image(WP_REST_Request $request){
  // [LOG START]
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | MODULE:product_set_image_simple | ACTIVE DB: ".DB_NAME." | IP:$ip");

  // [STEP 1] Auth
  $user_id=extract_user_from_jwt_token($request);
  if($user_id instanceof WP_REST_Response){ vogo_error_log3("[STEP 1][ERR] JWT response error | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return $user_id; }
  if(is_wp_error($user_id)){ vogo_error_log3("[STEP 1][ERR] ".$user_id->get_error_message()." | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>$user_id->get_error_message()],401); }

  // [STEP 2] Params + File pick (imagine|file)
  $product_id = (int)($request->get_param('product_id') ?? 0);
  if($product_id<=0){ vogo_error_log3("[STEP 2][ERR] Missing product_id | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Missing product_id'],400); }

  $post = get_post($product_id);
  if(!$post || $post->post_type!=='product'){ vogo_error_log3("[STEP 2][ERR] product_not_found | pid:$product_id | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Product not found'],404); }

  $files=$request->get_file_params(); $f=$files['imagine']??($files['file']??($_FILES['imagine']??($_FILES['file']??null)));
  if(empty($f)||!empty($f['error'])){ $code=$f['error']??'N/A'; vogo_error_log3("[STEP 2][ERR] Missing file or upload error:$code | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Missing file \"imagine\" (or \"file\") or upload error'],400); }
  if(!empty($f['size']) && $f['size']>10*1024*1024){ vogo_error_log3("[STEP 2][ERR] Too large >10MB | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Image too large (max 10MB)'],413); }

  // [STEP 3] WP media libs
  require_once ABSPATH.'wp-admin/includes/file.php';
  require_once ABSPATH.'wp-admin/includes/media.php';
  require_once ABSPATH.'wp-admin/includes/image.php';

  // [STEP 4] Upload to Media Library (attach to product)
  $field = (isset($files['imagine'])||isset($_FILES['imagine'])) ? 'imagine' : 'file';
  $attach_id=media_handle_upload($field,$product_id);
  if(is_wp_error($attach_id)){ vogo_error_log3("[STEP 4][ERR] media_handle_upload: ".$attach_id->get_error_message()." | IP:$ip | USER:$user_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'message'=>'Upload failed','error'=>$attach_id->get_error_message()],500); }

  // [STEP 5] Build URLs
  $full=wp_get_attachment_image_url($attach_id,'full')?:''; $thumb=wp_get_attachment_image_src($attach_id,'thumbnail'); $medium=wp_get_attachment_image_src($attach_id,'medium'); $large=wp_get_attachment_image_src($attach_id,'large');
  $sizes=['full'=>$full,'thumbnail'=>$thumb?$thumb[0]:'','medium'=>$medium?$medium[0]:'','large'=>$large?$large[0]:''];

  // [STEP 6] Set product featured image (strict, fără gallery)
  set_post_thumbnail($product_id, (int)$attach_id);

  vogo_error_log3("[STEP 6] Product image updated | PID:$product_id | ATTACH:$attach_id | URL:$full | BY:$user_id | IP:$ip");
  vogo_error_log3("VOGO_LOG_END");

  // [STEP 7] Response
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat (N/A) */
  return new WP_REST_Response([
    'success'=>true,'message'=>'Product image updated',
    'product_id'=>$product_id,
    'attachment_id'=>$attach_id,'url'=>$full,'sizes'=>$sizes
  ],200);
}


//end file