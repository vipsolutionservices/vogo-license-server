<?php
//client endpoints - for orders management
//wp_orders.`delivery_type` enum('DIRECT','POSTAL','COURIER','ELECTRONIC','TAXI') NOT NULL DEFAULT 'DIRECT',
// taxi = drive uber/bolt/blackcab
// direct = glovo
// postal, courier - emag
// electronic = viagogo

/*
daca tip livrare=DIRECT:
STATUS TRANSPORTES TRIPS - pastrate in WP_ORDERS.STATUS:
READY = disponilbila; 
ACCEPTED - luata de un transporter , 
STARTED - imediat ce incepe sa se comunice prima modificare de locatie de catre masina transporter, distangta<=100 m de la start location
IN_PROGRESS - miscarile urmatoare pana la comming soon, didtanta > 100 m de la start si >100 pana la end
COMMING_SOON - cand se apropie la 500 m or less, distangta<=500 m de la end location
ARRIVED - cand a ajuns in locatie , distanta <=50 m de end locatie
DELIVERED cand a predat coletul sau pasagerul, 
REJECTED - daca transportatorul a refuzat comanda
CLOSED dupa delivered, 
CANCELLED anulata de client


daca tip livrare=CURIER
READY = disponilbila; 
ACCEPTED - confirmata/preluata 
STARTED - in lucru, se impacheteaza
PACKAGED - pregatita pentru preluare de catre curier
CURIER - a fost preluata de curier
DELIVERED cand a predat coletul sau pasagerul, 
REJECTED - daca vendorul a refuzat comanda, cu motiv
CLIENT_NOT_FOUND - daca nu este in locatie
ADDRESS_NOT_FOUND - daca nu s-a gasit adresa
CLOSED dupa delivered, 
CANCELLED anulata de client

*/

add_action('rest_api_init', function(){


  register_rest_route('vogo/v1', '/client/nontaxi_client_get_active_orders', [
    'methods'  => 'POST',
    'callback' => 'nontaxi_client_get_active_orders',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);    

  register_rest_route('vogo/v1', '/client/nontaxi_client_get_history_orders', [
    'methods'  => 'POST',
    'callback' => 'nontaxi_client_get_history_orders',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);     

  register_rest_route('vogo/v1', '/client/nontaxi_client_get_order_details', [
    'methods'  => 'POST',
    'callback' => 'nontaxi_client_get_order_details',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);     

  register_rest_route('vogo/v1', '/client/nontaxi_wp_orders_calculate_fields', [
    'methods'  => 'POST',
    'callback' => 'nontaxi_wp_orders_calculate_fields',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', 'client/nontaxi_accept', [
    'methods' => 'POST',
    'callback' => 'nontaxi_accept',
    'permission_callback' => 'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1', '/client/nontaxi_update_current_position', [
    'methods' => 'POST',
    'callback' => 'nontaxi_update_current_position',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/vendor/nontaxi_vendor_reject', [ //to be implemented
    'methods'  => 'POST',
    'callback' => 'nontaxi_vendor_reject',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/vendor/nontaxi_update_status_and_notes', [
    'methods'  => 'POST',
    'callback' => 'nontaxi_update_status_and_notes',
    'permission_callback' => 'vogo_permission_check'
  ]);  

  register_rest_route('vogo/v1','/vendor/nontaxi_finish',[
    'methods'  => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'nontaxi_finish'
  ]);  

  register_rest_route('vogo/v1','/vendor/nontaxi_cancel',[
    'methods'  => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'nontaxi_cancel'
  ]);
  
  register_rest_route('vogo/v1','/client/nontaxi_client_order_status_details',[
    'methods'  => 'POST',
    'permission_callback' => 'nontaxi_client_order_status_details',
    'callback' => 'client_orders_list'
  ]);  

});


function nontaxi_client_get_active_orders(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    return $user_or_err;  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

  //audit for response
  $MODULE_PHP=basename(__FILE__);  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$uid;  $wp_user = get_user_by('id', (int)$jwt_user_id);   $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response  

  $t_orders=$wpdb->prefix.'orders';
  $t_del = $wpdb->prefix.'orders_delivery';
  $t_tr  = $wpdb->prefix.'transporters';  

  $clientFilter = ' AND o.client_id=%d';

  $status_list = ['READY','ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','PACKAGED','COURIER'];
 // $allowed = ['READY','ACCEPTED','STARTED','PACKAGED','COURIER','DELIVERED','REJECTED','CLIENT_NOT_FOUND','ADDRESS_NOT_FOUND','CLOSED','CANCELLED'];
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));

  $limit = 200; $offset = 0;

  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    LEFT JOIN $t_del d ON d.order_id=o.id
    LEFT JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE 1=1
      AND o.delivery_type in ('DIRECT','POSTAL','COURIER','ELECTRONIC')
      AND o.status IN ($placeholders)
      $clientFilter
    ORDER BY o.created_at DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge($status_list, [$uid, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);

  $rows=$wpdb->get_results($sql,ARRAY_A);

  if($wpdb->last_error){ return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error'.$sql,'sql_error'=>$wpdb->last_error],500);  }

  $out=[]; 
  $labels = ['READY' => 'Ready','ACCEPTED' => 'Accepted','STARTED' => 'Started','IN_PROGRESS' => 'In progress','COMMING_SOON' => 'Coming soon','ARRIVED' => 'Arrived'];

  foreach($rows as $r){
    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code; // fallback sigur
    $order_text = (string)$r['order_short_description'] . ((string)($r['notes_customer'] ?? '') . '-' . (string)($r['notes_provider'] ?? ''));

    $icon_display = (string)$r['delivery_type']; // cerut: identic cu delivery_type

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      'status_label'=>$status_label,
      'order_text'=>$order_text,
      'icon_name'=>$icon_display
    ];
  }
  $t_json_end = microtime(true);
  vogo_error_log3("[$module] JSON build=".round(($t_json_end - $t_json_start),3)."s",$module);
  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  $next=null;
  // vogo_error_log3("[$module] OK | found: ".count($out)." | next:".($next??'null')." | t_sql=".round(($t_sql_end-$t_sql_start),3)."s | t_json=".round(($t_json_end-$t_json_start),3)."s",$module);
  // vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','count'=>count($out),'orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}//client_get_active_drive_orders