<?php
$MODULE_PHP='social-endpoints.php';
/**
 * VOGO Social Auth Endpoints (adi-tehnic)
 * Ruta: /wp-json/vogo/v1/register/...
 * - google-login / apple-login / facebook-login
 * - google-register / apple-register / facebook-register
 * Helpers incluse: _vogo_find_user_only, _vogo_create_user_and_bind, _vogo_auth_response
 */

add_action('rest_api_init', function(){
    // LOGIN
    register_rest_route('vogo/v1','/social/vendor/google-login',[
        'methods'=>'POST','callback'=>'auth_google_login','permission_callback'=>'vogo_permission_check'
    ]);
  
    register_rest_route('vogo/v1','/social/client/google-login',[
        'methods'=>'POST','callback'=>'auth_google_login','permission_callback'=>'vogo_permission_check'
    ]);
    
    register_rest_route('vogo/v1','/social/transporter/google-login',[
        'methods'=>'POST','callback'=>'auth_google_login','permission_callback'=>'vogo_permission_check'
    ]);
    
    
    



    register_rest_route('vogo/v1','/social/vendor/facebook-login',[
        'methods'=>'POST','callback'=>'auth_facebook_login','permission_callback'=>'vogo_permission_check'
    ]);
    register_rest_route('vogo/v1','/social/client/facebook-login',[
        'methods'=>'POST','callback'=>'auth_facebook_login','permission_callback'=>'vogo_permission_check'
    ]);
    register_rest_route('vogo/v1','/social/transporter/facebook-login',[
        'methods'=>'POST','callback'=>'auth_facebook_login','permission_callback'=>'vogo_permission_check'
    ]);        

    register_rest_route('vogo/v1', '/social/vendor/apple-login', [
        'methods'  => 'POST',
        'callback' => 'auth_apple_login_debug',
        'permission_callback' => '__return_true'
    ]);    
    register_rest_route('vogo/v1', '/social/client/apple-login', [
        'methods'  => 'POST',
        'callback' => 'auth_apple_login_debug',
        'permission_callback' => '__return_true'
    ]);    
    register_rest_route('vogo/v1', '/social/transporter/apple-login', [
        'methods'  => 'POST',
        'callback' => 'auth_apple_login_debug',
        'permission_callback' => '__return_true'
    ]);            

    // REGISTER
    register_rest_route('vogo/v1','/social-old/google-register',[
        'methods'=>'POST','callback'=>'auth_google_register','permission_callback'=>'vogo_permission_check'
    ]);
    register_rest_route('vogo/v1','/social-old/apple-register',[
        'methods'=>'POST','callback'=>'auth_apple_register','permission_callback'=>'vogo_permission_check'
    ]);
    register_rest_route('vogo/v1','/social-old/facebook-register',[
        'methods'=>'POST','callback'=>'auth_facebook_register','permission_callback'=>'vogo_permission_check'
    ]);
});

/* =========================
 *         LOGIN
 * ========================= */

/** Google LOGIN */
function auth_google_login(WP_REST_Request $request){
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("GOOGLE_LOGIN_START | IP:$ip");
    $p=$request->get_json_params();
    $id_token = trim(sanitize_text_field($p['value']??'')); 
    $device   = trim(sanitize_text_field($p['device_token']??''));
    if(empty($id_token)) return ['success'=>false,'error'=>'Missing Google id_token'];

    $res=wp_remote_get('https://oauth2.googleapis.com/tokeninfo?id_token='.rawurlencode($id_token),['timeout'=>10]);
    if(is_wp_error($res) || wp_remote_retrieve_response_code($res)!==200) return ['success'=>false,'error'=>'Google token verify failed'];
    $body=json_decode(wp_remote_retrieve_body($res),true);
    $sub=$body['sub']??''; $email=sanitize_email($body['email']??'');
    if(empty($sub)) return ['success'=>false,'error'=>'Invalid Google token'];

    // find or create for login (login == auto-register dacă e nou)
    $user=_vogo_find_user_only('google',$sub,$email);
    if(!$user){
        $user=_vogo_create_user_and_bind('google',$sub,$email,$device);
        setup_role_at_register ($user);
        if(is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];
    } else {
        if(!empty($device)) update_user_meta($user->ID,'device_token',$device);
        setup_role_at_register ($user);
        update_user_meta($user->ID,'social_type','google');
        update_user_meta($user->ID,"google_sub",$sub);
    }

    return _vogo_auth_response($user,'google',$sub,true);
}

/** Facebook LOGIN */
function auth_facebook_login(WP_REST_Request $request){
    $p = $request->get_json_params();
    $access   = trim(sanitize_text_field($p['value']??''));     // accessToken (opțional)
    $socialId = trim(sanitize_text_field($p['social_id']??'')); // fb user id
    $email    = sanitize_email($p['email']??'');
    $device   = trim(sanitize_text_field($p['device_token']??''));

    if (empty($socialId) && empty($access)) {
        return ['success'=>false,'error'=>'Missing facebook social_id or accessToken'];
    }
    $sub = !empty($socialId) ? $socialId : 'fb_'.$access;

    // 1) Căutare user — normalizează WP_Error la false
    $user = _vogo_find_user_only('facebook', $sub, $email);
    if (is_wp_error($user)) {
        $user = false;
    }

    if (!$user) {
        // 2) Creare user — verifică imediat WP_Error, abia apoi folosește $user->ID
            $user = _vogo_create_user_and_bind('facebook', $sub, $email, $device);
            if (is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];
            setup_role_at_register($user);
    } else {
        // 3) User existent — rulează DOAR dacă e WP_User valid
        if ($user instanceof WP_User) {
            if (!empty($device)) update_user_meta($user->ID, 'device_token', $device);
            update_user_meta($user->ID, 'social_type', 'facebook');
            update_user_meta($user->ID, 'facebook_sub', $sub);
        } else {
            // fallback ultra-sigur (evită din nou accesul la ->ID)
            return ['success'=>false,'error'=>'Invalid user object'];
        }
    }

    // verified=false până adăugăm debug_token Graph
    return _vogo_auth_response($user, 'facebook', $sub, false);
}


/* =========================
 *       REGISTER
 * ========================= */

/** Google REGISTER */
function auth_google_register(WP_REST_Request $request){
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("GOOGLE_REGISTER_START | IP:$ip");
    $p=$request->get_json_params();
    $id_token = trim(sanitize_text_field($p['value']??''));
    $device   = trim(sanitize_text_field($p['device_token']??''));
    if(empty($id_token)) return ['success'=>false,'error'=>'Missing Google id_token'];

    $res=wp_remote_get('https://oauth2.googleapis.com/tokeninfo?id_token='.rawurlencode($id_token),['timeout'=>10]);
    if(is_wp_error($res) || wp_remote_retrieve_response_code($res)!==200) return ['success'=>false,'error'=>'Google token verify failed'];
    $body=json_decode(wp_remote_retrieve_body($res),true);
    $sub=$body['sub']??''; $email=sanitize_email($body['email']??'');
    if(empty($sub)) return ['success'=>false,'error'=>'Invalid Google token'];

    $exists=_vogo_find_user_only('google',$sub,$email);
    if($exists && !is_wp_error($exists)){
        return ['success'=>false,'reason'=>'already_registered','user_id'=>$exists->ID,'email'=>$exists->user_email];
    }

    $user=_vogo_create_user_and_bind('google',$sub,$email,$device);
    if(is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];

    return _vogo_auth_response($user,'google',$sub,true);
}

/** Apple REGISTER */
function auth_apple_register(WP_REST_Request $request){
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("APPLE_REGISTER_START | IP:$ip");
    $p=$request->get_json_params();
    $id_token = trim(sanitize_text_field($p['value']??''));
    $email_in = sanitize_email($p['email']??'');
    $device   = trim(sanitize_text_field($p['device_token']??''));
    if(empty($id_token)) return ['success'=>false,'error'=>'Missing Apple id_token'];

    $parts=explode('.',$id_token); if(count($parts)<2) return ['success'=>false,'error'=>'Invalid Apple token'];
    $payload=json_decode(base64_decode(strtr($parts[1],'-_','+/')),true)?:[];
    $sub=$payload['sub']??''; $email=sanitize_email($payload['email']??$email_in);
    if(empty($sub)) return ['success'=>false,'error'=>'Invalid Apple token payload'];

    $exists=_vogo_find_user_only('apple',$sub,$email);
    if($exists && !is_wp_error($exists)){
        return ['success'=>false,'reason'=>'already_registered','user_id'=>$exists->ID,'email'=>$exists->user_email];
    }

    $user=_vogo_create_user_and_bind('apple',$sub,$email,$device);
    if(is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];

    return _vogo_auth_response($user,'apple',$sub,false); // verified=false până adăugăm JWK
}

/** Facebook REGISTER */
function auth_facebook_register(WP_REST_Request $request){
    $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("FACEBOOK_REGISTER_START | IP:$ip");
    $p=$request->get_json_params();
    $access   = trim(sanitize_text_field($p['value']??''));     // accessToken (opțional)
    $socialId = trim(sanitize_text_field($p['social_id']??'')); // fb user id
    $email    = sanitize_email($p['email']??'');
    $device   = trim(sanitize_text_field($p['device_token']??''));

    if(empty($socialId) && empty($access)) return ['success'=>false,'error'=>'Missing facebook social_id or accessToken'];
    $sub = !empty($socialId) ? $socialId : 'fb_'.$access;

    $exists=_vogo_find_user_only('facebook',$sub,$email);
    if($exists && !is_wp_error($exists)){
        return ['success'=>false,'reason'=>'already_registered','user_id'=>$exists->ID,'email'=>$exists->user_email];
    }

    $user=_vogo_create_user_and_bind('facebook',$sub,$email,$device);
    if(is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];

    return _vogo_auth_response($user,'facebook',$sub,false); // verified=false până adăugăm debug_token
}

/* =========================
 *        HELPERS
 * ========================= */

function _vogo_find_user_only(string $provider,string $sub,string $email=''){
    $meta_key="{$provider}_sub";
    // 1) după provider_sub
    $users=get_users(['meta_key'=>$meta_key,'meta_value'=>$sub,'number'=>1,'count_total'=>false]);
    if(!empty($users)) return $users[0];
    // 2) după email (strict în wp_users)
    if(!empty($email) && is_email($email) && email_exists($email)){
        $u=get_user_by('email',$email);
        if($u) return $u;
    }
    return null;
}

function _vogo_create_user_and_bind($provider, $sub, $email = '', $device = '') {
    $provider = strtolower(trim((string)$provider));
    $sub      = trim((string)$sub);
    $email    = is_string($email) ? trim($email) : '';

    if ($provider === '' || $sub === '') {
        return new WP_Error('social_invalid_payload', 'Missing provider or sub');
    }

    // 0) Dacă există deja user pe email, leagă-l și ieși
    if ($email && is_email($email)) {
        $u = get_user_by('email', $email);
        if ($u instanceof WP_User) {
            update_user_meta($u->ID, 'social_type', $provider);
            update_user_meta($u->ID, "{$provider}_sub", $sub);
            if ($device) update_user_meta($u->ID, 'device_token', $device);
            return $u;
        }
    }

    // 1) Construiește un login sigur (fără șanse să fie gol)
    $login = '';
    // 1.a) Încearcă din email (local-part)
    if ($email && is_email($email)) {
        $local = current(explode('@', $email));
        $login = sanitize_user($local, true);
    }

    // 1.b) Dacă e gol, derivă din provider + sub (curățat strict)
    if ($login === '') {
        // reduce sub la alfanumeric + underscore
        $sub_clean = preg_replace('/[^a-zA-Z0-9_]/', '', $sub);
        // fallback extrem: dacă și asta e goală, folosește hash scurt
        if ($sub_clean === '' || strlen($sub_clean) < 3) {
            $sub_clean = substr(md5($provider . '|' . $sub . '|' . microtime(true)), 0, 10);
        }
        $login = sanitize_user(substr($provider, 0, 3) . '_' . $sub_clean, true); // ex: 'fac_123abc'
    }

    // 1.c) Ultimul fallback, dacă tot a rămas gol (improbabil)
    if ($login === '' || ctype_space($login)) {
        $login = 'usr_' . substr(md5(uniqid('', true)), 0, 10);
    }

    // 1.d) Normalizează lungimea (WP limite ~60)
    if (strlen($login) > 60) {
        $login = substr($login, 0, 60);
    }

    // 1.e) Unicizează username
    $base = $login;
    $i = 1;
    while (username_exists($login)) {
        $suffix = (string)$i;
        $login  = substr($base, 0, max(1, 60 - strlen($suffix))) . $suffix;
        $i++;
    }

    // 2) Email fallback unic dacă lipsește/invalid
    if (!$email || !is_email($email)) {
        $email = $login . '@vogo.family';
        $i = 1;
        while (email_exists($email)) {
            $email = $login . $i . '@vogo.family';
            $i++;
        }
    }

    // 3) Creează userul
    $password = wp_generate_password(20, true, true);
    $userdata = [
        'user_login'   => $login,
        'user_pass'    => $password,
        'user_email'   => $email,
        'display_name' => $login,
        'nickname'     => $login,
        'role'         => get_option('default_role', 'subscriber'),
    ];

    $uid = wp_insert_user($userdata);
    if (is_wp_error($uid)) {
        // dacă tot apare eroarea, oprim clar aici
        return new WP_Error('social_create_failed', 'User create failed: ' . $uid->get_error_message());
    }

    // 4) Leagă meta-urile sociale + device
    update_user_meta($uid, 'social_type', $provider);
    update_user_meta($uid, "{$provider}_sub", $sub);
    if ($device) update_user_meta($uid, 'device_token', $device);

    $u = get_user_by('id', $uid);
    if (!$u instanceof WP_User) {
        return new WP_Error('social_unknown_user', 'User created but could not be loaded');
    }
    return $u;
}


function _vogo_auth_response($user, string $provider, string $sub, bool $verified){
    if (is_wp_error($user)) return ['success'=>false,'error'=>$user->get_error_message()];

    // Use the same project-wide JWT generator used by vogo_api_login_jwt
    $jwt_data = function_exists('vogo_generate_jwt') ? vogo_generate_jwt((int)$user->ID) : null;
    $token    = is_array($jwt_data) ? ($jwt_data['token']  ?? null) : null;
    $expires  = is_array($jwt_data) ? ($jwt_data['expire'] ?? null) : null;

    if (!$token) {
        vogo_error_log3("[AUTH] JWT gen failed or vogo_generate_jwt() missing | USER:{$user->ID} | IP:".($_SERVER['REMOTE_ADDR']??'UNKNOWN'));
    }

    return [
        'success'       => true,
        'message'       => 'Login successful',
        'user_id'       => $user->ID,
        'user_login'    => $user->user_login,
        'email'         => $user->user_email,
        'provider'      => $provider,
        'provider_sub'  => $sub,
        'verified'      => $verified,
        // keep both for parity + backward-compat
        'token'         => $token,
        'expires_in'    => $expires,
        'jwt'           => $token
    ];
}


function auth_apple_login_debug(WP_REST_Request $request)
{
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        $p = $request->get_json_params();
        $id_token = trim(sanitize_text_field($p['value'] ?? ''));
        $email_in = sanitize_email($p['email'] ?? '');
        $device   = trim(sanitize_text_field($p['device_token'] ?? ''));

        if (empty($id_token)) {
            return ['success' => false, 'error' => 'Missing Apple id_token'];
        }

        $parts = explode('.', $id_token);
        if (count($parts) !== 3) {
            return [
                'success' => false,
                'error'   => 'Invalid token format',
                'debug'   => [
                    'token_parts_count' => count($parts),
                    'expected' => 3,
                    'raw_token_start' => substr($id_token, 0, 50) . '...'
                ]
            ];
        }

        [$rawHeader, $rawPayload, $rawSig] = $parts;

        // decode helper inline
        $b64url_decode = function ($b64) {
            $b64 = strtr($b64, '-_', '+/');
            $pad = strlen($b64) % 4;
            if ($pad) $b64 .= str_repeat('=', 4 - $pad);
            return base64_decode($b64, true);
        };

        $headerJson = $b64url_decode($rawHeader);
        $payloadJson = $b64url_decode($rawPayload);

        $header = json_decode($headerJson, true);
        $payload = json_decode($payloadJson, true);

        $debug = [
            'header_raw' => substr($headerJson ?: '', 0, 200),
            'payload_raw' => substr($payloadJson ?: '', 0, 200),
            'header_json_error' => json_last_error_msg(),
            'payload_json_error' => json_last_error_msg(),
            'header' => $header,
            'payload' => $payload,
        ];

        if (!is_array($payload)) {
            return [
                'success' => false,
                'error'   => 'Invalid payload JSON',
                'debug'   => $debug
            ];
        }

        $sub = $payload['sub'] ?? '';
        $email = sanitize_email($payload['email'] ?? $email_in);
        $iss = $payload['iss'] ?? null;
        $aud = $payload['aud'] ?? null;
        $exp = $payload['exp'] ?? null;
        $iat = $payload['iat'] ?? null;

        $debug['claims'] = [
            'sub' => $sub,
            'email' => $email,
            'iss' => $iss,
            'aud' => $aud,
            'exp' => $exp,
            'iat' => $iat,
        ];

        if (empty($sub)) {
            return ['success' => false, 'error' => 'Missing sub claim', 'debug' => $debug];
        }

        if ($iss && $iss !== 'https://appleid.apple.com') {
            return ['success' => false, 'error' => 'Invalid issuer', 'debug' => $debug];
        }

        $now = time();
        if (!empty($exp) && $exp <= $now) {
            return ['success' => false, 'error' => 'Token expired', 'debug' => $debug];
        }

        // === simulate login flow ===
        $user = _vogo_find_user_only('apple', $sub, $email);

        
//--verific user si il ii dau dreptrurile aferente de provider
        if (!$user) {
            $user = _vogo_create_user_and_bind('apple', $sub, $email, $device);
            setup_role_at_register($user);
            if (is_wp_error($user)) {
                return ['success' => false, 'error' => $user->get_error_message(), 'debug' => $debug];
            }
        } else {
            setup_role_at_register($user);
            if (!empty($device)) update_user_meta($user->ID, 'device_token', $device);
            update_user_meta($user->ID, 'social_type', 'apple');
            update_user_meta($user->ID, 'apple_sub', $sub);
        }

        $auth_response = _vogo_auth_response($user, 'apple', $sub, false);
        $auth_response['debug'] = $debug;

        make_pretty_username_from_apple($user, $payload, $email_in, $p['full_name'] ?? null);
        

        return $auth_response;
    } catch (Throwable $e) {
        return [
            'success' => false,
            'error'   => 'Exception: ' . $e->getMessage(),
            'trace'   => $e->getTraceAsString()
        ];
    }
}

function make_pretty_username_from_apple(WP_User $user, array $payload = [], $email_hint = null, $full_name = null){
  global $wpdb;
  $apple_email = sanitize_email($payload['email'] ?? $email_hint ?? '');
  $is_private  = isset($payload['is_private_email'])
                   ? (bool)$payload['is_private_email']
                   : (bool)preg_match('/@privaterelay\.appleid\.com$/i', $apple_email);
  $sub   = (string)($payload['sub'] ?? get_user_meta($user->ID,'apple_sub',true));
  $fn    = trim((string)($payload['given_name']  ?? $payload['firstName']  ?? ''));
  $ln    = trim((string)($payload['family_name'] ?? $payload['lastName']   ?? ''));
  $name  = $full_name ?: trim("$fn $ln");
  $base  = $name ? preg_replace('~[^a-z0-9]+~i','',$name)
                 : ($apple_email ? preg_replace('~[^a-z0-9]+~i','',strstr($apple_email,'@',true))
                                  : 'apple_'.substr($sub?:$user->ID,0,8));
  $pretty = sanitize_user(strtolower($base), true) ?: 'apple_'.substr(md5($user->ID),0,8);

  // nicename unic
  $slug=$pretty; $i=0; while(($u=get_user_by('slug',$slug)) && $u->ID!=$user->ID){ $slug=$pretty.(++$i); }
  $wpdb->update($wpdb->users, ['user_nicename'=>$slug], ['ID'=>$user->ID]);

  if($name) wp_update_user(['ID'=>$user->ID,'display_name'=>$name]);
  update_user_meta($user->ID,'nickname',$pretty);
  if($fn) update_user_meta($user->ID,'first_name',$fn);
  if($ln) update_user_meta($user->ID,'last_name',$ln);

  update_user_meta($user->ID,'apple_is_private_email', $is_private?'1':'0');
  if($apple_email && !$is_private && $user->user_email !== $apple_email){
    wp_update_user(['ID'=>$user->ID,'user_email'=>$apple_email]);
    update_user_meta($user->ID,'billing_email',$apple_email);
  } elseif($is_private && $email_hint && $email_hint !== $user->user_email){
    update_user_meta($user->ID,'profile_email',$email_hint); // doar informativ
  }
}

function setup_role_at_register($p_user)
{
$user = $p_user;
$uri = $_SERVER['REQUEST_URI'] ?? '';
if (preg_match('~/(vendor|client|transporter)\b~', $uri, $m)) {
    switch ($m[1]) {
        case 'vendor':
            woo_grant_role((int)$user->ID, 'provider');
            break;
        case 'client':
            woo_grant_role((int)$user->ID, 'customer');
            break;
        case 'transporter':
            woo_grant_role((int)$user->ID, 'transporter');
            break;
    }
}
}
