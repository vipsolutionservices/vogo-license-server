<?php
$MODULE_PHP='order-providers.php';

/*
daca tip livrare=DIRECT:
STATUS TRANSPORTES TRIPS - pastrate in WP_ORDERS.STATUS:
READY = disponilbila; 
ACCEPTED - luata de un transporter , 
STARTED - imediat ce incepe sa se comunice prima modificare de locatie de catre masina transporter, distangta<=100 m de la start location
IN_PROGRESS - miscarile urmatoare pana la comming soon, didtanta > 100 m de la start si >100 pana la end
COMMING_SOON - cand se apropie la 500 m or less, distangta<=500 m de la end location
ARRIVED - cand a ajuns in locatie , distanta <=50 m de end locatie
DELIVERED cand a predat coletul sau pasagerul, 
REJECTED - daca clientul a refuzat coletul
CLOSED dupa delivered, 
CANCELLED anulata de client


daca tip livrare=CURIER
READY = disponilbila; 
ACCEPTED - confirmata/preluata -/orders-provider/order_set_status_accepted - 
           param: vendor id from jwt = check security, order_id - check to be in status READY, vendor_notes
STARTED - in lucru, se impacheteaza> order_set_status_started; jwt = check security, order_id - check to be in status ACCEPTED or READY, vendor_notes - se actualizeaza doar daca este not null si este diferit de ce avem deja
PACKAGED - pregatita pentru preluare de catre curier
    order_set_status_PACKAGED; jwt = check security, order_id - check to be in status ACCEPTED,READY or STARTED, vendor_notes - se actualizeaza doar daca este not null si este diferit de ce avem deja
CURIER - a fost preluata de curier
    order_set_status_curier; jwt = check security, order_id - check to be in status ACCEPTED,READY, STARTED, PACKAGED; vendor_notes - se actualizeaza doar daca este not null si este diferit de ce avem deja
DIRECT - transportator direct - livrari in aceasi zi
    order_set_status_direct; jwt = check security, order_id - check to be in status ACCEPTED,READY, STARTED, PACKAGED; vendor_notes - se actualizeaza doar daca este not null si este diferit de ce avem deja
        

DELIVERED cand a predat coletul sau pasagerul, 
    order_set_status_delivered; no status check;
REJECTED - daca clientul a refuzat coletul
    order_set_status_rejected; no status check; param: order_id,vendor_notes and customer_notes. insert also in wp_order_transporter_rejects - transporter_id = null
CLIENT_NOT_FOUND - daca nu este in locatie
    order_set_status_client_not_found; no status check; param: order_id,vendor_notes and customer_notes. insert also in wp_order_transporter_rejects - transporter_id = null
ADDRESS_NOT_FOUND - daca nu s-a gasit adresa
    order_set_status_address_not_found; no status check; param: order_id,vendor_notes and customer_notes. insert also in wp_order_transporter_rejects - transporter_id = null
CLOSED dupa delivered, 
    order_set_status_closed; no status check;
CANCELLED anulata de client
    order_set_status_cancelled; no status check; param: order_id,vendor_notes and customer_notes. insert also in wp_order_transporter_rejects - transporter_id = null

*/
/**
 * VOGO PROVIDERS - ORDERS management
 */

add_action('rest_api_init', function(){

    // GET ORDERS
    register_rest_route('vogo/v1','/orders-provider/order-list',[
        'methods'=>'POST','callback'=>'custom_order_list','permission_callback'=>'vogo_permission_check'
    ]);

  register_rest_route('vogo/v1','/orders-provider/order-details',[
    'methods'  => 'POST',
    'callback' => 'orders_provider_order_details',
    'permission_callback' => 'vogo_permission_check'
  ]);    

  register_rest_route('vogo/v1','/orders-provider/order_set_status_accepted',[
    'methods'  => 'POST',
    'callback' => 'order_set_status_accepted',
    'permission_callback' => 'vogo_permission_check'
  ]);    

  register_rest_route('vogo/v1','/orders-provider/order_set_status_started',[
    'methods'=>'POST','callback'=>'order_set_status_started','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_PACKAGED',[
    'methods'=>'POST','callback'=>'order_set_status_PACKAGED','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_curier',[
    'methods'=>'POST','callback'=>'order_set_status_curier','permission_callback'=>'vogo_permission_check'
  ]);  

  register_rest_route('vogo/v1','/orders-provider/order_set_status_direct',[
    'methods'=>'POST',
    'callback'=>'order_set_status_direct',
    'permission_callback'=>'vogo_permission_check'
  ]);  

  register_rest_route('vogo/v1','/orders-provider/order_set_status_delivered',[
    'methods'=>'POST','callback'=>'order_set_status_delivered','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_rejected',[
    'methods'=>'POST','callback'=>'order_set_status_rejected','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_client_not_found',[
    'methods'=>'POST','callback'=>'order_set_status_client_not_found','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_address_not_found',[
    'methods'=>'POST','callback'=>'order_set_status_address_not_found','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_closed',[
    'methods'=>'POST','callback'=>'order_set_status_closed','permission_callback'=>'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1','/orders-provider/order_set_status_cancelled',[
    'methods'=>'POST','callback'=>'order_set_status_cancelled','permission_callback'=>'vogo_permission_check'
  ]);  
});

function custom_order_list(WP_REST_Request $request){ 
  global $wpdb;

  $ip = $_SERVER['REMOTE_ADDR'] ?? 'NA';
  $p  = (array)$request->get_json_params();

  // [STEP 0] Auth STRICT pe JWT (fără access_token)
  $jwt = extract_user_from_jwt_token($request);
  if ($jwt instanceof WP_REST_Response) return $jwt; // propagate JWT error
  if (is_wp_error($jwt)) return ['status'=>false,'code'=>401,'message'=>$jwt->get_error_message()];
  $provider_id = (int)$jwt;

  //audit for response
  $MODULE_PHP="orders-providers.php";
  $module = $MODULE_PHP . '.custom_order_list';
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response  

  
  if ($provider_id <= 0) return ['status'=>false,'code'=>401,'message'=>'Unauthorized'];

  if (function_exists('vogo_error_log3')) vogo_error_log3('VOGO_LOG_START [STEP 0] provider_order_list START | DB: '.(defined('DB_NAME')?DB_NAME:($wpdb->dbname ?? 'n/a')).' | provider='.$provider_id.' | ip='.$ip);

  // [STEP 1] Params & guards
  $limit  = isset($p['limit'])  ? max(1, min(100, (int)$p['limit'])) : 20;
  $offset = isset($p['offset']) ? max(0, (int)$p['offset']) : 0;

  $allowed = ['READY','ACCEPTED','STARTED','PACKAGED','COURIER','DELIVERED','REJECTED','CLIENT_NOT_FOUND','ADDRESS_NOT_FOUND','CLOSED','CANCELLED'];
  $statuses = [];
  if (isset($p['status'])) {
    $statuses = is_array($p['status']) ? $p['status'] : preg_split('/\s*,\s*/', (string)$p['status']);
    $statuses = array_values(array_intersect($allowed, array_map('strtoupper', array_map('trim', $statuses))));
  }

  $from = !empty($p['from']) ? sanitize_text_field($p['from']).' 00:00:00' : null; // Y-m-d
  $to   = !empty($p['to'])   ? sanitize_text_field($p['to']).' 23:59:59' : null; // Y-m-d

  // [STEP 2] SQL
    $tbl_orders = $wpdb->prefix.'orders';
    $tbl_prov   = $wpdb->prefix.'vogo_providers';
    $tbl_uinfo  = $wpdb->prefix.'vogo_user_info'; // [ADI-ADD]

  $where = ['o.provider_id = %d'];
  $params = [$provider_id];

  if (!empty($statuses)) {
    $where[] = 'o.status IN ('.implode(',', array_fill(0, count($statuses), '%s')).')';
    $params  = array_merge($params, $statuses);
  }
  if ($from) { $where[] = 'o.created_at >= %s'; $params[] = $from; }
  if ($to)   { $where[] = 'o.created_at <= %s'; $params[] = $to; }

  $where_sql = implode(' AND ', $where);

    $sql_list = "
    SELECT 
        o.*,
        o.relevant_image AS relevant_image, -- [ADI-ADD] explicit in payload
        vp.provider_name,
        vui.client_nickname AS client_nickname  -- [ADI-ADD]
    FROM {$tbl_orders} o
    LEFT JOIN {$tbl_prov} vp  ON vp.id = o.provider_id
    LEFT JOIN {$tbl_uinfo} vui ON vui.user_id = o.client_id  -- [ADI-ADD]
    WHERE {$where_sql}
    ORDER BY COALESCE(o.modified_at, o.created_at) DESC, o.id DESC
    LIMIT %d OFFSET %d
    ";
  $params_list = array_merge($params, [$limit, $offset]);

  $sql_count = "SELECT COUNT(*) FROM {$tbl_orders} o WHERE {$where_sql}";

  $rows  = $wpdb->get_results($wpdb->prepare($sql_list,  $params_list), ARRAY_A);
  $total = (int)$wpdb->get_var($wpdb->prepare($sql_count, $params));

  // [STEP 3] Decorare: status label pentru COURIER + short description
  $label_map = [
    'READY'            => 'Disponibilă',
    'ACCEPTED'         => 'Confirmată / Preluată',
    'STARTED'          => 'În lucru (se împachetează)',
    'PACKAGED'         => 'Pregătită pentru curier',
    'COURIER'          => 'În curs de livrare',
    'DELIVERED'        => 'Livrată',
    'REJECTED'         => 'Refuzată de client',
    'CLIENT_NOT_FOUND' => 'Client negăsit la locație',
    'ADDRESS_NOT_FOUND'=> 'Adresă negăsită',
    'CLOSED'           => 'Închisă',
    'CANCELLED'        => 'Anulată de client'
  ];

  foreach ($rows as &$r){
    $st = strtoupper((string)($r['status'] ?? ''));
    $isCourier = (($r['delivery_type'] ?? '') === 'COURIER');
    $r['status_label'] = ($isCourier && isset($label_map[$st])) ? $label_map[$st] : $st;

    // === Build short description (route • km • amount)
    $pick = trim((string)($r['address_pick'] ?? ''));
    $drop = trim((string)($r['address_end']  ?? ''));
    $km   = isset($r['distance_km']) ? (float)$r['distance_km'] : null;
    $amt  = isset($r['total_amount']) ? (float)$r['total_amount'] : null;

    $route = $pick && $drop ? ($pick.' → '.$drop) : ($drop ?: $pick);
    $bits  = [];
    if ($route) $bits[] = $route;
    if ($km && $km > 0) $bits[] = rtrim(rtrim(number_format($km, 1, '.', ''), '0'), '.').' km';
    if ($amt !== null)  $bits[] = number_format($amt, 2, '.', '').' RON';

    $computed_short = implode(' • ', $bits);

    // [ADI-ADD] Prefer server value if present; else use computed and PERSIST softly
    if (empty($r['order_short_description'])) {
      $r['order_short_description'] = $computed_short;

      // [ADI-ADD] Soft persist only when empty/NULL (BC-safe, minimal write)
      if (!empty($computed_short)) {
        $upd_sql = $wpdb->prepare(
          "UPDATE {$tbl_orders} SET order_short_description=%s, modified_at=NOW(), modified_by=%d WHERE id=%d",
          $computed_short, (int)$provider_id, (int)$r['id']
        );
        if (function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $upd_sql | ip=$ip | user=$provider_id");
        $upd_res = $wpdb->query($upd_sql);
        if ($upd_res === false && function_exists('vogo_error_log3')) {
          vogo_error_log3("[WARN] persist order_short_description failed for order_id=".$r['id']." | sql_error=".$wpdb->last_error." | ip=$ip | user=$provider_id");
        }
      }
    } else {
      // server value exists; keep as-is
    }
    // notes_* sunt deja incluse prin SELECT o.*
  }
  unset($r);

  // [STEP 4] Response
  $resp = [
    'status'       => true,
    'code'         => 200,
    'module' => $module.'.TENDS4',
    'message'      => 'Orders fetched successfully',
    'provider_id'  => $provider_id,
    'count'        => count($rows),
    'total'        => $total,
    'limit'        => $limit,
    'offset'       => $offset,
    'filters'      => [
      'status' => $statuses,
      'from'   => $from,
      'to'     => $to
    ],
    'data'         => $rows
  ];

  if (function_exists('vogo_error_log3')) vogo_error_log3('[STEP 4] provider_order_list DONE | rows='.count($rows).' of total='.$total.' | provider='.$provider_id.' | ip='.$ip);
  if (function_exists('vogo_error_log3')) vogo_error_log3('VOGO_LOG_END');
  /* ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return $resp;
}



function order_set_status_accepted(WP_REST_Request $request){
  global $wpdb; $module='order-set-accepted';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'; $db = DB_NAME;

  // VOGO_LOG_START
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 0 - JWT (strict)
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id = (int)$user_or_err;
  $u = get_user_by('id',$provider_id); $ulogin = $u?($u->user_login):'unknown';

  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    

  // STEP 0.1 - Payload
  $p = (array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);

  $order_id = (int)($p['order_id'] ?? 0);
  $vendor_notes = isset($p['vendor_notes']) ? sanitize_textarea_field((string)$p['vendor_notes']) : '';

  if(!$order_id){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] Missing order_id | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400);
  }

  $module=$module.'.order:'.$order_id;

  $tbl = $wpdb->prefix.'orders';

  // STEP 2 - Read current row for guards
  $sql_sel = $wpdb->prepare("SELECT id, provider_id, status, notes_provider FROM {$tbl} WHERE id=%d",$order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_sel | IP:$ip | USER:$provider_id",$module);
  $row = $wpdb->get_row($sql_sel, ARRAY_A);

  if(!$row || (int)$row['provider_id'] !== $provider_id){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] Not found or forbidden (order/provider mismatch) | order_id=$order_id | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'-ES2','error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404);
  }

  $prev_status = strtoupper((string)$row['status']);
  if($prev_status !== 'READY'){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] Invalid state transition $prev_status -> ACCEPTED | order_id=$order_id | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'-ES3','error'=>'not_ready_status','from_status'=>$prev_status,'expected'=>'READY','user_id'=>$provider_id,'user_login'=>$ulogin],409);
  }

  // STEP 4 - Build UPDATE (conditional set of notes_provider if provided)
  $sets = ["status='ACCEPTED'","modified_at=NOW()","modified_by=%d"];
  $args = [$provider_id];

  if($vendor_notes !== ''){
    $sets[] = "notes_provider=%s";
    $args[] = $vendor_notes;
  }

  // Constrain by id + provider + current status (READY) for atomic transition
  $args[] = $order_id; $args[] = $provider_id;

  $sql_upd = $wpdb->prepare(
    "UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d AND status='READY'",
    $args
  );
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_upd | IP:$ip | USER:$provider_id",$module);

  $res = $wpdb->query($sql_upd);
  if($res === false){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 5] SQL ERROR: ".$wpdb->last_error." | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'-ES4.1','error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500);
  }

  if($wpdb->rows_affected !== 1){
    // Race condition or status changed between read & write
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 6] No row updated (race or status changed) | order_id=$order_id | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'-ES4.2','error'=>'conflict_or_already_changed','user_id'=>$provider_id,'user_login'=>$ulogin],409);
  }

  // STEP 7 - OK
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 7] Transition READY -> ACCEPTED done | order_id=$order_id | IP:$ip | USER:$provider_id",$module);
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response([
    'success'        => true,
    'module' => $module.'TEND',
    'modified_id'    => $order_id,
    'from_status'    => $prev_status,
    'to_status'      => 'ACCEPTED',
    'notes_provider' => ($vendor_notes !== '' ? $vendor_notes : ($row['notes_provider'] ?? '')),
    'user_id'        => $provider_id,
    'user_login'     => $ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] READY/ACCEPTED -> STARTED (in lucru, se impacheteaza)
   Rules:
   - JWT -> provider_id
   - order_id mandatory
   - Allowed current statuses: READY, ACCEPTED
   - vendor_notes: update only if provided AND different from current notes_provider
   =========================================================== */
function order_set_status_started(WP_REST_Request $request){
  global $wpdb; $module='order-set-started'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes=array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  if(!$order_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] order_id required | IP:$ip | USER:$provider_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    

  $tbl=$wpdb->prefix.'orders';
  $sel=$wpdb->prepare("SELECT id,provider_id,status,notes_provider FROM {$tbl} WHERE id=%d",$order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sel | IP:$ip | USER:$provider_id",$module);
  $row=$wpdb->get_row($sel,ARRAY_A);
  if(!$row || (int)$row['provider_id']!==$provider_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] not_found_or_forbidden | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404); }

  $prev=strtoupper((string)$row['status']); $allowed=['READY','ACCEPTED'];
  if(!in_array($prev,$allowed,true)){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] invalid transition $prev -> STARTED",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'invalid_from_status','from_status'=>$prev,'allowed'=>implode(',',$allowed),'user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  $sets=["status='STARTED'","modified_at=NOW()","modified_by=%d"]; $args=[ $provider_id ];
  if($vendor_notes!==null && $vendor_notes!==$row['notes_provider']){ $sets[]="notes_provider=%s"; $args[]=$vendor_notes; }
  $args[]=$order_id; $args[]=$provider_id; $in_list="'READY','ACCEPTED'";
  $upd=$wpdb->prepare("UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d AND status IN ($in_list)",$args);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $upd | IP:$ip | USER:$provider_id",$module);
  $res=$wpdb->query($upd);
  if($res===false){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 4] SQL ERROR: ".$wpdb->last_error,$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500); }
  if($wpdb->rows_affected!==1){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 5] conflict_or_already_changed",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'conflict_or_already_changed','user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 6] READY/ACCEPTED -> STARTED OK | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response(['success'=>true,'module' => $module.'TEND','modified_id'=>$order_id,'from_status'=>$prev,'to_status'=>'STARTED','notes_provider'=>($vendor_notes!==null?$vendor_notes:$row['notes_provider']),'user_id'=>$provider_id,'user_login'=>$ulogin],200);
}

/* ===========================================================
   [ADI-ADD] READY/ACCEPTED/STARTED -> PACKAGED (pregatita pt curier)
   Rules:
   - Allowed current statuses: READY, ACCEPTED, STARTED
   - vendor_notes: update only if provided AND different
   =========================================================== */
function order_set_status_PACKAGED(WP_REST_Request $request){
  global $wpdb; $module='order-set-PACKAGED'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes=array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  if(!$order_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] order_id required",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    

  $tbl=$wpdb->prefix.'orders';
  $sel=$wpdb->prepare("SELECT id,provider_id,status,notes_provider FROM {$tbl} WHERE id=%d",$order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sel | IP:$ip | USER:$provider_id",$module);
  $row=$wpdb->get_row($sel,ARRAY_A);
  if(!$row || (int)$row['provider_id']!==$provider_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] not_found_or_forbidden | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404); }

  $prev=strtoupper((string)$row['status']); $allowed=['READY','ACCEPTED','STARTED'];
  if(!in_array($prev,$allowed,true)){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] invalid transition $prev -> PACKAGED",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'invalid_from_status','from_status'=>$prev,'allowed'=>implode(',',$allowed),'user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  $sets=["status='PACKAGED'","modified_at=NOW()","modified_by=%d"]; $args=[ $provider_id ];
  if($vendor_notes!==null && $vendor_notes!==$row['notes_provider']){ $sets[]="notes_provider=%s"; $args[]=$vendor_notes; }
  $args[]=$order_id; $args[]=$provider_id; $in_list="'READY','ACCEPTED','STARTED'";
  $upd=$wpdb->prepare("UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d AND status IN ($in_list)",$args);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $upd | IP:$ip | USER:$provider_id",$module);
  $res=$wpdb->query($upd);
  if($res===false){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 4] SQL ERROR: ".$wpdb->last_error,$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500); }
  if($wpdb->rows_affected!==1){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 5] conflict_or_already_changed",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'conflict_or_already_changed','user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 6] READY/ACCEPTED/STARTED -> PACKAGED OK | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response(['success'=>true,'module' => $module.'TEND','modified_id'=>$order_id,'from_status'=>$prev,'to_status'=>'PACKAGED','notes_provider'=>($vendor_notes!==null?$vendor_notes:$row['notes_provider']),'user_id'=>$provider_id,'user_login'=>$ulogin],200);
}

/* ===========================================================
   [ADI-ADD] READY/ACCEPTED/STARTED/PACKAGED -> COURIER (preluata de curier)
   Rules:
   - Allowed current statuses: READY, ACCEPTED, STARTED, PACKAGED
   - vendor_notes: update only if provided AND different
   - (numele endpointului după cerință: curier)
   =========================================================== */
function order_set_status_curier(WP_REST_Request $request){
  global $wpdb; $module='order-set-curier'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes=array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  if(!$order_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] order_id required",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    

  $tbl=$wpdb->prefix.'orders';
  $sel=$wpdb->prepare("SELECT id,provider_id,status,notes_provider FROM {$tbl} WHERE id=%d",$order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sel | IP:$ip | USER:$provider_id",$module);
  $row=$wpdb->get_row($sel,ARRAY_A);
  if(!$row || (int)$row['provider_id']!==$provider_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] not_found_or_forbidden | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404); }

  $prev=strtoupper((string)$row['status']); $allowed=['READY','ACCEPTED','STARTED','PACKAGED'];
  if(!in_array($prev,$allowed,true)){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] invalid transition $prev -> COURIER",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'invalid_from_status','from_status'=>$prev,'allowed'=>implode(',',$allowed),'user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  $sets=["status='COURIER'","modified_at=NOW()","modified_by=%d"]; $args=[ $provider_id ];
  if($vendor_notes!==null && $vendor_notes!==$row['notes_provider']){ $sets[]="notes_provider=%s"; $args[]=$vendor_notes; }
  $args[]=$order_id; $args[]=$provider_id; $in_list="'READY','ACCEPTED','STARTED','PACKAGED'";
  $upd=$wpdb->prepare("UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d AND status IN ($in_list)",$args);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $upd | IP:$ip | USER:$provider_id",$module);
  $res=$wpdb->query($upd);
  if($res===false){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 4] SQL ERROR: ".$wpdb->last_error,$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500); }
  if($wpdb->rows_affected!==1){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 5] conflict_or_already_changed",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'conflict_or_already_changed','user_id'=>$provider_id,'user_login'=>$ulogin],409); }

  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 6] READY/ACCEPTED/STARTED/PACKAGED -> COURIER OK | order_id=$order_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response(['success'=>true,'module' => $module.'TEND','modified_id'=>$order_id,'from_status'=>$prev,'to_status'=>'COURIER','notes_provider'=>($vendor_notes!==null?$vendor_notes:$row['notes_provider']),'user_id'=>$provider_id,'user_login'=>$ulogin],200);
}


/* ===========================================================
   [ADI-ADD] Helper (local) – perform order update with optional notes
   Note: No status check; updates status + modified_* and notes if provided & different.
   =========================================================== */
if(!function_exists('provider_update_order_status_no_check')){
  function provider_update_order_status_no_check($provider_id,$order_id,$new_status,$vendor_notes,$customer_notes){
    global $wpdb; $tbl=$wpdb->prefix.'orders';
    // Read current for guards (provider match + compare notes)
    $row = $wpdb->get_row($wpdb->prepare(
      "SELECT id, provider_id, status, notes_provider, notes_customer FROM {$tbl} WHERE id=%d",
      $order_id
    ), ARRAY_A);
    if(!$row || (int)$row['provider_id']!== (int)$provider_id){
      return ['err'=>'not_found_or_forbidden','row'=>null];
    }
    $sets=["status=%s","modified_at=NOW()","modified_by=%d"]; $args=[ $new_status, (int)$provider_id ];
    if($vendor_notes!==null && $vendor_notes!==$row['notes_provider']){ $sets[]="notes_provider=%s"; $args[]=$vendor_notes; }
    if($customer_notes!==null && $customer_notes!==$row['notes_customer']){ $sets[]="notes_customer=%s"; $args[]=$customer_notes; }
    $args[]=$order_id; $args[]=$provider_id;
    $sql=$wpdb->prepare("UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d",$args);
    vogo_error_log3("##############SQL: $sql");
    $res=$wpdb->query($sql);
    if($res===false){ return ['err'=>'sql_error','sql'=>$sql,'sql_error'=>$wpdb->last_error]; }
    if($wpdb->rows_affected!==1){ return ['err'=>'conflict_or_already_changed']; }
    return ['ok'=>true,'prev'=>$row['status'],'row'=>$row];
  }
}

/* ===========================================================
   [ADI-ADD] DELIVERED — no status check
   Params: order_id (required), vendor_notes (opt), customer_notes (opt)
   =========================================================== */
function order_set_status_delivered(WP_REST_Request $request){
  global $wpdb; $module='order-set-delivered'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    
  
  
  $r = provider_update_order_status_no_check($provider_id,$order_id,'DELIVERED',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  vogo_error_log3("[STEP 3] Status -> DELIVERED OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'DELIVERED',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] REJECTED — no status check + insert into wp_order_transporter_rejects (transporter_id=NULL)
   Params: order_id (required), vendor_notes (opt), customer_notes (opt)
   =========================================================== */
function order_set_status_rejected(WP_REST_Request $request){
  global $wpdb; $module='order-set-rejected'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    
  
  
  $r = provider_update_order_status_no_check($provider_id,$order_id,'REJECTED',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  // Soft insert into rejects (transporter_id NULL). Schema may vary; keep minimal & soft-fail.
  $rej_tbl = $wpdb->prefix.'order_transporter_rejects';
  $sql_ins = $wpdb->prepare(
    "INSERT INTO {$rej_tbl} (order_id, transporter_id, vendor_notes, customer_notes, created_at, created_by) VALUES (%d, NULL, %s, %s, NOW(), %d)",
    $order_id, (string)($vendor_notes??''), (string)($customer_notes??''), $provider_id
  );
  vogo_error_log3("##############SQL: $sql_ins",$module);
  $ins = $wpdb->query($sql_ins);
  if($ins===false){ vogo_error_log3("[WARN] rejects insert failed: ".$wpdb->last_error,$module); } // soft-fail

  vogo_error_log3("[STEP 3] Status -> REJECTED OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'REJECTED',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] CLIENT_NOT_FOUND — no status check + insert rejects(NULL)
   =========================================================== */
function order_set_status_client_not_found(WP_REST_Request $request){
  global $wpdb; $module='order-set-client-not-found'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response      

  $r = provider_update_order_status_no_check($provider_id,$order_id,'CLIENT_NOT_FOUND',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  $rej_tbl = $wpdb->prefix.'order_transporter_rejects';
  $sql_ins = $wpdb->prepare(
    "INSERT INTO {$rej_tbl} (order_id, transporter_id, vendor_notes, customer_notes, created_at, created_by) VALUES (%d, NULL, %s, %s, NOW(), %d)",
    $order_id, (string)($vendor_notes??''), (string)($customer_notes??''), $provider_id
  );
  vogo_error_log3("##############SQL: $sql_ins",$module);
  $ins = $wpdb->query($sql_ins);
  if($ins===false){ vogo_error_log3("[WARN] rejects insert failed: ".$wpdb->last_error,$module); }

  vogo_error_log3("[STEP 3] Status -> CLIENT_NOT_FOUND OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'CLIENT_NOT_FOUND',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] ADDRESS_NOT_FOUND — no status check + insert rejects(NULL)
   =========================================================== */
function order_set_status_address_not_found(WP_REST_Request $request){
  global $wpdb; $module='order-set-address-not-found'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response      

  $r = provider_update_order_status_no_check($provider_id,$order_id,'ADDRESS_NOT_FOUND',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  $rej_tbl = $wpdb->prefix.'order_transporter_rejects';
  $sql_ins = $wpdb->prepare(
    "INSERT INTO {$rej_tbl} (order_id, transporter_id, vendor_notes, customer_notes, created_at, created_by) VALUES (%d, NULL, %s, %s, NOW(), %d)",
    $order_id, (string)($vendor_notes??''), (string)($customer_notes??''), $provider_id
  );
  vogo_error_log3("##############SQL: $sql_ins",$module);
  $ins = $wpdb->query($sql_ins);
  if($ins===false){ vogo_error_log3("[WARN] rejects insert failed: ".$wpdb->last_error,$module); }

  vogo_error_log3("[STEP 3] Status -> ADDRESS_NOT_FOUND OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'ADDRESS_NOT_FOUND',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] CLOSED — no status check (after delivered as business flow, but not enforced here)
   =========================================================== */
function order_set_status_closed(WP_REST_Request $request){
  global $wpdb; $module='order-set-closed'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response      


  $r = provider_update_order_status_no_check($provider_id,$order_id,'CLOSED',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  vogo_error_log3("[STEP 3] Status -> CLOSED OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'CLOSED',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}

/* ===========================================================
   [ADI-ADD] CANCELLED — no status check + insert rejects(NULL)
   =========================================================== */
function order_set_status_cancelled(WP_REST_Request $request){
  global $wpdb; $module='order-set-cancelled'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id=(int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  $p=(array)$request->get_json_params();
  vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id=(int)($p['order_id']??0);
  $vendor_notes = array_key_exists('vendor_notes',$p)?sanitize_textarea_field((string)$p['vendor_notes']):null;
  $customer_notes = array_key_exists('customer_notes',$p)?sanitize_textarea_field((string)$p['customer_notes']):null;
  if(!$order_id){ vogo_error_log3("[STEP 1] order_id required",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response      

  $r = provider_update_order_status_no_check($provider_id,$order_id,'CANCELLED',$vendor_notes,$customer_notes);
  if(isset($r['err'])){
    if($r['err']==='sql_error'){ vogo_error_log3("[STEP 2] SQL ERROR: ".$r['sql_error'],$module); }
    vogo_error_log3("VOGO_LOG_END",$module);
    $code = ($r['err']==='not_found_or_forbidden')?404:(($r['err']==='sql_error')?500:409);
    return new WP_REST_Response(['success'=>false,'error'=>$r['err'],'user_id'=>$provider_id,'user_login'=>$ulogin] + ($r['err']==='sql_error'?['sql_error'=>$r['sql_error']]:[]), $code);
  }

  $rej_tbl = $wpdb->prefix.'order_transporter_rejects';
  $sql_ins = $wpdb->prepare(
    "INSERT INTO {$rej_tbl} (order_id, transporter_id, vendor_notes, customer_notes, created_at, created_by) VALUES (%d, NULL, %s, %s, NOW(), %d)",
    $order_id, (string)($vendor_notes??''), (string)($customer_notes??''), $provider_id
  );
  vogo_error_log3("##############SQL: $sql_ins",$module);
  $ins = $wpdb->query($sql_ins);
  if($ins===false){ vogo_error_log3("[WARN] rejects insert failed: ".$wpdb->last_error,$module); }

  vogo_error_log3("[STEP 3] Status -> CANCELLED OK | order_id=$order_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,'modified_id'=>$order_id,'from_status'=>strtoupper($r['prev']),'to_status'=>'CANCELLED',
    'user_id'=>$provider_id,'user_login'=>$ulogin
  ],200);
}


/* ===========================================================
   [ADI-ADD] READY/ACCEPTED/STARTED/PACKAGED -> DIRECT
   Business: Transportator direct (same-day)
   Rules:
   - JWT -> provider_id (strict)
   - order_id mandatory
   - Allowed current statuses: READY, ACCEPTED, STARTED, PACKAGED
   - vendor_notes: update only if provided AND different from notes_provider
   =========================================================== */
function order_set_status_direct(WP_REST_Request $request){
  global $wpdb; $module='order-set-direct'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 0 - JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return $user_or_err;
  }
  $provider_id = (int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  
  // STEP 0.1 - Payload
  $p = (array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id = (int)($p['order_id'] ?? 0);
  $vendor_notes = array_key_exists('vendor_notes',$p) ? sanitize_textarea_field((string)$p['vendor_notes']) : null;
  if(!$order_id){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] order_id required | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400);
  }


    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    

  $tbl = $wpdb->prefix.'orders';

  // STEP 2 - Read row & guards
  $sql_sel = $wpdb->prepare("SELECT id, provider_id, status, notes_provider FROM {$tbl} WHERE id=%d", $order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_sel | IP:$ip | USER:$provider_id",$module);
  $row = $wpdb->get_row($sql_sel, ARRAY_A);
  if(!$row || (int)$row['provider_id'] !== $provider_id){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] not_found_or_forbidden | order_id=$order_id | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404);
  }

  $prev = strtoupper((string)$row['status']);
  $allowed = ['READY','ACCEPTED','STARTED','PACKAGED','COURIER'];
  if(!in_array($prev, $allowed, true)){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] invalid transition $prev -> DIRECT | order_id=$order_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'invalid_from_status','from_status'=>$prev,'allowed'=>implode(',',$allowed),'user_id'=>$provider_id,'user_login'=>$ulogin],409);
  }

  // STEP 4 - Build UPDATE (atomic WHERE with allowed statuses)
  $sets = ["status='DIRECT'","modified_at=NOW()","modified_by=%d"]; $args = [ $provider_id ];
  if($vendor_notes !== null && $vendor_notes !== $row['notes_provider']){ $sets[]="notes_provider=%s"; $args[]=$vendor_notes; }
  $args[] = $order_id; $args[] = $provider_id; $in_list = "'READY','ACCEPTED','STARTED','PACKAGED'";
  $sql_upd = $wpdb->prepare("UPDATE {$tbl} SET ".implode(', ',$sets)." WHERE id=%d AND provider_id=%d AND status IN ($in_list)", $args);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_upd | IP:$ip | USER:$provider_id",$module);

  $res = $wpdb->query($sql_upd);
  if($res === false){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 4] SQL ERROR: ".$wpdb->last_error." | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500);
  }
  if($wpdb->rows_affected !== 1){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 5] conflict_or_already_changed | order_id=$order_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'conflict_or_already_changed','user_id'=>$provider_id,'user_login'=>$ulogin],409);
  }

  // STEP 6 - OK
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 6] READY/ACCEPTED/STARTED/PACKAGED -> DIRECT OK | order_id=$order_id",$module);
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response([
    'success'=>true,
    
    'modified_id'=>$order_id,
    'from_status'=>$prev,
    'to_status'=>'DIRECT',
    'notes_provider'=>($vendor_notes!==null ? $vendor_notes : ($row['notes_provider'] ?? '')),
    'user_id'=>$provider_id,
    'user_login'=>$ulogin
  ],200);
}


/**
 * [ADI-ADD] Get full order details (header + lines) for a provider (JWT).
 * Security:
 *  - Extract provider_id from JWT (no access_token accepted).
 *  - Order must belong to the same provider_id.
 *
 * BC-GUARD:
 *  - No schema changes. Read-only endpoint.
 *  - Returns: { order: o.*, lines: [...], lines_count, user_id, user_login }
 */
function orders_provider_order_details(WP_REST_Request $request){
  global $wpdb; $module='order-details'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 0 - JWT strict
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ if(function_exists('vogo_error_log3')) vogo_error_log3("[$module] JWT failed | IP:$ip",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $provider_id = (int)$user_or_err; $u=get_user_by('id',$provider_id); $ulogin=$u?($u->user_login):'unknown';

  //audit for response
  $MODULE_PHP="orders-providers.php";
  $module = $MODULE_PHP . '.orders_provider_order_details';
  $jwt_user_id   = (int)$provider_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    

  // STEP 0.1 - Payload
  $p = (array)$request->get_json_params();
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:$provider_id",$module);
  $order_id = (int)($p['order_id'] ?? 0);
  if(!$order_id){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 1] order_id required | IP:$ip | USER:$provider_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'order_id required','user_id'=>$provider_id,'user_login'=>$ulogin],400); }

  $module=$module.'.order:'.$order_id;
  // STEP 2 - Read order header with provider guard
  $tbl_orders = $wpdb->prefix.'orders';
  $sql_order  = $wpdb->prepare("SELECT o.* FROM {$tbl_orders} o WHERE o.id=%d AND o.provider_id=%d", $order_id, $provider_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_order | IP:$ip | USER:$provider_id",$module);
  $order = $wpdb->get_row($sql_order, ARRAY_A);
  if($order===null){ // SQL error check
    if($wpdb->last_error){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] SQL ERROR: ".$wpdb->last_error." | IP:$ip | USER:$provider_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'module' => $module.'-ES2','error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500); }
  }
  if(!$order){ if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 2] not_found_or_forbidden | order_id=$order_id | provider=$provider_id",$module); if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'module' => $module.'-ES3','error'=>'not_found_or_forbidden','user_id'=>$provider_id,'user_login'=>$ulogin],404); }

  // STEP 3 - Read order lines
  $tbl_lines = $wpdb->prefix.'orders_lines';
  $sql_lines = $wpdb->prepare("SELECT * FROM {$tbl_lines} WHERE order_id=%d ORDER BY id ASC", $order_id);
  if(function_exists('vogo_error_log3')) vogo_error_log3("##############SQL: $sql_lines | IP:$ip | USER:$provider_id",$module);
  $lines = $wpdb->get_results($sql_lines, ARRAY_A);
  if($lines===null && $wpdb->last_error){
    if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 3] SQL ERROR: ".$wpdb->last_error." | IP:$ip | USER:$provider_id",$module);
    if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'error'=>'sql_error','module' => $module.'-ES3.3','sql_error'=>$wpdb->last_error,'user_id'=>$provider_id,'user_login'=>$ulogin],500);
  }

  // STEP 4 - Response
  $resp = [
    'success'      => true,
    'module' => $module.'.TEND',
    'order_id'     => (int)$order_id,
    'order'        => $order,          // full o.*
    'lines'        => $lines ?: [],    // array of items
    'lines_count'  => $lines ? count($lines) : 0,
    'user_id'      => $provider_id,
    'user_login'   => $ulogin
  ];
  if(function_exists('vogo_error_log3')) vogo_error_log3("[STEP 4] order-details DONE | lines=".$resp['lines_count']." | order_id=$order_id | provider=$provider_id",$module);
  if(function_exists('vogo_error_log3')) vogo_error_log3("VOGO_LOG_END",$module);
  return new WP_REST_Response($resp, 200);
}