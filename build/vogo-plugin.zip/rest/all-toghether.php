<?php



























function get_available_shipping_methods($order) {
    vogo_error_log2('STEP 1: get_available_shipping_methods() started');

    // STEP 2: Check if cart is available and not empty
    if (!WC()->cart || !WC()->cart->get_cart_contents_count()) {
        vogo_error_log2('STEP 2: Cart not available or empty');
        return [];
    }

    // STEP 3: Get shipping packages from WooCommerce cart
    $packages = WC()->cart->get_shipping_packages();
    vogo_error_log2('STEP 3: Retrieved shipping packages: ' . count($packages));

    // STEP 4: Calculate shipping for packages
    $calculated_packages = WC()->shipping()->calculate_shipping($packages);
    vogo_error_log2('STEP 4: Shipping calculation done');

    // STEP 5: Extract available shipping rates from packages
    $shipping_methods = [];
    foreach ($calculated_packages as $package_index => $package) {
        if (!empty($package['rates'])) {
            foreach ($package['rates'] as $rate) {
                $shipping_methods[] = [
                    'id'    => $rate->get_id(),
                    'label' => $rate->get_label(),
                    'cost'  => floatval($rate->get_cost())
                ];
                vogo_error_log2("STEP 5: Shipping method found - {$rate->get_id()} ({$rate->get_label()}), Cost: {$rate->get_cost()}");
            }
        } else {
            vogo_error_log2("STEP 5: No shipping rates found for package index $package_index");
        }
    }

    // STEP 6: Return list of available shipping methods
    return $shipping_methods;
}





?>
