<?php
/**
 * VOGO API Endpoint Registration
 * All routes use standard JWT security check: vogo_permission_check
 * Adi-tehnic: clean, organized, secure, ergonomic structure.
 */

//use Twilio\Rest\Client;

add_action('rest_api_init', function () {

    // 🔐 Authentication Endpoints
    register_rest_route('vogo/v1', '/login', [
        'methods'             => 'POST',
        'callback'            => 'custom_login',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/mobile-auth', [
        'methods'             => 'POST',
        'callback'            => 'custom_mobile_auth',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/SignUp', [
        'methods'             => 'POST',
        'callback'            => 'custom_register',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/forgot', [
        'methods'             => 'POST',
        'callback'            => 'custom_forgot',
        'permission_callback' => 'vogo_permission_check',
    ]);

    // 👤 Profile Endpoint
    register_rest_route('vogo/v1', '/view-profile', [
        'methods'             => 'GET',
        'callback'            => 'custom_view_profile',
        'permission_callback' => 'vogo_permission_check',
    ]);

    // 🚪 Logout Endpoint
    register_rest_route('vogo/v1', '/logout', [
        'methods'             => 'GET',
        'callback'            => 'custom_logout',
        'permission_callback' => 'vogo_permission_check',
    ]);

});

/**
 * Custom login function for mobile clients
 *
 * @return array JSON response
 */
function custom_login() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $email    = sanitize_text_field($data['email'] ?? '');
    $password = sanitize_text_field($data['password'] ?? '');
    $remember = !empty($data['rememberme']) ? (bool)$data['rememberme'] : false;
    $device_token = sanitize_text_field($data['device_token'] ?? '');

    vogo_error_log2("STEP 1: custom_login called with email={$email}");

    if (empty($email) || empty($password)) {
        vogo_error_log2("STEP 2: Missing email or password");
        return [
            'status'  => false,
            'message' => 'Email and password are required.'
        ];
    }

    try {
        $creds = [
            'user_login'    => $email,
            'user_password' => $password,
            'remember'      => $remember
        ];

        $user = wp_signon($creds, is_ssl());

        if (is_wp_error($user)) {
            vogo_error_log2("STEP 3: Login failed - " . $user->get_error_message());
            return [
                'status'  => false,
                'message' => strip_tags($user->get_error_message())
            ];
        }

        update_user_meta($user->ID, 'device_token', $device_token);

        vogo_error_log2("STEP 4: Login successful for user_id={$user->ID}");

        return [
            'status'  => true,
            'message' => 'Login successful.',
            'data'    => [
                'id'       => (string)$user->ID,
                'username' => $user->user_login,
                'email'    => $user->user_email
            ]
        ];

    } catch (\Throwable $e) {
        vogo_error_log2("STEP 5: Exception - " . $e->getMessage());
        return [
            'status'  => false,
            'message' => 'Server error. Please try again later.',
            'error'   => $e->getMessage()
        ];
    }
}

/**
 * Handle mobile OTP-based authentication (send and verify OTP).
 *
 * @return array JSON response with status, message, and optional user data.
 */
function custom_mobile_auth() {
    // STEP 1: Extract JSON input
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    // STEP 2: Sanitize input fields
    $mobile = isset($data['mobile']) ? sanitize_text_field($data['mobile']) : '';
    $otp    = isset($data['otp']) ? sanitize_text_field($data['otp']) : '';
    $action = isset($data['action']) ? sanitize_text_field($data['action']) : 'send_otp';

    // STEP 3: Validate mobile format (E.164)
    if (empty($mobile) || !preg_match('/^\+[1-9]\d{1,14}$/', $mobile)) {
        vogo_error_log2("STEP 3: Invalid mobile format: {$mobile}");
        return [
            'status'  => false,
            'code'    => 400,
            'message' => 'Valid mobile number in E.164 format (e.g., +1234567890) is required',
        ];
    }

    // STEP 4: Initialize Twilio client
    $twilio = new Client(get_option('twilio_account_sid'), get_option('twilio_auth_token'));
    $twilio_phone_number = get_option('twilio_phone_number');

    // STEP 5: Handle OTP sending
    if ($action === 'send_otp') {
        $otp = generate_otp();
        vogo_error_log2("STEP 5: Generated OTP: {$otp}");

        // STEP 6: Check if user exists by mobile
        $users = get_users([
            'meta_key'   => 'auth_mobile_number',
            'meta_value' => $mobile,
            'number'     => 1,
        ]);

        // STEP 7: Create new user if not found
        if (empty($users)) {
            $username = 'user_' . wp_generate_uuid4();
            $email    = 'user_' . wp_generate_uuid4() . '@vogofamily.local';
            $password = wp_generate_password(12, true);
            $user_id  = wp_create_user($username, $password, $email);

            if (is_wp_error($user_id)) {
                vogo_error_log2("STEP 7: Failed to create user: " . $user_id->get_error_message());
                return [
                    'status'  => false,
                    'code'    => 500,
                    'message' => 'Failed to create user: ' . $user_id->get_error_message(),
                ];
            }

            update_user_meta($user_id, 'auth_mobile_number', $mobile);
            update_user_meta($user_id, 'auth_otp', $otp);
            vogo_error_log2("STEP 7: New user created with ID: {$user_id}");
        } else {
            $user = $users[0];
            update_user_meta($user->ID, 'auth_otp', $otp);
            vogo_error_log2("STEP 7: OTP updated for user ID: {$user->ID}");
        }

        // STEP 8: Send SMS via Twilio
        try {
            $twilio->messages->create($mobile, [
                'from' => $twilio_phone_number,
                'body' => 'Your VogoFamily OTP is: ' . $otp,
            ]);
            vogo_error_log2("STEP 8: OTP SMS sent to {$mobile}");
            return [
                'status'  => true,
                'code'    => 200,
                'message' => 'OTP sent to mobile number.',
            ];
        } catch (Exception $e) {
            vogo_error_log2("STEP 8: Failed to send OTP via Twilio: " . $e->getMessage());
            return [
                'status'  => false,
                'code'    => 500,
                'message' => 'Failed to send OTP: ' . $e->getMessage(),
            ];
        }

    // STEP 9: Handle OTP verification
    } elseif ($action === 'verify_otp') {
        if (empty($otp)) {
            return [
                'status'  => false,
                'code'    => 400,
                'message' => 'OTP is required',
            ];
        }

        $users = get_users([
            'meta_key'   => 'auth_mobile_number',
            'meta_value' => $mobile,
            'number'     => 1,
        ]);

        if (empty($users)) {
            vogo_error_log2("STEP 9: No user found with mobile: {$mobile}");
            return [
                'status'  => false,
                'code'    => 404,
                'message' => 'No user found with this mobile number',
            ];
        }

        $user       = $users[0];
        $stored_otp = get_user_meta($user->ID, 'auth_otp', true);

        if ($otp === $stored_otp) {
            wp_set_current_user($user->ID);
            wp_set_auth_cookie($user->ID, true);
            delete_user_meta($user->ID, 'auth_otp');
            vogo_error_log2("STEP 9: User authenticated: {$user->ID}");

            return [
                'status'  => true,
                'code'    => 200,
                'message' => 'User logged in successfully.',
                'data'    => ['id' => $user->ID],
            ];
        } else {
            vogo_error_log2("STEP 9: Invalid OTP for user ID: {$user->ID}");
            return [
                'status'  => false,
                'code'    => 400,
                'message' => 'Invalid OTP',
            ];
        }
    }

    // STEP 10: Invalid action fallback
    return [
        'status'  => false,
        'code'    => 400,
        'message' => 'Invalid action (use send_otp or verify_otp)',
    ];
}

/**
 * Custom registration for mobile clients
 *
 * @return array JSON response
 */
function custom_register() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $email         = sanitize_email($data['email'] ?? '');
    $password      = sanitize_text_field($data['password'] ?? '');
    $referral_code = sanitize_text_field($data['referral_code'] ?? '');
    $device_token  = sanitize_text_field($data['device_token'] ?? '');

    vogo_error_log2("STEP 1: custom_register called with email={$email}");

    if (empty($email) || empty($password) || empty($referral_code) || empty($device_token)) {
        vogo_error_log2("STEP 2: Missing required fields");
        return [
            'status'  => false,
            'message' => 'All fields are required: email, password, referral code, device token.'
        ];
    }

    try {
        // STEP 3: Check if email already exists
        if (email_exists($email)) {
            vogo_error_log2("STEP 3: Email already exists - {$email}");
            return [
                'status'  => false,
                'message' => 'This email address is already registered.'
            ];
        }

        // STEP 4: Prepare new user data
        $username = explode('@', $email)[0];
        $userdata = [
            'user_login' => $username,
            'user_pass'  => $password,
            'user_email' => $email
        ];

        // STEP 5: Insert user
        $new_customer = wp_insert_user($userdata);

        if (is_wp_error($new_customer)) {
            $error_codes = $new_customer->get_error_codes();

            vogo_error_log2("STEP 5: wp_insert_user error - " . json_encode($error_codes));

            if (in_array('empty_user_login', $error_codes)) {
                $message = $new_customer->get_error_message('empty_user_login');
            } elseif (in_array('existing_user_email', $error_codes)) {
                $message = 'This email address is already registered.';
            } elseif (in_array('existing_user_login', $error_codes)) {
                $message = 'This username is already taken.';
            } else {
                $message = 'Registration failed. Please try again.';
            }

            return [
                'status'  => false,
                'message' => $message
            ];
        }

        // STEP 6: Post-registration actions
        $user = get_user_by('id', $new_customer);
        update_user_meta($user->ID, 'device_token', $device_token);

        vogo_error_log2("STEP 6: Registration successful for user_id={$user->ID}");

        return [
            'status'  => true,
            'message' => 'Registration successful.',
            'data'    => [
                'token'     => (string)$user->ID,
                'user_id'   => $user->ID,
                'user_name' => $user->user_login,
                'email'     => $user->user_email
            ]
        ];

    } catch (\Throwable $e) {
        vogo_error_log2("STEP 7: Exception - " . $e->getMessage());
        return [
            'status'  => false,
            'message' => 'Server error. Please try again.',
            'error'   => $e->getMessage()
        ];
    }
}

/**
 * Sends WooCommerce reset password email to user based on email or username
 *
 * @return array JSON response
 */
function custom_forgot() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $email_or_username = sanitize_text_field($data['email'] ?? '');
    vogo_error_log2("STEP 1: custom_forgot called with input={$email_or_username}");

    if (empty($email_or_username)) {
        return [
            'status'  => false,
            'message' => 'Email or username is required.'
        ];
    }

    try {
        $user_id = email_exists($email_or_username);
        if (!$user_id) {
            $user_id = username_exists($email_or_username);
        }

        if (!$user_id) {
            vogo_error_log2("STEP 2: No user found for identifier={$email_or_username}");
            return [
                'status'  => false,
                'message' => 'User does not exist.'
            ];
        }

        $user = new WP_User((int)$user_id);
        $reset_key = get_password_reset_key($user);

        if (is_wp_error($reset_key)) {
            vogo_error_log2("STEP 3: Error generating reset key: " . $reset_key->get_error_message());
            return [
                'status'  => false,
                'message' => 'Failed to generate reset key.'
            ];
        }

        $wc_emails = WC()->mailer()->get_emails();
        $wc_emails['WC_Email_Customer_Reset_Password']->trigger($user->user_login, $reset_key);

        vogo_error_log2("STEP 4: Password reset email sent to {$user->user_email}");

        return [
            'status'  => true,
            'message' => 'An email has been sent with the password reset link. Please check your inbox.',
            'data'    => [
                'token'     => (string)$user_id,
                'user_name' => $user->user_login,
                'email'     => $user->user_email
            ]
        ];

    } catch (\Throwable $e) {
        vogo_error_log2("STEP 5: Exception - " . $e->getMessage());
        return [
            'status'  => false,
            'message' => 'Server error. Please try again later.',
            'error'   => $e->getMessage()
        ];
    }
}

/**
 * Fetches WooCommerce user profile data (billing, shipping, and image)
 *
 * @return array JSON response
 */
function custom_view_profile() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id = isset($data['access_token']) ? $data['access_token'] : null;
    vogo_error_log2("STEP 1: custom_view_profile called for user_id={$user_id}");

    if (empty($user_id)) {
        return [
            'status'  => false,
            'message' => 'Invalid user ID.'
        ];
    }

    try {
        $customer = new WC_Customer($user_id);

        if (!$customer || !is_a($customer, 'WC_Customer')) {
            vogo_error_log2("STEP 2: WC_Customer not found for ID {$user_id}");
            return [
                'status'  => false,
                'message' => 'Invalid user.'
            ];
        }

        // STEP 3: Basic user info
        $profile = [
            'id'           => $user_id,
            'username'     => $customer->get_username(),
            'email'        => $customer->get_email(),
            'first_name'   => $customer->get_first_name(),
            'last_name'    => $customer->get_last_name(),
            'display_name' => $customer->get_display_name()
        ];

        // STEP 4: Profile image from user meta
        $user_image_id = get_user_meta($user_id, 'profile_image', true);
        $profile['profile_image'] = $user_image_id ? wp_get_attachment_url($user_image_id) : '';

        // STEP 5: Billing & shipping addresses
        $profile['billing'] = [
            'first_name'     => $customer->get_billing_first_name(),
            'last_name'      => $customer->get_billing_last_name(),
            'company'        => $customer->get_billing_company(),
            'address_1'      => $customer->get_billing_address_1(),
            'address_2'      => $customer->get_billing_address_2(),
            'city'           => $customer->get_billing_city(),
            'state'          => $customer->get_billing_state(),
            'postcode'       => $customer->get_billing_postcode(),
            'country'        => $customer->get_billing_country()
        ];

        $profile['shipping'] = [
            'first_name'     => $customer->get_shipping_first_name(),
            'last_name'      => $customer->get_shipping_last_name(),
            'company'        => $customer->get_shipping_company(),
            'address_1'      => $customer->get_shipping_address_1(),
            'address_2'      => $customer->get_shipping_address_2(),
            'city'           => $customer->get_shipping_city(),
            'state'          => $customer->get_shipping_state(),
            'postcode'       => $customer->get_shipping_postcode(),
            'country'        => $customer->get_shipping_country()
        ];

        vogo_error_log2("STEP 6: Profile data fetched successfully for user_id={$user_id}");

        return [
            'status'  => true,
            'message' => 'User information fetched successfully.',
            'data'    => $profile
        ];

    } catch (\Throwable $e) {
        vogo_error_log2("STEP 7: Exception - " . $e->getMessage());
        return [
            'status'  => false,
            'message' => 'Server error. Please try again later.',
            'error'   => $e->getMessage()
        ];
    }
}

/**
 * Logs out a user by clearing session and user-specific meta
 *
 * @return array JSON response
 */
function custom_logout() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id = isset($data['access_token']) ? intval($data['access_token']) : null;

    vogo_error_log2("STEP 1: Logout request received for user_id: {$user_id}");

    if (empty($user_id) || $user_id <= 0) {
        vogo_error_log2("STEP 2: Missing or invalid access_token (user ID)");
        return [
            'status'  => false,
            'code'    => 400,
            'message' => 'Access token (user ID) is missing or invalid.'
        ];
    }

    try {
        $user = get_user_by('id', $user_id);
        if (!is_a($user, 'WP_User')) {
            vogo_error_log2("STEP 3: No valid user found for ID {$user_id}");
            return [
                'status'  => false,
                'code'    => 400,
                'message' => 'Invalid user ID.'
            ];
        }

        wp_set_current_user($user->ID);

        delete_user_meta($user_id, 'applied_coupons');
        delete_user_meta($user_id, 'device_token');

        wp_destroy_current_session();
        wp_clear_auth_cookie();

        vogo_error_log2("STEP 4: User {$user_id} logged out successfully");
        return [
            'status'  => true,
            'code'    => 200,
            'message' => 'User logged out successfully.'
        ];
    } catch (\Throwable $e) {
        vogo_error_log2("STEP 5: Exception during logout - " . $e->getMessage());
        return [
            'status'  => false,
            'code'    => 500,
            'message' => 'Logout failed: ' . $e->getMessage()
        ];
    }
}

/**
 * Generate a 6-digit OTP code.
 *
 * @return string A zero-padded 6-digit numeric OTP.
 */
function generate_otp() {
    // STEP 1: Generate random number between 0 and 999999
    $otp = mt_rand(0, 999999);

    // STEP 2: Pad number with leading zeros to ensure 6 digits
    return str_pad($otp, 6, '0', STR_PAD_LEFT);
}

/**
 * Deletes the user account along with related meta
 *
 * @return array JSON response
 */
function custom_delete_user_account() {
    $data = json_decode(file_get_contents('php://input'), true);
    if (empty($data)) {
        $data = $_REQUEST;
    }

    $user_id = isset($data['access_token']) ? intval($data['access_token']) : null;

    vogo_error_log2("STEP 1: User deletion request received for user_id: {$user_id}");

    if (empty($user_id) || $user_id <= 0) {
        vogo_error_log2("STEP 2: Invalid or missing user ID");
        return [
            'status'  => false,
            'code'    => 400,
            'message' => 'Invalid User.'
        ];
    }

    $user = get_user_by('id', $user_id);
    if (!is_a($user, 'WP_User')) {
        vogo_error_log2("STEP 3: No valid user found with ID {$user_id}");
        return [
            'status'  => false,
            'code'    => 400,
            'message' => 'User not found.'
        ];
    }

    require_once(ABSPATH . 'wp-admin/includes/user.php');

    delete_user_meta($user_id, 'applied_coupons');
    delete_user_meta($user_id, 'device_token');

    $deleted = wp_delete_user($user_id);

    if ($deleted) {
        vogo_error_log2("STEP 4: User ID {$user_id} successfully deleted");
        return [
            'status'  => true,
            'code'    => 200,
            'message' => 'User account deleted successfully.'
        ];
    } else {
        vogo_error_log2("STEP 5: wp_delete_user() failed for user ID {$user_id}");
        return [
            'status'  => false,
            'code'    => 500,
            'message' => 'Failed to delete user account.'
        ];
    }
}



