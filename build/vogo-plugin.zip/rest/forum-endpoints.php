<?php
$MODULE_PHP='forum-endpoints.php';

clear_debug_log_file();

add_action('rest_api_init', function () {
//get documents
register_rest_route('vogo/v1', '/get-vogo-documents', [
  'methods'             => 'POST',
  'callback'            => 'get_vogo_documents',
  'permission_callback' => 'vogo_permission_check'
]);    
//upload documents
register_rest_route('vogo/v1', '/upload-document/(?P<module>[a-zA-Z0-9_-]+)/(?P<submodule>[a-zA-Z0-9_-]+)/(?P<reference_id>\d+)', [
    'methods'             => 'POST',
    'callback'            => 'vogo_upload_document',
    'permission_callback' => 'vogo_permission_check'
]); 
//edit answer
register_rest_route('vogo/v1', '/forum-chat/edit_or_hide_forum_post_answer_reply_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_edit_or_hide_forum_post_answer_reply_by_id',
  'permission_callback' => 'vogo_permission_check'
]);
//post edit
register_rest_route('vogo/v1/forum', '/edit_forum_discussion_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_edit_forum_discussion_by_id_forum',
  'permission_callback' => 'vogo_permission_check'
]);
//post hide
register_rest_route('vogo/v1/forum-chat', '/hide_forum_discussion_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_hide_forum_discussion_by_id',
  'permission_callback' => 'vogo_permission_check'
]);
//answer edit
register_rest_route('vogo/v1', '/forum-chat/edit_or_hide_forum_post_answer_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_edit_or_hide_forum_post_answer_by_id',
  'permission_callback' => 'vogo_permission_check'
]);
//forum post get one
register_rest_route('vogo/v1', '/forum/get_forum_discussion_by_id', [
  'methods' => 'POST',
  'callback' => 'vogo_get_forum_discussion_by_id_forum',
  'permission_callback' => 'vogo_permission_check'
]);    
//forum post get all
register_rest_route('vogo/v1', '/forum-chat/get_forum_discussions', [
  'methods' => 'POST',
  'callback' => 'vogo_get_forum_discussions',
  'permission_callback' => 'vogo_permission_check'
]);    
//forum post add
    register_rest_route('vogo/v1', '/forum-chat/forum_post', [
        'methods' => 'POST',
        'callback' => 'vogo_insert_forum_post',
        'permission_callback' => 'vogo_permission_check'
    ]);    

    //forum answers - add
    register_rest_route('vogo/v1', '/forum/forum_post_answer', [
        'methods' => 'POST',
        'callback' => 'vogo_insert_forum_post_answer_forum',
        'permission_callback' => 'vogo_permission_check'
    ]);

//forum answer reply - add
    register_rest_route('vogo/v1', '/forum-chat/add_forum_post_answer_reply', [
        'methods' => 'POST',
        'callback' => 'vogo_add_forum_post_answer_reply',
        'permission_callback' => 'vogo_permission_check'
    ]);

    //forum replies - get all
    register_rest_route('vogo/v1', '/forum-chat/get_replies_by_answer_id', [
        'methods' => 'POST',
        'callback' => 'vogo_get_replies_by_answer_id',
        'permission_callback' => 'vogo_permission_check'
    ]);    

    //forum answers - get all - clonat in chat
    register_rest_route('vogo/v1', '/forum/forum_get_answers_by_post_id', [
        'methods' => 'POST',
        'callback' => 'forum_get_answers_by_post_id',
        'permission_callback' => 'vogo_permission_check'
    ]);      

    });

function vogo_get_replies_by_answer_id(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'vogo_forum_post_answer_reply';
  $ip = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id = extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data = json_decode($raw_input, true);
  $answer_id = (int)($data['answer_id'] ?? 0);
  if (!$answer_id) return new WP_REST_Response(['success' => false, 'error' => 'Missing answer_id'], 400);

  $sql = "
    SELECT *, 'REPLY' AS type
    FROM $table
    WHERE PARENT_ID_vogo_forum_post_answer = %d AND post_status = 'active'
    ORDER BY post_date ASC
  ";

  $rows = $wpdb->get_results($wpdb->prepare($sql, $answer_id), ARRAY_A);
  vogo_error_log3("##############SQL: $sql");
  vogo_error_log3("[STEP 9] Replies fetched: " . count($rows) . " | ANSWER_ID: $answer_id | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response([
    'success' => true,
    'replies' => $rows
  ], 200);
}    

function forum_get_answers_by_post_id(WP_REST_Request $request) {
  global $wpdb;

  $table_answers = $wpdb->prefix . 'vogo_forum_post_answer';
  $table_parent  = $wpdb->prefix . 'vogo_forum_post';
  $table_read    = $wpdb->prefix . 'vogo_forum_post_no_to_read';

  $ip        = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id   = (int) extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data    = json_decode($raw_input, true);
  $post_id = (int)($data['post_id'] ?? 0);

  if (!$post_id || !$user_id) {
    vogo_error_log3("[STEP 1] Missing post_id or auth | POST_ID=$post_id | USER=$user_id");
    vogo_error_log3("############ END ########################################");
    return new WP_REST_Response(['success' => false, 'error' => 'Missing post_id or auth'], 400);
  }

  // --- [STEP 1.1] Load parent thread (strict columns: post_author, chat_user_id) ---
  $parent = $wpdb->get_row(
    $wpdb->prepare("SELECT ID, post_author, chat_user_id FROM $table_parent WHERE ID = %d", $post_id),
    ARRAY_A
  );
  if (!$parent) {
    vogo_error_log3("[STEP 1.1] Thread not found | POST_ID=$post_id");
    vogo_error_log3("############ END ########################################");
    return new WP_REST_Response(['success' => false, 'error' => 'Thread not found'], 404);
  }

  $initiator_id = (int)$parent['post_author'];
  $recipient_id = (int)$parent['chat_user_id'];

  vogo_error_log3("[STEP 1.2] Participants: initiator=$initiator_id | recipient=$recipient_id | current=$user_id");

  // --- [STEP 1.3] Permission check: current must be initiator OR recipient ---
  $is_allowed = ($user_id === $initiator_id) || ($user_id === $recipient_id);
  if (!$is_allowed) {
    vogo_error_log3("[STEP 1.3] Permission denied for USER=$user_id on POST_ID=$post_id");
    vogo_error_log3("############ END ########################################");
    return new WP_REST_Response(['success' => false, 'error' => 'permission_denied'], 403);
  }

  // --- [STEP 1.4] UPSERT per-user unread counter -> set 0 for current user ---
  $upsert_sql = $wpdb->prepare(
    "INSERT INTO $table_read (post_id, user_id, nr_to_read, created_at, created_by)
     VALUES (%d, %d, 0, NOW(), %d)
     ON DUPLICATE KEY UPDATE
       nr_to_read = 0,
       updated_at = NOW(),
       updated_by = VALUES(created_by)",
    $post_id, $user_id, $user_id
  );
  vogo_error_log3("##############SQL UPSERT READ: $upsert_sql");
  $wpdb->query($upsert_sql);

  // --- [STEP 1.5] Read back current user's nr_to_read (for payload) ---
  $my_nr_to_read = $wpdb->get_var(
    $wpdb->prepare(
      "SELECT nr_to_read FROM $table_read WHERE post_id = %d AND user_id = %d LIMIT 1",
      $post_id, $user_id
    )
  );
  if ($my_nr_to_read === null) { $my_nr_to_read = 0; }
  vogo_error_log3("##############SQL NR_TO_READ: SELECT nr_to_read ... -> $my_nr_to_read");

  // --- [STEP 2] Fetch answers (unchanged) ---
  $sql = "SELECT *, 'ANSWER' AS type
            FROM $table_answers
           WHERE PARENT_ID_vogo_forum_post = %d
             AND post_status = 'active'
        ORDER BY post_date ASC";
  $sql_prepared = $wpdb->prepare($sql, $post_id);
  vogo_error_log3("##############SQL: $sql_prepared");

  $results = $wpdb->get_results($sql_prepared, ARRAY_A);

  vogo_error_log3("[STEP 9] Answers fetched: " . count($results) . " | POST_ID: $post_id | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response([
    'success'     => true,
    'answers'     => $results,
    'nr_to_read'  => (int)$my_nr_to_read,
  ], 200);
}


function vogo_insert_forum_post_answer_forum(WP_REST_Request $request) {
    global $wpdb; $active_db = DB_NAME;
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown'; $user_id = extract_user_from_jwt_token($request); if (is_wp_error($user_id)) return $user_id;
    vogo_error_log3("[STEP 1] ACTIVE DB: $active_db | IP: $ip | USER: $user_id | Start insert forum post answer");

    if (vogo_rate_limit('forum_post_answer')) {
        vogo_error_log3("[STEP 2] Rate limit exceeded | IP: $ip | USER: $user_id");
        return new WP_REST_Response(['success' => false, 'error' => 'Rate limit exceeded'], 429);
    }

    $data = $request->get_json_params();
    $parent_id = intval($data['PARENT_ID_vogo_forum_post'] ?? 0);
    $post_status = sanitize_text_field($data['post_status'] ?? 'active');
    $post_answer = sanitize_textarea_field($data['post_answer'] ?? '');
    $post_content = sanitize_textarea_field($data['post_content'] ?? '');
    $mesaj = sanitize_textarea_field($data['mesaj'] ?? '');
    $post_image = sanitize_text_field($data['post_image'] ?? '');
    $post_mime_type = sanitize_text_field($data['post_mime_type'] ?? '');
/*
    if (!vogo_valid_status($post_status)) {
        vogo_error_log3("[STEP 3] Invalid post status: $post_status | IP: $ip | USER: $user_id");
        return new WP_REST_Response(['success' => false, 'error' => 'Invalid status'], 400);
    }
*/
    $insert_data = [
        'PARENT_ID_vogo_forum_post' => $parent_id,
        'post_author' => $user_id,
        'post_answer' => $post_answer,
        'post_status' => $post_status,
        'post_content' => $post_content,
        'post_date' => current_time('mysql'),
        'mesaj' => $mesaj,
        'comment_count' => 0,
        'post_image' => $post_image,
        'post_mime_type' => $post_mime_type,
        'created_at' => current_time('mysql'),
        'created_user' => $user_id,
        'modified_at' => current_time('mysql'),
        'modified_user' => $user_id
    ];

    $insert_format = ['%d','%d','%s','%s','%s','%s','%s','%d','%s','%s','%s','%s','%d','%d'];
    $result = $wpdb->insert($wpdb->prefix.'vogo_forum_post_answer', $insert_data, $insert_format);

    if (!$result) {
        vogo_error_log3("[STEP 4] DB insert failed | Error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
        return new WP_REST_Response(['success' => false, 'data' => ['error' => 'Database insert failed', 'details' => $wpdb->last_error]], 500);
    }

//actualizam last answer datetime de pe parinte

// [STEP 5.1] Update parent thread last_answer_datetime (+ audit on parent)
$parent_table = $wpdb->prefix . 'vogo_forum_post';
$now = current_time('mysql');
$upd = $wpdb->update(
  $parent_table,
  ['last_answer_datetime' => $now, 'post_modified_date' => $now, 'post_modified_user' => $user_id],
  ['ID' => $parent_id],
  ['%s','%s','%d'],
  ['%d']
);
vogo_error_log3("##############SQL: UPDATE $parent_table SET last_answer_datetime='$now', post_modified_date='$now', post_modified_user=$user_id WHERE ID=$parent_id");

if ($upd === false) {
  vogo_error_log3("[STEP 5.2] Parent update failed | Error: {$wpdb->last_error} | parent_id=$parent_id | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'success' => false,
    'error' => 'Failed to update parent last_answer_datetime',
    'sql_error' => $wpdb->last_error
  ], 500);
}
vogo_error_log3("[STEP 5.3] Parent last_answer_datetime updated | parent_id=$parent_id | ts=$now | IP: $ip | USER: $user_id");


//end update last answer datetime

    $inserted_id = $wpdb->insert_id;
    vogo_error_log3("[STEP 5] Insert successful | New ID: $inserted_id | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success' => true, 'inserted_id' => $inserted_id], 201);
}


function vogo_edit_or_hide_forum_post_answer_by_id(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'vogo_forum_post_answer';
  $ip = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id = extract_user_from_jwt_token($request);
  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data = json_decode($raw_input, true);
  $id = (int)($data['id'] ?? 0);
  if (!$id) return new WP_REST_Response(['success' => false, 'error' => 'Missing ID'], 400);

  $fields = [];
  if (isset($data['post_answer'])) $fields['post_answer'] = sanitize_text_field($data['post_answer']);
  if (isset($data['post_content'])) $fields['post_content'] = sanitize_textarea_field($data['post_content']);
  if (isset($data['mesaj'])) $fields['mesaj'] = sanitize_text_field($data['mesaj']);
  if (isset($data['post_status'])) $fields['post_status'] = sanitize_text_field($data['post_status']);

  $fields['modified_user'] = $user_id;
  $fields['modified_at'] = current_time('mysql');

  $result = $wpdb->update($table, $fields, ['ID' => $id], null, ['%d']);
  vogo_error_log3("##############SQL: UPDATE $table SET ... WHERE ID = $id");
  vogo_error_log3("[STEP 9] Update/hide result: $result | IP: $ip | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response(['success' => $result !== false, 'modified_id' => $id], 200);
}

function vogo_upload_document(WP_REST_Request $request){
  global $wpdb; $active_db=DB_NAME; $ip=$_SERVER['REMOTE_ADDR']??'unknown';
  $user_id=extract_user_from_jwt_token($request); if(is_wp_error($user_id)) return $user_id;
  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: (multipart upload) | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: $active_db");

  // [STEP 1] Route params validation
  $module=sanitize_key($request['module']??''); $submodule=sanitize_key($request['submodule']??''); $reference_id=intval($request['reference_id']??0);
  vogo_error_log3("[STEP 1.1] Route params: module=$module, submodule=$submodule, reference_id=$reference_id | IP: $ip | USER: $user_id");

  if(!$module||!$submodule||$reference_id<=0){ vogo_error_log3("[STEP 1] Invalid route params: module=$module, submodule=$submodule, reference_id=$reference_id | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'Invalid route parameters'],400);
  }

  // [STEP 2] File presence & meta
  if(!isset($_FILES['file'])||$_FILES['file']['error']!==UPLOAD_ERR_OK){
    vogo_error_log3("[STEP 2] No file or upload error code: ".($_FILES['file']['error']??'N/A')." | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'No file uploaded or error'],400);
  }
  $file=$_FILES['file']; $original_file_name=$file['name']; $filename=sanitize_file_name($file['name']); $file_mime_type=$file['type']??''; $filesize=intval($file['size']??0);
  vogo_error_log3("[STEP 2.1] FILE meta: name=$original_file_name, type=$file_mime_type, size=$filesize | IP: $ip | USER: $user_id");

  // [STEP 3] Build target paths (unique name)
  $upload_dir=wp_upload_dir(); $basedir=trailingslashit($upload_dir['basedir']); $baseurl=trailingslashit($upload_dir['baseurl']);
  $base_dir=$basedir."vogo-documents/$module/$submodule/$user_id/"; if(!wp_mkdir_p($base_dir)){ vogo_error_log3("[STEP 3] Failed to create folder $base_dir | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Could not create folder'],500); }
  $filename=wp_unique_filename($base_dir,$filename); $server_path="vogo-documents/$module/$submodule/$user_id/$filename"; $target_path=$base_dir.$filename; $upload_url=$baseurl.$server_path;

  // [STEP 4] Move uploaded file
  if(!move_uploaded_file($file['tmp_name'],$target_path)){ vogo_error_log3("[STEP 4] File move failed to $target_path | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Upload failed'],500); }

  // [STEP 5] Insert into documents table
  $docs_table=$wpdb->prefix.'vogo_documents';
  $now=current_time('mysql');
  $ins=$wpdb->insert($docs_table,[
    'module'=>$module,'submodule'=>$submodule,'reference_id'=>$reference_id,'user_id'=>$user_id,'server_path'=>$server_path,'file_name'=>$filename,'file_type'=>$file_mime_type,'file_size'=>$filesize,'created_at'=>$now,'created_user'=>$user_id,'modified_at'=>$now,'modified_user'=>$user_id
  ],['%s','%s','%d','%d','%s','%s','%s','%d','%s','%d','%s','%d']);
  vogo_error_log3("##############SQL: INSERT INTO $docs_table (module,submodule,reference_id,...) VALUES ('$module','$submodule',$reference_id,...)");
  if(!$ins){ vogo_error_log3("[STEP 5.1] DB insert failed: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB insert failed','sql_error'=>$wpdb->last_error],500);
  }
  $doc_id=$wpdb->insert_id; vogo_error_log3("[STEP 5.2] Document inserted | doc_id=$doc_id | IP: $ip | USER: $user_id");

  // [STEP 6] Mirror into forum thread as an answer message when route is /forum/post
$forum_answer_id=null;
if($module==='forum' && $submodule==='post'){
  $forum_table=$wpdb->prefix.'vogo_forum_post_answer';
  $ins2=$wpdb->insert($forum_table,[
    'PARENT_ID_vogo_forum_post'=>$reference_id,'post_author'=>$user_id,'post_answer'=>'','post_status'=>'active','post_content'=>'#FILE#:'.$upload_url,'post_date'=>$now,'mesaj'=>$original_file_name,'comment_count'=>0,'post_image'=>$upload_url,'post_mime_type'=>$file_mime_type,'created_at'=>$now,'created_user'=>$user_id,'modified_at'=>$now,'modified_user'=>$user_id
  ],['%d','%d','%s','%s','%s','%s','%s','%d','%s','%s','%s','%d','%s','%d']);
  vogo_error_log3("##############SQL: INSERT INTO $forum_table (PARENT_ID_vogo_forum_post,post_author,post_content,post_date,mesaj,post_image,post_mime_type,...) VALUES ($reference_id,$user_id,'#FILE#:{$upload_url}','$now','$original_file_name','$upload_url','$file_mime_type',...)");
  if($ins2===false){ vogo_error_log3("[STEP 6.1] Insert forum_post_answer failed: {$wpdb->last_error} | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Insert forum answer failed','sql_error'=>$wpdb->last_error],500); }
  $forum_answer_id=$wpdb->insert_id; vogo_error_log3("[STEP 6.2] Forum answer inserted | answer_id=$forum_answer_id | thread_id=$reference_id | IP: $ip | USER: $user_id");

  // [STEP 6.3] Update parent thread last_answer_datetime
  $parent_table=$wpdb->prefix.'vogo_forum_post';
  $upd=$wpdb->update($parent_table,['last_answer_datetime'=>$now,'post_modified_date'=>$now,'post_modified_user'=>$user_id],['ID'=>$reference_id],['%s','%s','%d'],['%d']);
  vogo_error_log3("##############SQL: UPDATE $parent_table SET last_answer_datetime='$now', post_modified_date='$now', post_modified_user=$user_id WHERE ID=$reference_id");
  if($upd===false){ vogo_error_log3("[STEP 6.4] Parent update failed: {$wpdb->last_error} | IP: $ip | USER: $user_id"); return new WP_REST_Response(['success'=>false,'error'=>'Failed to update parent last_answer_datetime','sql_error'=>$wpdb->last_error],500); }
}



  // [STEP 7] Build response
  $caller=get_userdata($user_id); $caller_name=$caller?$caller->user_login:'';
  vogo_error_log3("[STEP 7] Upload OK | doc_id=$doc_id | forum_answer_id=".($forum_answer_id??'NULL')." | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'success'=>true,
    'userId'=>$user_id,
    'userName'=>$caller_name,
    'inserted_id'=>$doc_id,
    'forum_answer_id'=>$forum_answer_id,
    'module'=>$module,
    'submodule'=>$submodule,
    'reference_id'=>$reference_id,
    'server_path'=>$server_path,
    'file_url'=>$upload_url,
    'file_name'=>$original_file_name,
    'file_type'=>$file_mime_type,
    'file_size'=>$filesize
  ],200);
}


/**
 * Get all documents matching module, submodule, reference_id, filtered by permission
 */

function get_vogo_documents(WP_REST_Request $request) {
    global $wpdb;
    $table = $wpdb->prefix . 'vogo_documents';
    clear_debug_log_file();

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $user_id = extract_user_from_jwt_token($request);
    $raw_input = file_get_contents('php://input');

    vogo_error_log3("[user:get_vogo_documents | IP: $ip | USER: $user_id] " . VOGO_LOG_START);
    vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
    vogo_error_log3("[STEP 1] ACTIVE DB: {$wpdb->dbname} | IP: $ip | USER: $user_id");

    $data = json_decode($raw_input, true);
    $module = sanitize_text_field($data['module'] ?? '');
    $submodule = sanitize_text_field($data['submodule'] ?? '');
    $reference_id = (int)($data['reference_id'] ?? 0);

    if (!$module || !$submodule || !$reference_id) {
        vogo_error_log3("[user:Invalid parameters | Module: $module | Submodule: $submodule | Ref ID: $reference_id | IP: $ip | USER: $user_id] STEP 2");
        vogo_error_log3("[user:get_vogo_documents | IP: $ip | USER: $user_id] " . VOGO_LOG_END);
        return new WP_REST_Response(['success' => false, 'error' => 'Invalid parameters'], 400);
    }

    $query = $wpdb->prepare("SELECT * FROM $table WHERE module = %s AND submodule = %s AND reference_id = %d", $module, $submodule, $reference_id);
    vogo_error_log3("##############SQL: $query");
    $results = $wpdb->get_results($query);
    $filtered = [];

foreach ($results as $doc) {
    $doc_id = isset($doc->ID) ? (int)$doc->ID : 0;
    vogo_error_log3("##############DOC_ID: $doc_id");    
    if ($doc_id <= 0) continue;

    if (has_permission_to_view_document_by_id($doc_id, $user_id) === true) {
        $server_path = $doc->server_path ?? null;
        $url_link = $server_path ? site_url('/wp-content/uploads/' . ltrim($server_path, '/')) : null;

        $filtered[] = [
            'ID'             => $doc_id,
            'module'         => $doc->module ?? null,
            'submodule'      => $doc->submodule ?? null,
            'reference_id'   => isset($doc->reference_id) ? (int)$doc->reference_id : null,
            'user_id'        => isset($doc->user_id) ? (int)$doc->user_id : null,
            'server_path'    => $server_path,
            'file_name'      => $doc->file_name ?? null,
            'file_type'      => $doc->file_type ?? null,
            'file_size'      => isset($doc->file_size) ? (int)$doc->file_size : null,
            'created_at'     => $doc->created_at ?? null,
            'created_user'   => isset($doc->created_user) ? (int)$doc->created_user : null,
            'modified_at'    => $doc->modified_at ?? null,
            'modified_user'  => isset($doc->modified_user) ? (int)$doc->modified_user : null,
            'url_link'       => $url_link
        ];
    }
}

    vogo_error_log3("[user:get_vogo_documents | IP: $ip | USER: $user_id] STEP 3: Returned " . count($filtered) . " documents for user.");
    vogo_error_log3("[user:get_vogo_documents | IP: $ip | USER: $user_id] " . VOGO_LOG_END);

    return new WP_REST_Response(['success' => true, 'documents' => $filtered], 200);
}


/**
 * Insert new forum post with full audit and permission checks
 */
function vogo_insert_forum_post(WP_REST_Request $request) {
    global $wpdb;

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
    $current_db = DB_NAME;
    vogo_error_log3("[STEP 1] ACTIVE DB: $current_db | IP: $ip | Start forum_post", $ip, 'unknown');

    $user_id_result = extract_user_from_jwt_token($request);
    if ($user_id_result instanceof WP_REST_Response) return $user_id_result;
    $user_id = $user_id_result;

    $data = $request->get_json_params();
    $oras = sanitize_text_field($data['oras'] ?? '');
    $domeniu = sanitize_text_field($data['domeniu'] ?? '');
    $post_title = sanitize_text_field($data['post_title'] ?? '');
    $post_content = sanitize_textarea_field($data['post_content'] ?? '');
    $mesaj = sanitize_textarea_field($data['mesaj'] ?? '');
    $post_image = esc_url_raw($data['post_image'] ?? '');
    $post_mime_type = sanitize_text_field($data['post_mime_type'] ?? '');
    $modified_user = sanitize_text_field($data['post_modified_user'] ?? '');

    if (!$oras || !$domeniu || !$post_title || !$post_content || !$mesaj) {
        vogo_error_log3("[STEP 2] Missing required fields", $ip, $user_id);
        return new WP_REST_Response(['success' => false, 'error' => 'Required fields missing'], 400);
    }

    $now = current_time('mysql');

    $result = $wpdb->insert('wp_vogo_forum_post', [
        'oras' => $oras,
        'domeniu' => $domeniu,
        'post_author' => $user_id,
        'post_title' => $post_title,
        'post_status' => 'active',
        'post_content' => $post_content,
        'post_date' => $now,
        'mesaj' => $mesaj,
        'comment_count' => 0,
        'post_image' => $post_image,
        'post_mime_type' => $post_mime_type,
        'post_modified_date' => $now,
        'post_modified_user' => $modified_user
    ]);

    if ($result === false) {
        $error = $wpdb->last_error;
        vogo_error_log3("[STEP 3] DB INSERT FAILED | Error: $error", $ip, $user_id);
        return new WP_REST_Response(['success' => false, 'error' => 'DB insert failed'], 500);
    }

    $inserted_id = $wpdb->insert_id;
    vogo_error_log3("[STEP 4] Insert successful | ID: $inserted_id", $ip, $user_id);
    return new WP_REST_Response(['success' => true, 'post_id' => $inserted_id], 200);
}

//get all discussions / paginated
function vogo_get_forum_discussions(WP_REST_Request $request) {
  global $wpdb;

  // STEP 1: Extract IP and user
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  $db = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db | IP: $ip | User: $user_id | Start forum_discussions");

  // STEP 2: Prepare filters and pagination
  $params = $request->get_json_params();
  $page = max(1, intval($params['page'] ?? 1));
  $limit = max(1, intval($params['limit'] ?? 20));
  $offset = ($page - 1) * $limit;

  $conditions = [];
  $values = [];

  if (!empty($params['oras'])) {
    $conditions[] = "oras = %s";
    $values[] = sanitize_text_field($params['oras']);
  }

  if (!empty($params['domeniu'])) {
    $conditions[] = "domeniu = %s";
    $values[] = sanitize_text_field($params['domeniu']);
  }

  if (!empty($params['post_author'])) {
    $conditions[] = "post_author = %d";
    $values[] = intval($params['post_author']);
  }

  // STEP 3: Build and execute query
  $where = $conditions ? "WHERE " . implode(" AND ", $conditions) : "";
  $table = $wpdb->prefix . "vogo_forum_post";
  $sql = "SELECT * FROM $table $where ORDER BY post_date DESC LIMIT %d OFFSET %d";
  $values[] = $limit;
  $values[] = $offset;

  $query = $wpdb->prepare($sql, $values);
  $results_raw = $wpdb->get_results($query, ARRAY_A);

  // STEP 4: Add post_username and post_username_short to each result
  $results = [];
  foreach ($results_raw as $row) {
    $author_id = intval($row['post_author']);
    $user = get_user_by('id', $author_id);
    $username = $user ? $user->user_login : 'unknown';
    $row['post_username'] = $username;
    $row['post_username_short'] = mb_substr($username, 0, 10); // safe truncate
    $row['post_icon_letter'] = mb_substr($username, 0, 1);
    $row['post_icon_color'] = "blue";  
    $results[] = $row;
  }

  vogo_error_log3("[STEP 2] Retrieved forum posts: " . count($results) . " | IP: $ip | User: $user_id");

  // STEP 5: Return response
  return new WP_REST_Response([
    'success' => true,
    'user_id' => $user_id,
    'filters' => [
      'oras' => $params['oras'] ?? '',
      'domeniu' => $params['domeniu'] ?? '',
      'post_author' => $params['post_author'] ?? ''
    ],
    'page' => $page,
    'limit' => $limit,
    'results' => $results
  ], 200);
}

//get discussion details by id
function vogo_get_forum_discussion_by_id_forum(WP_REST_Request $request) {
  global $wpdb;

  // STEP 1: Extract IP, user and DB
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;
  $db = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db | IP: $ip | User: $user_id | Start get_forum_discussion_by_id");

  // STEP 2: Extract discussion ID
  $params = $request->get_json_params();
  $discussion_id = intval($params['id'] ?? 0);
  if ($discussion_id <= 0) {
    vogo_error_log3("[STEP 2] Invalid discussion_id received: $discussion_id | IP: $ip | User: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid discussion_id'], 400);
  }

  // STEP 3: Query forum post by ID
  $table = $wpdb->prefix . "vogo_forum_post";
  $sql = $wpdb->prepare("SELECT * FROM $table WHERE ID = %d LIMIT 1", $discussion_id);
  $discussion = $wpdb->get_row($sql, ARRAY_A);
  vogo_error_log3("[STEP 3] SQL executed: $sql | IP: $ip | User: $user_id");
  vogo_error_log3("[STEP 4] SQL result: " . json_encode($discussion) . " | IP: $ip | User: $user_id");

  if (!$discussion || !isset($discussion['ID'])) {
    vogo_error_log3("[STEP 5] No discussion found for ID: $discussion_id | IP: $ip | User: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid discussion_id'], 400);
  }

  // STEP 6: Add username and avatar info
  $user = get_user_by('id', $discussion['post_author']);
  $post_username = $user ? $user->user_login : 'unknown';
  $post_username_short = substr($post_username, 0, 10);
  $first_letter = strtolower(substr($post_username, 0, 1));
  $color_list = ['red', 'blue', 'green', 'orange', 'purple', 'teal', 'cyan', 'yellow'];
  $post_icon_color = $color_list[ord($first_letter) % count($color_list)];

  $discussion['post_username'] = $post_username;
  $discussion['post_username_short'] = $post_username_short;
  $discussion['post_icon_letter'] = $first_letter;
  $discussion['post_icon_color'] = $post_icon_color;

  // STEP 7: Return result
  return new WP_REST_Response([
    'success' => true,
    'user_id' => $user_id,
    'discussion_id' => $discussion_id,
    'result' => $discussion
  ], 200);
}

function vogo_edit_forum_discussion_by_id_forum(WP_REST_Request $request) {
    clear_debug_log_file();
  global $wpdb; $table = $wpdb->prefix . 'vogo_forum_post';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $active_db = DB_NAME;

  $user_id_result = extract_user_from_jwt_token($request);
  if ($user_id_result instanceof WP_REST_Response) return $user_id_result;
  $user_id = $user_id_result;

  vogo_error_log3("[STEP 1] ACTIVE DB: $active_db | IP: $ip | USER: $user_id | Edit forum discussion");

  $data = $request->get_json_params();
  $discussion_id = intval($data['discussion_id'] ?? 0);
  $post_title = sanitize_text_field($data['post_title'] ?? '');
  $post_status = sanitize_text_field($data['post_status'] ?? '');
  $post_content = sanitize_textarea_field($data['post_content'] ?? '');
  $mesaj = sanitize_textarea_field($data['mesaj'] ?? '');  

  if ($discussion_id <= 0 || !$post_title || !$post_content) {
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid or missing fields'], 400);
  }

  $sql = $wpdb->prepare("SELECT post_author FROM $table WHERE ID = %d LIMIT 1", $discussion_id);
  $existing_author = $wpdb->get_var($sql);
  if (!$existing_author || (int)$existing_author !== $user_id) {
     vogo_error_log3("[STEP 1.5] Discussion ID $discussion_id SECURITY - Access denied | existing_author: $existing_author | USER: $user_id");
    return new WP_REST_Response(['success' => false, 'error' => 'Access denied'], 403);
  }

    $now = current_time('mysql');
    $update_result = $wpdb->update(
    $table,
    [
        'post_title'         => $post_title,
        'post_content'       => $post_content,
        'post_status'       => $post_status,
        'mesaj'              => $mesaj,      
        'post_modified_date' => $now,
        'post_modified_user' => $user_id
    ],
    ['ID' => $discussion_id],
    ['%s', '%s', '%s', '%s', '%d'], // 🛠️ 4 stringuri + 1 integer
    ['%d']
    );

  if ($update_result === false) {
    return new WP_REST_Response(['success' => false, 'error' => 'DB update failed', 'details' => $wpdb->last_error], 500);
  }

  vogo_error_log3("[STEP 2] Discussion ID $discussion_id updated successfully | IP: $ip | USER: $user_id");
  return new WP_REST_Response(['success' => true, 'discussion_id' => $discussion_id], 200);
}


function vogo_hide_forum_discussion_by_id(WP_REST_Request $request) {
  global $wpdb; $table = $wpdb->prefix . 'vogo_forum_post';
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $active_db = DB_NAME;

  $user_id_result = extract_user_from_jwt_token($request);
  if ($user_id_result instanceof WP_REST_Response) return $user_id_result;
  $user_id = $user_id_result;

  vogo_error_log3("[STEP 1] ACTIVE DB: $active_db | IP: $ip | USER: $user_id | Hide forum discussion");

  $data = $request->get_json_params();
  $discussion_id = intval($data['discussion_id'] ?? 0);
  if ($discussion_id <= 0) {
    return new WP_REST_Response(['success' => false, 'error' => 'Invalid discussion_id'], 400);
  }

  $sql = $wpdb->prepare("SELECT post_author FROM $table WHERE ID = %d LIMIT 1", $discussion_id);
  $existing_author = $wpdb->get_var($sql);
  if (!$existing_author || (int)$existing_author !== $user_id) {
    return new WP_REST_Response(['success' => false, 'error' => 'Access denied'], 403);
  }

  $now = current_time('mysql');
  $update_result = $wpdb->update(
    $table,
    [
      'post_status'   => 'hidden',
      'modified_at'   => $now,
      'modified_user' => $user_id
    ],
    ['ID' => $discussion_id],
    ['%s', '%s', '%d'],
    ['%d']
  );

  if ($update_result === false) {
    return new WP_REST_Response(['success' => false, 'error' => 'DB update failed', 'details' => $wpdb->last_error], 500);
  }

  vogo_error_log3("[STEP 2] Discussion ID $discussion_id hidden successfully | IP: $ip | USER: $user_id");
  return new WP_REST_Response(['success' => true, 'discussion_id' => $discussion_id], 200);
}

function vogo_edit_or_hide_forum_post_answer_reply_by_id(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'vogo_forum_post_answer_reply';
  $ip = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id = extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data = json_decode($raw_input, true);
  $id = (int)($data['id'] ?? 0);
  if (!$id) return new WP_REST_Response(['success' => false, 'error' => 'Missing ID'], 400);

  $fields = [];
  if (isset($data['post_answer']))        $fields['post_answer']        = sanitize_text_field($data['post_answer']);
  if (isset($data['post_content']))       $fields['post_content']       = sanitize_textarea_field($data['post_content']);
  if (isset($data['mesaj']))              $fields['mesaj']              = sanitize_text_field($data['mesaj']);
  if (isset($data['post_status']))        $fields['post_status']        = sanitize_text_field($data['post_status']);
  if (isset($data['comment_count']))      $fields['comment_count']      = (int)($data['comment_count']);
  if (isset($data['post_image']))         $fields['post_image']         = sanitize_textarea_field($data['post_image']);
  if (isset($data['post_mime_type']))     $fields['post_mime_type']     = sanitize_text_field($data['post_mime_type']);

  $fields['post_modified_date'] = current_time('mysql');
  $fields['post_modified_user'] = $user_id;

  $result = $wpdb->update($table, $fields, ['ID' => $id], null, ['%d']);
  vogo_error_log3("##############SQL: UPDATE $table SET ... WHERE ID = $id");
  vogo_error_log3("[STEP 9] Update/hide result: $result | IP: $ip | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response(['success' => $result !== false, 'modified_id' => $id], 200);
}


function vogo_add_forum_post_answer_reply(WP_REST_Request $request) {
  global $wpdb;
  $table = $wpdb->prefix . 'vogo_forum_post_answer_reply';
  $ip = $_SERVER['REMOTE_ADDR'];
  $raw_input = file_get_contents('php://input');
  $user_id = extract_user_from_jwt_token($request);

  vogo_error_log3("############ START ########################################");
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: $user_id");
  vogo_error_log3("ACTIVE DB: " . DB_NAME);

  $data = json_decode($raw_input, true);
  $fields = [
    'PARENT_ID_vogo_forum_post'        => (int)($data['PARENT_ID_vogo_forum_post'] ?? 0),
    'PARENT_ID_vogo_forum_post_answer' => (int)($data['PARENT_ID_vogo_forum_post_answer'] ?? 0),
    'post_author'                      => $user_id,
    'post_answer'                      => sanitize_text_field($data['post_answer'] ?? ''),
    'post_status'                      => sanitize_text_field($data['post_status'] ?? 'active'),
    'post_content'                     => sanitize_textarea_field($data['post_content'] ?? ''),
    'post_date'                        => current_time('mysql'),
    'mesaj'                            => sanitize_text_field($data['mesaj'] ?? ''),
    'comment_count'                    => (int)($data['comment_count'] ?? 0),
    'post_image'                       => sanitize_textarea_field($data['post_image'] ?? ''),
    'post_mime_type'                   => sanitize_text_field($data['post_mime_type'] ?? ''),
    'post_modified_date'              => current_time('mysql'),
    'post_modified_user'              => $user_id
  ];

  $result = $wpdb->insert($table, $fields);
  $insert_id = $wpdb->insert_id;

  vogo_error_log3("##############SQL: INSERT INTO $table (...) VALUES (...)");
  vogo_error_log3("[STEP 9] Insert result: $result | insert_id: $insert_id | IP: $ip | USER: $user_id");
  vogo_error_log3("############ END ########################################");

  return new WP_REST_Response(['success' => $result !== false, 'insert_id' => $insert_id], 200);
}