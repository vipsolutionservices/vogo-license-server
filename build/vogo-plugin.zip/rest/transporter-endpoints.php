<?php
//$MODULE_PHP='transporter-endpoints.php';

/*
daca tip livrare=DIRECT:
STATUS TRANSPORTES TRIPS - pastrate in WP_ORDERS.STATUS:
READY = disponilbila; 
ACCEPTED - luata de un transporter , 
STARTED - imediat ce incepe sa se comunice prima modificare de locatie de catre masina transporter, distangta<=100 m de la start location
IN_PROGRESS - miscarile urmatoare pana la comming soon, didtanta > 100 m de la start si >100 pana la end
COMMING_SOON - cand se apropie la 500 m or less, distangta<=500 m de la end location
ARRIVED - cand a ajuns in locatie , distanta <=50 m de end locatie
DELIVERED cand a predat coletul sau pasagerul, 
REJECTED - daca transportatorul a refuzat comanda
CLOSED dupa delivered, 
CANCELLED anulata de client


daca tip livrare=CURIER
READY = disponilbila; 
ACCEPTED - confirmata/preluata 
STARTED - in lucru, se impacheteaza
PACKAGED - pregatita pentru preluare de catre curier
CURIER - a fost preluata de curier
DELIVERED cand a predat coletul sau pasagerul, 
REJECTED - daca vendorul a refuzat comanda, cu motiv
CLIENT_NOT_FOUND - daca nu este in locatie
ADDRESS_NOT_FOUND - daca nu s-a gasit adresa
CLOSED dupa delivered, 
CANCELLED anulata de client

*/

add_action('rest_api_init', function(){

  //nealocate --READY
  register_rest_route('vogo/v1', '/transport/available_orders', [
    'methods'  => 'POST',
    'callback' => 'vogo_transport_available_orders',
    'permission_callback' => 'rest_check_jwt_is_user_transporter'
  ]);
//curse in derulare curenta ACCEPTED,STARTED,IN_PROGRESS,COMMING_SOON,ARRIVED
    register_rest_route('vogo/v1', '/transport/get_current_order', [
    'methods'  => 'POST',
    'callback' => 'get_current_order',
    'permission_callback' => 'rest_check_jwt_is_user_transporter'
  ]);
//istoric - DELIVERED,FINISHED
    register_rest_route('vogo/v1', '/transport/get_history_orders', [
    'methods'  => 'POST',
    'callback' => 'get_history_orders',
    'permission_callback' => 'rest_check_jwt_is_user_transporter'
  ]);

  register_rest_route('vogo/v1', '/client/client_get_my_orders-old', [
    'methods'  => 'POST',
    'callback' => 'client_get_my_orders',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);  

  register_rest_route('vogo/v1', '/client/client_get_active_drive_orders', [
    'methods'  => 'POST',
    'callback' => 'client_get_active_drive_orders',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);    

  register_rest_route('vogo/v1', '/client/client_get_history_drive_orders', [
    'methods'  => 'POST',
    'callback' => 'client_get_history_drive_orders',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);     

  register_rest_route('vogo/v1', '/client/client_add_new_drive_order', [
    'methods'  => 'POST',
    'callback' => 'client_add_new_drive_order',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);     

  register_rest_route('vogo/v1', '/client/client_get_drive_order_details', [
    'methods'  => 'POST',
    'callback' => 'client_get_drive_order_details',
    'permission_callback' => 'rest_check_jwt_is_user_client'
  ]);     

    register_rest_route('vogo/v1', '/transport/transport_get_drive_order_details', [
    'methods'  => 'POST',
    'callback' => 'transport_get_drive_order_details',
    'permission_callback' => 'rest_check_jwt_is_user_transporter'
  ]);     

  register_rest_route('vogo/v1', '/transport/wp_orders_calculate_fields', [
    'methods'  => 'POST',
    'callback' => 'wp_orders_calculate_fields',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/transport/accept', [
    'methods' => 'POST',
    'callback' => 'vogo_order_accept',
    'permission_callback' => 'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1', '/transport/transporter_update_current_position', [
    'methods' => 'POST',
    'callback' => 'vogo_transporter_update_current_position',
    'permission_callback' => 'vogo_permission_check'
  ]);
  register_rest_route('vogo/v1', '/client/client_get_transported_position-old', [
    'methods' => 'POST',
    'callback' => 'vogo_client_get_transported_position',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/transport/reject', [
    'methods'  => 'POST',
    'callback' => 'vogo_order_reject',
    'permission_callback' => 'vogo_permission_check'
  ]);

  register_rest_route('vogo/v1', '/transport/update_status_and_notes', [
    'methods'  => 'POST',
    'callback' => 'vogo_transporter_update_status_notes',
    'permission_callback' => 'vogo_permission_check'
  ]);  

  register_rest_route('vogo/v1','/transport/finish',[
    'methods'  => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'transport_finish'
  ]);  

  register_rest_route('vogo/v1','/transport/cancel',[
    'methods'  => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'transport_cancel'
  ]);
  
  register_rest_route('vogo/v1','/transport/client_order_status_details',[
    'methods'  => 'POST',
    'permission_callback' => 'vogo_permission_check',
    'callback' => 'client_orders_list'
  ]);  

});


//actualizeaza doar in wp_orders => status diagram = ACCEPTED


function vogo_order_accept(WP_REST_Request $request){
  global $wpdb; $module='order-accept'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';

  // 0) Auth
  $transporter_id = (int) extract_user_from_jwt_token($request);
  if(!$transporter_id){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'auth'],403);
  }

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$transporter_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response      

  // 1) Input minim
  $p = $request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0);
  if(!$order_id){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.ERR1','error'=>'order_id required'],400);


  }

  $lat = isset($p['lat']) ? (float)$p['lat'] : null;
  $long = isset($p['long']) ? (float)$p['long'] : null;
  if($lat===null || $long===null){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR2','error'=>'lat_and_long_required'],400);
  }
  if($lat<-90 || $lat>90 || $long<-180 || $long>180){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR3','error'=>'lat_long_out_of_range'],400);
  }

  $module=$module.'.order_id:'.$order_id;  
  $module=$module.'.lat:'.$lat;  
  $module=$module.'.long:'.$long;  

  // 2) Citim rapid din comanda bază (wp_orders)
  $orders_tbl = $wpdb->prefix.'orders';               // wp_orders
  $o = $wpdb->get_row(
    $wpdb->prepare("SELECT id, client_id, provider_id, total_amount FROM $orders_tbl WHERE id=%d LIMIT 1", $order_id),
    ARRAY_A
  );
  if(!$o){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_not_found'],404);
  }
  $client_id   = (int)$o['client_id'];
  $provider_id = (int)$o['provider_id'];
  $amount      = (float)$o['total_amount'];

  // [ADI-ADD] folosim orders_delivery ca sursă unică; wp_order_transporter a fost eliminată
  $t_del = $wpdb->prefix.'orders_delivery'; // [ADI-ADD]

  // 3) Verificăm existența unei preluări în wp_orders_delivery [ADI-ADD]
  $existing = $wpdb->get_row(
    $wpdb->prepare("SELECT id, transporter_id, current_status FROM $t_del WHERE order_id=%d LIMIT 1", $order_id),
    ARRAY_A
  );
  if($existing){
    $ex_tid = (int)$existing['transporter_id'];
    $ex_st  = strtoupper($existing['current_status'] ?? '');

    // deja luată de mine (activă)
    if($ex_tid === $transporter_id && in_array($ex_st, ['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','DELIVERED'])){
      return new WP_REST_Response([
        'success'=>false,'module' => $module.'.TEND','error'=>'already_accepted_by_you','status'=>$ex_st
      ],409);
    }
    // deja luată de altcineva (activă)
    if($ex_tid && $ex_tid !== $transporter_id && in_array($ex_st, ['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','DELIVERED'])){
      return new WP_REST_Response([
        'success'=>false,'module' => $module.'.TEND','error'=>'already_taken','assigned_transporter_id'=>$ex_tid,'status'=>$ex_st
      ],409);
    }
    // alte cazuri non-active (ex. NEW/CLOSED/CANCELLED) → continuăm și o revendicăm mai jos
  }

  // 4) (eliminat INSERT în wp_order_transporter) [ADI-ADD]

  // 5) Upsert în orders_delivery (setează accepted_date dacă lipsește/zero-date)
  $now_utc = current_time('mysql', 1); // UTC, ca restul

  // încercăm UPDATE direct (cu gardă minimă să nu suprascriem o cursă activă) [ADI-ADD]
  $upd = $wpdb->query( $wpdb->prepare("
    UPDATE $t_del
       SET current_status='ACCEPTED',
           transporter_id=%d,
           accepted_date = CASE
             WHEN accepted_date IS NULL OR accepted_date = '0000-00-00 00:00:00' THEN %s
             ELSE accepted_date
           END
     WHERE order_id=%d
       AND (transporter_id IS NULL OR transporter_id=0)
       AND (current_status IS NULL OR current_status IN ('NEW','READY'))
  ", $transporter_id, $now_utc, $order_id));

  // dacă nu există rând → INSERT
  if($upd === 0){
    // [ADI-ADD] scoatem delivery_type (coloana eliminată)
    $ins = $wpdb->insert($t_del, [
      'order_id'        => $order_id,
      'current_status'  => 'ACCEPTED',
      'accepted_date'   => $now_utc,
      'transporter_id'  => $transporter_id,
      'created_at'      => current_time('mysql', 1),
      'created_by'      => $transporter_id
    ], ['%d','%s','%s','%d','%s','%d']);

    if(!$ins){
      if(stripos($wpdb->last_error, 'duplicate') !== false){
        // alt thread a inserat între timp → re-try UPDATE (fără a suprascrie o preluare activă de altcineva) [ADI-ADD]
        $retry = $wpdb->query( $wpdb->prepare("
          UPDATE $t_del
             SET current_status='ACCEPTED',
                 transporter_id=%d,
                 accepted_date = CASE
                   WHEN accepted_date IS NULL OR accepted_date = '0000-00-00 00:00:00' THEN %s
                   ELSE accepted_date
                 END
           WHERE order_id=%d
             AND (transporter_id IS NULL OR transporter_id=0)
             AND (current_status IS NULL OR current_status IN ('NEW','READY'))
        ", $transporter_id, $now_utc, $order_id));

        if($retry===0){
          // dacă tot 0, atunci probabil a fost deja luată
          $taken = $wpdb->get_row(
            $wpdb->prepare("SELECT transporter_id, current_status FROM $t_del WHERE order_id=%d LIMIT 1", $order_id),
            ARRAY_A
          );
          return new WP_REST_Response([
            'success'=>false,'error'=>'already_taken','module' => $module.'.TEND',
            'assigned_transporter_id'=>(int)($taken['transporter_id'] ?? 0),
            'status'=>$taken['current_status'] ?? 'ACCEPTED'
          ],409);
        }
      }else{
        return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql','sql_message'=>$wpdb->last_error],500);
      }
    }
  }

  // id-ul rândului din delivery ca să păstrăm cheia veche din response [ADI-ADD]
  $delivery_id = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $t_del WHERE order_id=%d LIMIT 1",$order_id));
  $ot_id = $delivery_id; // [ADI-ADD] păstrăm numele cheii în răspuns

  // 5.1) [ADI-ADD] Sync explicit: reflectăm acceptarea și în wp_orders.status (BC-safe)
  $wpdb->query( $wpdb->prepare("UPDATE $orders_tbl SET status=%s WHERE id=%d", 'ACCEPTED', $order_id) );

    // 7) GPS — apel helper cerut (INSERT pos + UPSERT last_lat/last_long)
  transporter_save_position_and_sync_delivery($order_id, $transporter_id, $lat, $long);


  return new WP_REST_Response([
    'success'=>true,
    'module' => $module.'.TEND',    
    'order_transporter_id'=>$ot_id, // [ADI-ADD] compat cu vechiul contract
    'order_id'=>$order_id,
    'status'=>'ACCEPTED',
    'user_id'=>$transporter_id
  ],200);
}//vogo_order_accept

//send real time position and update status
function vogo_transporter_update_current_position(WP_REST_Request $request){
  global $wpdb; $module='transporter-pos'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';

  // 0) Auth
  $transporter_id=(int)extract_user_from_jwt_token($request);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$transporter_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response   

  if(!$transporter_id){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'auth','current_user_id'=>$transporter_id],403);
  }

  // 1) Input
  $p=$request->get_json_params();
  $order_id=(int)($p['order_id']??0);
  $module=$module.'.order_id:'.$order_id;
  
  $lat=isset($p['latitude'])?(float)$p['latitude']:0;
  $lng=isset($p['longitude'])?(float)$p['longitude']:0;
  $in_status=isset($p['status'])?strtoupper(trim($p['status'])):'';
  if(!$order_id||!$lat||!$lng){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id/latitude/longitude required','current_user_id'=>$transporter_id],400);
  }

  $module=$module.'.lat:'.$lat;
  $module=$module.'.lng:'.$lng;


  $t_orders=$wpdb->prefix.'orders';
  $t_del=$wpdb->prefix.'orders_delivery';
  $t_pos=$wpdb->prefix.'order_transporter_pos';

  // 2) Check mapping
  $map=$wpdb->get_row($wpdb->prepare("SELECT id,transporter_id,current_status FROM $t_del WHERE order_id=%d LIMIT 1",$order_id),ARRAY_A);
  if(!$map){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>"THIS ORDER IS NOT ASSIGNED TO YOU. Use transport/accept first",'current_user_id'=>$transporter_id],403);
  }
  $map_tid=(int)($map['transporter_id']??0);
  $current=strtoupper($map['current_status']??'ACCEPTED');
  if($map_tid && $map_tid!==$transporter_id && in_array($current,['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','DELIVERED'],true)){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response([
      'success'=>false,
      'module' => $module.'.TEND',
      'error'=>'already_taken',
      'message'=>'Order belongs to another transporter',
      'assigned_transporter_id'=>$map_tid,
      'status'=>$current,
      'current_user_id'=>$transporter_id
    ],409);
  }
  if(!$map_tid){$wpdb->update($t_del,['transporter_id'=>$transporter_id],['id'=>(int)$map['id']],['%d'],['%d']);}

  // 3) Status flow
  if(in_array($current,['CLOSED','CANCELLED'],true)){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_inactive','status'=>$current,'current_user_id'=>$transporter_id],409);
  } 
  // 3.1) Distances
  $o=$wpdb->get_row($wpdb->prepare("SELECT pick_latitude,pick_longitude,end_lat,end_long,status FROM $t_orders WHERE id=%d LIMIT 1",$order_id),ARRAY_A);
  $pick_lat=$o['pick_latitude']!==null?(float)$o['pick_latitude']:null;
  $pick_lng=$o['pick_longitude']!==null?(float)$o['pick_longitude']:null;
  $end_lat =$o['end_lat']!==null?(float)$o['end_lat']:null;
  $end_lng =$o['end_long']!==null?(float)$o['end_long']:null;
  $o_status_cur=strtoupper((string)($o['status']??''));
  $h=function($a1,$o1,$a2,$o2){if($a1===null||$o1===null||$a2===null||$o2===null)return null; $R=6371000.0;$dLat=deg2rad($a2-$a1);$dLon=deg2rad($o2-$o1);$la1=deg2rad($a1);$la2=deg2rad($a2);$x=sin($dLat/2)**2+cos($la1)*cos($la2)*sin($dLon/2)**2;return 2*$R*asin(min(1,sqrt($x)));};
  $d_start=$pick_lat!==null?$h($lat,$lng,$pick_lat,$pick_lng):null;
  $d_end=$end_lat!==null?$h($lat,$lng,$end_lat,$end_lng):null;  
  
  // 3.2 Business auto-status progression (wp_orders si wp_order_transporter_pos)
    $desired=null;
    if($d_end!==null && $d_end<=50){$desired='ARRIVED';}
    elseif($d_end!==null && $d_end<=500){$desired='COMMING_SOON';}
    elseif($d_start!==null && $d_start>100 && ($d_end===null || $d_end>100)){$desired='IN_PROGRESS';}
    elseif($d_start!==null && $d_start<=100){$desired='STARTED';}

    $new_status=$desired;

    $module=$module.'.new_status:'.$new_status;

  /* [ADI-ADD] Safety fallback to avoid NULL/empty status */
  if(!$new_status){ $new_status = $current; }

  /* [ADI-ADD] Keep wp_orders.status in sync with delivery/POS */
  if($o_status_cur !== $new_status){
    $wpdb->update($t_orders, ['status'=>$new_status], ['id'=>$order_id], ['%s'], ['%d']);
  }

  // 5) Insert POS (respect structura actuală)
  $ins_data=['order_id'=>$order_id,'latitude'=>$lat,'longitude'=>$lng,'status'=>$new_status,'transporter_id'=>$transporter_id,'created_by'=>$transporter_id];
  $ok=$wpdb->insert($t_pos,$ins_data,['%d','%f','%f','%s','%d','%d']);
  if(!$ok){
    /* [ADI-ADD] include current_user_id in error response */
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql','sql_message'=>$wpdb->last_error,'current_user_id'=>$transporter_id],500);
  }

  // 6) Update delivery last coords
  $now_utc=current_time('mysql',1);
  $wpdb->update($t_del,['last_lat'=>$lat,'last_lng'=>$lng,'last_update_at'=>$now_utc,'current_status'=>$new_status,'modified_at'=>$now_utc,'modified_by'=>$transporter_id],['order_id'=>$order_id],['%f','%f','%s','%s','%s','%d'],['%d']);

  // 8) Push optional
  if(in_array($new_status,['COMMING_SOON','ARRIVED','DELIVERED','CLOSED'],true)){
    try{if(function_exists('vogo_fcm_send_to_user')){@vogo_fcm_send_to_user((int)$wpdb->get_var($wpdb->prepare("SELECT client_id FROM $t_orders WHERE id=%d",$order_id)),'Order '.$new_status,'Order #'.$order_id.' status: '.$new_status,['order_id'=>$order_id,'status'=>$new_status,'lat'=>$lat,'lng'=>$lng]);}}catch(Throwable $e){}
  }

  /* [ADI-ADD] also include current_user_id in success (non-breaking) */
  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','order_id'=>$order_id,'status'=>$new_status,'lat'=>$lat,'lng'=>$lng,'user_id'=>$transporter_id,'current_user_id'=>$transporter_id],200);
}//vogo_transporter_update_current_position



function vogo_client_get_transported_position(WP_REST_Request $request){
  global $wpdb; $module='client-pos'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $user_id=(int)$user_or_err; vogo_error_log3("[$module] STEP 1 OK | user_id:$user_id | IP:$ip",$module);



  // STEP 2 - Input
  $p=$request->get_json_params(); vogo_error_log3("[$module] [STEP 0.1] Raw JSON payload received: ".json_encode($p),$module);
  $order_id=(int)($p['order_id']??0);
  if(!$order_id){ vogo_error_log3("[$module] order_id missing | IP:$ip | USER:$user_id",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id required'],400); }
    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$user_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  $module=$module.'.order:'.$order_id;
  //end audit for response    


  $t_ord=$wpdb->prefix.'orders';
  $t_del=$wpdb->prefix.'orders_delivery';
  $t_tr =$wpdb->prefix.'transporters';

  // STEP 3 - Permission gate (must be client of the order)
  $sql_perm="SELECT EXISTS(SELECT 1 FROM $t_ord o WHERE o.id=%d AND o.client_id=%d) AS is_client";
  vogo_error_log3("[$module] ##############SQL: ".sprintf($sql_perm,$order_id,$user_id),$module);
  $perm=$wpdb->get_row($wpdb->prepare($sql_perm,$order_id,$user_id),ARRAY_A);
  $is_client=isset($perm['is_client'])&&((int)$perm['is_client']===1);
  if(!$is_client){ vogo_error_log3("[$module] permission_denied | order_id:$order_id | user_id:$user_id | IP:$ip",$module); vogo_error_log3("VOGO_LOG_END",$module); return new WP_REST_Response(['success'=>false,'error'=>'permission_denied'],403); }

  // STEP 4 - Status + latest position from delivery only (+ transporter info)
  $sql_del="SELECT d.order_id,d.transporter_id,d.current_status AS status,d.last_lat AS latitude,d.last_lng AS longitude,d.last_update_at AS created_at,t.nickname,t.plate_number,t.auto_type,t.auto_model,t.auto_colour,t.phone FROM $t_del d LEFT JOIN $t_tr t ON t.user_id=d.transporter_id WHERE d.order_id=%d LIMIT 1";
  vogo_error_log3("[$module] ##############SQL: ".sprintf($sql_del,$order_id),$module);
  $delivery=$wpdb->get_row($wpdb->prepare($sql_del,$order_id),ARRAY_A);

  // STEP 5 - Response (transporter_info only; no duplicated top-level fields)
  if(!$delivery){
    $resp=[
      'success'=>true,
      'order_id'=>$order_id,
      'status'=>'UNASSIGNED',
      'transporter_id'=>null,
      'latest_position'=>null,
      'transporter_info'=>null,
      'user_id'=>$user_id
    ];
  }else{
    $latest=null;
    if($delivery['latitude']!==null && $delivery['longitude']!==null){
      $latest=['latitude'=>(float)$delivery['latitude'],'longitude'=>(float)$delivery['longitude'],'status'=>$delivery['status'],'created_at'=>$delivery['created_at']];
    }
    $transporter_info = null;
    if($delivery['transporter_id']!==null){
      $transporter_info=[
        'user_id'=>(int)$delivery['transporter_id'],
        'nickname'=>$delivery['nickname']??null,
        'plate_number'=>$delivery['plate_number']??null,
        'auto_type'=>$delivery['auto_type']??null,
        'auto_model'=>$delivery['auto_model']??null,
        'auto_colour'=>$delivery['auto_colour']??null,
        'phone'=>$delivery['phone']??null
      ];
    }
    $resp=[
      'success'=>true,
      'module' => $module.'.TEND',
      'order_id'=>(int)$delivery['order_id'],
      'status'=>$delivery['status'],
      'transporter_id'=>($delivery['transporter_id']!==null?(int)$delivery['transporter_id']:null),
      'latest_position'=>$latest,
      'transporter_info'=>$transporter_info,
      'user_id'=>$user_id
    ];
  }

  vogo_error_log3("[$module] Response: ".json_encode($resp)." | IP:$ip | USER:$user_id",$module);
  vogo_error_log3("VOGO_LOG_END",$module);
  /* BC-GUARD: ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */
  return new WP_REST_Response($resp,200);
}//vogo_client_get_transported_position


/* ====== CONFIG CALCUL TRASEU GEO PLANNER ====== */
if(!defined('VOGO_OSRM_BASE')) define('VOGO_OSRM_BASE','https://router.project-osrm.org'); // schimbă cu instanța ta OSRM self-hosted pentru prod

/* ====== HELPERS (compact) ====== */
// [Adi-tehnic] Check if column exists (cached)
function vogo_col_exists($table,$col){ static $c=[]; global $wpdb; $k="$table|$col"; if(isset($c[$k])) return $c[$k];
  $sql=$wpdb->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s AND COLUMN_NAME=%s",$table,$col);
  $c[$k]=(int)$wpdb->get_var($sql)>0; return $c[$k];
}
// [Adi-tehnic] OSRM route distance (km) with transient cache
function vogo_osrm_route_km($lat1,$lng1,$lat2,$lng2,$ttl=900){
  $mod='osrm-route'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $key='osrm_'.md5("$lat1,$lng1,$lat2,$lng2"); $cached=get_transient($key);
  if($cached!==false) return $cached; $url=VOGO_OSRM_BASE."/route/v1/driving/{$lng1},{$lat1};{$lng2},{$lat2}?overview=false&alternatives=false&annotations=distance";
  vogo_error_log3("[$mod] call: $url | IP:$ip");
  $r=wp_remote_get($url,['timeout'=>6]); if(is_wp_error($r)){ vogo_error_log3("[$mod] ERR ".$r->get_error_message()); return null; }
  $code=wp_remote_retrieve_response_code($r); $body=json_decode(wp_remote_retrieve_body($r),true);
  if($code!==200||!isset($body['routes'][0]['distance'])){ vogo_error_log3("[$mod] bad response code:$code"); return null; }
  $km=max(0.0, round($body['routes'][0]['distance']/1000,3)); set_transient($key,$km,$ttl); return $km;
}
// [Adi-tehnic] OSRM table 1→N distances (km) from source to array of [lat,lng]; returns array index-aligned
function vogo_osrm_table_km($srcLat,$srcLng,$targets,$ttl=900){
  $mod='osrm-table'; if(empty($targets)) return []; $parts=["{$srcLng},{$srcLat}"]; foreach($targets as $t){ $parts[]=$t[1].','.$t[0]; }
  $coords=implode(';',$parts); $url=VOGO_OSRM_BASE."/table/v1/driving/{$coords}?sources=0&annotations=distance";
  $key='osrm_tbl_'.md5($coords); $cached=get_transient($key); if($cached!==false) return $cached;
  vogo_error_log3("[$mod] call: $url");
  $r=wp_remote_get($url,['timeout'=>7]); if(is_wp_error($r)){ vogo_error_log3("[$mod] ERR ".$r->get_error_message()); return array_fill(0,count($targets),null); }
  $body=json_decode(wp_remote_retrieve_body($r),true); $dist=($body['distances'][0]??[]);
  $out=[]; for($i=1;$i<count($dist)+1;$i++){ $m=$dist[$i]??null; $out[]=$m!==null?max(0.0,round($m/1000,3)):null; }
  set_transient($key,$out,$ttl); return $out;
}
// [Adi-tehnic] Fallback straight-line (km)
function vogo_geodesic_km($lat1,$lng1,$lat2,$lng2){ $R=6371; $x=cos(deg2rad($lat1))*cos(deg2rad($lat2))*cos(deg2rad($lng2-$lng1))+sin(deg2rad($lat1))*sin(deg2rad($lat2)); return $R*acos(min(1,max(-1,$x))); }

function vogo_transport_available_orders(WP_REST_Request $request){
  global $wpdb; $module='available-orders'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  // vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    // vogo_error_log3("[$module] JWT failed | IP:$ip",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';
  // vogo_error_log3("[$module] JWT ok | user_id:$uid | user_login:$ulogin",$module);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response      

  // STEP 2 - Payload
  $p=$request->get_json_params(); 
  // vogo_error_log3("[$module] [STEP 0.1] Raw: ".wp_json_encode($p),$module);
  $lat=(float)($p['latitude']??0); $lng=(float)($p['longitude']??0); 
  if(!$lat||!$lng){ 
    // vogo_error_log3("[$module] Missing lat/lng",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return new WP_REST_Response(['success'=>false,'error'=>'latitude/longitude required','user_id'=>$uid,'user_login'=>$ulogin],400); 
  }

  $module=$module.'.lat:'.$lat;  
  $module=$module.'.lng:'.$lng;  
  $km_max=max(0,(float)($p['km_max_distance']??10)); $limit=(int)($p['limit']??20); if($limit<1||$limit>200)$limit=20; $offset=(int)($p['offset']??0);
  $km_max=100000;
  $city_id=(int)($p['city_id']??0);
  $module=$module.'.km_max:'.$km_max;  
  $module=$module.'.city_id:'.$city_id;  

  // [ADI-ADD] status param (BC default: READY; multiple accepted)
  $status_raw = isset($p['status']) ? strtoupper(trim((string)$p['status'])) : '';
  $module=$module.'.status_raw:'.$status_raw;  
  $status_list = array_filter(array_map('trim', explode(',', $status_raw)));
  if(empty($status_list)) $status_list=['READY'];
  // vogo_error_log3("[$module] [STEP 2.1] status_list=".implode(',',$status_list),$module);

  // STEP 3 - Tables
  $t_rej = $wpdb->prefix.'order_transporter_rejects';
  $t_orders=$wpdb->prefix.'orders'; 
  $cityFilter = $city_id>0 ? $wpdb->prepare("AND o.city_id=%d",$city_id) : '';

  // STEP 4 - Query (din wp_orders direct)
// [ADI-ADD] Tables
$t_del = $wpdb->prefix.'orders_delivery';
$t_tr  = $wpdb->prefix.'transporters';
$t_rej = $wpdb->prefix.'order_transporter_rejects';

// [ADI-ADD] Role check (is transporter?)
$is_transporter = true;

// [ADI-ADD] Select cu join-uri pt transporter_info (nu schimbăm filtrele/logica)
// ✅ compat: calc Haversine simplificat cu ACOS; ✅ LOCK respectat; ✅ SQL validat
$earth = isset($earth) ? (float)$earth : 6371.0; // km
$city_id   = isset($city_id)   ? (int)$city_id   : 0;
$client_id = isset($client_id) ? (int)$client_id : 0;
$km_max    = (float)$km_max;
$jwt_user_id = (int)$jwt_user_id;

$where = "WHERE o.pick_latitude IS NOT NULL AND o.pick_longitude IS NOT NULL
  AND o.delivery_type IN ('DIRECT','TAXI')
  AND o.status = 'READY'";

$args = [$lat, $lng, $lat];

if ($city_id > 0){ $where .= " AND o.city_id = %d";   $args[] = $city_id; }
if ($client_id > 0){ $where .= " AND o.client_id = %d"; $args[] = $client_id; }

$sql = "
  SELECT 
    o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
    o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
    o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
    ({$earth}*ACOS(LEAST(1,
      COS(RADIANS(%f))*COS(RADIANS(o.pick_latitude))*COS(RADIANS(o.pick_longitude)-RADIANS(%f)) +
      SIN(RADIANS(%f))*SIN(RADIANS(o.pick_latitude))
    ))) AS distance_calc,
    d.transporter_id,
    t.nickname AS tr_nickname,
    t.plate_number AS tr_plate_number,
    t.auto_type AS tr_auto_type,
    t.auto_model AS tr_auto_model,
    t.auto_colour AS tr_auto_colour,
    t.phone AS tr_phone
  FROM $t_orders o
  LEFT JOIN $t_del d ON d.order_id=o.id
  LEFT JOIN $t_tr  t ON t.user_id=d.transporter_id
  $where
  AND NOT EXISTS (
    SELECT 1 FROM $t_rej r
    WHERE r.order_id=o.id AND r.transporter_id=%d
  )
  HAVING distance_calc <= %f
  ORDER BY distance_calc ASC,o.created_at DESC";

$args[] = $jwt_user_id;
$args[] = $km_max;

$sql = $wpdb->prepare($sql, $args);



vogo_error_log3("SQL exec=[$sql] ");

/* BC-GUARD: ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */

  // vogo_error_log3("##############SQL: $sql",$module);

  // [ADI-ADD] timing SQL exec
  $t_sql_start = microtime(true);
  $rows=$wpdb->get_results($sql,ARRAY_A);
  $t_sql_end = microtime(true);
  vogo_error_log3("[$module] SQL exec=".round(($t_sql_end - $t_sql_start),3)."s | rows=".count($rows),$module);

  if($wpdb->last_error){ 
    // vogo_error_log3("[$module][SQL ERROR] ".$wpdb->last_error,$module); 
    return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON (toate câmpurile + distance fields)
  $out=[]; 

  $labels = [
    'READY' => 'Ready',
    'ACCEPTED' => 'Accepted',
    'STARTED' => 'Started',
    'IN_PROGRESS' => 'In progress',
    'COMMING_SOON' => 'Coming soon',
    'ARRIVED' => 'Arrived'
  ];

  // [ADI-ADD] timing JSON build
$t_json_start = microtime(true);
foreach($rows as $r){

  // [ADI-ADD] transporter_info (only if a transporter is assigned)
  $tr_info = null;
  if(isset($r['transporter_id']) && $r['transporter_id']!==null){
    $tr_info = [
      'user_id'      => (int)$r['transporter_id'],
      'nickname'     => $r['tr_nickname']??null,
      'plate_number' => $r['tr_plate_number']??null,
      'auto_type'    => $r['tr_auto_type']??null,
      'auto_model'   => $r['tr_auto_model']??null,
      'auto_colour'  => $r['tr_auto_colour']??null,
      'phone'        => $r['tr_phone']??null
    ];
  }

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code; // fallback sigur
    $route_text = (string)$r['address_pick'].' -> '.(string)$r['address_end'].'.'.(string)($r['notes_customer']??'').'.'.(string)($r['notes_provider']??'');
    $icon_display = (string)$r['delivery_type']; // cerut: identic cu delivery_type


$out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      // [ADI-ADD] câmpurile cerute (plasate la final pentru BC)
      'status_label'=>$status_label,
      'route_text'=>$route_text,
      'icon_name'=>$icon_display
    ];
}
$t_json_end = microtime(true);
vogo_error_log3("[$module] JSON build=".round(($t_json_end - $t_json_start),3)."s",$module);
/* BC-GUARD: ✅ BC respectat, ✅ LOCK respectat, ✅ SQL validat */


  $next=(count($rows)===$limit)?($offset+$limit):null;
  // vogo_error_log3("[$module] OK | found: ".count($out)." | next:".($next??'null')." | t_sql=".round(($t_sql_end-$t_sql_start),3)."s | t_json=".round(($t_json_end-$t_json_start),3)."s",$module);
  // vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'count'=>count($out),'module' => $module.'.TEND','orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}



function vogo_order_reject(WP_REST_Request $request){
  global $wpdb; $module='order-reject'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START"); vogo_error_log3("[$module] Raw: ".file_get_contents('php://input')." | DB:$db | IP:$ip");

  $transporter_id = (int) extract_user_from_jwt_token($request);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$transporter_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response    
  
  
  if(!$transporter_id){
    vogo_error_log3("[$module] No JWT | IP:$ip"); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'auth'],403);
  }
  $p = $request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0);
  $reason   = isset($p['reason']) ? sanitize_text_field($p['reason']) : '';

  if(!$order_id){
    vogo_error_log3("[$module] Missing order_id"); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id required'],400);
  }

  $lat = isset($p['lat']) ? (float)$p['lat'] : null;
  $long = isset($p['long']) ? (float)$p['long'] : null;
  if($lat===null || $long===null){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR2','error'=>'lat_and_long_required'],400);
  }
  if($lat<-90 || $lat>90 || $long<-180 || $long>180){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR3','error'=>'lat_long_out_of_range'],400);
  }

  // opțional: verificăm că orderul există în wp_orders
  $t_orders = $wpdb->prefix.'orders';
  $exists = (int)$wpdb->get_var($wpdb->prepare("SELECT id FROM $t_orders WHERE id=%d", $order_id));
  vogo_error_log3("##############SQL: SELECT id FROM $t_orders WHERE id=$order_id");
  if(!$exists){
    vogo_error_log3("[$module] order not found"); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_not_found'],404);
  }

  // upsert în lista de reject/ignore
  $t_rej = $wpdb->prefix.'order_transporter_rejects';
  $sql = $wpdb->prepare("
    INSERT INTO $t_rej (order_id, transporter_id, reason, created_by)
    VALUES (%d, %d, %s, %d)
    ON DUPLICATE KEY UPDATE
      reason=VALUES(reason),
      created_at=CURRENT_TIMESTAMP,
      created_by=VALUES(created_by)
  ", $order_id, $transporter_id, $reason, $transporter_id);
  vogo_error_log3("##############SQL: $sql");
  $ok = $wpdb->query($sql);
  if($ok===false){
    vogo_error_log3("[$module] SQL error: ".$wpdb->last_error); vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql','sql_message'=>$wpdb->last_error],500);
  }

  vogo_error_log3("[$module] OK | order:$order_id | transporter:$transporter_id | IP:$ip"); vogo_error_log3("VOGO_LOG_END");
  return new WP_REST_Response(['success'=>true,'order_id'=>$order_id,'module' => $module.'.TEND','status'=>'REJECTED_FOR_USER'],200);
}//vogo_order_reject

function vogo_transporter_update_status_notes(WP_REST_Request $request){
  global $wpdb; $module='transporter-status'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN';

  $transporter_id = (int) extract_user_from_jwt_token($request);
  if(!$transporter_id){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'auth'],403);
  }

  $p = $request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0);
  $status_in = isset($p['status']) ? strtoupper(trim($p['status'])) : '';
  $notes_in  = array_key_exists('transporter_notes', $p) ? trim((string)$p['transporter_notes']) : null;

  if(!$order_id || (!$status_in && $notes_in===null)){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id and at least one of status/transporter_notes required'],400);
  }

  $t_ot   = $wpdb->prefix.'orders_delivery';   // [UPDATE] folosim orders_delivery
  $t_od   = $wpdb->prefix.'orders_delivery';
  $t_ord  = $wpdb->prefix.'orders';

  // 1) verifică mapping: acest order e al acestui transporter?
  $row = $wpdb->get_row(
    $wpdb->prepare("
      SELECT d.id, o.client_id, o.provider_id, d.current_status AS status, d.notes
        FROM $t_ot d
        JOIN $t_ord o ON o.id = d.order_id
       WHERE d.order_id=%d AND d.transporter_id=%d
       LIMIT 1
    ", $order_id, $transporter_id),
    ARRAY_A
  );
  if(!$row){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'not_assigned'],403);
  }

  $current = strtoupper($row['status'] ?? 'ACCEPTED');
  if(in_array($current, ['CLOSED','CANCELLED'])){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_inactive','status'=>$current],409);
  }

  // 2) validare flow (numai upgrade)
  $flow = ['ACCEPTED'=>1,'STARTED'=>2,'IN_PROGRESS'=>3,'COMMING_SOON'=>4,'ARRIVED'=>5,'DELIVERED'=>6,'CLOSED'=>7,'CANCELLED'=>8];
  $new_status = $current;
  $status_changed = false;

  if($status_in){
    if(!isset($flow[$status_in])){
      return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'invalid_status'],400);
    }
    if($flow[$status_in] < ($flow[$current] ?? 0)){
      return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'cannot_downgrade','current_status'=>$current],409);
    }
    if($status_in !== $current){
      $new_status = $status_in;
      $status_changed = true;
    }
  }

  // 3) update în master (simplu: suprascriem; dacă notes_in e null, păstrăm notes curente)
  $upd_notes = ($notes_in !== null) ? $notes_in : $row['notes'];

  $ok = $wpdb->update($t_ot, [
      'current_status' => $new_status,     // [UPDATE] coloana din orders_delivery
      'notes'          => $upd_notes,
      'modified_at'    => current_time('mysql', 1),
      'modified_by'    => $transporter_id
    ],
    ['id'=>(int)$row['id']],
    ['%s','%s','%s','%d'],
    ['%d']
  );
  if($ok===false){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql','sql_message'=>$wpdb->last_error],500);
  }

  // 4) oglinzim note în wp_orders (dacă ai coloana)
  if($notes_in !== null){
    $wpdb->query($wpdb->prepare("UPDATE $t_ord SET notes_transporter=%s WHERE id=%d", $notes_in, $order_id));
  }

  // 5) sincronizare orders_delivery
  if($status_changed){
    if(in_array($new_status, ['DELIVERED','CLOSED'])){
      $wpdb->query($wpdb->prepare("
        UPDATE $t_od
           SET current_status=%s,
               transporter_id=%d,
               transport_end_date = IFNULL(transport_end_date, UTC_TIMESTAMP())
         WHERE order_id=%d
      ", $new_status, $transporter_id, $order_id));
    } else {
      $wpdb->query($wpdb->prepare("
        UPDATE $t_od
           SET current_status=%s,
               transporter_id=%d
         WHERE order_id=%d
      ", $new_status, $transporter_id, $order_id));
    }
  }

  // 6) push pe praguri selectate
  if($status_changed && in_array($new_status, ['COMMING_SOON','ARRIVED','DELIVERED','CLOSED'])){
    try{
      if(function_exists('vogo_fcm_send_to_user')){
        @vogo_fcm_send_to_user((int)$row['client_id'],
          'Order '.$new_status,
          'Order #'.$order_id.' status: '.$new_status,
          ['order_id'=>$order_id,'status'=>$new_status]
        );
      }
    } catch(Throwable $e){}
  }

  return new WP_REST_Response([
    'success'=>true,
    'order_id'=>$order_id,
    'status'=>$new_status,
    'transporter_notes'=>($notes_in !== null ? $notes_in : $row['notes'])
  ],200);
} //vogo_transporter_update_status_notes



function transport_finish(WP_REST_Request $request){
  global $wpdb;
  $module='transport-finish'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown", $module);

  // STEP 1 - JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[STEP 1] JWT extraction failed | IP:$ip", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return $user_or_err; }
  $user_id = (int)$user_or_err; $u=get_user_by('id',$user_id); $user_login=$u?$u->user_login:'unknown';
  vogo_error_log3("[STEP 1] JWT ok | user_id:$user_id | user_login:$user_login | IP:$ip", $module);

      //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$user_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response    

  // STEP 2 - Input
  $p = $request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($p), $module);
  $order_id = (int)($p['order_id']??0);
  if($order_id<=0){ vogo_error_log3("[STEP 2] Missing order_id | IP:$ip | user:$user_id", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id_required','user_id'=>$user_id,'user_login'=>$user_login],400); }


  $lat = isset($p['lat']) ? (float)$p['lat'] : null;
  $long = isset($p['long']) ? (float)$p['long'] : null;
  if($lat===null || $long===null){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR2','error'=>'lat_and_long_required'],400);
  }
  if($lat<-90 || $lat>90 || $long<-180 || $long>180){
    return new WP_REST_Response(['success'=>false,'module'=>$module.'.ERR3','error'=>'lat_long_out_of_range'],400);
  }
  // STEP 3 - Tables
  $t_ord = $wpdb->prefix.'orders';
  $t_del = $wpdb->prefix.'orders_delivery';

  // STEP 4 - Validate order + delivery mapping
  $sql_order = $wpdb->prepare("SELECT id FROM $t_ord WHERE id=%d LIMIT 1",$order_id);
  vogo_error_log3("##############SQL: $sql_order", $module);
  $order_exists = (bool)$wpdb->get_var($sql_order);
  if(!$order_exists){ vogo_error_log3("[STEP 4] Order not found | order_id:$order_id | user:$user_id", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'error'=>'order_not_found','order_id'=>$order_id],404); }

  $sql_del = $wpdb->prepare("SELECT transporter_id,current_status FROM $t_del WHERE order_id=%d LIMIT 1",$order_id);
  vogo_error_log3("##############SQL: $sql_del", $module);
  $del = $wpdb->get_row($sql_del, ARRAY_A);
  if(!$del){ vogo_error_log3("[STEP 4] Delivery mapping missing | order_id:$order_id | user:$user_id", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_not_assigned','order_id'=>$order_id],403); }

  $assigned_tid = isset($del['transporter_id']) ? (int)$del['transporter_id'] : 0;
  $cur_status   = strtoupper((string)($del['current_status']??''));
  if($assigned_tid!==$user_id){ vogo_error_log3("[STEP 4] Not your order | assigned:$assigned_tid | you:$user_id | order:$order_id", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'not_assigned_to_you','assigned_transporter_id'=>$assigned_tid,'order_id'=>$order_id],403); }

  // Idempotency
  if($cur_status==='FINISHED'){ vogo_error_log3("[STEP 4] Already FINISHED (idempotent) | order:$order_id | user:$user_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>true,'message'=>'already_finished','order_id'=>$order_id,'transporter_id'=>$user_id,'final_status'=>'FINISHED','user_id'=>$user_id,'user_login'=>$user_login],200);
  }

  // STEP 5 - Transition to FINISHED
  $finishable=['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','DELIVERED'];
  $ph = implode(',', array_fill(0,count($finishable),'%s'));

  $wpdb->query('START TRANSACTION');

  $sql_upd_del = $wpdb->prepare("UPDATE $t_del SET current_status='FINISHED', modified_by=%d, modified_at=UTC_TIMESTAMP() WHERE order_id=%d AND transporter_id=%d AND UPPER(current_status) IN ($ph)",
    array_merge([$user_id,$order_id,$user_id], $finishable)
  );
  vogo_error_log3("##############SQL: $sql_upd_del", $module);
  $wpdb->query($sql_upd_del);
  if($wpdb->last_error){ $wpdb->query('ROLLBACK'); vogo_error_log3("[STEP 5][SQL ERROR] {$wpdb->last_error}", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }

  if($wpdb->rows_affected===0){
    $st = strtoupper((string)$wpdb->get_var($wpdb->prepare("SELECT current_status FROM $t_del WHERE order_id=%d LIMIT 1",$order_id)));
    if($st==='FINISHED'){ $wpdb->query('COMMIT'); vogo_error_log3("[STEP 5] Already FINISHED after recheck | order:$order_id",$module); }
    else { $wpdb->query('ROLLBACK'); vogo_error_log3("[STEP 5] Not in finishable state | status:$st | order:$order_id",$module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'not_in_finishable_state','current_status'=>$st,'order_id'=>$order_id],409); }
  } else {
    // Sync wp_orders
    $sql_upd_ord = $wpdb->prepare("UPDATE $t_ord SET status='FINISHED', modified_by=%d, modified_at=UTC_TIMESTAMP() WHERE id=%d LIMIT 1",$user_id,$order_id);
    vogo_error_log3("##############SQL: $sql_upd_ord", $module);
    $wpdb->query($sql_upd_ord);
    if($wpdb->last_error){ $wpdb->query('ROLLBACK'); vogo_error_log3("[STEP 5][SQL ERROR] {$wpdb->last_error}", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error],500); }
    $wpdb->query('COMMIT');
  }

  transporter_save_position_and_sync_delivery($order_id, $user_id, $lat, $long);
  vogo_error_log3("[STEP 6] FINISHED ok | order_id:$order_id | transporter:$user_id | IP:$ip", $module);
  vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);

  return new WP_REST_Response([
    'success'=>true,
    'order_id'=>$order_id,
    'module' => $module.'.TEND',
    'transporter_id'=>$user_id,
    'final_status'=>'FINISHED',
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
} //transport_finish

/**
 * Cancel a transport order by the assigned transporter for emergencies.
 * Business rules:
 * - Only the transporter currently assigned to the order can cancel it.
 * - Delivery mapping (wp_orders_delivery) becomes CANCELLED and stores reason.
 * - Order (wp_orders) becomes AVAILABLE (open for other transporters).
 * - Idempotent: if already CANCELLED by the same user, returns success.
 */
function transport_cancel(WP_REST_Request $request){
  global $wpdb;
  $module='transport-cancel'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown", $module);

  // STEP 1 - Extract user from JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[STEP 1] JWT extraction failed | IP:$ip", $module); vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module); return $user_or_err; }
  $user_id = intval($user_or_err); $u = get_user_by('id',$user_id); $user_login = $u ? $u->user_login : 'unknown';
  vogo_error_log3("[STEP 1] JWT ok | user_id:$user_id | user_login:$user_login | IP:$ip", $module);

      //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$user_id;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response    


  // STEP 2 - Parse payload
  $params = $request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".wp_json_encode($params), $module);
  $order_id = intval($params['order_id'] ?? 0);
  $cancel_reason = trim((string)($params['cancelletion_reason'] ?? $params['cancellation_reason'] ?? $params['reason'] ?? ''));
  if ($order_id<=0){
    vogo_error_log3("[STEP 2] Missing order_id | IP:$ip | user:$user_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_id_required','user_id'=>$user_id,'user_login'=>$user_login],400);
  }
  if ($cancel_reason===''){ $cancel_reason='not provided'; }

  // STEP 3 - Tables
  $t_ord = $wpdb->prefix.'orders';
  $t_del = $wpdb->prefix.'orders_delivery';

  // STEP 4 - Validate order + delivery mapping (assignment & current status)
  $sql_order = $wpdb->prepare("SELECT id FROM $t_ord WHERE id=%d LIMIT 1",$order_id);
  vogo_error_log3("##############SQL: $sql_order", $module);
  $order_exists = (bool)$wpdb->get_var($sql_order);
  if(!$order_exists){
    vogo_error_log3("[STEP 4] Order not found | order_id:$order_id | user:$user_id | IP:$ip", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_not_found','user_id'=>$user_id,'user_login'=>$user_login],404);
  }

  $sql_del = $wpdb->prepare("SELECT transporter_id,current_status FROM $t_del WHERE order_id=%d LIMIT 1",$order_id);
  vogo_error_log3("##############SQL: $sql_del", $module);
  $del = $wpdb->get_row($sql_del, ARRAY_A);
  if(!$del){
    vogo_error_log3("[STEP 4] Delivery mapping missing | order_id:$order_id | user:$user_id | IP:$ip", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'order_not_assigned','order_id'=>$order_id,'user_id'=>$user_id,'user_login'=>$user_login],403);
  }

  $assigned_tid = isset($del['transporter_id']) ? (int)$del['transporter_id'] : 0;
  $cur_status   = strtoupper((string)($del['current_status']??''));
  if($assigned_tid!==$user_id){
    vogo_error_log3("[STEP 4] Not your order | assigned:$assigned_tid | you:$user_id | order:$order_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'not_assigned_to_you','assigned_transporter_id'=>$assigned_tid,'order_id'=>$order_id],403);
  }

  // Idempotency: if already CANCELLED, ensure order is AVAILABLE and return success
  if($cur_status==='CANCELLED'){
    $sql_upd_order_idem = $wpdb->prepare("UPDATE $t_ord SET status='AVAILABLE', modified_by=%d, modified_at=UTC_TIMESTAMP() WHERE id=%d LIMIT 1",$user_id,$order_id);
    vogo_error_log3("##############SQL: $sql_upd_order_idem", $module);
    $wpdb->query($sql_upd_order_idem);
    if ($wpdb->last_error){ vogo_error_log3("[IDEMPOTENT][SQL WARNING] {$wpdb->last_error}", $module); }
    vogo_error_log3("[STEP 4] Already CANCELLED (idempotent) | order_id:$order_id | user:$user_id | IP:$ip", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response([
      'success'=>true,
      'module' => $module.'.TEND',
      'message'=>'already_cancelled',
      'order_id'=>$order_id,
      'transporter_id'=>$user_id,
      'final_status'=>'CANCELLED',
      'order_status'=>'AVAILABLE',
      'cancel_reason'=>$cancel_reason,
      'user_id'=>$user_id,
      'user_login'=>$user_login
    ],200);
  }

  // STEP 5 - Transition to CANCELLED in delivery + reopen order
  $cancellable=['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','DELIVERED'];
  $ph = implode(',', array_fill(0,count($cancellable),'%s'));

  $wpdb->query('START TRANSACTION');

  $sql_upd_del = $wpdb->prepare(
    "UPDATE $t_del
       SET current_status='CANCELLED',
           cancel_reason=%s,
           modified_by=%d,
           modified_at=UTC_TIMESTAMP()
     WHERE order_id=%d
       AND transporter_id=%d
       AND UPPER(current_status) IN ($ph)",
    array_merge([$cancel_reason,$user_id,$order_id,$user_id], $cancellable)
  );
  vogo_error_log3("##############SQL: $sql_upd_del", $module);
  $wpdb->query($sql_upd_del);
  if($wpdb->last_error){
    $wpdb->query('ROLLBACK');
    vogo_error_log3("[STEP 5][SQL ERROR] {$wpdb->last_error} | IP:$ip | user:$user_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
  }

  if($wpdb->rows_affected===0){
    $st = strtoupper((string)$wpdb->get_var($wpdb->prepare("SELECT current_status FROM $t_del WHERE order_id=%d LIMIT 1",$order_id)));
    $wpdb->query('ROLLBACK');
    vogo_error_log3("[STEP 5] Not in cancellable state | status:$st | order:$order_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'not_in_cancellable_state','current_status'=>$st,'order_id'=>$order_id],409);
  }

  // Sync wp_orders to AVAILABLE
  $sql_upd_ord = $wpdb->prepare("UPDATE $t_ord SET status='AVAILABLE', modified_by=%d, modified_at=UTC_TIMESTAMP() WHERE id=%d LIMIT 1",$user_id,$order_id);
  vogo_error_log3("##############SQL: $sql_upd_ord", $module);
  $wpdb->query($sql_upd_ord);
  if($wpdb->last_error){
    $wpdb->query('ROLLBACK');
    vogo_error_log3("[STEP 5][SQL ERROR] {$wpdb->last_error} | IP:$ip | user:$user_id", $module);
    vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login],500);
  }

  $wpdb->query('COMMIT');

  vogo_error_log3("[STEP 6] CANCELLED ok | order_id:$order_id | transporter:$user_id | reason:$cancel_reason | IP:$ip", $module);
  vogo_error_log3("VOGO_LOG_END | MODULE:$module", $module);

  return new WP_REST_Response([
    'success'        => true,
    'module' => $module.'.TEND',
    'order_id'       => $order_id,
    'transporter_id' => $user_id,
    'final_status'   => 'CANCELLED',
    'order_status'   => 'AVAILABLE',
    'cancel_reason'  => $cancel_reason,
    'user_id'        => $user_id,
    'user_login'     => $user_login
  ],200);
}//transport_cancel



//nu o mai folosesc acum - de verificat - am mers pe available orders
function client_orders_list(WP_REST_Request $request){
  global $wpdb; $module='client-orders'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | DB:$db | IP:$ip",$module);

  // STEP 1 - JWT (client)
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ vogo_error_log3("[$module] JWT failed",$module); vogo_error_log3("VOGO_LOG_END",$module); return $user_or_err; }
  $client_id=(int)$user_or_err; $u=get_user_by('id',$client_id); $user_login=$u?$u->user_login:'unknown';
  vogo_error_log3("[$module] JWT ok | client_id:$client_id | user_login:$user_login",$module);

  // STEP 2 - Payload
  $p=$request->get_json_params(); vogo_error_log3("[$module] RAW: ".wp_json_encode($p),$module);
  $limit=(int)($p['limit']??50); if($limit<1||$limit>200)$limit=50; $offset=(int)($p['offset']??0);

  // single status filter (CSV sau array). Normalizăm la UPPER și 'CANCELED'->'CANCELLED'
  $norm_csv=function($v){ if(is_array($v)) return $v; if(is_string($v)) return preg_split('/\s*,\s*/',trim($v),-1,PREG_SPLIT_NO_EMPTY); return []; };
  $statuses=array_map(function($s){ $x=strtoupper(trim($s)); return $x==='CANCELED'?'CANCELLED':$x; }, $norm_csv($p['status']??[]));
  $statuses=array_values(array_filter($statuses));

  // STEP 3 - Tables & dynamic dest cols
  $t_o=$wpdb->prefix.'orders'; $t_d=$wpdb->prefix.'orders_delivery';
  $destLatSel = vogo_col_exists($t_d,'dest_lat')?'od.dest_lat':(vogo_col_exists($t_d,'drop_latitude')?'od.drop_latitude':'NULL');
  $destLngSel = vogo_col_exists($t_d,'dest_lng')?'od.dest_lng':(vogo_col_exists($t_d,'drop_longitude')?'od.drop_longitude':'NULL');

  // STEP 4 - WHERE (un singur status filter aplicat unificat)
  $w=[]; $w[]=$wpdb->prepare("o.client_id=%d",$client_id);
  if(!empty($statuses)){
    $in="'".implode("','",array_map('esc_sql',$statuses))."'";
    $w[]="(UPPER(o.status) IN ($in) OR UPPER(od.current_status) IN ($in) OR UPPER(od.transport_status) IN ($in))";
  }
  $where='WHERE '.implode(' AND ',$w);

  // STEP 5 - ORDER BY pe status_unified + created_at
  $prio="'READY','ASSIGNED','STARTED','EN_ROUTE','DELIVERED','CANCELLED','PAID','NEW','FINISHED'";
  $orderBy="FIELD(COALESCE(UPPER(od.current_status),UPPER(o.status),UPPER(od.transport_status)),$prio) ASC, o.created_at DESC";

  // STEP 6 - SQL (LEFT JOIN ca să apară comanda și fără rând în delivery)
  $sql="
    SELECT
      /* wp_orders */
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status AS o_status,o.created_at AS o_created_at,
      /* wp_orders_delivery */
      od.id AS od_id,od.order_id,od.delivery_type,od.current_status,od.accepted_date,od.transporter_id,od.transport_status,od.transport_end_date,
      od.last_lat,od.last_lng,od.last_update_at,od.created_at AS od_created_at,od.created_by,od.modified_at AS od_modified_at,od.modified_by,
      {$destLatSel} AS dest_lat, {$destLngSel} AS dest_lng,
      /* unified status for sort/filter/output */
      COALESCE(UPPER(od.current_status), UPPER(o.status), UPPER(od.transport_status), 'NEW') AS status_unified
    FROM $t_o o
    LEFT JOIN $t_d od ON od.order_id=o.id
    $where
    ORDER BY $orderBy
    LIMIT %d OFFSET %d
  ";
  $sql=$wpdb->prepare($sql,$limit,$offset);
  vogo_error_log3("##############SQL: $sql",$module);

  $rows=$wpdb->get_results($sql,ARRAY_A);
  if($wpdb->last_error){
    vogo_error_log3("[$module][SQL ERROR] ".$wpdb->last_error,$module);
    vogo_error_log3("VOGO_LOG_END",$module);
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error,'user_id'=>$client_id,'user_login'=>$user_login],500);
  }

  // STEP 7 - Compute road trip pick->dest; fallback 7.3 dacă nu se poate
  $out=[];
  foreach($rows as $r){
    $tripKm=null;
    if(!empty($r['pick_latitude']) && !empty($r['pick_longitude']) && $r['dest_lat']!==null && $r['dest_lng']!==null){
      $km=vogo_osrm_route_km((float)$r['pick_latitude'],(float)$r['pick_longitude'],(float)$r['dest_lat'],(float)$r['dest_lng']);
      if($km===null){ $km=vogo_geodesic_km((float)$r['pick_latitude'],(float)$r['pick_longitude'],(float)$r['dest_lat'],(float)$r['dest_lng']); }
      $tripKm=$km!==null?round($km,3):null;
    }
    $out[]=[
      'status_unified'=>$r['status_unified'], // un singur status expus
      'order'=>[
        'id'=>(int)$r['o_id'],'client_id'=>(int)$r['client_id'],'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],'notes_provider'=>$r['notes_provider'],'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],'total_amount'=>(float)$r['total_amount'],'status'=>$r['o_status'],'created_at'=>$r['o_created_at'],
      ],
      'delivery'=>[
        'id'=>$r['od_id']!==null?(int)$r['od_id']:null,'order_id'=>$r['order_id']!==null?(int)$r['order_id']:null,
        'delivery_type'=>$r['delivery_type']??null,'current_status'=>$r['current_status']??null,'accepted_date'=>$r['accepted_date']??null,
        'transporter_id'=>$r['transporter_id']!==null?(int)$r['transporter_id']:null,'transport_status'=>$r['transport_status']??null,
        'transport_end_date'=>$r['transport_end_date']??null,'last_lat'=>$r['last_lat']!==null?(float)$r['last_lat']:null,
        'last_lng'=>$r['last_lng']!==null?(float)$r['last_lng']:null,'last_update_at'=>$r['last_update_at']??null,
        'created_at'=>$r['od_created_at']??null,'created_by'=>$r['created_by']!==null?(int)$r['created_by']:null,
        'modified_at'=>$r['od_modified_at']??null,'modified_by'=>$r['modified_by']!==null?(int)$r['modified_by']:null,
        'dest_lat'=>($r['dest_lat']!==null)?(float)$r['dest_lat']:null,'dest_lng'=>($r['dest_lng']!==null)?(float)$r['dest_lng']:null
      ],
      'estimated_km_trip_on_roads'=>($tripKm===null?7.3:$tripKm) // fallback cerut
    ];
  }

  $next=(count($rows)===$limit)?($offset+$limit):null;
  vogo_error_log3("[$module] OK | client:$client_id | found: ".count($out)." | next:".($next??'null'),$module);
  vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','count'=>count($out),'orders'=>$out,'next_offset'=>$next,'user_id'=>$client_id,'user_login'=>$user_login],200);
}//client_orders_list

function wp_orders_calculate_fields(WP_REST_Request $request){
  global $wpdb; $module='orders-calc'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  vogo_error_log3("VOGO_LOG_START | MODULE:$module | DB:$db | IP:$ip | USER:unknown",$module);

  $orders_tbl=$wpdb->prefix.'orders';
  $rows=$wpdb->get_results("SELECT id,pick_latitude,pick_longitude,end_lat,end_long FROM $orders_tbl WHERE calculated_fields=0 LIMIT 100",ARRAY_A);
  $updated=0;

  $geo=function($a1,$o1,$a2,$o2){
    $R=6371; $dLat=deg2rad($a2-$a1); $dLon=deg2rad($o2-$o1);
    $la1=deg2rad($a1); $la2=deg2rad($a2);
    $h=sin($dLat/2)**2+cos($la1)*cos($la2)*sin($dLon/2)**2;
    return 2*$R*asin(min(1,sqrt($h)));
  };

  foreach($rows as $r){
    if($r['pick_latitude']!==null && $r['pick_longitude']!==null && $r['end_lat']!==null && $r['end_long']!==null){
      $km=$geo((float)$r['pick_latitude'],(float)$r['pick_longitude'],(float)$r['end_lat'],(float)$r['end_long']);
      $wpdb->update($orders_tbl,
        ['distance_km'=>round($km,3),'calculated_fields'=>1],
        ['id'=>(int)$r['id']],
        ['%f','%d'],['%d']
      );
      $updated++;
    } else {
      $wpdb->update($orders_tbl,['calculated_fields'=>1],['id'=>(int)$r['id']],['%d'],['%d']);
    }
  }

  vogo_error_log3("[$module] Updated:$updated",$module);
  vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','updated'=>$updated],200);
}//wp_orders_calculate_fields

function client_get_my_orders(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  // vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    // vogo_error_log3("[$module] JWT failed | IP:$ip",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response  

  // [ONLY CLIENT] role check
  $roles = $u && is_array($u->roles) ? $u->roles : [];
  if( !in_array('customer', $roles, true) ){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'role_customer_required','user_id'=>$uid,'user_login'=>$ulogin],403);
  }
  // vogo_error_log3("[$module] JWT ok | user_id:$uid | user_login:$ulogin",$module);

  // STEP 2 - Payload
  $p=$request->get_json_params(); 
  // vogo_error_log3("[$module] [STEP 0.1] Raw: ".wp_json_encode($p),$module);
  $lat=(float)($p['latitude']??0); $lng=(float)($p['longitude']??0); 
  if(!$lat||!$lng){ 
    // vogo_error_log3("[$module] Missing lat/lng",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'latitude/longitude required','user_id'=>$uid,'user_login'=>$ulogin],400); 
  }
  $km_max=max(0,(float)($p['km_max_distance']??10)); $limit=(int)($p['limit']??20); if($limit<1||$limit>200)$limit=20; $offset=(int)($p['offset']??0);
  $city_id=(int)($p['city_id']??0);

  

  // [ADI-ADD] status param (BC default: READY; multiple accepted)
  $status_raw = isset($p['status']) ? strtoupper(trim((string)$p['status'])) : '';
  $module=$module.'.status_raw:'.$status_raw;
  $status_list = array_filter(array_map('trim', explode(',', $status_raw)));
  if(empty($status_list)) $status_list=['READY'];
  // vogo_error_log3("[$module] [STEP 2.1] status_list=".implode(',',$status_list),$module);

  // STEP 3 - Tables
  $t_orders=$wpdb->prefix.'orders'; $earth=6371;
  $cityFilter = $city_id>0 ? $wpdb->prepare("AND o.city_id=%d",$city_id) : '';

  // [ADI-ONLY-CLIENT] Tables necesare pt info transport
  $t_del = $wpdb->prefix.'orders_delivery';
  $t_tr  = $wpdb->prefix.'transporters';

  // [ADI-ONLY-CLIENT] Filtru strict pe client_id
  $clientFilter = ' AND o.client_id=%d';

  // [ADI-ONLY-CLIENT] SQL (fără rejects / fără ramură transporter)
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));
  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      ($earth*ACOS(LEAST(1,
        COS(RADIANS(%f))*COS(RADIANS(o.pick_latitude))*COS(RADIANS(o.pick_longitude)-RADIANS(%f)) +
        SIN(RADIANS(%f))*SIN(RADIANS(o.pick_latitude))
      ))) AS distance_calc,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    LEFT JOIN $t_del d ON d.order_id=o.id
    LEFT JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE o.pick_latitude IS NOT NULL AND o.pick_longitude IS NOT NULL
      $cityFilter
      AND o.delivery_type='DIRECT'
      AND o.status IN ($placeholders)
      $clientFilter
    HAVING distance_calc <= %f
    ORDER BY distance_calc ASC,o.created_at DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge([$lat,$lng,$lat], $status_list, [$uid, $km_max, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);

  vogo_error_log3("SQL exec=[$sql] ");

  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  // vogo_error_log3("##############SQL: $sql",$module);

  // [ADI-ADD] timing SQL exec
  $t_sql_start = microtime(true);
  $rows=$wpdb->get_results($sql,ARRAY_A);
  $t_sql_end = microtime(true);
  vogo_error_log3("[$module] SQL exec=".round(($t_sql_end - $t_sql_start),3)."s | rows=".count($rows),$module);

  if($wpdb->last_error){ 
    // vogo_error_log3("[$module][SQL ERROR] ".$wpdb->last_error,$module); 
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON (toate câmpurile + distance fields)
  $out=[]; 
  // [ADI-ADD] timing JSON build
  $t_json_start = microtime(true);
  foreach($rows as $r){

    // [ADI-ADD] transporter_info (optional, dacă există asignare)
    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$r['status'],
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>round((float)$r['distance_calc'],3),
      // [ADI-ADD] append transporter_info at the end to preserve BC
      'transporter_info'=>$tr_info
    ];
  }
  $t_json_end = microtime(true);
  vogo_error_log3("[$module] JSON build=".round(($t_json_end - $t_json_start),3)."s",$module);
  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  $next=(count($rows)===$limit)?($offset+$limit):null;
  // vogo_error_log3("[$module] OK | found: ".count($out)." | next:".($next??'null')." | t_sql=".round(($t_sql_end-$t_sql_start),3)."s | t_json=".round(($t_json_end-$t_json_start),3)."s",$module);
  // vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','count'=>count($out),'orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}//client_get_my_orders

function client_get_active_drive_orders(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  // vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    // vogo_error_log3("[$module] JWT failed | IP:$ip",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response  

  // [ONLY CLIENT] role check
  $roles = $u && is_array($u->roles) ? $u->roles : [];
  if( !in_array('customer', $roles, true) ){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'role_customer_required','user_id'=>$uid,'user_login'=>$ulogin],403);
  }
  // vogo_error_log3("[$module] JWT ok | user_id:$uid | user_login:$ulogin",$module);

  // STEP 2 - Payload (NO PARAMS ACCEPTED) – Adi stay on request
  // $p=$request->get_json_params(); // not used by design

  // STEP 3 - Tables
  $t_orders=$wpdb->prefix.'orders';
  $t_del = $wpdb->prefix.'orders_delivery';
  $t_tr  = $wpdb->prefix.'transporters';

  // [ADI-ONLY-CLIENT] Filtru strict pe client_id
  $clientFilter = ' AND o.client_id=%d';

  // [ADI-ADD] Status list fix (fără input de la client)
  $status_list = ['READY','ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED'];
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));

  // [ADI-ADD] LIMIT/ OFFSET interne (fără input) – conservative defaults
  $limit = 200; $offset = 0;

  // [ADI-ONLY-CLIENT] SQL (fără filtrare pe distanță; calculăm distanța cursei)
  $earth = 6371;
  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      ($earth*ACOS(LEAST(1,
        COS(RADIANS(o.pick_latitude))*COS(RADIANS(o.end_lat))*COS(RADIANS(o.end_long)-RADIANS(o.pick_longitude)) +
        SIN(RADIANS(o.pick_latitude))*SIN(RADIANS(o.end_lat))
      ))) AS distance_calc,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    LEFT JOIN $t_del d ON d.order_id=o.id
    LEFT JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE 1=1
      AND o.delivery_type in ('DIRECT','TAXI')
      AND o.status IN ($placeholders)
      $clientFilter
    ORDER BY o.created_at DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge($status_list, [$uid, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);

  vogo_error_log3("SQL exec=[$sql] ");

  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  // [ADI-ADD] timing SQL exec
  $t_sql_start = microtime(true);
  $rows=$wpdb->get_results($sql,ARRAY_A);
  $t_sql_end = microtime(true);
  vogo_error_log3("[$module] SQL exec=".round(($t_sql_end - $t_sql_start),3)."s | rows=".count($rows),$module);

  if($wpdb->last_error){ 
    // vogo_error_log3("[$module][SQL ERROR] ".$wpdb->last_error,$module); 
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON (same fields + requested extras)
  $out=[]; 
  // [ADI-ADD] status labels (EN) – fallback la cod
  $labels = [
    'READY' => 'Ready',
    'ACCEPTED' => 'Accepted',
    'STARTED' => 'Started',
    'IN_PROGRESS' => 'In progress',
    'COMMING_SOON' => 'Coming soon',
    'ARRIVED' => 'Arrived'
  ];
  // [ADI-ADD] timing JSON build
  $t_json_start = microtime(true);
  foreach($rows as $r){

    // [ADI-ADD] transporter_info (optional, dacă există asignare)
    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code; // fallback sigur
    $route_text = (string)$r['address_pick'].' -> '.(string)$r['address_end'].'.'.(string)($r['notes_customer']??'').'.'.(string)($r['notes_provider']??'');

    $icon_display = (string)$r['delivery_type']; // cerut: identic cu delivery_type

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      // [ADI-ADD] câmpurile cerute (plasate la final pentru BC)
      'status_label'=>$status_label,
      'route_text'=>$route_text,
      'icon_name'=>$icon_display
    ];
  }
  $t_json_end = microtime(true);
  vogo_error_log3("[$module] JSON build=".round(($t_json_end - $t_json_start),3)."s",$module);
  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  $next=null;
  // vogo_error_log3("[$module] OK | found: ".count($out)." | next:".($next??'null')." | t_sql=".round(($t_sql_end-$t_sql_start),3)."s | t_json=".round(($t_json_end-$t_json_start),3)."s",$module);
  // vogo_error_log3("VOGO_LOG_END",$module);

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','count'=>count($out),'orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}//client_get_active_drive_orders

function client_add_new_drive_order(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  // vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    // vogo_error_log3("[$module] JWT failed | IP:$ip",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response  

  // [ONLY CLIENT] role check
  $roles = $u && is_array($u->roles) ? $u->roles : [];
  if( !in_array('customer', $roles, true) ){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'role_customer_required','user_id'=>$uid,'user_login'=>$ulogin],403);
  }
  // vogo_error_log3("[$module] JWT ok | user_id:$uid | user_login:$ulogin",$module);

  // STEP 2 - Payload
  $p=$request->get_json_params(); 
  // vogo_error_log3("[$module] [STEP 0.1] Raw: ".wp_json_encode($p),$module);

  $pick_lat = (float)($p['pick_latitude']??0);
  $pick_lng = (float)($p['pick_longitude']??0);
  $end_lat  = (float)($p['end_lat']??0);
  $end_lng  = (float)($p['end_long']??0);
  $address_pick = isset($p['address_pick']) ? trim((string)$p['address_pick']) : '';
  $address_end  = isset($p['address_end'])  ? trim((string)$p['address_end'])  : '';
  $notes_customer= isset($p['notes_customer']) ? (string)$p['notes_customer'] : '';
  $city_id_req = isset($p['city_id']) ? (int)$p['city_id'] : 0; // [ADI-ADD] city_id from request (optional)

  if(!$pick_lat||!$pick_lng||!$end_lat||!$end_lng||$address_pick===''||$address_end===''){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'required_fields_missing','user_id'=>$uid,'user_login'=>$ulogin],400);
  }

  // STEP 3 - Compute distance + city_id by nearest city (from ${prefix}cities)
  $earth=6371;
  $distance_calc = $earth*acos(min(1.0,
    cos(deg2rad($pick_lat))*cos(deg2rad($end_lat))*cos(deg2rad($end_lng)-deg2rad($pick_lng)) +
    sin(deg2rad($pick_lat))*sin(deg2rad($end_lat))
  ));
  $distance_km = is_finite($distance_calc) ? (float)$distance_calc : 0.0; // fallback sigur

  $t_cities = $wpdb->prefix.'cities';
  $sqlCity = "
    SELECT c.id,
    ($earth*ACOS(LEAST(1,
      COS(RADIANS(%f))*COS(RADIANS(c.latitude))*COS(RADIANS(c.longitude)-RADIANS(%f)) +
      SIN(RADIANS(%f))*SIN(RADIANS(c.latitude))
    ))) AS dcalc
    FROM $t_cities c
    WHERE c.latitude IS NOT NULL AND c.longitude IS NOT NULL
    ORDER BY dcalc ASC
    LIMIT 1";
  $sqlCity = $wpdb->prepare($sqlCity, [$pick_lat,$pick_lng,$pick_lat]);
  $city_row = $wpdb->get_row($sqlCity, ARRAY_A);
  $city_id_auto = $city_row && isset($city_row['id']) ? (int)$city_row['id'] : 0; // fallback 0
  $city_id = $city_id_req>0 ? $city_id_req : $city_id_auto; // [ADI-ADD] prefer request city_id if provided

  // STEP 4 - Prepare INSERT (provider_id/total_amount fixed defaults; city_id from lookup)
  $t_orders=$wpdb->prefix.'orders';
$data = [
  'client_id'         => $uid,
  'provider_id'       => 0,
  'picking_point_id'  => null,
  'pick_latitude'     => $pick_lat,
  'pick_longitude'    => $pick_lng,
  'end_lat'           => $end_lat,
  'end_long'          => $end_lng,
  'address_pick'      => $address_pick,
  'address_end'       => $address_end,
  'notes_customer'    => $notes_customer,
  'notes_provider'    => '',
  'notes_transporter' => '',
  'city_id'           => $city_id,
  'total_amount'      => 0,
  'status'            => 'READY',
  'created_at'        => current_time('mysql', 1),
  'delivery_type'     => 'TAXI',
  'order_short_description' => $address_pick.'->'.$address_end,
  'distance_km'       => $distance_km,
  'calculated_fields' => 1
];

// IMPORTANT: formats aliniate 1:1 cu $data (20 itemi) — include '%s' pentru delivery_type și order_short_description
$formats = [
  '%d','%d','%d','%f','%f','%f','%f','%s','%s','%s','%s','%s','%d','%f','%s','%s','%s','%s','%f','%d'
];


  // [ADI-ADD] timing SQL exec
  $t_sql_start = microtime(true);
  $ok = $wpdb->insert($t_orders,$data,$formats);
  $t_sql_end = microtime(true);
  vogo_error_log3("[$module] SQL insert in:$t_orders | t_sql=".round(($t_sql_end - $t_sql_start),3)."s | ok=".($ok?1:0)." | err=".$wpdb->last_error,$module);

  if(!$ok){
    return new WP_REST_Response(['success'=>false,'module' => $module.'.TEND','error'=>'sql_insert_error','sql_error'=>$wpdb->last_error],500);
  }

  $order_id = (int)$wpdb->insert_id;

  // STEP 5 - Build response (compat + extras)
  $labels = [
    'READY' => 'Ready',
    'ACCEPTED' => 'Accepted',
    'STARTED' => 'Started',
    'IN_PROGRESS' => 'In progress',
    'COMMING_SOON' => 'Coming soon',
    'ARRIVED' => 'Arrived'
  ];
  $status_code='READY';
  $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code; // fallback
  $route_text = (string)$address_pick.' -> '.(string)$address_end;
  $icon_display = 'DIRECT';

  $out=[
    'order'=>[
      'id'=>$order_id,
      'client_id'=>$uid,
      'provider_id'=>0,
      'picking_point_id'=>null,
      'pick_latitude'=>$pick_lat,
      'pick_longitude'=>$pick_lng,
      'notes_customer'=>$notes_customer,
      'notes_provider'=>'',
      'notes_transporter'=>'',
      'city_id'=>$city_id,
      'total_amount'=>0,
      'status'=>$status_code,
      'created_at'=>$data['created_at'],
      'delivery_type'=>'DIRECT',
      'end_lat'=>$end_lat,
      'end_long'=>$end_lng,
      'address_pick'=>$address_pick,
      'address_end'=>$address_end,
      'distance_km'=>$distance_km,
      'calculated_fields'=>1
    ],
    'distance_calc'=>round($distance_km,3),
    'transporter_info'=>null,
    'status_label'=>$status_label,
    'route_text'=>$route_text,
    'icon_display'=>$icon_display
  ];

  return new WP_REST_Response(['success'=>true,'module' => $module.'.TEND','created_id'=>$order_id,'order'=>$out,'user_id'=>$uid,'user_login'=>$ulogin],201);
}//client_add_new_drive_order


// -----------------------------------------------------------------------------
// client_get_drive_order_details — returns order core + live delivery details
// Notes: logs only SQL statements for readability (per request)
// -----------------------------------------------------------------------------
function client_get_drive_order_details(WP_REST_Request $request){ 
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;

  // STEP 1 - JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ return $user_or_err; }
  $user_id=(int)$user_or_err;

  // STEP 2 - Input
  $p=$request->get_json_params();
  $order_id=(int)($p['order_id']??0);
  if(!$order_id){ return new WP_REST_Response(['success'=>false,'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'order_id required'],400); }

  $t_ord=$wpdb->prefix.'orders';
  $t_del=$wpdb->prefix.'orders_delivery';
  $t_tr =$wpdb->prefix.'transporters';

  // STEP 3 - Permission gate (must be client of the order)
  $sql_perm="SELECT EXISTS(SELECT 1 FROM $t_ord o WHERE o.id=%d AND o.client_id=%d) AS is_client";
  $q_perm=$wpdb->prepare($sql_perm,$order_id,$user_id);
  vogo_error_log3("##############SQL: $q_perm");
  $perm=$wpdb->get_row($q_perm,ARRAY_A);
  $is_client=isset($perm['is_client'])&&((int)$perm['is_client']===1);
  if(!$is_client){ return new WP_REST_Response(['success'=>false,'error'=>'permission_denied'],403); }

  // STEP 4 - Read order core + delivery status/position/transporter
  $sql_order="SELECT id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,notes_customer,notes_provider,notes_transporter,city_id,total_amount,status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields FROM $t_ord WHERE id=%d LIMIT 1";
  $q_order=$wpdb->prepare($sql_order,$order_id);
  vogo_error_log3("##############SQL: $q_order");
  $o=$wpdb->get_row($q_order,ARRAY_A);
  if(!$o){ return new WP_REST_Response(['success'=>false,'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'order_not_found'],404); }

  $sql_del="SELECT d.order_id,d.transporter_id,d.current_status AS status,d.last_lat AS latitude,d.last_lng AS longitude,d.last_update_at AS created_at,t.nickname,t.plate_number,t.auto_type,t.auto_model,t.auto_colour,t.phone FROM $t_del d LEFT JOIN $t_tr t ON t.user_id=d.transporter_id WHERE d.order_id=%d LIMIT 1";
  $q_del=$wpdb->prepare($sql_del,$order_id);
  vogo_error_log3("##############SQL: $q_del");
  $delivery=$wpdb->get_row($q_del,ARRAY_A);

  // STEP 5 - Labels & display_text
  $labels = [
    'READY'=>'Ready','ACCEPTED'=>'Accepted','STARTED'=>'Started','IN_PROGRESS'=>'In progress',
    'COMMING_SOON'=>'Coming soon','ARRIVED'=>'Arrived','DELIVERED'=>'Delivered','FINISHED'=>'Finished'
  ];
  $display_map = [
    'READY'=>'Waiting for a driver.','ACCEPTED'=>'Driver accepted your order.','STARTED'=>'Driver is heading to you.',
    'IN_PROGRESS'=>'Your ride is in progress.','COMMING_SOON'=>'Driver is approaching.','ARRIVED'=>'Driver has arrived.',
    'DELIVERED'=>'Order delivered.','FINISHED'=>'Drive completed.'
  ];

  // STEP 6 - Build transporter & latest_position
  $latest=null; $transporter_info=null; $status_code=(string)$o['status'];
  if($delivery){
    $status_code = (string)$delivery['status'];
    if($delivery['latitude']!==null && $delivery['longitude']!==null){
      $latest=['latitude'=>(float)$delivery['latitude'],'longitude'=>(float)$delivery['longitude'],'status'=>$status_code,'created_at'=>$delivery['created_at']];
    }
    if($delivery['transporter_id']!==null){
      $transporter_info=[
        'user_id'=>(int)$delivery['transporter_id'],
        'nickname'=>$delivery['nickname']??null,
        'plate_number'=>$delivery['plate_number']??null,
        'auto_type'=>$delivery['auto_type']??null,
        'auto_model'=>$delivery['auto_model']??null,
        'auto_colour'=>$delivery['auto_colour']??null,
        'phone'=>$delivery['phone']??null
      ];
    }
  }

  // STEP 7 - distance_calc (Haversine pick -> end), route_text, icon_name
  $earth=6371; $distance_calc=null;
  if(isset($o['pick_latitude'],$o['pick_longitude'],$o['end_lat'],$o['end_long']) && $o['pick_latitude']!==null && $o['pick_longitude']!==null && $o['end_lat']!==null && $o['end_long']!==null){
    $distance_calc=$earth*acos(min(1.0,
      cos(deg2rad((float)$o['pick_latitude']))*cos(deg2rad((float)$o['end_lat']))*cos(deg2rad((float)$o['end_long'])-deg2rad((float)$o['pick_longitude'])) +
      sin(deg2rad((float)$o['pick_latitude']))*sin(deg2rad((float)$o['end_lat']))
    )); if(!is_finite($distance_calc)) $distance_calc=null;
  }
  $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code;
  $display_text = isset($display_map[$status_code]) ? $display_map[$status_code] : $status_label;
  $notes_part = '';
  if(isset($o['notes_customer']) && $o['notes_customer']!=='') $notes_part.='.'.(string)$o['notes_customer'].'.';
  if(isset($o['notes_provider']) && $o['notes_provider']!=='')  $notes_part.=(substr($notes_part,-1)==='.'?'':'').(string)$o['notes_provider'].'.';
  $route_text = (string)$o['address_pick'].' -> '.(string)$o['address_end'].$notes_part;
  $icon_name  = (string)$o['delivery_type'];

  // STEP 8 - Shape response
  $order_obj=[
    'id'=>(int)$o['id'],
    'client_id'=>(int)$o['client_id'],
    'provider_id'=>(int)$o['provider_id'],
    'picking_point_id'=>$o['picking_point_id']!==null?(int)$o['picking_point_id']:null,
    'pick_latitude'=>$o['pick_latitude']!==null?(float)$o['pick_latitude']:null,
    'pick_longitude'=>$o['pick_longitude']!==null?(float)$o['pick_longitude']:null,
    'notes_customer'=>$o['notes_customer'],
    'notes_provider'=>$o['notes_provider'],
    'notes_transporter'=>$o['notes_transporter'],
    'city_id'=>(int)$o['city_id'],
    'total_amount'=>(float)$o['total_amount'],
    'status'=>$status_code,
    'created_at'=>$o['created_at'],
    'delivery_type'=>$o['delivery_type'],
    'end_lat'=>$o['end_lat'],
    'end_long'=>$o['end_long'],
    'address_pick'=>$o['address_pick'],
    'address_end'=>$o['address_end'],
    'distance_km'=>($o['distance_km']!==null)?(float)$o['distance_km']:null,
    'calculated_fields'=>(int)$o['calculated_fields']
  ];

  $resp=[
    'success'=>true,
    'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND',
    'order'=>$order_obj,
    'distance_calc'=>($distance_calc!==null?round((float)$distance_calc,3):null),
    'transporter_info'=>$transporter_info,
    'latest_position'=>$latest,
    'status_label'=>$status_label,
    'route_text'=>$route_text,
    'icon_name'=>$icon_name,
    'display_text'=>$display_text,
    'user_id'=>$user_id
  ];

  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */
  return new WP_REST_Response($resp,200);
}//client_get_drive_order_details

// -----------------------------------------------------------------------------
// transport_get_drive_order_details — transporter must be assigned to the order
// -----------------------------------------------------------------------------
function transport_get_drive_order_details(WP_REST_Request $request){ 
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;
  
  
  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // în proiectul tău returnează WP_REST_Response pe eroare
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }
  vogo_error_log3("STEP 0.0 – JWT ctx | user:$jwt_user_name(" . ($jwt_user_id??'null') . ")", $module);

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response    



  // STEP 1 - JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ return $user_or_err; }
  $user_id=(int)$user_or_err;

  // STEP 2 - Role check (ONLY TRANSPORTER)
  $u = get_user_by('id',$user_id);
  $roles = $u && is_array($u->roles) ? $u->roles : [];
  if( !in_array('transporter',$roles,true) ){
    return new WP_REST_Response(['success'=>false,'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'role_transporter_required','user_id'=>$user_id],403);
  }

  // STEP 3 - Input
  $p=$request->get_json_params();
  $order_id=(int)($p['order_id']??0);
  if(!$order_id){ return new WP_REST_Response(['success'=>false,'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'order_id required'],400); }

  
  $module=$module.'.order:'.$order_id;
  //end audit for response        

  $t_ord=$wpdb->prefix.'orders';
  $t_del=$wpdb->prefix.'orders_delivery';
  $t_tr =$wpdb->prefix.'transporters';

  // STEP 4 - Permission gate (must be assigned transporter on this order)
  $sql_perm="SELECT count(0) AS order_exists from wp_orders where id=%d";
  $q_perm=$wpdb->prepare($sql_perm,$order_id);
  $perm=$wpdb->get_row($q_perm,ARRAY_A);
  $order_exists=isset($perm['order_exists'])&&((int)$perm['order_exists']===1);
  if(!$order_exists){ return new WP_REST_Response(['success'=>false,'module' => $module.'-ERR4','error'=>'Order '.$order_id.' does not exists'],403); }


  // STEP 4 - Permission gate (must be assigned transporter on this order)
  $sql_perm="SELECT EXISTS(SELECT 1 FROM $t_del d WHERE d.order_id=%d AND d.transporter_id=%d) AS is_transporter";
  $q_perm=$wpdb->prepare($sql_perm,$order_id,$user_id);
  //vogo_error_log3("##############SQL: $q_perm");
  $perm=$wpdb->get_row($q_perm,ARRAY_A);
  $is_transporter=isset($perm['is_transporter'])&&((int)$perm['is_transporter']===1);
  if(!$is_transporter){ return new WP_REST_Response(['success'=>false,'module' => $module.'-ERR4','error'=>'permission_denied:Permission gate (must be assigned transporter on this order)'],403); }

  // STEP 5 - Read order core
  $sql_order="SELECT id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,notes_customer,notes_provider,notes_transporter,city_id,total_amount,status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields FROM $t_ord WHERE id=%d LIMIT 1";
  $q_order=$wpdb->prepare($sql_order,$order_id);
  vogo_error_log3("##############SQL: $q_order");
  $o=$wpdb->get_row($q_order,ARRAY_A);
  if(!$o){ return new WP_REST_Response(['success'=>false,'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'order_not_found'],404); }

  // STEP 6 - Delivery status/position + transporter self info
  $sql_del="SELECT d.order_id,d.transporter_id,d.current_status AS status,d.last_lat AS latitude,d.last_lng AS longitude,d.last_update_at AS created_at,t.nickname,t.plate_number,t.auto_type,t.auto_model,t.auto_colour,t.phone FROM $t_del d LEFT JOIN $t_tr t ON t.user_id=d.transporter_id WHERE d.order_id=%d LIMIT 1";
  $q_del=$wpdb->prepare($sql_del,$order_id);
  vogo_error_log3("##############SQL: $q_del");
  $delivery=$wpdb->get_row($q_del,ARRAY_A);

  // STEP 7 - Labels & display_text
  $labels = [
    'READY'=>'Ready','ACCEPTED'=>'Accepted','STARTED'=>'Started','IN_PROGRESS'=>'In progress',
    'COMMING_SOON'=>'Coming soon','ARRIVED'=>'Arrived','DELIVERED'=>'Delivered','FINISHED'=>'Finished'
  ];
  $display_map = [
    'READY'=>'Waiting for a driver.','ACCEPTED'=>'Driver accepted your order.','STARTED'=>'Driver is heading to you.',
    'IN_PROGRESS'=>'Your ride is in progress.','COMMING_SOON'=>'Driver is approaching.','ARRIVED'=>'Driver has arrived.',
    'DELIVERED'=>'Order delivered.','FINISHED'=>'Drive completed.'
  ];

  // STEP 8 - latest position & transporter info
  $latest=null; $transporter_info=null; $status_code=(string)$o['status'];
  if($delivery){
    $status_code = (string)$delivery['status'];
    if($delivery['latitude']!==null && $delivery['longitude']!==null){
      $latest=['latitude'=>(float)$delivery['latitude'],'longitude'=>(float)$delivery['longitude'],'status'=>$status_code,'created_at'=>$delivery['created_at']];
    }
    if($delivery['transporter_id']!==null){
      $transporter_info=[
        'user_id'=>(int)$delivery['transporter_id'],
        'nickname'=>$delivery['nickname']??null,
        'plate_number'=>$delivery['plate_number']??null,
        'auto_type'=>$delivery['auto_type']??null,
        'auto_model'=>$delivery['auto_model']??null,
        'auto_colour'=>$delivery['auto_colour']??null,
        'phone'=>$delivery['phone']??null
      ];
    }
  }

  // STEP 9 - distance_calc (Haversine pick -> end), route_text, icon_name
  $earth=6371; $distance_calc=null;
  if(isset($o['pick_latitude'],$o['pick_longitude'],$o['end_lat'],$o['end_long']) && $o['pick_latitude']!==null && $o['pick_longitude']!==null && $o['end_lat']!==null && $o['end_long']!==null){
    $distance_calc=$earth*acos(min(1.0,
      cos(deg2rad((float)$o['pick_latitude']))*cos(deg2rad((float)$o['end_lat']))*cos(deg2rad((float)$o['end_long'])-deg2rad((float)$o['pick_longitude'])) +
      sin(deg2rad((float)$o['pick_latitude']))*sin(deg2rad((float)$o['end_lat']))
    )); if(!is_finite($distance_calc)) $distance_calc=null;
  }
  $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code;
  $display_text = isset($display_map[$status_code]) ? $display_map[$status_code] : $status_label;
  $notes_part = '';
  if(isset($o['notes_customer']) && $o['notes_customer']!=='') $notes_part.='.'.(string)$o['notes_customer'].'.';
  if(isset($o['notes_provider']) && $o['notes_provider']!=='')  $notes_part.=(substr($notes_part,-1)==='.'?'':'').(string)$o['notes_provider'].'.';
  $route_text = (string)$o['address_pick'].' -> '.(string)$o['address_end'].$notes_part;
  $icon_name  = (string)$o['delivery_type'];

  // STEP 10 - Shape response (same schema as client_* for BC)
  $order_obj=[
    'id'=>(int)$o['id'],
    'client_id'=>(int)$o['client_id'],
    'provider_id'=>(int)$o['provider_id'],
    'picking_point_id'=>$o['picking_point_id']!==null?(int)$o['picking_point_id']:null,
    'pick_latitude'=>$o['pick_latitude']!==null?(float)$o['pick_latitude']:null,
    'pick_longitude'=>$o['pick_longitude']!==null?(float)$o['pick_longitude']:null,
    'notes_customer'=>$o['notes_customer'],
    'notes_provider'=>$o['notes_provider'],
    'notes_transporter'=>$o['notes_transporter'],
    'city_id'=>(int)$o['city_id'],
    'total_amount'=>(float)$o['total_amount'],
    'status'=>$status_code,
    'created_at'=>$o['created_at'],
    'delivery_type'=>$o['delivery_type'],
    'end_lat'=>$o['end_lat'],
    'end_long'=>$o['end_long'],
    'address_pick'=>$o['address_pick'],
    'address_end'=>$o['address_end'],
    'distance_km'=>($o['distance_km']!==null)?(float)$o['distance_km']:null,
    'calculated_fields'=>(int)$o['calculated_fields']
  ];

  $resp=[
    'success'=>true,
    'module'=>basename(__FILE__).'.'.__FUNCTION__.'.TEND',
    'order'=>$order_obj,
    'distance_calc'=>($distance_calc!==null?round((float)$distance_calc,3):null),
    'transporter_info'=>$transporter_info,
    'latest_position'=>$latest,
    'status_label'=>$status_label,
    'route_text'=>$route_text,
    'icon_name'=>$icon_name,
    'display_text'=>$display_text,
    'user_id'=>$user_id
  ];

  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */
  return new WP_REST_Response($resp,200);
}//transport_get_drive_order_details

function client_get_history_drive_orders(WP_REST_Request $request){
  global $wpdb; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

  // [ONLY CLIENT] role check
  $roles = $u && is_array($u->roles) ? $u->roles : [];
  if( !in_array('customer', $roles, true) ){
    return new WP_REST_Response(['success'=>false,'module' => basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'role_customer_required','user_id'=>$uid,'user_login'=>$ulogin],403);
  }

  // STEP 2 - No payload (Adi stay on request)

  // STEP 3 - Tables
  $t_orders=$wpdb->prefix.'orders';
  $t_del = $wpdb->prefix.'orders_delivery';
  $t_tr  = $wpdb->prefix.'transporters';

  // [CLIENT] strict filter
  $clientFilter = ' AND o.client_id=%d';

  // History statuses
  $status_list = ['CLOSED','CANCELLED','DELIVERED','FINISHED'];
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));

  // LIMIT/OFFSET fixed
  $limit = 200; $offset = 0;

  // SQL: no distance filter, but compute trip distance (pick -> end)
  $earth = 6371;
  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      ($earth*ACOS(LEAST(1,
        COS(RADIANS(o.pick_latitude))*COS(RADIANS(o.end_lat))*COS(RADIANS(o.end_long)-RADIANS(o.pick_longitude)) +
        SIN(RADIANS(o.pick_latitude))*SIN(RADIANS(o.end_lat))
      ))) AS distance_calc,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    LEFT JOIN $t_del d ON d.order_id=o.id
    LEFT JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE 1=1
      AND o.delivery_type IN ('DIRECT','TAXI')
      AND o.status IN ($placeholders)
      $clientFilter
    ORDER BY o.created_at DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge($status_list, [$uid, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);
  vogo_error_log3("##############SQL: $sql");

  /* BC-GUARD: ✅ companatibility respectat, ✅ LOCK format respectat, ✅ SQL validat */

  $rows=$wpdb->get_results($sql,ARRAY_A);
  if($wpdb->last_error){ 
    return new WP_REST_Response(['success'=>false,'module' => basename(__FILE__).'.'.__FUNCTION__.'.TEND','error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON
  $out=[]; 
  $labels = [
    'CLOSED'    => 'Closed',
    'CANCELLED' => 'Cancelled',
    'FINISHED' => 'Finished',    
    'DELIVERED' => 'Delivered'
  ];

  foreach($rows as $r){

    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code;
    $route_text = (string)$r['address_pick'].' -> '.(string)$r['address_end'].' '.(string)($r['notes_customer']??'').' '.(string)($r['notes_provider']??'');
    $icon_display = (string)$r['delivery_type'];

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      'status_label'=>$status_label,
      'route_text'=>$route_text,
      'icon_display'=>$icon_display
    ];
  }

  $next=null;
  return new WP_REST_Response(['success'=>true,'module' => basename(__FILE__).'.'.__FUNCTION__.'.TEND','count'=>count($out),'orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}//client_get_history_drive_orders


function transporter_save_position_and_sync_delivery($order_id, $transporter_id, $lat, $lng){
  global $wpdb; $module='gps-sync';

  // DEBUG: input sanity
  vogo_error_log3("[$module] START | order_id:$order_id | transporter_id:$transporter_id | lat:$lat | lng:$lng");
  if(!is_numeric($order_id)||$order_id<=0){ vogo_error_log3("[$module] ERR input order_id"); return ['success'=>false,'stage'=>'input','error'=>'bad_order_id']; }
  if(!is_numeric($transporter_id)||$transporter_id<=0){ vogo_error_log3("[$module] ERR input transporter_id"); return ['success'=>false,'stage'=>'input','error'=>'bad_transporter_id']; }
  if(!is_numeric($lat)||!is_numeric($lng)){ vogo_error_log3("[$module] ERR input lat/lng non-numeric"); return ['success'=>false,'stage'=>'input','error'=>'bad_lat_lng']; }
  if($lat<-90||$lat>90||$lng<-180||$lng>180){ vogo_error_log3("[$module] ERR input lat/lng out_of_range"); return ['success'=>false,'stage'=>'input','error'=>'lat_lng_range']; }

  $table_pos = $wpdb->prefix.'order_transporter_pos';
  $table_del = $wpdb->prefix.'orders_delivery';

  // 1) INSERT breadcrumb în POS
  $sql_pos = $wpdb->prepare(
    "INSERT INTO $table_pos (order_id, transporter_id, latitude, longitude, created_at, created_by)
     VALUES (%d,%d,%f,%f,UTC_TIMESTAMP(),%d)",
    $order_id, $transporter_id, $lat, $lng, $transporter_id
  );
  $ok_pos = $wpdb->query($sql_pos);
  if($ok_pos===false){ vogo_error_log3("[$module] POS INSERT ERR: ".$wpdb->last_error); return ['success'=>false,'stage'=>'pos-insert','sql_error'=>$wpdb->last_error]; }
  $pos_id=(int)$wpdb->insert_id;
  vogo_error_log3("[$module] POS INSERT ok | pos_id:$pos_id | rows:$ok_pos");

  // 2) UPDATE #1 — strict pe transporter_id
  $sql_upd1 = $wpdb->prepare(
    "UPDATE $table_del
        SET last_lat=%f, last_lng=%f, modified_at=UTC_TIMESTAMP(), modified_by=%d
      WHERE order_id=%d AND transporter_id=%d
      LIMIT 1",
    $lat, $lng, $transporter_id, $order_id, $transporter_id
  );
  $aff1 = $wpdb->query($sql_upd1);
  if($aff1===false){ vogo_error_log3("[$module] UPD#1 ERR: ".$wpdb->last_error); return ['success'=>false,'stage'=>'delivery-update-1','sql_error'=>$wpdb->last_error,'pos_id'=>$pos_id]; }
  vogo_error_log3("[$module] UPD#1 rows:$aff1");

  // 3) UPDATE #2 — relaxat dacă rândul există dar transporter_id e NULL/0
  $aff2 = 0;
  if($aff1===0){
    $sql_upd2 = $wpdb->prepare(
      "UPDATE $table_del
          SET transporter_id=%d, last_lat=%f, last_lng=%f, modified_at=UTC_TIMESTAMP(), modified_by=%d
        WHERE order_id=%d AND (transporter_id IS NULL OR transporter_id=0)
        LIMIT 1",
      $transporter_id, $lat, $lng, $transporter_id, $order_id
    );
    $aff2 = $wpdb->query($sql_upd2);
    if($aff2===false){ vogo_error_log3("[$module] UPD#2 ERR: ".$wpdb->last_error); return ['success'=>false,'stage'=>'delivery-update-2','sql_error'=>$wpdb->last_error,'pos_id'=>$pos_id]; }
    vogo_error_log3("[$module] UPD#2 rows:$aff2");
  }

  // 4) UPSERT — dacă încă nu s-a atins niciun rând, creăm minimul și setăm din nou
  $aff3 = 0; $aff4 = 0;
  if($aff1===0 && $aff2===0){
    $sql_insd = $wpdb->prepare(
      "INSERT IGNORE INTO $table_del
         (order_id, transporter_id, current_status, last_lat, last_lng, created_at, created_by, accepted_date)
       VALUES (%d,%d,%s,%f,%f,UTC_TIMESTAMP(),%d,UTC_TIMESTAMP())",
      $order_id, $transporter_id, 'ACCEPTED', $lat, $lng, $transporter_id
    );
    $insd = $wpdb->query($sql_insd);
    if($insd===false){ vogo_error_log3("[$module] INS#D ERR: ".$wpdb->last_error); return ['success'=>false,'stage'=>'delivery-insert','sql_error'=>$wpdb->last_error,'pos_id'=>$pos_id]; }
    vogo_error_log3("[$module] INS#D rows:$insd");

    // UPDATE #3 — după insert, ne asigurăm că rămân coordonatele și modified_by corecte
    $sql_upd3 = $wpdb->prepare(
      "UPDATE $table_del
          SET last_lat=%f, last_lng=%f, modified_at=UTC_TIMESTAMP(), modified_by=%d
        WHERE order_id=%d AND transporter_id=%d
        LIMIT 1",
      $lat, $lng, $transporter_id, $order_id, $transporter_id
    );
    $aff3 = $wpdb->query($sql_upd3);
    if($aff3===false){ vogo_error_log3("[$module] UPD#3 ERR: ".$wpdb->last_error); return ['success'=>false,'stage'=>'delivery-update-3','sql_error'=>$wpdb->last_error,'pos_id'=>$pos_id]; }
    vogo_error_log3("[$module] UPD#3 rows:$aff3");
  }

  // 5) Snapshot de verificare — citim coordonatele curente din delivery
  $snap = $wpdb->get_row(
    $wpdb->prepare(
      "SELECT id, order_id, transporter_id, current_status, last_lat, last_long, accepted_date, modified_at
         FROM $table_del WHERE order_id=%d LIMIT 1", $order_id
    ),
    ARRAY_A
  );
  if($wpdb->last_error){ vogo_error_log3("[$module] SNAP ERR: ".$wpdb->last_error); }
  vogo_error_log3("[$module] SNAP: ".json_encode($snap));

  // 6) Rezultat
  $touched = ($aff1>0 || $aff2>0 || $aff3>0 || $aff4>0);
  vogo_error_log3("[$module] DONE | touched:" . ($touched?'yes':'no'));

  return [
    'success'      => true,
    'pos_id'       => $pos_id,
    'upd_rows'     => ['strict'=>$aff1,'relaxed'=>$aff2,'post_insert'=>$aff3],
    'delivery_row' => $snap
  ];
}





function get_current_order(WP_REST_Request $request){
  global $wpdb; $module='current-orders'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;
  // vogo_error_log3("VOGO_LOG_START | MODULE:$module | ACTIVE DB:$db | IP:$ip | USER:unknown",$module);

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    // vogo_error_log3("[$module] JWT failed | IP:$ip",$module); 
    // vogo_error_log3("VOGO_LOG_END",$module); 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';
  // vogo_error_log3("[$module] JWT ok | user_id:$uid | user_login:$ulogin",$module);

    //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . __FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  
  //end audit for response      

  // STEP 2 - Payload
  $p=$request->get_json_params(); 
  // vogo_error_log3("[$module] [STEP 0.1] Raw: ".wp_json_encode($p),$module);
  $limit=(int)($p['limit']??20); if($limit<1||$limit>200)$limit=20; $offset=(int)($p['offset']??0);

  // [ADI-ADD] status list FIX: doar cele active curente
  $status_list=['ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED'];

  // STEP 3 - Tables
  $t_orders=$wpdb->prefix.'orders';
  $t_del   =$wpdb->prefix.'orders_delivery';
  $t_tr    =$wpdb->prefix.'transporters';

  // STEP 4 - Query (doar comenzile unde d.transporter_id = JWT și status în lista fixă)
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));
  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    INNER JOIN $t_del d ON d.order_id=o.id
    LEFT  JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE o.delivery_type in ('DIRECT','TAXI')
      AND o.status IN ($placeholders)
      AND d.transporter_id=%d
    ORDER BY o.created_at DESC, o.id DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge($status_list, [$uid, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);

  vogo_error_log3("SQL exec=[$sql] ");

  /* BC-GUARD: ✅ compatibilitate respectată, ✅ LOCK format respectat, ✅ SQL validat */

  // [ADI-ADD] timing SQL exec
  $t_sql_start = microtime(true);
  $rows=$wpdb->get_results($sql,ARRAY_A);
  $t_sql_end = microtime(true);
  vogo_error_log3("[$module] SQL exec=".round(($t_sql_end - $t_sql_start),3)."s | rows=".count($rows),$module);

  if($wpdb->last_error){ 
    // vogo_error_log3("[$module][SQL ERROR] ".$wpdb->last_error,$module); 
    return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON
  $out=[]; 
  $t_json_start = microtime(true);
  foreach($rows as $r){

    // transporter_info
    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }


  $labels = [
    'READY' => 'Ready',
    'ACCEPTED' => 'Accepted',
    'STARTED' => 'Started',
    'IN_PROGRESS' => 'In progress',
    'COMMING_SOON' => 'Coming soon',
    'ARRIVED' => 'Arrived'
  ];

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code; // fallback sigur
    $route_text = (string)$r['address_pick'].' -> '.(string)$r['address_end'].'.'.(string)($r['notes_customer']??'').'.'.(string)($r['notes_provider']??'');
    $icon_display = (string)$r['delivery_type']; // cerut: identic cu delivery_type

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      // [ADI-ADD] câmpurile cerute (plasate la final pentru BC)
      'status_label'=>$status_label,
      'route_text'=>$route_text,
      'icon_name'=>$icon_display
    ];
  }
  $t_json_end = microtime(true);
  vogo_error_log3("[$module] JSON build=".round(($t_json_end - $t_json_start),3)."s",$module);
  /* BC-GUARD: ✅ compatibilitate respectată, ✅ LOCK format respectat, ✅ SQL validat */

  $next=(count($rows)===$limit)?($offset+$limit):null;

  return new WP_REST_Response(['success'=>true,'count'=>count($out),'module' => $module.'.TEND','orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}

function get_history_orders(WP_REST_Request $request){
  global $wpdb; $module='history-orders'; $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; $db=DB_NAME;

  // STEP 1 - JWT
  $user_or_err=extract_user_from_jwt_token($request);
  if($user_or_err instanceof WP_REST_Response){ 
    return $user_or_err; 
  }
  $uid=(int)$user_or_err; $u=get_user_by('id',$uid); $ulogin=$u?$u->user_login:'unknown';

  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.' . __FUNCTION__;
  $jwt_user_id   = (int)$uid;
  $wp_user = get_user_by('id', (int)$jwt_user_id); 
  $jwt_user_name = $wp_user ? $wp_user->user_login : 'unknown';    
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response      

  // STEP 2 - Payload
  $p=$request->get_json_params(); 
  $limit=(int)($p['limit']??20); if($limit<1||$limit>200)$limit=20; $offset=(int)($p['offset']??0);

  // [ADI-ADD] status list FIX: istorice
  $status_list=['DELIVERED','FINISHED'];

  // STEP 3 - Tables
  $t_orders=$wpdb->prefix.'orders';
  $t_del   =$wpdb->prefix.'orders_delivery';
  $t_tr    =$wpdb->prefix.'transporters';

  // STEP 4 - Query
  $placeholders = implode(',', array_fill(0,count($status_list),'%s'));
  $sql = "
    SELECT 
      o.id AS o_id,o.client_id,o.provider_id,o.picking_point_id,o.pick_latitude,o.pick_longitude,
      o.notes_customer,o.notes_provider,o.notes_transporter,o.city_id,o.total_amount,o.status,o.created_at AS o_created_at,
      o.delivery_type,o.end_lat,o.end_long,o.address_pick,o.address_end,o.distance_km,o.calculated_fields,
      d.transporter_id,
      t.nickname AS tr_nickname,
      t.plate_number AS tr_plate_number,
      t.auto_type AS tr_auto_type,
      t.auto_model AS tr_auto_model,
      t.auto_colour AS tr_auto_colour,
      t.phone AS tr_phone
    FROM $t_orders o
    INNER JOIN $t_del d ON d.order_id=o.id
    LEFT  JOIN $t_tr  t ON t.user_id=d.transporter_id
    WHERE o.delivery_type in ('DIRECT','TAXI')
      AND o.status IN ($placeholders)
      AND d.transporter_id=%d
    ORDER BY o.created_at DESC, o.id DESC
    LIMIT %d OFFSET %d";

  $prepArgs = array_merge($status_list, [$uid, $limit, $offset]);
  $sql = $wpdb->prepare($sql, $prepArgs);

  /* BC-GUARD: ✅ compatibilitate respectată, ✅ LOCK format respectat, ✅ SQL validat */

  // timing SQL exec
  $t_sql_start = microtime(true);
  $rows=$wpdb->get_results($sql,ARRAY_A);
  $t_sql_end = microtime(true);

  if($wpdb->last_error){ 
    return new WP_REST_Response(['success'=>false,'error'=>'sql_error','sql_error'=>$wpdb->last_error],500); 
  }

  // STEP 5 - Shape JSON
  $out=[]; 
  $t_json_start = microtime(true);
  foreach($rows as $r){

    // transporter_info
    $tr_info = null;
    if(isset($r['transporter_id']) && $r['transporter_id']!==null){
      $tr_info = [
        'user_id'      => (int)$r['transporter_id'],
        'nickname'     => $r['tr_nickname']??null,
        'plate_number' => $r['tr_plate_number']??null,
        'auto_type'    => $r['tr_auto_type']??null,
        'auto_model'   => $r['tr_auto_model']??null,
        'auto_colour'  => $r['tr_auto_colour']??null,
        'phone'        => $r['tr_phone']??null
      ];
    }

    $labels = [
      'READY' => 'Ready',
      'ACCEPTED' => 'Accepted',
      'STARTED' => 'Started',
      'IN_PROGRESS' => 'In progress',
      'COMMING_SOON' => 'Coming soon',
      'ARRIVED' => 'Arrived'
    ];    

    $status_code = (string)$r['status'];
    $status_label = isset($labels[$status_code]) ? $labels[$status_code] : $status_code;
    $route_text = (string)$r['address_pick'].' -> '.(string)$r['address_end'].'.'.(string)($r['notes_customer']??'').'.'.(string)($r['notes_provider']??'');
    $icon_display = (string)$r['delivery_type'];

    $out[]=[
      'order'=>[
        'id'=>(int)$r['o_id'],
        'client_id'=>(int)$r['client_id'],
        'provider_id'=>(int)$r['provider_id'],
        'picking_point_id'=>$r['picking_point_id']!==null?(int)$r['picking_point_id']:null,
        'pick_latitude'=>$r['pick_latitude']!==null?(float)$r['pick_latitude']:null,
        'pick_longitude'=>$r['pick_longitude']!==null?(float)$r['pick_longitude']:null,
        'notes_customer'=>$r['notes_customer'],
        'notes_provider'=>$r['notes_provider'],
        'notes_transporter'=>$r['notes_transporter'],
        'city_id'=>(int)$r['city_id'],
        'total_amount'=>(float)$r['total_amount'],
        'status'=>$status_code,
        'created_at'=>$r['o_created_at'],
        'delivery_type'=>$r['delivery_type'],
        'end_lat'=>$r['end_lat'],
        'end_long'=>$r['end_long'],
        'address_pick'=>$r['address_pick'],
        'address_end'=>$r['address_end'],
        'distance_km'=>($r['distance_km']!==null)?(float)$r['distance_km']:null,
        'calculated_fields'=>(int)$r['calculated_fields']
      ],
      'distance_calc'=>isset($r['distance_calc']) ? round((float)$r['distance_calc'],3) : null,
      'transporter_info'=>$tr_info,
      'status_label'=>$status_label,
      'route_text'=>$route_text,
      'icon_name'=>$icon_display
    ];
  }
  $t_json_end = microtime(true);

  /* BC-GUARD: ✅ compatibilitate respectată, ✅ LOCK format respectat, ✅ SQL validat */

  $next=(count($rows)===$limit)?($offset+$limit):null;

  return new WP_REST_Response(['success'=>true,'count'=>count($out),'module' => $module.'.TEND','orders'=>$out,'next_offset'=>$next,'user_id'=>$uid,'user_login'=>$ulogin],200);
}

