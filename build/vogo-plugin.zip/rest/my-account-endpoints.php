<?php

add_action('rest_api_init', function () {


    register_rest_route('vogo/v1', '/my-account/Address-List', [
        'methods'             => 'POST',
        'callback'            => 'vogo_list_all_user_addresses',
        'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/my-account/standard-address', [
      'methods' => 'POST',
      'callback' => 'vogo_add_edit_standard_address',
      'permission_callback' => 'vogo_permission_check',
    ]);

    register_rest_route('vogo/v1', '/my-account/add-new-custom-address', [
      'methods' => 'POST',
      'callback' => 'vogo_add_new_custom_address',
      'permission_callback' => 'vogo_permission_check',
    ]);


});


function vogo_list_all_user_addresses(WP_REST_Request $request) {
  global $wpdb;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  $db_name = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db_name | IP: $ip | User: $user_id");

  // STEP 2: Load billing & shipping addresses with unique_code
  $types = ['billing', 'shipping'];
  $fields = [
    'first_name', 'last_name', 'company', 'address_1', 'address_2',
    'city', 'state', 'state_name', 'postcode', 'country',
    'country_name', 'phone', 'email', 'dialCode'
  ];

  $addresses = [];
  foreach ($types as $type) {
    $address = ['type' => $type];
    foreach ($fields as $field) {
      $address[$field] = get_user_meta($user_id, "{$type}_{$field}", true);
    }
    $address['unique_code'] = get_user_meta($user_id, "{$type}_unique_code", true) ?? '';
    if (!empty($address['address_1'])) $addresses[] = $address;
  }

  // STEP 3: Load custom addresses from wp_user_addresses
  $table = $wpdb->prefix . 'user_addresses';
  $custom_addresses = $wpdb->get_results(
    $wpdb->prepare("SELECT * FROM $table WHERE user_id = %d AND status = 'active'", $user_id),
    ARRAY_A
  );

  vogo_error_log3("[STEP 3] Fetched " . count($custom_addresses) . " custom addresses from SQL | IP: $ip | User: $user_id");

  // STEP 4: Return final payload
  return new WP_REST_Response([
    'success' => true,
    'user_id' => $user_id,
    'billing_shipping' => $addresses,
    'custom_addresses' => $custom_addresses
  ]);
}


function vogo_add_edit_standard_address(WP_REST_Request $request) {
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  $db_name = DB_NAME;
  vogo_error_log3("[STEP 1] ACTIVE DB: $db_name | IP: $ip | User: $user_id");

  $data = $request->get_json_params();
  $type = sanitize_text_field($data['type'] ?? '');
  $code = sanitize_text_field($data['unique_code'] ?? '');

  if (empty($type) || empty($code)) {
    return new WP_REST_Response([
      'success' => false,
      'message' => 'Missing type or unique_code'
    ], 400);
  }

  $fields = ['first_name','last_name','company','address_1','address_2','city','state','state_name','postcode','country','country_name','phone','email','dialCode','latitudine','longitudine'];
  $action = 'insert';

  // STEP 2: Check if code already exists for this user and type
  $existing_code = get_user_meta($user_id, "{$type}_unique_code", true);
  if ($existing_code === $code) $action = 'update';

  // STEP 3: Save all fields as usermeta
  foreach ($fields as $field) {
    $value = sanitize_text_field($data[$field] ?? '');
    update_user_meta($user_id, "{$type}_{$field}", $value);
  }
  update_user_meta($user_id, "{$type}_unique_code", $code);

  vogo_error_log3("[STEP 2] $action standard address | type: $type | code: $code | IP: $ip | User: $user_id");

  return new WP_REST_Response([
    'success' => true,
    'action' => $action,
    'message' => strtoupper($action) . " standard address with code '{$code}' for user {$user_id}"
  ], 200);
}
