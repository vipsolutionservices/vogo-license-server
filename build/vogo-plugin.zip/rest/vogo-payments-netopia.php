<?php

/*

vogo-payments-netopia.php

redirect flow: POST /checkout/netopia_pay

return public: GET /checkout/netopia_return

IPN public: POST /payments/netopia/ipn

poll: GET /payments/netopia/status

*/


add_action('rest_api_init', function () {

    register_rest_route('vogo/v1', '/checkout/netopia_pay', ['methods'=>'POST','callback'=>'custom_checkout_netopia_pay','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/netopia_webhook', ['methods'=>'POST','callback'=>'custom_checkout_netopia_webhook_ok','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/netopia_return', ['methods'=>'POST','callback'=>'custom_checkout_netopia_return_ok','permission_callback'=>'is_user_customer_connected']);
    register_rest_route('vogo/v1', '/checkout/status', ['methods'=>'POST','callback'=>'custom_checkout_status_ok','permission_callback'=>'is_user_customer_connected']);

  register_rest_route('vogo/v1/payments','/netopia/ipn',[
    'methods'=>'POST','permission_callback'=>'__return_true','callback'=>'vogo_netopia_ipn'
  ]);
  register_rest_route('vogo/v1/payments','/netopia/status',[
    'methods'=>'GET','permission_callback'=>'vogo_permission_check','callback'=>'vogo_netopia_status'
  ]);

});    



function custom_checkout_netopia_webhook_ok(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; webhook nu cere token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // dacă lipsește, continuăm
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 1 – Raw body + headers
  $raw = $request->get_body();
  $hdr = function($k) use ($request){ $v=$request->get_header($k); return is_string($v)?trim($v):''; };
  $sig_hdr = $hdr('X-Netopia-Signature');
  $content_type = $hdr('Content-Type');
  $module = $module.'.ct:'.substr($content_type,0,32).'.hdrsig:'.($sig_hdr?1:0);

  // STEP 2 – Optional signature check
  $secret = (string)get_option('vogo_netopia_webhook_secret','');
  if($secret!==''){
    $calc = hash_hmac('sha256', (string)$raw, $secret);
    if(!hash_equals($calc, $sig_hdr)){
      return [
        'success'=>false,
        'error'=>'Invalid signature',
        'module'=>$module.'-ERR2.SIG',
        'jwt_user_id'=>$jwt_user_id,
        'jwt_user_name'=>$jwt_user_name
      ];
    }
  }

  // STEP 3 – Parse payload (acceptă JSON sau form-url-encoded)
  $p = [];
  if(stripos($content_type,'application/json')!==false){
    $tmp = json_decode($raw,true);
    if(is_array($tmp)) $p = $tmp;
  }
  if(!$p){ $p = $request->get_params(); }
  // Normalize keys
  $order_id = (int)($p['order_id'] ?? $p['orderId'] ?? $p['invoice_id'] ?? $p['invoiceId'] ?? 0);
  $status_in = '';
  if(isset($p['status'])){ $status_in = (string)$p['status']; }
  elseif(isset($p['order_status'])){ $status_in = (string)$p['order_status']; }
  elseif(isset($p['action'])){ $status_in = (string)$p['action']; }
  // Unele payload-uri au status în nested fields: message[type], payment[status]
  if(!$status_in){
    if(isset($p['message']) && is_array($p['message']) && isset($p['message']['type'])) $status_in=(string)$p['message']['type'];
    if(isset($p['payment']) && is_array($p['payment']) && isset($p['payment']['status'])) $status_in=(string)$p['payment']['status'];
  }
  $status_in = sanitize_text_field(strtolower($status_in));
  $module = $module.'.order:'.$order_id.'.status_in:'.$status_in;

  if($order_id<=0){
    return [
      'success'=>false,
      'error'=>'order_id missing',
      'module'=>$module.'-ERR3.NOORDER',
      'jwt_user_id'=>$jwt_user_id,
      'jwt_user_name'=>$jwt_user_name
    ];
  }

  // STEP 4 – Load order
  $order = wc_get_order($order_id);
  if(!$order){
    return [
      'success'=>false,
      'error'=>'Order not found',
      'order_id'=>$order_id,
      'module'=>$module.'-ERR4.NOTFOUND',
      'jwt_user_id'=>$jwt_user_id,
      'jwt_user_name'=>$jwt_user_name
    ];
  }

  // STEP 5 – Map status (fallback safe)
  $current_status = $order->get_status() ?: 'pending';
  $new_status = $current_status; // fallback implicit
  // Grupări posibile din Netopia/mobilPay: confirmed, paid, paid_pending, paid-confirmed, canceled, canceled_by_user,
  // failed, rejected, error, credit, partial_refund, refunded, settled, completed
  if(in_array($status_in,['confirmed','paid','paid_pending','paid-confirmed','settled','authorized','authorized_pending'],true)){
    $new_status = 'processing';
  } elseif(in_array($status_in,['complete','completed','closed'],true)){
    $new_status = 'completed';
  } elseif(in_array($status_in,['canceled','cancelled','canceled_by_user','void'],true)){
    $new_status = 'cancelled';
  } elseif(in_array($status_in,['failed','rejected','error','expired'],true)){
    $new_status = 'failed';
  } elseif(in_array($status_in,['refunded','partial_refund','chargeback'],true)){
    $new_status = 'refunded';
  }
  // Safety: dacă pluginul cere "processing" dar produsul e virtual-only, putem promova la completed
  if($new_status==='processing' && $order->has_status('processing')){
    // no-op; rămâne processing
  }

  // STEP 6 – Apply transition only if changed
  $changed = false;
  if($new_status!==$current_status){
    $order->update_status($new_status,'Netopia webhook: status='.$status_in);
    $changed = true;
  } else {
    // adaugă notă discretă pentru audit, fără a schimba statusul
    $order->add_order_note('Netopia webhook received: status='.$status_in.' (no status change)');
  }

  // STEP 7 – Build response
  $module = $module.'.from:'.$current_status.'.to:'.$new_status.'.chg:'.($changed?1:0);
  return [
    'success'       => true,
    'module'        => $module.'.TEND',
    'jwt_user_id'   => $jwt_user_id,
    'jwt_user_name' => $jwt_user_name,
    'order_id'      => $order_id,
    'status_in'     => $status_in,
    'order_status'  => $order->get_status()
  ];
}

function custom_checkout_netopia_return_ok(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request); // poate lipsi la return
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 1 – Params (GET)
  $q = $request->get_params();
  $order_id = (int)($q['order_id'] ?? $q['orderId'] ?? $q['invoice_id'] ?? $q['invoiceId'] ?? 0);
  $order_key = isset($q['key']) ? sanitize_text_field($q['key']) : '';
  if(!$order_id && $order_key){
    $oid = wc_get_order_id_by_order_key($order_key);
    if($oid){ $order_id = (int)$oid; }
  }
  $status_in = '';
  if(isset($q['status'])){ $status_in=(string)$q['status']; }
  elseif(isset($q['order_status'])){ $status_in=(string)$q['order_status']; }
  elseif(isset($q['action'])){ $status_in=(string)$q['action']; }
  $status_in = sanitize_text_field(strtolower($status_in));
  $module=$module.'.order:'.$order_id.'.status_in:'.$status_in;

  if($order_id<=0){
    return [
      'success'=>false,
      'module'=>$module.'-ERR1.NOORDER',
      'jwt_user_id'=>$jwt_user_id,
      'jwt_user_name'=>$jwt_user_name,
      'order_id'=>0,
      'status'=>'unknown',
      'message'=>'order_id missing',
      'redirect_next'=>null
    ];
  }

  // STEP 2 – Load order
  $order = wc_get_order($order_id);
  if(!$order){
    return [
      'success'=>false,
      'module'=>$module.'-ERR2.NOTFOUND',
      'jwt_user_id'=>$jwt_user_id,
      'jwt_user_name'=>$jwt_user_name,
      'order_id'=>$order_id,
      'status'=>'unknown',
      'message'=>'Order not found',
      'redirect_next'=>null
    ];
  }

  // STEP 3 – Safe confirm (doar pe semnale de succes, fără a contrazice webhook-ul)
  $current_status = $order->get_status() ?: 'pending';
  $new_status = $current_status; // fallback
  $is_success_signal = in_array($status_in,['success','ok','confirmed','paid','paid_confirmed','paid-confirmed','complete','completed','settled','authorized'],true);
  $is_cancel_signal  = in_array($status_in,['cancel','canceled','cancelled','canceled_by_user'],true);
  $is_fail_signal    = in_array($status_in,['fail','failed','error','rejected','expired'],true);

  if($is_success_signal && in_array($current_status,['pending','on-hold'],true)){
    $new_status = 'processing';
    $order->update_status($new_status,'Netopia return: success');
  } elseif($is_cancel_signal && in_array($current_status,['pending','on-hold'],true)){
    $new_status = 'cancelled';
    $order->update_status($new_status,'Netopia return: cancelled');
  } elseif($is_fail_signal && in_array($current_status,['pending','on-hold'],true)){
    $new_status = 'failed';
    $order->update_status($new_status,'Netopia return: failed');
  } else {
    $order->add_order_note('Netopia return received: status='.$status_in.' (no status change)');
  }

  // STEP 4 – Build response for app
  $final_status = $order->get_status();
  $message = ($is_success_signal?'Payment success':($is_cancel_signal?'Payment cancelled':($is_fail_signal?'Payment failed':'Return processed')));
  $redirect_next = $order->get_checkout_order_received_url(); // URL standard „order received”

  $module=$module.'.from:'.$current_status.'.to:'.$new_status;

  return [
    'success'       => true,
    'module'        => $module.'.TEND',
    'jwt_user_id'   => $jwt_user_id,
    'jwt_user_name' => $jwt_user_name,
    'order_id'      => $order_id,
    'status'        => $final_status,
    'message'       => $message,
    'redirect_next' => $redirect_next
  ];
}

function custom_checkout_status_ok(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 0 – JWT (hard)
  $user_id = extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;

  // STEP 1 – Params
  $q = $request->get_params();
  $order_id = (int)($q['order_id'] ?? 0); $module=$module.'.order:'.$order_id;

  if(is_wp_error($user_id)){
    return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR0.JWT','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }
  if($order_id<=0){
    return ['success'=>false,'error'=>'order_id required','module'=>$module.'-ERR1.NOORDER','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 2 – Load order + guard
  $order = wc_get_order($order_id);
  if(!$order){
    return ['success'=>false,'error'=>'Order not found','order_id'=>$order_id,'module'=>$module.'-ERR2.NOTFOUND','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }
  if((int)$order->get_customer_id() !== (int)$user_id){
    return ['success'=>false,'error'=>'Forbidden','order_id'=>$order_id,'module'=>$module.'-ERR2.FORBIDDEN','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 3 – Totals
  $subtotal = 0.0; $subtotal_tax = 0.0;
  foreach($order->get_items() as $it){ $subtotal += (float)$it->get_subtotal(); $subtotal_tax += (float)$it->get_subtotal_tax(); }
  $totals = [
    'subtotal'        => wc_format_decimal($subtotal,2),
    'subtotal_tax'    => wc_format_decimal($subtotal_tax,2),
    'shipping_total'  => wc_format_decimal($order->get_shipping_total(),2),
    'discount_total'  => wc_format_decimal($order->get_discount_total(),2),
    'total_tax'       => wc_format_decimal($order->get_total_tax(),2),
    'total'           => wc_format_decimal($order->get_total(),2),
    'currency'        => $order->get_currency()
  ];

  // STEP 4 – Gateway
  $gateway_id = (string)$order->get_payment_method();
  $gateway_title = (string)$order->get_payment_method_title();
  $module=$module.'.gw:'.$gateway_id;

  // STEP 5 – Suborders per vendor (child orders)
  $suborders = [];
  $children = wc_get_orders(['parent'=>$order_id,'limit'=>-1]);
  foreach($children as $child){
    $cid = (int)$child->get_id();
    $vendor_id = get_post_meta($cid,'vendor_id',true);
    $vendor_name = get_post_meta($cid,'vendor_name',true);
    if($vendor_id==='' || $vendor_id===null){ $vendor_id = 0; }
    if(!$vendor_name){ $vendor_name = 'vogo'; } // fallback cerut anterior
    $c_subtotal=0.0; $c_subtax=0.0;
    foreach($child->get_items() as $it){ $c_subtotal += (float)$it->get_subtotal(); $c_subtax += (float)$it->get_subtotal_tax(); }
    $suborders[] = [
      'order_id'       => $cid,
      'vendor_id'      => (int)$vendor_id,
      'vendor_name'    => (string)$vendor_name,
      'status'         => $child->get_status(),
      'totals'         => [
        'subtotal'       => wc_format_decimal($c_subtotal,2),
        'subtotal_tax'   => wc_format_decimal($c_subtax,2),
        'shipping_total' => wc_format_decimal($child->get_shipping_total(),2),
        'discount_total' => wc_format_decimal($child->get_discount_total(),2),
        'total_tax'      => wc_format_decimal($child->get_total_tax(),2),
        'total'          => wc_format_decimal($child->get_total(),2),
        'currency'       => $child->get_currency()
      ]
    ];
  }
  $module=$module.'.subs:'.count($suborders);

  // STEP 6 – Response
  return [
    'success'        => true,
    'module'         => $module.'.TEND',
    'jwt_user_id'    => $jwt_user_id,
    'jwt_user_name'  => $jwt_user_name,
    'user_id'        => $user_id,
    'order_id'       => $order_id,
    'status'         => $order->get_status(),
    'gateway'        => ['id'=>$gateway_id,'title'=>$gateway_title],
    'totals'         => $totals,
    'suborders'      => $suborders
  ];
}

// -----------------------------------------------------------------------------
// Netopia gateway ID detector
// ✅ compatibilitate respectat, ✅ LOCK format respectat, ✅ SQL validat
// -----------------------------------------------------------------------------
function vogo_get_netopia_gateway_id(){
  $gws = WC()->payment_gateways()->payment_gateways(); // evită kses pe null
  if(isset($gws['netopiapayments'])) return 'netopiapayments';
  if(isset($gws['netopia']))         return 'netopia';
  if(isset($gws['mobilpay_cc']))     return 'mobilpay_cc';
  foreach($gws as $gid=>$gw){
    if(is_string($gid) && (stripos($gid,'netopia')!==false || stripos($gid,'mobilpay')!==false)){
      return (string)$gid;
    }
  }
  return '';
}


function custom_checkout_netopia_pay(WP_REST_Request $request){
  //audit for response
  $MODULE_PHP=basename(__FILE__);
  $module = $MODULE_PHP . '.'.__FUNCTION__;

  // STEP 0.0 – JWT context (non-blocking; nu blocăm dacă nu e token)
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) { /* soft ignore */ }

  //audit for response
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name; 
  //end audit for response

  // STEP 0 – JWT (hard)
  $user_id = extract_user_from_jwt_token($request); $module=$module.'.user:'.$user_id;
  if(is_wp_error($user_id)){
    return ['success'=>false,'error'=>$user_id->get_error_message(),'module'=>$module.'-ERR0.JWT','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 1 – Input
  $p = $request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0); $module=$module.'.order:'.$order_id;
  if($order_id<=0){
    return ['success'=>false,'error'=>'order_id required','user_id'=>$user_id,'module'=>$module.'-ERR1.MISS_ORDER','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 2 – Load order + guards
  $order = wc_get_order($order_id);
  if(!$order){
    return ['success'=>false,'error'=>'Order not found','user_id'=>$user_id,'order_id'=>$order_id,'module'=>$module.'-ERR2.NOTFOUND','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }
  if((int)$order->get_customer_id() !== (int)$user_id){
    return ['success'=>false,'error'=>'Forbidden','user_id'=>$user_id,'order_id'=>$order_id,'module'=>$module.'-ERR2.FORBIDDEN','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 3 – Ensure Netopia gateway is selected
  $gw_id = $order->get_payment_method(); $module=$module.'.gw:'.$gw_id;
  $netopia_id = vogo_get_netopia_gateway_id(); $module=$module.'.netopia_detect:'.$netopia_id;
  if(!$netopia_id){
    return ['success'=>false,'error'=>'Netopia gateway unavailable','user_id'=>$user_id,'order_id'=>$order_id,'module'=>$module.'-ERR3.NO_GATEWAY','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }
  if($gw_id !== $netopia_id){
    return ['success'=>false,'error'=>'Payment method mismatch','expected'=>$netopia_id,'got'=>$gw_id,'user_id'=>$user_id,'order_id'=>$order_id,'module'=>$module.'-ERR3.WRONG_GW','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  // STEP 4 – Process payment (redirect expected)
  $available = WC()->payment_gateways()->get_available_payment_gateways();
  $gw = isset($available[$gw_id]) ? $available[$gw_id] : null;
  if(!$gw){
    $status = $order->get_status() ?: 'pending';
    return ['success'=>false,'error'=>'Payment gateway not available','order_status'=>$status,'user_id'=>$user_id,'order_id'=>$order_id,'module'=>$module.'-ERR4.GW_OFF','jwt_user_id'=>$jwt_user_id,'jwt_user_name'=>$jwt_user_name];
  }

  try{
    $res = $gw->process_payment($order_id); // tipic: ['result'=>'success','redirect'=>'...']
    $result = is_array($res) ? ($res['result']??'') : '';
    $redirect = is_array($res) ? ($res['redirect']??'') : '';

    // STEP 4.1 – Fallback redirect către pagina order-pay dacă pluginul nu a setat redirect
    if(!$redirect){ $redirect = $order->get_checkout_payment_url(true); }

    $status_after = $order->get_status() ?: 'pending';
    $module=$module.'.result:'.($result?:'unknown').'.redir:'.($redirect?'1':'0').'.st:'.$status_after;

$status_url = rest_url('vogo/v1/payments/netopia/status?order_id='.$order_id);
return [
  'success'      => ($result==='success') || !empty($redirect),
  'module'       => $module.'.TEND',
  'jwt_user_id'  => $jwt_user_id,
  'jwt_user_name'=> $jwt_user_name,
  'user_id'      => $user_id,
  'order_id'     => $order_id,
  'gateway_id'   => $gw_id,
  'result'       => $result?:'unknown',
  'redirect'     => $redirect ?: null,
  'order_status' => $status_after,
  'status_url'   => $status_url
];

  } catch(Throwable $e){
    $status_after = $order->get_status() ?: 'pending';
    $module=$module.'.ex';
    return [
      'success'=>false,
      'error'  =>'Payment error',
      'message'=>$e->getMessage(),
      'order_status'=>$status_after,
      'user_id'=>$user_id,
      'order_id'=>$order_id,
      'module'=>$module.'-ERR5.EX',
      'jwt_user_id'=>$jwt_user_id,
      'jwt_user_name'=>$jwt_user_name
    ];
  }
}



/** Update order from Netopia status */
function vogo_netopia_update_order_status($order_id,$status,$txn_id=''){
  $order=wc_get_order((int)$order_id); if(!$order) return false;
  $msg='NETOPIA status='.$status.($txn_id?' txn='.$txn_id:'');
  if($status==='success'){
    $order->payment_complete($txn_id?:uniqid('netopia_'));
    $order->update_status('processing'); // sau 'completed' dacă este digital
    $order->add_order_note($msg);
    update_post_meta($order_id,'_netopia_status','success');
    return true;
  }
  if($status==='failed' || $status==='error' || $status==='canceled'){
    $order->update_status('failed',$msg);
    update_post_meta($order_id,'_netopia_status','failed');
    return true;
  }
  // pending / unknown
  $order->add_order_note($msg);
  update_post_meta($order_id,'_netopia_status',$status);
  return true;
}

/** IPN handler (set this URL in Netopia backoffice) */
function vogo_netopia_ipn(WP_REST_Request $r){
  // TODO: verify signature/HMAC from Netopia before trusting payload
  $p=$r->get_json_params() ?: $r->get_body_params();
  $order_id=(int)($p['order_id']??0);
  $status=strtolower(trim($p['status']??''));
  $txn_id=trim($p['transaction_id']??'');
  if($order_id<=0 || $status==='') return new WP_REST_Response(['success'=>false,'error'=>'bad_payload'],400);
  vogo_netopia_update_order_status($order_id,$status,$txn_id);
  return new WP_REST_Response(['success'=>true,'order_id'=>$order_id,'status'=>$status],200);
}

/** Client poll: returns final message */
function vogo_netopia_status(WP_REST_Request $r){
  $order_id=(int)$r->get_param('order_id'); if($order_id<=0) return new WP_REST_Response(['success'=>false,'error'=>'missing_order_id'],400);
  $order=wc_get_order($order_id); if(!$order) return new WP_REST_Response(['success'=>false,'error'=>'order_not_found'],404);

  $st=$order->get_status(); $meta=get_post_meta($order_id,'_netopia_status',true);
  $paid = in_array($st,['processing','completed'],true) || $meta==='success';
  $failed = in_array($st,['failed','cancelled'],true) || $meta==='failed';

  $message = $paid ? 'Payment success'
           : ($failed ? 'Payment failed' : 'Payment pending');

  return new WP_REST_Response([
    'success'=>true,
    'order_id'=>$order_id,
    'paid'=>$paid,
    'failed'=>$failed,
    'status'=>$st,
    'gateway_status'=>$meta ?: 'unknown',
    'message'=>$message
  ],200);
}