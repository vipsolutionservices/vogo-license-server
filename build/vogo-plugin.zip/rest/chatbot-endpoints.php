<?php
$MODULE_PHP='chatbot-endpoints.php';

//require_once $rest_dir . 'vogolib.php';

	//chatbot

add_action('rest_api_init', function () {    
	register_rest_route('vogo/v1', '/predefined_qa', array(
		'methods' => 'POST',
		'callback' => 'vogo_get_predefined_qa',
		'permission_callback' => 'vogo_permission_check',
	));

	register_rest_route('vogo/v1', '/search_by_keyword', array(
		'methods' => 'POST',
		'callback' => 'vogo_search_by_text',
		'permission_callback' => 'vogo_permission_check',
	));

//agenda    

    register_rest_route('vogo/v1', '/agendaAddItem', [
        'methods' => 'POST',
        'callback' => 'agenda_add_item',
        'permission_callback' => 'vogo_permission_check'
    ]);
    register_rest_route('vogo/v1', '/agendaShowUserItems', [
        'methods' => 'POST',
        'callback' => 'vogo_agenda_show_items',
        'permission_callback' => 'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/agendaMarkDone', [
        'methods' => 'POST',
        'callback' => 'vogo_agenda_mark_done',
        'permission_callback' => 'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/agendaDeleteItem', [
        'methods' => 'POST',
        'callback' => 'vogo_agenda_delete_item',
        'permission_callback' => 'vogo_permission_check'
    ]);

    //shoplist

    register_rest_route('vogo/v1', '/shopListAddItem', [
        'methods' => 'POST',
        'callback' => 'vogo_add_shopping_item',
        'permission_callback' => 'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/shopListShowUserItems', [
        'methods' => 'POST',
        'callback' => 'vogo_get_shopping_items',
        'permission_callback' => 'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/shopListMarkDone', [
        'methods' => 'POST',
        'callback' => 'vogo_shop_list_mark_done',
        'permission_callback' => 'vogo_permission_check'
    ]);

    register_rest_route('vogo/v1', '/shopListDeleteItem', [
        'methods' => 'POST',
        'callback' => 'vogo_shop_list_delete_item',
        'permission_callback' => 'vogo_permission_check'
    ]);


});    



function agenda_add_item($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START agenda_add_item ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate required fields and user ID
    $params = $request->get_json_params();
    if (!$user_id || empty($params['event_name']) || empty($params['event_datetime'])) {
        $error_message = 'Missing required fields or invalid user.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        
        // Log the action failure
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-ADD-AGENDA', $error_message);

        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }
    
    $table = $wpdb->prefix . 'vogo_calendar';

    // Prepare data for insertion
    $data = [
        'user_id' => $user_id,
        'event_name' => sanitize_text_field($params['event_name']),
        'event_datetime' => sanitize_text_field($params['event_datetime']),
        'location' => sanitize_text_field($params['location'] ?? ''),
        'duration' => intval($params['duration'] ?? 60),
        'participants_names' => sanitize_text_field($params['participants_names'] ?? ''),
        'done_checked' => intval($params['done_checked'] ?? 0),
        'created_by' => $user_id,
        'modified_by' => $user_id
    ];
    
    // Log the prepared data
    vogo_error_log3("[STEP 2] Attempting to insert new item for user: $user_name ($user_id)");

    // Perform the INSERT operation
    $insert_result = $wpdb->insert($table, $data);

    // Check for SQL errors
    if ($insert_result === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL INSERT failed: " . $sql_error;
        vogo_error_log3("[STEP 3] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-ADD-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Failed to add item.', 'sql_error' => $sql_error], 500);
    }
    
    $item_id = $wpdb->insert_id;
    $message = "Item added successfully.";

    // Log the successful action
    vogo_log_action($user_id, $user_name, $ip, 1, 'M-ADD-AGENDA', $message);
    vogo_error_log3("[STEP 4] Action completed successfully. " . $message . " | ID: $item_id");
    
    // Return success response with new item ID and user details
    return new WP_REST_Response([
        'success' => true,
        'message' => $message,
        'id' => $item_id,
        'userId' => $user_id,
        'userName' => $user_name
    ], 201);
}

function vogo_agenda_show_items($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START agenda_show_items ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Invalid user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        
        // Log the action failure
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-SHOW-AGENDA', $error_message);
        
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }
    
    // Get parameters with default values
    $date_from = sanitize_text_field($request->get_param('dateFrom') ?? date('Y-m-d H:i:s', strtotime('-7 days')));
    $date_to = sanitize_text_field($request->get_param('dateTo') ?? date('Y-m-d H:i:s', strtotime('+30 days')));

    vogo_error_log3("[STEP 2] Fetching agenda for user: $user_name ($user_id) | From: $date_from | To: $date_to");

    $table = $wpdb->prefix . 'vogo_calendar';

    // Fetch items from the database using 'user_id' instead of 'created_by'
    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$table}
            WHERE user_id = %d AND event_datetime BETWEEN %s AND %s
            ORDER BY event_datetime ASC",
            $user_id, $date_from, $date_to
        ),
        ARRAY_A
    );
    
    // Check for query errors
    if ($results === null) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL query failed: " . $sql_error;
        vogo_error_log3("[STEP 3] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-SHOW-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Failed to retrieve items.', 'sql_error' => $sql_error], 500);
    }

    // Log the successful action
    $message = "Retrieved " . count($results) . " agenda items.";
    vogo_log_action($user_id, $user_name, $ip, 1, 'M-SHOW-AGENDA', $message);
    vogo_error_log3("[STEP 4] Action completed successfully. " . $message);

    // Return the items
    return new WP_REST_Response([
        'success' => true,
        'message' => $message,
        'items' => $results
    ], 200);
}

/**
 * Returns all shopping items for the authenticated user in the selected time window.
 * Defaults: dateFrom = now() - 7 days, dateTo = now() + 30 days
 */
function vogo_get_shopping_items($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START shopListShowUserItems ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-SHOW-ITEMS', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }

    // Get parameters with default values
    $date_from = sanitize_text_field($request->get_param('dateFrom') ?? date('Y-m-d H:i:s', strtotime('-7 days')));
    $date_to = sanitize_text_field($request->get_param('dateTo') ?? date('Y-m-d H:i:s', strtotime('+30 days')));

    vogo_error_log3("[STEP 2] Fetching shopping items for user: $user_name ($user_id) | From: $date_from | To: $date_to");

    $table = $wpdb->prefix . 'vogo_shopping_list';

    // Fetch items from the database
    $results = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM {$table}
            WHERE user_id = %d AND created_at BETWEEN %s AND %s
            ORDER BY created_at DESC",
            $user_id, $date_from, $date_to
        ),
        ARRAY_A
    );
    
    // Check for query errors
    if ($results === null) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL query failed: " . $sql_error;
        vogo_error_log3("[STEP 3] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-SHOW-ITEMS', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Failed to retrieve items.', 'sql_error' => $sql_error], 500);
    }

    // Log the successful action
    $message = "Retrieved " . count($results) . " shopping items.";
    vogo_log_action($user_id, $user_name, $ip, 1, 'S-SHOW-ITEMS', $message);
    vogo_error_log3("[STEP 4] Action completed successfully. " . $message);

    // Return the items
    return new WP_REST_Response([
        'success' => true,
        'message' => $message,
        'items' => $results
    ], 200);
}


/**
 * Adds a shopping item to the user's list.
 * Requires valid JWT authentication and logs the action to wp_vogo_audit.
 */
function vogo_add_shopping_item($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START shopListAddItem ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Get JSON parameters from the request body
    $params = $request->get_json_params();

    // Validate user ID and required product name
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-ADD-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }
    
    $product_name = sanitize_text_field($params['product_name'] ?? '');
    if (empty($product_name)) {
        $error_message = 'Product name is required.';
        vogo_error_log3("[STEP 1.1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-ADD-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }

    // Prepare data for insertion
    $data = [
        'user_id' => $user_id,
        'product_name' => $product_name,
        'product_id' => intval($params['product_id'] ?? 0),
        'product_vendor' => sanitize_text_field($params['product_vendor'] ?? ''),
        'quantity' => intval($params['quantity'] ?? 1),
        'other_info' => sanitize_textarea_field($params['other_info'] ?? ''),
        'done_checked' => intval($params['done_checked'] ?? 0)
    ];

    vogo_error_log3("[STEP 2] Attempting to insert new shopping list item: " . $data['product_name'] . " | User: $user_name ($user_id)");

    // Perform the INSERT operation
    $table = $wpdb->prefix . 'vogo_shopping_list';
    $result = $wpdb->insert(
        $table,
        $data,
        ['%d', '%s', '%d', '%s', '%d', '%s', '%d']
    );

    // Check for SQL errors
    if ($result === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL INSERT failed: " . $sql_error;
        vogo_error_log3("[STEP 3] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-ADD-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Database insert failed.', 'sql_error' => $sql_error], 500);
    }

    $inserted_id = $wpdb->insert_id;
    $message = "Shopping item added successfully.";

    // Log the successful action
    vogo_log_action($user_id, $user_name, $ip, 1, 'S-ADD-ITEM', $message . " | ID: $inserted_id");
    vogo_error_log3("[STEP 4] Action completed successfully. " . $message . " | ID: $inserted_id");

    // Return success response with new item ID
    return new WP_REST_Response([
        'success' => true,
        'message' => $message,
        'inserted_id' => $inserted_id
    ], 201);
}

/**
 * Deletes a specific shopping list item for the current authenticated user.
 * Required parameter: item_id (int)
 */
function vogo_shop_list_delete_item($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START shopListDeleteItem ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-DELETE-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }

    // Get JSON parameters from the request body
    $params = $request->get_json_params();
    $item_id = intval($params['item_id'] ?? 0);

    // Validate item ID
    if ($item_id <= 0) {
        $error_message = 'Invalid or missing item_id.';
        vogo_error_log3("[STEP 1.1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-DELETE-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }

    vogo_error_log3("[STEP 2] Attempting to delete shopping item ID $item_id. | User: $user_name ($user_id)");

    // Check if item exists and belongs to the user
    $table = $wpdb->prefix . 'vogo_shopping_list';
    $owned = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table} WHERE id = %d AND user_id = %d",
        $item_id, $user_id
    ));

    if (!$owned) {
        $error_message = 'Item not found or does not belong to user.';
        vogo_error_log3("[STEP 3] Access denied. " . $error_message . " | ID: $item_id | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-DELETE-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 404);
    }

    // Delete the item from the database
    $deleted = $wpdb->delete($table, ['id' => $item_id], ['%d']);

    // Check for delete result
    if ($deleted === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL DELETE failed: " . $sql_error;
        vogo_error_log3("[STEP 4] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-DELETE-ITEM', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Could not delete shopping item.', 'sql_error' => $sql_error], 500);
    }

    if ($deleted === 0) {
        $message = "Shopping item with ID $item_id was not found or was already deleted.";
        vogo_error_log3("[STEP 4.1] $message");
        vogo_log_action($user_id, $user_name, $ip, 1, 'S-DELETE-ITEM', $message);
        return new WP_REST_Response(['success' => true, 'message' => $message], 200);
    }

    $message = "Shopping item with ID $item_id deleted successfully.";
    vogo_error_log3("[STEP 5] Action completed successfully. " . $message);
    vogo_log_action($user_id, $user_name, $ip, 1, 'S-DELETE-ITEM', $message);
    
    // Return success response
    return new WP_REST_Response([
        'success' => true,
        'message' => $message
    ], 200);
}

function vogo_agenda_delete_item($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START agenda_delete_item ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-DELETE-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }
    
    // Get JSON parameters from the request body
    $params = $request->get_json_params();
    $id = intval($params['id'] ?? 0);

    // Validate agenda item ID
    if ($id <= 0) {
        $error_message = 'Invalid or missing agenda item ID.';
        vogo_error_log3("[STEP 1.1] Validation failed. Error: " . $error_message . " | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-DELETE-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }

    vogo_error_log3("[STEP 2] Attempting to delete item ID $id. | User: $user_name ($user_id)");

    // Check if the item exists and belongs to the user
    $table = $wpdb->prefix . 'vogo_calendar';
    $owned = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table} WHERE id = %d AND created_by = %d",
        $id, $user_id
    ));

    if (!$owned) {
        $error_message = 'Event not found or does not belong to user.';
        vogo_error_log3("[STEP 3] Access denied. " . $error_message . " | ID: $id | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-DELETE-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 404);
    }

    // Delete the item from the database
    $deleted = $wpdb->delete($table, ['id' => $id], ['%d']);

    // Check if the deletion was successful
    if ($deleted === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL DELETE failed: " . $sql_error;
        vogo_error_log3("[STEP 4] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-DELETE-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Could not delete agenda item.', 'sql_error' => $sql_error], 500);
    }

    if ($deleted === 0) {
        $message = "Agenda item with ID $id was not found.";
        vogo_error_log3("[STEP 4.1] $message");
        vogo_log_action($user_id, $user_name, $ip, 1, 'M-DELETE-AGENDA', $message);
        return new WP_REST_Response(['success' => true, 'message' => $message], 200);
    }

    $message = "Agenda item with ID $id deleted successfully.";
    vogo_error_log3("[STEP 5] Action completed successfully. " . $message);
    vogo_log_action($user_id, $user_name, $ip, 1, 'M-DELETE-AGENDA', $message);
    
    // Return success response
    return new WP_REST_Response([
        'success' => true,
        'message' => $message
    ], 200);
}

function vogo_agenda_mark_done($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START agenda_mark_done ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-MARK-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }
    
    // Get JSON parameters from the request body
    $params = $request->get_json_params();
    $id = intval($params['id'] ?? 0);

    // Validate agenda item ID
    if ($id <= 0) {
        $error_message = 'Invalid or missing agenda item ID.';
        vogo_error_log3("[STEP 1.1] Validation failed. Error: " . $error_message . " | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-MARK-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }

    vogo_error_log3("[STEP 2] Attempting to mark item ID $id as done. | User: $user_name ($user_id)");

    // Check if the item exists and belongs to the user
    $table = $wpdb->prefix . 'vogo_calendar';
    $owned = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table} WHERE id = %d AND created_by = %d",
        $id, $user_id
    ));
    
    if (!$owned) {
        $error_message = 'Event not found or does not belong to user.';
        vogo_error_log3("[STEP 3] Access denied. " . $error_message . " | ID: $id | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-MARK-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 404);
    }

    // Mark item as done
    $updated = $wpdb->update(
        $table,
        ['done_checked' => 1],
        ['id' => $id],
        ['%d'],
        ['%d']
    );

    // Check for update result
    if ($updated === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL UPDATE failed: " . $sql_error;
        vogo_error_log3("[STEP 4] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'M-MARK-AGENDA', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Could not update agenda item.', 'sql_error' => $sql_error], 500);
    }
    
    if ($updated === 0) {
        $message = "Agenda item with ID $id was already done or no changes were made.";
        vogo_error_log3("[STEP 4.1] $message");
        vogo_log_action($user_id, $user_name, $ip, 1, 'M-MARK-AGENDA', $message);
        return new WP_REST_Response(['success' => true, 'message' => $message], 200);
    }

    $message = "Agenda item with ID $id marked as done.";
    vogo_error_log3("[STEP 5] Action completed successfully. " . $message);
    vogo_log_action($user_id, $user_name, $ip, 1, 'M-MARK-AGENDA', $message);
    
    // Return success response
    return new WP_REST_Response([
        'success' => true,
        'message' => $message
    ], 200);
}

function vogo_get_predefined_qa(WP_REST_Request $request) {
    global $wpdb;

    // 🔐 Identifică utilizatorul curent (dacă există)
    $current_user = wp_get_current_user();

    // 🌐 IP-ul clientului
    $ip = vogo_get_client_ip();

    // 📊 Tabela reală (cu prefix WordPress)
    $table = $wpdb->prefix . 'predefined_question_answer';

    // 🎯 Parametru opțional din query: parent_id (pentru a prelua opțiunile unei întrebări)
    $parent_id = $request->get_param('parent_id');

    // ⚙️ Construiește interogarea
    if (!is_null($parent_id)) {
        $sql = $wpdb->prepare("
            SELECT id, parent_id, text, html_text, link, position, active, type
            FROM $table
            WHERE parent_id = %d AND active = 1
            ORDER BY position ASC
        ", $parent_id);
        $log_action_info = "Returned options for parent_id $parent_id";
    } else {
        $sql = "
            SELECT id, parent_id, text, html_text, link, position, active, type
            FROM $table
            WHERE parent_id IS NULL AND active = 1
            ORDER BY position ASC
        ";
        $log_action_info = "Returned root-level predefined QA entries";
    }

    // 🧪 Execută interogarea
    $results = $wpdb->get_results($sql, ARRAY_A);

    // ✅ Succes?
    $log_success = count($results) > 0 ? 1 : 0;

    // 📝 Loghează acțiunea
    vogo_log_action(
        $current_user,
        $current_user->exists() ? $current_user->user_login : '',
        $ip,
        $log_success,
        'M-GET-QA',
        $log_action_info
    );

    // 📤 Returnează răspunsul API
    return new WP_REST_Response([
        'success' => true,
        'data' => $results
    ], 200);
}


function vogo_search_by_text(WP_REST_Request $request) {
    $search_text = sanitize_text_field($request->get_param('searchText'));
    $location = sanitize_text_field($request->get_param('location')); // opțional, momentan neutilizat

    $results = [];

    // 🔍 Caută produse WooCommerce
    $product_query = new WP_Query([
        'post_type' => 'product',
        's' => $search_text,
        'posts_per_page' => 10,
        'post_status' => 'publish'
    ]);

    foreach ($product_query->posts as $product) {
        $results[] = [
            'type' => 'product',
            'title' => $product->post_title,
            'link' => get_permalink($product->ID)
        ];
    }

    // 🔍 Caută categorii de produse
    $product_cats = get_terms([
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
        'name__like' => $search_text
    ]);

    foreach ($product_cats as $cat) {
        $results[] = [
            'type' => 'category',
            'title' => $cat->name,
            'link' => get_term_link($cat)
        ];
    }

    return new WP_REST_Response([
        'success' => true,
        'searchText' => $search_text,
        'results' => $results
    ], 200);
}

function vogo_shop_list_mark_done($request) {
    global $wpdb;

    // ############ START ########################################
    vogo_error_log3("################ START shopListMarkDone ########################");

    // Get client IP address
    $ip = vogo_get_client_ip();

    // Get user from the current WordPress session
    $user_id = get_current_user_id();
    $user = get_user_by('id', $user_id);
    $user_name = $user ? $user->user_login : 'unknown';

    // Validate user ID
    if (!$user_id) {
        $error_message = 'Unauthorized user. Authentication failed.';
        vogo_error_log3("[STEP 1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-MARK-DONE', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 401);
    }
    
    // Get JSON parameters from the request body
    $params = $request->get_json_params();
    $item_id = intval($params['item_id'] ?? 0);

    // Validate item ID
    if ($item_id <= 0) {
        $error_message = 'Invalid or missing item_id.';
        vogo_error_log3("[STEP 1.1] Validation failed. Error: " . $error_message);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-MARK-DONE', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 400);
    }

    vogo_error_log3("[STEP 2] Attempting to mark shopping item ID $item_id as done. | User: $user_name ($user_id)");

    // Check if the item exists and belongs to the user
    $table = $wpdb->prefix . 'vogo_shopping_list';
    $owned = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$table} WHERE id = %d AND user_id = %d",
        $item_id, $user_id
    ));
    
    if (!$owned) {
        $error_message = 'Item not found or does not belong to user.';
        vogo_error_log3("[STEP 3] Access denied. " . $error_message . " | ID: $item_id | User ID: $user_id");
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-MARK-DONE', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => $error_message], 404);
    }

    // Mark item as done
    $updated = $wpdb->update(
        $table,
        ['done_checked' => 1],
        ['id' => $item_id],
        ['%d'],
        ['%d']
    );

    // Check for update result
    if ($updated === false) {
        $sql_error = $wpdb->last_error;
        $error_message = "SQL UPDATE failed: " . $sql_error;
        vogo_error_log3("[STEP 4] $error_message | SQL: " . $wpdb->last_query);
        vogo_log_action($user_id, $user_name, $ip, 0, 'S-MARK-DONE', $error_message);
        return new WP_REST_Response(['success' => false, 'error' => 'Could not update shopping item.', 'sql_error' => $sql_error], 500);
    }
    
    if ($updated === 0) {
        $message = "Shopping item with ID $item_id was already done or no changes were made.";
        vogo_error_log3("[STEP 4.1] $message");
        vogo_log_action($user_id, $user_name, $ip, 1, 'S-MARK-DONE', $message);
        return new WP_REST_Response(['success' => true, 'message' => $message], 200);
    }

    $message = "Shopping item with ID $item_id marked as done.";
    vogo_error_log3("[STEP 5] Action completed successfully. " . $message);
    vogo_log_action($user_id, $user_name, $ip, 1, 'S-MARK-DONE', $message);
    
    // Return success response
    return new WP_REST_Response([
        'success' => true,
        'message' => $message
    ], 200);
}