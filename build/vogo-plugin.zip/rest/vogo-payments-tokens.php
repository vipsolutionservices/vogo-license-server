<?php
/**
 * vogo-payment-tokens.php
 * Namespace: /wp-json/vogo/v1/payments-tokens
 * - Token CRUD for Netopia + WooPayments
 * - Charge by saved token
 */

if (!defined('ABSPATH')) exit;

/* ---------------- Helpers ---------------- */

/** Extract current user id from JWT (0 if missing). */
function vogo_current_user_id_from_request(WP_REST_Request $r){
  $u = extract_user_from_jwt_token($r);
  if(is_wp_error($u) || $u instanceof WP_REST_Response) return 0;
  return (int)$u;
}

/* ---------------- Routes ---------------- */

add_action('rest_api_init', function(){
  $ns = 'vogo/v1/payments-tokens';

  /* Netopia */
  register_rest_route($ns,'/netopia/token',[
    'methods'=>'POST','permission_callback'=>'vogo_permission_check','callback'=>'vogo_netopia_token_create'
  ]);
  register_rest_route($ns,'/netopia/tokens',[
    'methods'=>'GET','permission_callback'=>'vogo_permission_check','callback'=>'vogo_netopia_tokens_list'
  ]);
  register_rest_route($ns,'/netopia/token/(?P<id>\d+)',[
    'methods'=>'DELETE','permission_callback'=>'vogo_permission_check','callback'=>'vogo_netopia_token_delete'
  ]);
  register_rest_route($ns,'/netopia/charge',[
    'methods'=>'POST','permission_callback'=>'vogo_permission_check','callback'=>'vogo_netopia_charge'
  ]);

  /* WooPayments (Stripe) */
  register_rest_route($ns,'/wc/token',[
    'methods'=>'POST','permission_callback'=>'vogo_permission_check','callback'=>'vogo_wc_token_create'
  ]);
  register_rest_route($ns,'/wc/tokens',[
    'methods'=>'GET','permission_callback'=>'vogo_permission_check','callback'=>'vogo_wc_tokens_list'
  ]);
  register_rest_route($ns,'/wc/token/(?P<id>\d+)',[
    'methods'=>'DELETE','permission_callback'=>'vogo_permission_check','callback'=>'vogo_wc_token_delete'
  ]);
  register_rest_route($ns,'/wc/charge',[
    'methods'=>'POST','permission_callback'=>'vogo_permission_check','callback'=>'vogo_wc_charge'
  ]);
});

/* ---------------- Netopia: CRUD ---------------- */

function vogo_netopia_token_create(WP_REST_Request $r){
  global $wpdb;
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $p = $r->get_json_params();
  $token = trim((string)($p['token']??''));
  if($token==='') return new WP_REST_Response(['success'=>false,'error'=>'token_required'],400);

  $ok = $wpdb->insert($wpdb->prefix.'vogo_payment_tokens',[
    'user_id'=>$uid,'gateway'=>'netopia','token'=>$token,
    'last4'=>$p['last4']??null,'brand'=>$p['brand']??null,
    'exp_month'=>!empty($p['exp_month'])?(int)$p['exp_month']:null,
    'exp_year' =>!empty($p['exp_year'])?(int)$p['exp_year']:null,
    'meta'=>!empty($p['meta'])?wp_json_encode($p['meta']):null
  ],['%d','%s','%s','%s','%s','%d','%d','%s']);
  if(!$ok) return new WP_REST_Response(['success'=>false,'error'=>'db_insert','db_error'=>$wpdb->last_error],500);

  return new WP_REST_Response(['success'=>true,'id'=>(int)$wpdb->insert_id],200);
}

function vogo_netopia_tokens_list(WP_REST_Request $r){
  global $wpdb;
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $rows = $wpdb->get_results($wpdb->prepare("
    SELECT id,gateway,last4,brand,exp_month,exp_year,created_at
    FROM {$wpdb->prefix}vogo_payment_tokens
    WHERE user_id=%d AND gateway='netopia'
    ORDER BY id DESC
  ",$uid), ARRAY_A);

  return new WP_REST_Response(['success'=>true,'tokens'=>$rows],200);
}

function vogo_netopia_token_delete(WP_REST_Request $r){
  global $wpdb;
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $id = (int)$r->get_param('id');
  if($id<=0) return new WP_REST_Response(['success'=>false,'error'=>'bad_id'],400);

  $wpdb->query($wpdb->prepare("
    DELETE FROM {$wpdb->prefix}vogo_payment_tokens
    WHERE id=%d AND user_id=%d AND gateway='netopia'
  ",$id,$uid));
  if($wpdb->last_error) return new WP_REST_Response(['success'=>false,'error'=>'db','db_error'=>$wpdb->last_error],500);

  return new WP_REST_Response(['success'=>true,'deleted_id'=>$id],200);
}

/* ---------------- Netopia: Charge ---------------- */

function vogo_netopia_charge(WP_REST_Request $r){
  global $wpdb;
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $p = $r->get_json_params();
  $token_id = (int)($p['token_id']??0);
  $amount   = (float)($p['amount']??0);
  $currency = strtoupper((string)($p['currency']??'RON'));
  $order_id = (int)($p['order_id']??0);
  if($token_id<=0 || $amount<=0) return new WP_REST_Response(['success'=>false,'error'=>'bad_args'],400);

  $row = $wpdb->get_row($wpdb->prepare("
    SELECT token FROM {$wpdb->prefix}vogo_payment_tokens
    WHERE id=%d AND user_id=%d AND gateway='netopia' LIMIT 1
  ",$token_id,$uid), ARRAY_A);
  if(!$row) return new WP_REST_Response(['success'=>false,'error'=>'token_not_found'],404);

  $resp = vogo_netopia_charge_provider($row['token'],$amount,$currency,$order_id);
  if(empty($resp['success'])) return new WP_REST_Response(['success'=>false,'error'=>'provider_error','detail'=>$resp],502);

  if($order_id>0 && !empty($resp['transaction_id'])){
    $order = wc_get_order($order_id);
    if($order){ $order->payment_complete($resp['transaction_id']); update_post_meta($order_id,'_netopia_charge_txn',$resp['transaction_id']); }
  }
  return new WP_REST_Response(['success'=>true,'provider'=>$resp],200);
}

/** Replace with real Netopia API call. */
function vogo_netopia_charge_provider($netopia_token,$amount,$currency='RON',$order_id=0){
  $api_key = (string)get_option('vogo_netopia_api_key','');
  $api_secret = (string)get_option('vogo_netopia_api_secret','');
  if($api_key==='' || $api_secret==='') return ['success'=>false,'error'=>'no_api_credentials'];
  // Stub success:
  return ['success'=>true,'transaction_id'=>'demo_'.time()];
}

/* ---------------- WooPayments: CRUD ---------------- */

function vogo_wc_token_create(WP_REST_Request $r){
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $p = $r->get_json_params();
  $pm = trim((string)($p['token']??'')); if($pm==='') return new WP_REST_Response(['success'=>false,'error'=>'token_required'],400);
  $gateway = trim((string)($p['gateway']??'woocommerce_payments'));

  $t = new WC_Payment_Token_CC();
  $t->set_token($pm);
  $t->set_gateway_id($gateway);
  $t->set_user_id($uid);
  if(!empty($p['last4']))     $t->set_last4($p['last4']);
  if(!empty($p['brand']))     $t->set_card_type($p['brand']);
  if(!empty($p['exp_month'])) $t->set_expiry_month((int)$p['exp_month']);
  if(!empty($p['exp_year']))  $t->set_expiry_year((int)$p['exp_year']);
  $t->save();

  return new WP_REST_Response(['success'=>true,'id'=>$t->get_id()],200);
}

function vogo_wc_tokens_list(WP_REST_Request $r){
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $tokens = WC_Payment_Tokens::get_customer_tokens($uid);
  $out = [];
  foreach($tokens as $t){
    if(!($t instanceof WC_Payment_Token_CC)) continue;
    $out[] = [
      'id'=>$t->get_id(),
      'gateway'=>$t->get_gateway_id(),
      'last4'=>$t->get_last4(),
      'brand'=>$t->get_card_type(),
      'exp_month'=>$t->get_expiry_month(),
      'exp_year'=>$t->get_expiry_year()
    ];
  }
  return new WP_REST_Response(['success'=>true,'tokens'=>$out],200);
}

function vogo_wc_token_delete(WP_REST_Request $r){
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $id = (int)$r->get_param('id'); if($id<=0) return new WP_REST_Response(['success'=>false,'error'=>'bad_id'],400);
  $t = WC_Payment_Tokens::get($id);
  if(!$t || (int)$t->get_user_id() !== $uid) return new WP_REST_Response(['success'=>false,'error'=>'not_found'],404);
  $t->delete();
  return new WP_REST_Response(['success'=>true,'deleted_id'=>$id],200);
}

/* ---------------- WooPayments: Charge ---------------- */

function vogo_wc_charge(WP_REST_Request $r){
  $uid = vogo_current_user_id_from_request($r);
  if($uid<=0) return new WP_REST_Response(['success'=>false,'error'=>'auth_required'],401);

  $p = $r->get_json_params();
  $token_id = (int)($p['token_id']??0);
  $amount   = (float)($p['amount']??0);
  $currency = strtoupper((string)($p['currency']??''));
  $order_id = (int)($p['order_id']??0);
  if($token_id<=0 || $amount<=0) return new WP_REST_Response(['success'=>false,'error'=>'bad_args'],400);

  $tok = WC_Payment_Tokens::get($token_id);
  if(!$tok || (int)$tok->get_user_id()!==$uid) return new WP_REST_Response(['success'=>false,'error'=>'token_not_found'],404);

  $gwid = $tok->get_gateway_id();
  $gws = WC()->payment_gateways()->get_available_payment_gateways();
  if(empty($gws[$gwid])) return new WP_REST_Response(['success'=>false,'error'=>'gateway_unavailable'],500);
  $gw = $gws[$gwid];

  if(method_exists($gw,'charge_token')){
    $resp = $gw->charge_token($tok->get_token(),$amount,$currency,$order_id);
    if(is_array($resp) && !empty($resp['success'])){
      if($order_id>0){ $order = wc_get_order($order_id); if($order) $order->payment_complete($resp['transaction_id'] ?? uniqid($gwid.'_')); }
      return new WP_REST_Response(['success'=>true,'provider'=>$resp],200);
    }
    return new WP_REST_Response(['success'=>false,'provider'=>$resp],502);
  }

  return new WP_REST_Response(['success'=>false,'error'=>'no_gateway_token_charge_impl','gateway'=>$gwid],501);
}
