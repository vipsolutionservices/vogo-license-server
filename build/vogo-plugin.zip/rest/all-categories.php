<?php
/**
 * VOGO API Endpoint Registration
 * Adi-tehnic: Clean SQL-first approach with inline JSON construction.
 * Comment style: English only. Logs: step-by-step with user/IP trace.
 */
//clear_debug_log_file();
$MODULE_PHP='all-categories.php';

add_action('rest_api_init', function () {
    register_rest_route('vogo/v1', '/category-list', [
        'methods'             => 'POST',
        'callback'            => 'custom_category_list_all',
        'permission_callback' => 'vogo_permission_check',
    ]);

    //deprecated
register_rest_route('vogo/v1/products', '/get_products_by_filters', [
  'methods' => 'POST',
  'callback' => 'get_products_by_filters',
  'permission_callback' => 'vogo_permission_check'
]);

});



/**
 * Returns up to 100 mobile-enabled product categories using SQL and JSON_OBJECT()
 */
function custom_category_list_all(WP_REST_Request $request) {
  global $wpdb;

  // ─────────────────────────────────────────────────────────────────────────────
  // VOGO_LOG_START + initial debug context
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | IP: $ip | USER: 0");
  $raw_input = file_get_contents('php://input'); vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: 0");
  $db_name = $wpdb->get_var("SELECT DATABASE()"); vogo_error_log3("ACTIVE DB: $db_name | IP: $ip | USER: 0");

  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 1] Security: extract user from JWT (mandatory in adi-tehnic)
  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) { vogo_error_log3("[STEP 1] JWT validation failed | IP: $ip | USER: 0"); return $user_id; }
  $wp_user = get_user_by('id', (int)$user_id); $user_login = $wp_user ? $wp_user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] JWT validated | IP: $ip | USER: $user_id");

  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 2] Parse & sanitize pagination params (defaults + caps)
  $p = $request->get_json_params();
  $current_page = max(1, intval($p['current_page'] ?? 1));
  $per_page_raw = intval($p['per_page'] ?? 20);
  $per_page = ($per_page_raw > 0 && $per_page_raw <= 100) ? $per_page_raw : 20; // cap at 100 for safety
  $offset = ($current_page - 1) * $per_page;
  vogo_error_log3("[STEP 2] Pagination resolved: current_page=$current_page, per_page=$per_page, offset=$offset | IP: $ip | USER: $user_id");

  // ─────────────────────────────────────────────────────────────────────────────
  // [STEP 3] Table names with WP prefix (adi-tehnic rule)
  $t_terms = $wpdb->prefix . 'terms';
  $t_term_tax = $wpdb->prefix . 'term_taxonomy';
  $t_termmeta = $wpdb->prefix . 'termmeta';
  $t_posts = $wpdb->prefix . 'posts';

  try {
    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 4] COUNT total_items (filters identical to data query)
    $sql_count = "
      SELECT COUNT(1)
      FROM {$t_terms} t
      INNER JOIN {$t_term_tax} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'
      LEFT JOIN {$t_termmeta} m ON m.term_id = t.term_id AND m.meta_key = 'mobile_category'
      WHERE m.meta_value = '1'
    ";
    vogo_error_log3("##############SQL: $sql_count | IP: $ip | USER: $user_id");
    $total_items = (int)$wpdb->get_var($sql_count);
    if (!empty($wpdb->last_error)) { vogo_error_log3("[STEP 4] SQL Error (count): {$wpdb->last_error} | IP: $ip | USER: $user_id"); }

    $total_pages = ($per_page > 0) ? (int)ceil($total_items / $per_page) : 0;
    vogo_error_log3("[STEP 4.1] Totals computed: total_items=$total_items, total_pages=$total_pages | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 5] DATA query with JSON_OBJECT + ORDER + LIMIT/OFFSET
    $sql_data = "
      SELECT JSON_OBJECT(
        'id', t.term_id,
        'name', t.name,
        'slug', t.slug,
        'description', COALESCE(tt.description, ''),
        'image', IFNULL(p.guid, ''),
        'position', t.term_order,
        'has_children', (
          SELECT IF(COUNT(*) > 0, TRUE, FALSE)
          FROM {$t_terms} c
          INNER JOIN {$t_term_tax} ct ON ct.term_id = c.term_id AND ct.taxonomy = 'product_cat'
          LEFT JOIN {$t_termmeta} cm ON cm.term_id = c.term_id AND cm.meta_key = 'mobile_category'
          WHERE ct.parent = t.term_id AND cm.meta_value = '1'
        )
      ) AS json_data
      FROM {$t_terms} t
      INNER JOIN {$t_term_tax} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'
      LEFT JOIN {$t_termmeta} m  ON m.term_id  = t.term_id AND m.meta_key = 'mobile_category'
      LEFT JOIN {$t_termmeta} mt ON mt.term_id = t.term_id AND mt.meta_key = 'thumbnail_id'
      LEFT JOIN {$t_posts} p     ON p.ID       = mt.meta_value
      WHERE m.meta_value = '1'
      ORDER BY t.term_order ASC
      LIMIT %d OFFSET %d
    ";
    $sql_data = $wpdb->prepare($sql_data, $per_page, $offset);
    vogo_error_log3("##############SQL: $sql_data | IP: $ip | USER: $user_id");

    $raw = $wpdb->get_col($sql_data);
    if (!empty($wpdb->last_error)) { vogo_error_log3("[STEP 5] SQL Error (data): {$wpdb->last_error} | IP: $ip | USER: $user_id"); }

    vogo_error_log3("[STEP 5.1] RAW SQL JSON rows: " . print_r($raw, true) . " | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 6] Decode JSON rows safely
    $results = array_map(static function($r){ return json_decode($r, true); }, $raw ?? []);
    vogo_error_log3("[STEP 6] Decoded " . count($results) . " categories | IP: $ip | USER: $user_id");

    // ───────────────────────────────────────────────────────────────────────────
    // [STEP 7] Build response with pagination meta + user
    $response = array(
      'status'        => true,
      'code'          => 200,
      'message'       => 'Category list fetched successfully.',
      'current_page'  => $current_page,
      'per_page'      => $per_page,
      'total_pages'   => $total_pages,
      'total_items'   => $total_items,
      'data'          => $results,
      'user_id'       => (int)$user_id,
      'user_login'    => $user_login,
    );
    vogo_error_log3("VOGO_LOG_END | IP: $ip | USER: $user_id");
    return new WP_REST_Response($response, 200);

  } catch (Throwable $e) {
    // ───────────────────────────────────────────────────────────────────────────
    vogo_error_log3("[STEP ERR] Exception: " . $e->getMessage() . " | IP: $ip | USER: $user_id");
    vogo_error_log3("VOGO_LOG_END | IP: $ip | USER: $user_id");
    return new WP_REST_Response(array(
      'status'     => false,
      'code'       => 500,
      'message'    => 'Server error. Please try again.',
      'error'      => $e->getMessage(),
      'sql_error'  => $wpdb->last_error ?? null,
      'user_id'    => (int)$user_id,
      'user_login' => $user_login ?? 'unknown',
    ), 500);
  }
}

// Function is POST-only (Adi-tehnic rule)
function get_products_by_filters(WP_REST_Request $request) {

  // ADI-TECHNIC: Hard deprecation gate — short-circuit old endpoint
  if (!headers_sent() && function_exists('vogo_error_log3')) {
      vogo_error_log3('[DEPRECATED] /product_list called. Use /product/product-list instead.');
  }
  return new WP_REST_Response([
      'success' => false,
      'code'    => 410,
      'message' => 'Deprecated API. Use /product/product-list instead'
  ], 410);
    
  global $wpdb;

  // ────────────────────────────────────────────────
  // Logs bootstrap
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  vogo_error_log3("VOGO_LOG_START [GET PRODUCTS BY FILTERS] | IP: $ip | USER: ?");
  $active_db = $wpdb->get_var('SELECT DATABASE()');
  vogo_error_log3("ACTIVE DB: {$active_db} | IP: $ip | USER: ?");
  $raw_input = file_get_contents('php://input');
  vogo_error_log3("[STEP 0.1] Raw JSON payload received: $raw_input | IP: $ip | USER: ?");

  // ────────────────────────────────────────────────
  // JWT
  $user_or_err = extract_user_from_jwt_token($request);
  if ($user_or_err instanceof WP_REST_Response) {
    vogo_error_log3("[STEP 0.2] JWT extraction failed | IP: $ip | USER: ?");
    return $user_or_err;
  }
  $user_id = (int)$user_or_err;
  $user = get_userdata($user_id);
  $user_login = $user ? $user->user_login : 'unknown';
  vogo_error_log3("[STEP 1] User resolved: user_id=$user_id, user_login=$user_login | IP: $ip | USER: $user_id");

  // ────────────────────────────────────────────────
  // Payload
  $data = json_decode($raw_input, true);
  if (empty($data)) $data = $request->get_params();

  $product_id = isset($data['product_id']) ? (int)$data['product_id'] : 0;
  $keyword    = isset($data['keyword']) ? sanitize_text_field($data['keyword']) : '';
  $orderby    = isset($data['orderby']) ? sanitize_text_field($data['orderby']) : 'ID';
  $order      = strtoupper(isset($data['order']) ? sanitize_text_field($data['order']) : 'DESC');
  $order      = in_array($order, ['ASC','DESC'], true) ? $order : 'DESC';

  $per_page   = isset($data['per_page']) ? max(1, min(100, (int)$data['per_page'])) : 10;
  $page       = isset($data['current_page']) ? max(1, (int)$data['current_page']) : 1;
  $offset     = ($page - 1) * $per_page;

  $category_ids = !empty($data['category']) ? array_map('intval', (array)$data['category']) : [];
  $brand_ids    = !empty($data['product_brand']) ? array_map('intval', (array)$data['product_brand']) : [];
  $city_ids     = !empty($data['city_id']) ? array_map('intval', (array)$data['city_id']) : [];
  $mall_ids     = !empty($data['mall_id']) ? array_map('intval', (array)$data['mall_id']) : [];

  vogo_error_log3("[STEP 2] Filters parsed | product_id=$product_id | keyword=$keyword | per_page=$per_page | page=$page | categories=[".implode(',',$category_ids)."] | brands=[".implode(',',$brand_ids)."] | cities=[".implode(',',$city_ids)."] | malls=[".implode(',',$mall_ids)."] | IP: $ip | USER: $user_id");

  // ────────────────────────────────────────────────
  // Tables
  $p  = $wpdb->posts;
  $tr = $wpdb->term_relationships;
  $tt = $wpdb->term_taxonomy;
  $lk = $wpdb->prefix . 'wc_product_meta_lookup';
  $pc = $wpdb->prefix . 'product_cities';
  $mc = $wpdb->prefix . 'product_malls';

  // WHERE
  $where  = ["p.post_type='product'","p.post_status='publish'"];
  $params = [];

  if ($product_id > 0) { $where[]="p.ID = %d"; $params[]=$product_id; }
  if ($keyword !== '') { $where[]="(p.post_title LIKE %s OR p.post_name LIKE %s)"; $params[]='%'.$wpdb->esc_like($keyword).'%'; $params[]='%'.$wpdb->esc_like($keyword).'%'; }
  if (!empty($category_ids)) { $ids=implode(',', $category_ids); $where[]="EXISTS (SELECT 1 FROM {$tr} trc JOIN {$tt} ttc ON ttc.term_taxonomy_id=trc.term_taxonomy_id WHERE trc.object_id=p.ID AND ttc.taxonomy='product_cat' AND ttc.term_id IN ($ids))"; }
  if (!empty($brand_ids))    { $ids=implode(',', $brand_ids);    $where[]="EXISTS (SELECT 1 FROM {$tr} trb JOIN {$tt} ttb ON ttb.term_taxonomy_id=trb.term_taxonomy_id WHERE trb.object_id=p.ID AND ttb.taxonomy='product_brand' AND ttb.term_id IN ($ids))"; }
  if (!empty($city_ids))     { $ids=implode(',', $city_ids);     $where[]="EXISTS (SELECT 1 FROM {$pc} pc WHERE pc.product_id=p.ID AND pc.city_id IN ($ids))"; }
  if (!empty($mall_ids))     { $ids=implode(',', $mall_ids);     $where[]="EXISTS (SELECT 1 FROM {$mc} pm WHERE pm.product_id=p.ID AND pm.mall_id IN ($ids))"; }

  $where_sql = implode(' AND ', $where);

  // ORDER
  $order_col = "p.ID";
  if ($orderby==='price')        $order_col="l.min_price";
  elseif ($orderby==='rating')   $order_col="l.average_rating";
  elseif ($orderby==='popularity') $order_col="l.total_sales";
  elseif ($orderby==='date')     $order_col="p.post_date";
  elseif ($orderby==='title')    $order_col="p.post_title";
  elseif ($orderby==='position') $order_col="p.menu_order";

  // ────────────────────────────────────────────────
  // COUNT
  $count_sql = "SELECT COUNT(1) FROM {$p} p JOIN {$lk} l ON l.product_id=p.ID WHERE $where_sql";
  $sql_count = !empty($params) ? $wpdb->prepare($count_sql, $params) : $count_sql;
  vogo_error_log3("##############SQL COUNT: " . preg_replace('/\s+/', ' ', $sql_count) . " | IP: $ip | USER: $user_id");
  $total_count = (int)$wpdb->get_var($sql_count);
  if ($wpdb->last_error) {
    vogo_error_log3("[STEP 3.E] SQL count error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB error on count','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login], 500);
  }

  // ────────────────────────────────────────────────
  // MAIN
  $select = "
    p.ID,
    p.post_title,
    p.post_name AS slug,
    p.menu_order AS position,
    l.min_price      AS price,
    l.max_price      AS max_price,
    l.onsale         AS onsale,
    l.stock_quantity,
    l.stock_status,
    l.average_rating AS rating,
    l.total_sales    AS popularity
  ";
  $main_sql = "
    SELECT $select
    FROM {$p} p
    JOIN {$lk} l ON l.product_id=p.ID
    WHERE $where_sql
    ORDER BY $order_col $order
    LIMIT %d OFFSET %d
  ";
  $bind_main = array_merge($params, [$per_page, $offset]);
  $sql_main  = $wpdb->prepare($main_sql, $bind_main);
  vogo_error_log3("##############SQL MAIN: " . preg_replace('/\s+/', ' ', $sql_main) . " | IP: $ip | USER: $user_id");
  $rows = $wpdb->get_results($sql_main, ARRAY_A);
  if ($wpdb->last_error) {
    vogo_error_log3("[STEP 4.E] SQL main error: {$wpdb->last_error} | IP: $ip | USER: $user_id");
    return new WP_REST_Response(['success'=>false,'error'=>'DB error on fetch','sql_error'=>$wpdb->last_error,'user_id'=>$user_id,'user_login'=>$user_login], 500);
  }

  // ────────────────────────────────────────────────
  // Currency
  $currency_symbol = html_entity_decode(get_woocommerce_currency_symbol());
  $currency_code   = get_woocommerce_currency();

  // Hydrate rows
  $data=[]; 
  foreach ($rows as $r) {
    $pid=(int)$r['ID'];
    $thumb_id = (int)get_post_thumbnail_id($pid);
    $img = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
    $cats=[]; 
    $terms=get_the_terms($pid,'product_cat'); 
    if ($terms && !is_wp_error($terms)) { foreach($terms as $term){ $cats[]=['id'=>$term->term_id,'name'=>$term->name]; } }

    $data[] = [
      'id'              => $pid,
      'name'            => $r['post_title'],
      'slug'            => $r['slug'],
      'position'        => (int)($r['position'] ?? 0),
      'price'           => (string)($r['price'] ?? ''),
      'max_price'       => (string)($r['max_price'] ?? ''),
      'onsale'          => (int)($r['onsale'] ?? 0),
      'stock_quantity'  => isset($r['stock_quantity']) ? (int)$r['stock_quantity'] : null,
      'stock_status'    => $r['stock_status'],
      'rating'          => (float)($r['rating'] ?? 0),
      'popularity'      => (int)($r['popularity'] ?? 0),
      'currency_symbol' => $currency_symbol,
      'currency_code'   => $currency_code,
      'image'           => $img,
      'post_status'     => 'active',
      'categories'      => $cats
    ];
  }

  // ────────────────────────────────────────────────
  // Response
  vogo_error_log3("VOGO_LOG_END | IP: $ip | USER: $user_id");
  return new WP_REST_Response([
    'success'        => true,
    'code'           => 200,
    'message'        => $total_count>0 ? 'Products fetched successfully' : 'No records found',
    'current_page'   => $page,
    'per_page'       => $per_page,
    'total_pages'    => $per_page>0 ? ceil($total_count/$per_page) : 0,
    'total_items'    => $total_count,
    'currency_code'  => $currency_code,
    'currency_symbol'=> $currency_symbol,
    'data'           => $data,
    'user_id'        => $user_id,
    'user_login'     => $user_login
  ], 200);
}


