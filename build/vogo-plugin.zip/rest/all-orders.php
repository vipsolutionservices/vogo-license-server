<?php
$MODULE_PHP='all-orders.php';
/**
 * VOGO API — Orders (customer & provider)
 * - Customer: get order + vendor suborders (status per vendor)
 * - Provider: list own suborders, update suborder status
 * Notes:
 * - Auth via vogo_permission_check (JWT); user_id via extract_user_from_jwt_token($request)
 * - Suborders are shop_order posts with post_parent = parent order id and meta _vogo_vendor_id
 */



/* ─────────────────────────────────────────────────────────────────────────────
 * ROUTES
 * ───────────────────────────────────────────────────────────────────────────── */
add_action('rest_api_init', function () {

  // BACKCOMP (existing)
//just rewrite
register_rest_route('vogo/v1/order', '/customer-get-order-list-old-dar-bun-cu suborders', [
  'methods'  => 'POST',
  'callback' => 'vogo_customer_get_order_list_with_suborders',
  'permission_callback' => 'vogo_permission_check',
]);

register_rest_route('vogo/v1/account', '/account_orders_list', [
  'methods'  => 'POST',
  'callback' => 'account_orders_list',
  'permission_callback' => 'vogo_permission_check',
]);

  register_rest_route('vogo/v1/account', '/account_order_details', [
  'methods'  => 'POST',
  'callback' => 'account_order_details',
  'permission_callback' => 'vogo_permission_check',
]);

  // Legacy mobile endpoint (VOGOFAMILY namespace)
  register_rest_route('VOGOFAMILY', '/order-list', [
    'methods'  => ['GET','POST'],
    'callback' => 'account_orders_list',
    'permission_callback' => '__return_true',
  ]);

//just rewrite
  register_rest_route('vogo/v1', '/order-list-old', [
    'methods'  => 'GET',
    'callback' => 'custom_order_list_old',
    'permission_callback' => 'vogo_permission_check',
  ]);

//just rewrite
  register_rest_route('vogo/v1', 'client/order-list-deprecated', [ //old - woo based
    'methods'  => 'POST',
    'callback' => 'custom_order_list2',
    'permission_callback' => 'vogo_permission_check',
  ]);  
//just rewrite
  register_rest_route('vogo/v1', '/order-detail', [
    'methods'  => 'GET',
    'callback' => 'custom_order_detail',
    'permission_callback' => 'vogo_permission_check',
  ]);

  register_rest_route('vogo/v1', '/notification-list', [
    'methods'  => 'GET',
    'callback' => 'custom_notification_list',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // CUSTOMER: rate own order (Woo standard meta)
  register_rest_route('vogo/v1', '/order-review', [
    'methods'  => 'POST',
    'callback' => 'vogo_order_review',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // NEW — CUSTOMER: get order + suborders
  register_rest_route('vogo/v1/order', '/customer-get-order - old', [
    'methods'  => 'POST',
    'callback' => 'vogo_customer_get_order_with_suborders',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // NEW — PROVIDER: list own suborders
  register_rest_route('vogo/v1/provider', '/orders-list', [
    'methods'  => 'POST',
    'callback' => 'vogo_provider_orders_list',
    'permission_callback' => 'vogo_permission_check',
  ]);

  // NEW — PROVIDER: update suborder status
  register_rest_route('vogo/v1/provider', '/update-order-status', [
    'methods'  => 'POST',
    'callback' => 'vogo_provider_update_order_status',
    'permission_callback' => 'vogo_permission_check',
  ]);

}, 10);

/* ─────────────────────────────────────────────────────────────────────────────
 * HELPERS
 * ───────────────────────────────────────────────────────────────────────────── */
/** Map Woo status -> RO label for app UI */
if (!function_exists('vogo_status_ro')) {
  function vogo_status_ro($st){
    $st = is_string($st) ? ltrim($st,'wc-') : $st;
    return match($st){
      'completed' => 'livrat',
      'processing','on-hold','pending' => 'în curs de livrare',
      'cancelled','refunded','failed' => 'anulat',
      default => $st
    };
  }
}

if (!function_exists('vogo_sync_recent_woo_orders_for_user')) {
  /**
   * Sync parent Woo orders from the last N hours for a user into custom orders table.
   * Inserts only orders missing from {$wpdb->prefix}orders by calling proc_sync_vogo_parent_order.
   */
  function vogo_sync_recent_woo_orders_for_user(int $uid, int $hours = 24, bool $debug = false): array {
    global $wpdb;

    $tbl_o = $wpdb->prefix . 'orders';
    if ($uid <= 0 || !get_userdata($uid)) {
      return ['synced_count' => 0, 'missing_ids' => [], 'error' => 'invalid_user'];
    }

    $hours = max(1, min(168, $hours));
    $after_gmt = gmdate('Y-m-d H:i:s', time() - ($hours * HOUR_IN_SECONDS));
    $user = get_userdata($uid);
    $email = $user ? trim((string)$user->user_email) : '';

    $woo_ids = wc_get_orders([
      'type'        => 'shop_order',
      'status'      => array_keys(wc_get_order_statuses()),
      'parent'      => 0,
      'customer_id' => $uid,
      'date_created'=> '>' . $after_gmt,
      'return'      => 'ids',
      'limit'       => -1,
    ]);
    $woo_ids = array_values(array_unique(array_map('intval', (array)$woo_ids)));

    if ($email !== '') {
      $woo_by_email = wc_get_orders([
        'type'          => 'shop_order',
        'status'        => array_keys(wc_get_order_statuses()),
        'parent'        => 0,
        'billing_email' => $email,
        'date_created'  => '>' . $after_gmt,
        'return'        => 'ids',
        'limit'         => -1,
      ]);
      $woo_ids = array_values(array_unique(array_merge($woo_ids, array_map('intval', (array)$woo_by_email))));
    }

    if (empty($woo_ids)) {
      return [
        'synced_count' => 0,
        'missing_ids' => [],
        'woo_ids_count' => 0,
        'hours' => $hours,
        'after_gmt' => $after_gmt,
      ];
    }

    $placeholders = implode(',', array_fill(0, count($woo_ids), '%d'));
    $q_existing = $wpdb->prepare("SELECT id FROM {$tbl_o} WHERE id IN ($placeholders)", $woo_ids);
    $existing_ids = array_map('intval', (array)$wpdb->get_col($q_existing));
    $missing_ids = array_values(array_diff($woo_ids, $existing_ids));

    $synced_count = 0;
    if (!empty($missing_ids)) {
      vogo_error_log3("[SYNC-24H] Missing Woo parent orders for user {$uid}: " . implode(',', $missing_ids));
      foreach ($missing_ids as $oid) {
        $res = $wpdb->query($wpdb->prepare("CALL proc_sync_vogo_parent_order(%d)", (int)$oid));
        if ($res !== false) {
          $synced_count++;
        } else {
          vogo_error_log3("[SYNC-24H] Sync failed for order {$oid} | USER:$uid");
        }
      }
    }

    $out = [
      'synced_count' => $synced_count,
      'missing_ids' => $missing_ids,
      'woo_ids_count' => count($woo_ids),
      'hours' => $hours,
      'after_gmt' => $after_gmt,
    ];
    if ($debug) {
      $out['woo_ids_sample'] = array_slice($woo_ids, 0, 5);
      $out['missing_ids_sample'] = array_slice($missing_ids, 0, 5);
    }
    return $out;
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
 * 1) CUSTOMER — get order + vendor suborders
 * ───────────────────────────────────────────────────────────────────────────── */
/** Title: Customer gets own order with suborders (per vendor) */
function vogo_customer_get_order_with_suborders(WP_REST_Request $request){ //old
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
  $p  = (array)$request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0);

  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  if ($order_id <= 0) return new WP_REST_Response(['success'=>false,'error'=>'order_id is required'],400);

  $order = wc_get_order($order_id);
  if (!$order) return new WP_REST_Response(['success'=>false,'error'=>'Order not found'],404);

  // Ownership check (guest handling poate fi adăugat separat dacă e nevoie)
  if ((int)$order->get_user_id() !== (int)$user_id) {
    return new WP_REST_Response(['success'=>false,'error'=>'Forbidden'],403);
  }

  // Shipping address + street number
  $ship = $order->get_address('shipping');
  $street_no = $order->get_meta('_shipping_street_number');
  if (!$street_no && $order->get_user_id()) {
    $street_no = get_user_meta($order->get_user_id(),'shipping_street_number',true);
  }
  if (!empty($ship['address_1']) && $street_no && strpos($ship['address_1'], (string)$street_no) === false) {
    $ship['address_1'] .= ' '.$street_no;
  }

  $parent = [
    'order_id'   => $order->get_id(),
    'status'     => $order->get_status(),
    'status_ro'  => vogo_status_ro($order->get_status()),
    'created_at' => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : null,
    'currency'   => $order->get_currency(),
    'totals'     => [
      'subtotal' => (float)$order->get_subtotal(),
      'shipping' => (float)$order->get_shipping_total(),
      'tax'      => (float)$order->get_total_tax(),
      'discount' => (float)$order->get_discount_total(),
      'total'    => (float)$order->get_total(),
    ],
    'shipping_address' => $ship,
  ];

  // Collect children (suborders)
  $children = get_children([
    'post_parent' => $order->get_id(),
    'post_type'   => 'shop_order',
    'post_status' => 'any',
    'numberposts' => -1,
    'orderby'     => 'ID',
    'order'       => 'ASC',
  ]);

  global $wpdb;
  $out_sub = [];
  foreach ($children as $child_post) {
    $child = wc_get_order($child_post->ID);
    if (!$child) continue;

    $vid   = (int)$child->get_meta('_vogo_vendor_id');
    $vname = $vid ? $wpdb->get_var($wpdb->prepare(
      "SELECT provider_name FROM {$wpdb->prefix}vogo_providers WHERE id=%d LIMIT 1", $vid
    )) : '';

    $out_sub[] = [
      'child_order_id' => $child->get_id(),
      'vendor_id'      => $vid ?: null,
      'vendor_name'    => $vname ?: null,
      'status'         => $child->get_status(),
      'status_ro'      => vogo_status_ro($child->get_status()),
      'totals'         => [
        'subtotal' => (float)$child->get_subtotal(),
        'shipping' => (float)$child->get_shipping_total(),
        'tax'      => (float)$child->get_total_tax(),
        'total'    => (float)$child->get_total(),
      ],
      'items' => array_values(array_map(function($it){
        return [
          'product_id' => (int)$it->get_product_id(),
          'name'  => $it->get_name(),
          'qty'   => (int)$it->get_quantity(),
          'total' => (float)$it->get_total() + (float)$it->get_total_tax(),
        ];
      }, $child->get_items('line_item'))),
    ];
  }

  return new WP_REST_Response([
    'success'   => true,
    'order'     => $parent,
    'suborders' => $out_sub,
  ],200);
}

/* ─────────────────────────────────────────────────────────────────────────────
 * 2) PROVIDER — list own suborders
 * ───────────────────────────────────────────────────────────────────────────── */
/** Title: Provider lists his suborders (child orders) */
function vogo_provider_orders_list(WP_REST_Request $request){
  $p = (array)$request->get_json_params();

  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  $vendor_id = get_vendor_id_for_user($user_id);
  if (!$vendor_id) return new WP_REST_Response(['success'=>false,'error'=>'No vendor mapped to this user'],403);

  $page = max(1,(int)($p['page'] ?? 1));
  $per  = max(1,min(100,(int)($p['per_page'] ?? 20)));
  $ofs  = ($page-1)*$per;

  $statuses = $p['status'] ?? [];
  $statuses = is_array($statuses) ? array_filter(array_map('sanitize_text_field',$statuses)) : [];

  // Query child orders that belong to this vendor
  $args = [
    'post_type'      => 'shop_order',
    'post_status'    => !empty($statuses) ? array_map(fn($s)=> 'wc-'.ltrim($s,'wc-'), $statuses) : array_keys(wc_get_order_statuses()),
    'meta_query'     => [
      [
        'key'   => '_vogo_vendor_id',
        'value' => (string)$vendor_id,
      ]
    ],
    'posts_per_page' => $per,
    'offset'         => $ofs,
    'orderby'        => 'ID',
    'order'          => 'DESC',
    'fields'         => 'ids',
  ];

  $q   = new WP_Query($args);
  $ids = $q->posts;

  $rows = [];
  foreach ($ids as $oid) {
    $o = wc_get_order($oid);
    if (!$o) continue;
    $rows[] = [
      'order_id'   => $o->get_id(),
      'parent_id'  => wp_get_post_parent_id($o->get_id()) ?: null,
      'status'     => $o->get_status(),
      'status_ro'  => vogo_status_ro($o->get_status()),
      'date'       => $o->get_date_created() ? $o->get_date_created()->date('Y-m-d H:i:s') : null,
      'currency'   => $o->get_currency(),
      'totals'     => [
        'subtotal' => (float)$o->get_subtotal(),
        'shipping' => (float)$o->get_shipping_total(),
        'tax'      => (float)$o->get_total_tax(),
        'total'    => (float)$o->get_total(),
      ],
      'items' => array_values(array_map(function($it){
        return [
          'product_id' => (int)$it->get_product_id(),
          'name'  => $it->get_name(),
          'qty'   => (int)$it->get_quantity(),
          'total' => (float)$it->get_total() + (float)$it->get_total_tax(),
        ];
      }, $o->get_items('line_item'))),
    ];
  }

  return new WP_REST_Response([
    'success'   => true,
    'vendor_id' => $vendor_id,
    'page'      => $page,
    'per_page'  => $per,
    'total'     => (int)$q->found_posts,
    'orders'    => $rows,
  ],200);
}

/* ─────────────────────────────────────────────────────────────────────────────
 * 3) PROVIDER — update suborder status
 * ───────────────────────────────────────────────────────────────────────────── */
/** Title: Provider updates status of his suborder */
function vogo_provider_update_order_status(WP_REST_Request $request){
  $p = (array)$request->get_json_params();
  $order_id = (int)($p['order_id'] ?? 0);
  $new      = sanitize_text_field($p['status'] ?? '');

  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  if ($order_id <= 0 || $new === '') {
    return new WP_REST_Response(['success'=>false,'error'=>'order_id and status are required'],400);
  }

  $vendor_id = get_vendor_id_for_user($user_id);
  if (!$vendor_id) return new WP_REST_Response(['success'=>false,'error'=>'No vendor mapped to this user'],403);

  $order = wc_get_order($order_id);
  if (!$order) return new WP_REST_Response(['success'=>false,'error'=>'Order not found'],404);

  // Must be a child order belonging to this vendor
  $belongs = (int)$order->get_meta('_vogo_vendor_id') === (int)$vendor_id;
  if (!$belongs) return new WP_REST_Response(['success'=>false,'error'=>'Forbidden'],403);

  // Allowed statuses (Woo slugs, w/o wc- prefix)
  $allowed = ['processing','completed','cancelled','on-hold','refunded','failed','pending'];
  $new = ltrim($new,'wc-');
  if (!in_array($new, $allowed, true)) {
    return new WP_REST_Response(['success'=>false,'error'=>'Unsupported status'],400);
  }

  // Update
  $order->update_status($new, sprintf('Vendor API status update by user %d', $user_id), true);

  return new WP_REST_Response([
    'success'   => true,
    'order_id'  => $order->get_id(),
    'status'    => $order->get_status(),
    'status_ro' => vogo_status_ro($order->get_status()),
  ],200);
}

/* ─────────────────────────────────────────────────────────────────────────────
 * BACKCOMP: existing functions left intact (from old file)
 * ───────────────────────────────────────────────────────────────────────────── */

/** Title: Order list (legacy) */
function custom_order_list_old() {
  $data = json_decode(file_get_contents('php://input'), true);
  if (empty($data)) $data = $_REQUEST;

  $user_id = isset($data['access_token']) ? intval($data['access_token']) : null;
  vogo_error_log2("STEP 1: Order list requested for user_id: {$user_id}");

  if (empty($user_id) || $user_id <= 0) {
    return ['status'=>false,'code'=>400,'message'=>'Invalid User ID'];
  }

  $user = get_user_by('id', $user_id);
  if (!is_a($user, 'WP_User')) {
    return ['status'=>false,'code'=>400,'message'=>'Invalid User'];
  }

  $orders = wc_get_orders(['customer_id'=>$user_id,'orderby'=>'modified','order'=>'DESC','limit'=>-1]);
  $out = [];
  foreach ($orders as $o) {
    $out[] = [
      'order_id'    => $o->get_id(),
      'order_date'  => date('F d, Y', strtotime($o->get_date_created())),
      'order_status'=> $o->get_status(),
      'total_item'  => $o->get_item_count(),
      'order_total' => $o->get_total()
    ];
  }

  return [
    'status'=>!empty($out),
    'code'  => !empty($out)?200:404,
    'message'=>!empty($out)?'Orders fetched successfully':'No orders found',
    'total'=>count($out),
    'data'=>$out
  ];
}

/** Title: Order detail (legacy) */
function custom_order_detail() {
  $data = json_decode(file_get_contents('php://input'), true);
  if (empty($data)) $data = $_REQUEST;

  $user_id  = isset($data['access_token']) ? intval($data['access_token']) : null;
  $order_id = isset($data['order_id']) ? intval($data['order_id']) : null;

  if (empty($order_id))   return ['status'=>false,'code'=>400,'message'=>'Order ID is required'];
  if (empty($user_id))    return ['status'=>false,'code'=>400,'message'=>'Invalid User ID'];

  $user = get_user_by('id', $user_id);
  if (!is_a($user, 'WP_User')) return ['status'=>false,'code'=>400,'message'=>'Invalid User'];

  $order = wc_get_order($order_id);
  if (!$order) return ['status'=>false,'code'=>404,'message'=>'No Order Found.','data'=>[]];

  $orderData = [
    'order_id'       => $order->get_id(),
    'order_date'     => date('F d, Y', strtotime($order->get_date_created())),
    'order_status'   => $order->get_status(),
    'total_item'     => $order->get_item_count(),
    'order_subtotal' => $order->get_subtotal(),
    'shipping_total' => $order->get_shipping_total(),
    'vat'            => $order->get_total_tax(),
    'total_discount' => $order->get_discount_total(),
    'payment_method' => $order->get_payment_method_title(),
    'order_total'    => $order->get_total(),
    'billing_address'=> [
      'first_name' => $order->get_billing_first_name(),
      'last_name'  => $order->get_billing_last_name(),
      'company'    => $order->get_billing_company(),
      'address_1'  => $order->get_billing_address_1(),
      'address_2'  => $order->get_billing_address_2(),
      'city'       => $order->get_billing_city(),
      'state'      => $order->get_billing_state(),
      'postcode'   => $order->get_billing_postcode(),
      'country'    => $order->get_billing_country(),
      'email'      => $order->get_billing_email(),
      'phone'      => $order->get_billing_phone()
    ]
  ];

  $items = [];
  foreach ($order->get_items() as $item) {
    $items[] = [
      'product_id'    => $item->get_product_id(),
      'variation_id'  => $item->get_variation_id(),
      'product_title' => $item->get_name(),
      'quantity'      => $item->get_quantity(),
      'item_subtotal' => $item->get_subtotal(),
      'item_total'    => $item->get_total()
    ];
  }
  $orderData['items'] = $items;

  $meta_rating     = (int)$order->get_meta('_vogo_order_rating', true);
  $meta_comment    = (string)$order->get_meta('_vogo_order_review_comment', true);
  $meta_user_id    = (int)$order->get_meta('_vogo_order_review_user_id', true);
  $meta_reviewed_at= (string)$order->get_meta('_vogo_order_reviewed_at', true);

  if ($meta_rating > 0 && $meta_user_id === (int)$user_id) {
    $orderData['review'] = [
      'rating'  => $meta_rating,
      'comment' => $meta_comment,
      'date'    => $meta_reviewed_at !== '' ? gmdate('Y-m-d', strtotime($meta_reviewed_at)) : gmdate('Y-m-d'),
    ];
  } else {
    // Backward compatibility: fallback to legacy custom table if present.
    global $wpdb;
    $table = $wpdb->prefix . 'order_reviews';
    $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
    if ($table_exists === $table) {
      $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE order_id = %d AND user_id = %d",
        $order_id,
        $user_id
      ));

      $orderData['review'] = $existing ? [
        'rating'  => (int)$existing->rating,
        'comment' => (string)$existing->comment,
        'date'    => date('Y-m-d', strtotime($existing->created_at)),
      ] : (object)[];
    } else {
      $orderData['review'] = (object)[];
    }
  }

  return [
    'status'=>true,'code'=>200,'message'=>"#{$order_id} found.",'data'=>$orderData
  ];
}

/** Title: Rate own order using WooCommerce standard order meta */
function vogo_order_review(WP_REST_Request $request) {
  $data = (array)$request->get_json_params();

  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) {
    return $user_id;
  }

  $order_id = isset($data['order_id']) ? (int)$data['order_id'] : 0;
  $rating   = isset($data['rating']) ? (int)$data['rating'] : 0;
  $comment  = isset($data['comment']) ? sanitize_textarea_field((string)$data['comment']) : '';

  if ($order_id <= 0) {
    return new WP_REST_Response(['status' => false, 'message' => 'order_id is required.'], 400);
  }

  if ($rating < 1 || $rating > 5) {
    return new WP_REST_Response(['status' => false, 'message' => 'rating must be between 1 and 5.'], 400);
  }

  $order = wc_get_order($order_id);
  if (!$order) {
    return new WP_REST_Response(['status' => false, 'message' => 'Order not found.'], 404);
  }

  if ((int)$order->get_user_id() !== (int)$user_id) {
    return new WP_REST_Response(['status' => false, 'message' => 'Forbidden.'], 403);
  }

  $existing_user_id = (int)$order->get_meta('_vogo_order_review_user_id', true);
  $existing_rating  = (int)$order->get_meta('_vogo_order_rating', true);
  if ($existing_user_id === (int)$user_id && $existing_rating > 0) {
    return new WP_REST_Response([
      'status'  => false,
      'message' => 'Order was already rated.',
      'review'  => [
        'rating'  => $existing_rating,
        'comment' => (string)$order->get_meta('_vogo_order_review_comment', true),
        'date'    => (string)$order->get_meta('_vogo_order_reviewed_at', true),
      ],
    ], 409);
  }

  $reviewed_at = gmdate('Y-m-d H:i:s');

  $order->update_meta_data('_vogo_order_rating', $rating);
  $order->update_meta_data('_vogo_order_review_comment', $comment);
  $order->update_meta_data('_vogo_order_review_user_id', (int)$user_id);
  $order->update_meta_data('_vogo_order_reviewed_at', $reviewed_at);
  $order->save();

  if ($comment !== '') {
    $order->add_order_note(sprintf('Client order rating: %d/5. Comment: %s', $rating, $comment), false, true);
  } else {
    $order->add_order_note(sprintf('Client order rating: %d/5.', $rating), false, true);
  }

  return new WP_REST_Response([
    'status'  => true,
    'message' => 'Review submitted successfully.',
    'review'  => [
      'rating'  => $rating,
      'comment' => $comment,
      'date'    => $reviewed_at,
    ],
  ], 200);
}

/** Title: Notifications list (legacy) */
function custom_notification_list() {
  $data = json_decode(file_get_contents('php://input'), true);
  if (empty($data)) $data = $_REQUEST;

  $user_id = isset($data['access_token']) ? intval($data['access_token']) : null;
  if (empty($user_id) || $user_id <= 0) return ['status'=>false,'code'=>400,'message'=>'Invalid User'];

  try {
    $user = get_user_by('id', $user_id);
    if (!is_a($user, 'WP_User')) return ['status'=>false,'code'=>400,'message'=>'Invalid User'];

    global $wpdb;
    $table = $wpdb->prefix . 'custom_notification';
    $rows  = $wpdb->get_results($wpdb->prepare(
      "SELECT * FROM {$table} WHERE user_id=%d ORDER BY updated_date DESC", $user_id
    ), ARRAY_A);

    $data = array_map(function($r){
      return [
        'message'      => $r['message'],
        'order_id'     => $r['order_id'],
        'add_date'     => $r['add_date'],
        'updated_date' => $r['updated_date']
      ];
    }, $rows ?? []);

    return ['status'=>true,'code'=>200,'message'=>'Notifications fetched successfully','count'=>count($data),'data'=>$data];

  } catch (\Throwable $e) {
    return ['status'=>false,'code'=>500,'message'=>$e->getMessage()];
  }
}

/**
 * Title: Customer lists own parent orders with their vendor suborders
 * Body: { "page":1, "per_page":20, "status":["processing","completed"] }
 */
//just rewrite
function vogo_customer_get_order_list_with_suborders(WP_REST_Request $request){
  $p = (array)$request->get_json_params();

  $user_id = extract_user_from_jwt_token($request);
  if ($user_id instanceof WP_REST_Response) return $user_id;

  $page = max(1,(int)($p['page'] ?? 1));
  $per  = max(1,min(100,(int)($p['per_page'] ?? 20)));
  $statuses = $p['status'] ?? [];
  $statuses = is_array($statuses) ? array_filter(array_map('sanitize_text_field',$statuses)) : [];
  $post_status = !empty($statuses) ? array_map(fn($s)=> 'wc-'.ltrim($s,'wc-'), $statuses) : array_keys(wc_get_order_statuses());

  // parent orders ale clientului (post_parent = 0)
  $q = new WP_Query([
    'post_type'      => 'shop_order',
    'post_status'    => $post_status,
    'meta_query'     => [[ 'key'=>'_customer_user', 'value'=>(string)$user_id ]],
    'post_parent'    => 0,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'posts_per_page' => $per,
    'paged'          => $page,
    'fields'         => 'ids',
  ]);

  global $wpdb;
  $orders = [];

  // mic cache pentru provider_name ca să nu dăm query la fiecare suborder
  $provider_name_cache = [];

  foreach ($q->posts as $oid){
    $o = wc_get_order($oid);
    if (!$o) continue;

    // suborders
    $children = get_children([
      'post_parent' => $oid,
      'post_type'   => 'shop_order',
      'post_status' => 'any',
      'numberposts' => -1,
      'orderby'     => 'ID',
      'order'       => 'ASC',
    ]);

    $subs = [];
    $by_vendor = []; // agregare per vendor_id pentru total_per_provider

    foreach ($children as $cpost){
      $co = wc_get_order($cpost->ID); 
      if(!$co) continue;

      $vid = (int)$co->get_meta('_vogo_vendor_id');

      // provider_name din cache sau DB
      $vname = null;
      if ($vid > 0) {
        if (!array_key_exists($vid, $provider_name_cache)) {
          $provider_name_cache[$vid] = $wpdb->get_var(
            $wpdb->prepare("SELECT provider_name FROM {$wpdb->prefix}vogo_providers WHERE id=%d LIMIT 1", $vid)
          ) ?: null;
        }
        $vname = $provider_name_cache[$vid];
      }

      // totals per suborder
      $sub_totals = [
        'subtotal' => (float)$co->get_subtotal(),
        'shipping' => (float)$co->get_shipping_total(),
        'tax'      => (float)$co->get_total_tax(),
        'discount' => (float)$co->get_discount_total(),
        'total'    => (float)$co->get_total(),
      ];

      // push în lista de suborders (cum aveai deja)
      $subs[] = [
        'child_order_id' => $co->get_id(),
        'vendor_id'      => $vid ?: null,
        'vendor_name'    => $vname,
        'status'         => $co->get_status(),
        'status_ro'      => vogo_status_ro($co->get_status()),
        'totals'         => $sub_totals,
      ];

      // agregare per vendor pentru total_per_provider
      if ($vid > 0) {
        if (!isset($by_vendor[$vid])) {
          $by_vendor[$vid] = [
            'provider_id'   => $vid,
            'provider_name' => $vname,
            'subtotal'      => 0.0,
            'shipping'      => 0.0,
            'tax'           => 0.0,
            'discount'      => 0.0,
            'total'         => 0.0,
          ];
        }
        $by_vendor[$vid]['subtotal'] += $sub_totals['subtotal'];
        $by_vendor[$vid]['shipping'] += $sub_totals['shipping'];
        $by_vendor[$vid]['tax']      += $sub_totals['tax'];
        $by_vendor[$vid]['discount'] += $sub_totals['discount'];
        $by_vendor[$vid]['total']    += $sub_totals['total'];
      }
    }

    // dacă există un singur vendor în acest order părinte, expune-l și la nivel de order
    $order_vendor_id   = null;
    $order_vendor_name = null;
    if (count($by_vendor) === 1) {
      $only = reset($by_vendor);
      $order_vendor_id   = $only['provider_id'];
      $order_vendor_name = $only['provider_name'];
    }

    $orders[] = [
      'order_id'      => $o->get_id(),
      'status'        => $o->get_status(),
      'status_ro'     => vogo_status_ro($o->get_status()),
      'created_at'    => $o->get_date_created() ? $o->get_date_created()->date('Y-m-d H:i:s') : null,
      'currency'      => $o->get_currency(),
      'totals'        => [
        'subtotal' => (float)$o->get_subtotal(),
        'shipping' => (float)$o->get_shipping_total(),
        'tax'      => (float)$o->get_total_tax(),
        'discount' => (float)$o->get_discount_total(),
        'total'    => (float)$o->get_total(),
      ],

      // nou: vendor info la nivel de order (dacă e single-vendor)
      'vendor_id'     => $order_vendor_id,
      'vendor_name'   => $order_vendor_name,

      // nou: agregat pe provider, similar cu ce ai dorit la cart/checkout
      'total_per_provider' => array_values($by_vendor),

      // păstrăm suborders ca înainte
      'suborders'     => $subs,
    ];
  }

  return new WP_REST_Response([
    'success'     => true,
    'page'        => $page,
    'per_page'    => $per,
    'total'       => (int)$q->found_posts,
    'total_pages' => (int)$q->max_num_pages,
    'orders'      => $orders,
  ], 200);
}


//rewrite
/** 
 * Title: Order list (legacy+) with vendor info and per-vendor subtotals
 * Body (legacy): { "access_token": <user_id> }
 * Body (JWT):    {}  // user_id extras din JWT (preferat)
 */
function custom_order_list2(WP_REST_Request $request){ //este old - woo based
  global $wpdb;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'NA';
  $p  = (array)$request->get_json_params();

  // STEP 0: Identify user (prefer JWT; fallback legacy access_token=user_id)
  $user_id = null;
  if (!empty($p['access_token'])) {
    $user_id = (int)$p['access_token'];
  } else {
    $jwt_user = extract_user_from_jwt_token($request);
    if (!($jwt_user instanceof WP_REST_Response)) $user_id = (int)$jwt_user;
  }

  if (function_exists('vogo_error_log3')) vogo_error_log3('VOGO_LOG_START [STEP 0] custom_order_list START | ACTIVE DB: '.($wpdb->dbname ?? 'n/a').' | user_id='.$user_id.' | ip='.$ip);

  // STEP 1: Validate user
  if (empty($user_id) || $user_id <= 0) {
    if (function_exists('vogo_error_log3')) vogo_error_log3('[STEP 1] Invalid user_id | ip='.$ip);
    return ['status'=>false,'code'=>400,'message'=>'Invalid User ID'];
  }
  $user = get_user_by('id', $user_id);
  if (!is_a($user, 'WP_User')) {
    if (function_exists('vogo_error_log3')) vogo_error_log3('[STEP 1.1] User not found | user_id='.$user_id.' | ip='.$ip);
    return ['status'=>false,'code'=>400,'message'=>'Invalid User'];
  }

  // STEP 2: Fetch parent orders (no suborders)
  $orders = wc_get_orders([
    'customer_id' => $user_id,
    'orderby'     => 'modified',
    'order'       => 'DESC',
    'limit'       => -1,
    'return'      => 'objects',
    'parent'      => 0, // only parent orders
  ]);

  $provider_name_cache = [];
  $data = [];

  // STEP 3: Build payload with vendor info & per-vendor totals
  foreach ($orders as $o) {
    if (!$o) continue;

    // Gather child orders (= suborders per vendor)
    $children = get_children([
      'post_parent' => $o->get_id(),
      'post_type'   => 'shop_order',
      'post_status' => 'any',
      'numberposts' => -1,
      'orderby'     => 'ID',
      'order'       => 'ASC',
    ]);

    $by_vendor = []; // aggregate totals per vendor
    foreach ($children as $cpost) {
      $co = wc_get_order($cpost->ID);
      if (!$co) continue;

      $vid = (int)$co->get_meta('_vogo_vendor_id');
      if ($vid > 0 && !array_key_exists($vid, $provider_name_cache)) {
        $provider_name_cache[$vid] = $wpdb->get_var($wpdb->prepare(
          "SELECT provider_name FROM {$wpdb->prefix}vogo_providers WHERE id=%d LIMIT 1", $vid
        )) ?: null;
      }
      $vname = $vid > 0 ? ($provider_name_cache[$vid] ?? null) : null;

      // child totals
      $subtotals = [
        'subtotal' => (float)$co->get_subtotal(),
        'shipping' => (float)$co->get_shipping_total(),
        'tax'      => (float)$co->get_total_tax(),
        'discount' => (float)$co->get_discount_total(),
        'total'    => (float)$co->get_total(),
      ];

      // aggregate per vendor
      if ($vid > 0) {
        if (!isset($by_vendor[$vid])) {
          $by_vendor[$vid] = [
            'provider_id'   => $vid,
            'provider_name' => $vname,
            'subtotal'      => 0.0,
            'shipping'      => 0.0,
            'tax'           => 0.0,
            'discount'      => 0.0,
            'total'         => 0.0,
          ];
        }
        $by_vendor[$vid]['subtotal'] += $subtotals['subtotal'];
        $by_vendor[$vid]['shipping'] += $subtotals['shipping'];
        $by_vendor[$vid]['tax']      += $subtotals['tax'];
        $by_vendor[$vid]['discount'] += $subtotals['discount'];
        $by_vendor[$vid]['total']    += $subtotals['total'];
      }
    }

    // If single vendor, expose vendor at order level too
    $order_vendor_id = null; $order_vendor_name = null;
    if (count($by_vendor) === 1) {
      $only = reset($by_vendor);
      $order_vendor_id   = $only['provider_id'];
      $order_vendor_name = $only['provider_name'];
    }

    $data[] = [
      'order_id'     => $o->get_id(),
      'order_date'   => $o->get_date_created() ? $o->get_date_created()->date('Y-m-d H:i:s') : null,
      'order_status' => $o->get_status(),
      'total_item'   => $o->get_item_count(),
      'order_total'  => (float)$o->get_total(),

      // NEW: single-vendor info at order level (if applicable)
      'vendor_id'    => $order_vendor_id,
      'vendor_name'  => $order_vendor_name,

      // NEW: per-vendor totals for this parent order
      'total_per_provider' => array_values($by_vendor),
    ];
  }

  // STEP 4: Response
  $resp = [
    'status'  => !empty($data),
    'code'    => !empty($data) ? 200 : 404,
    'message' => !empty($data) ? 'Orders fetched successfully' : 'No orders found',
    'total'   => count($data),
    'data'    => $data
  ];

  if (function_exists('vogo_error_log3')) vogo_error_log3('[STEP 4] custom_order_list DONE | orders='.count($data).' | user_id='.$user_id.' | ip='.$ip);
  if (function_exists('vogo_error_log3')) vogo_error_log3('VOGO_LOG_END');
  return $resp;
}


// ========== HELPERS ==========
function vogo_collect_lines_from_order(WC_Order $o): array {
  $out = [];
  foreach ($o->get_items() as $it) {
    $out[] = [
      'order_item_id'     => (int)$it->get_id(),
      'product_name'      => (string)$it->get_name(),
      'product_id'        => (string)$it->get_product_id(),
      'variation_id'      => (string)$it->get_variation_id(),
      'qty'               => (float)$it->get_quantity(),
      'line_subtotal'     => (float)$it->get_subtotal(),
      'line_subtotal_tax' => (float)$it->get_subtotal_tax(),
      'line_total'        => (float)$it->get_total(),
      'line_tax'          => (float)$it->get_total_tax(),
      'tax_rate'          => null,
      'discount_total'    => null,
    ];
  }
  return $out;
}

function vogo_get_child_order_ids(int $parent_id): array {
  $ids = wc_get_orders(['parent' => $parent_id, 'return' => 'ids', 'limit' => -1]);
  return is_array($ids) ? $ids : [];
}

// ========== HANDLER ==========
function account_get_my_orders(WP_REST_Request $request){
  $MODULE_PHP = basename(__FILE__);
  $module = $MODULE_PHP.'.'.__FUNCTION__;

  // soft JWT
  $jwt_user_id = null; $jwt_user_name = 'unknown';
  try {
    $jwt_candidate = extract_user_from_jwt_token($request);
    if (!($jwt_candidate instanceof WP_REST_Response)) {
      $jwt_id = (int)$jwt_candidate;
      if ($jwt_id>0) { $ju = get_userdata($jwt_id); if ($ju){ $jwt_user_id=$jwt_id; $jwt_user_name=$ju->user_login; } }
    }
  } catch (Throwable $e) {}
  $module .= '.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  // hard JWT
  $user_raw = extract_user_from_jwt_token($request);
  if ($user_raw instanceof WP_REST_Response){
    $data = $user_raw->get_data();
    $msg  = is_array($data)?($data['error']??($data['message']??'jwt_invalid')):'jwt_invalid';
    return ['success'=>false,'error'=>'jwt_invalid','error_detail'=>$msg,'user_id'=>null,'user_login'=>null];
  }
  if (is_wp_error($user_raw)){
    return ['success'=>false,'error'=>'jwt_invalid','error_detail'=>$user_raw->get_error_message(),'user_id'=>null,'user_login'=>null];
  }
  $user_id = (int)$user_raw;
  if ($user_id<=0){ return ['success'=>false,'error'=>'jwt_missing','user_id'=>null,'user_login'=>null]; }

  // input
  $page       = max(1, (int)($request->get_param('page') ?: 1));
  $per_page   = min(100, max(1, (int)($request->get_param('per_page') ?: 20)));
  $status_in  = trim((string)($request->get_param('status') ?: ''));
  $with_lines = (int)($request->get_param('with_lines') ?: 0) === 1;
  $with_meta  = (int)($request->get_param('with_meta')  ?: 1) === 1;
  $include_children = (int)($request->get_param('include_children') ?: 1) === 1; // 1 = aduce și subcomenzi
  $lines_mode = (string)($request->get_param('lines_mode') ?: 'parent'); // parent | aggregate_children | children_only
  $expose_children_ids = (int)($request->get_param('expose_children_ids') ?: 1) === 1;

  // status
  $valid_status = array_keys(wc_get_order_statuses());
  $status_filter = [];
  if ($status_in !== '') {
    foreach (explode(',', $status_in) as $s) {
      $s = trim($s);
      if ($s==='') continue;
      $s = strncmp($s,'wc-',3)===0 ? $s : 'wc-'.$s;
      if (in_array($s, $valid_status, true)) $status_filter[] = $s;
    }
  }

  // query
  $user  = get_userdata($user_id);
  $email = $user ? $user->user_email : '';
  $args = [
    'type'      => 'shop_order',
    'status'    => $status_filter ?: array_keys(wc_get_order_statuses()),
    'customer'  => array_filter([$user_id, $email]),
    'paginate'  => true,
    'page'      => $page,
    'limit'     => $per_page,
    'orderby'   => 'date',
    'order'     => 'DESC',
    'return'    => 'ids',
  ];
  if (!$include_children) { $args['parent'] = 0; }

  $result = wc_get_orders($args);
  $order_ids  = is_object($result) ? (array)($result->orders ?? []) : (array)$result;
  $total      = is_object($result) ? (int)($result->total ?? count($order_ids)) : count($order_ids);
  $total_pages = (int)ceil(($per_page>0 ? $total/$per_page : 0));

  $orders = [];
  if ($order_ids) {
    global $wpdb;

    // wp_orders
    $meta_map = [];
    if ($with_meta) {
      $place = implode(',', array_fill(0, count($order_ids), '%d'));
      $sql = "SELECT id, provider_id, order_short_description, relevant_image
              FROM wp_orders WHERE id IN ($place)";
      $rows = $wpdb->get_results($wpdb->prepare($sql, $order_ids), ARRAY_A);
      foreach ($rows as $r) {
        $meta_map[(int)$r['id']] = [
          'provider_id' => isset($r['provider_id']) ? (int)$r['provider_id'] : null,
          'order_short_description' => (string)$r['order_short_description'],
          'relevant_image' => (string)$r['relevant_image'],
        ];
      }
    }

    // wp_orders_lines
    $lines_map = [];
    if ($with_lines) {
      $place = implode(',', array_fill(0, count($order_ids), '%d'));
      $sql = "SELECT order_id, order_item_id, product_name, product_id, variation_id, qty,
                     line_subtotal, line_subtotal_tax, line_total, line_tax, tax_rate, discount_total
              FROM wp_orders_lines
              WHERE order_id IN ($place)
              ORDER BY order_id, order_item_id";
      $rows = $wpdb->get_results($wpdb->prepare($sql, $order_ids), ARRAY_A);
      foreach ($rows as $r) {
        $oid = (int)$r['order_id'];
        $lines_map[$oid][] = [
          'order_item_id'     => (int)$r['order_item_id'],
          'product_name'      => (string)$r['product_name'],
          'product_id'        => (string)$r['product_id'],
          'variation_id'      => (string)$r['variation_id'],
          'qty'               => $r['qty'] !== null ? (float)$r['qty'] : null,
          'line_subtotal'     => $r['line_subtotal'] !== null ? (float)$r['line_subtotal'] : null,
          'line_subtotal_tax' => $r['line_subtotal_tax'] !== null ? (float)$r['line_subtotal_tax'] : null,
          'line_total'        => $r['line_total'] !== null ? (float)$r['line_total'] : null,
          'line_tax'          => $r['line_tax'] !== null ? (float)$r['line_tax'] : null,
          'tax_rate'          => $r['tax_rate'] !== null ? (float)$r['tax_rate'] : null,
          'discount_total'    => $r['discount_total'] !== null ? (float)$r['discount_total'] : null,
        ];
      }
    }

    // compose
    foreach ($order_ids as $oid) {
      $o = wc_get_order($oid);
      if (!$o) continue;

      $row = [
        'id'             => $oid,
        'parent_id'      => (int)$o->get_parent_id(),
        'number'         => $o->get_order_number(),
        'status'         => $o->get_status(),
        'created_at'     => $o->get_date_created() ? $o->get_date_created()->date('c') : null,
        'updated_at'     => $o->get_date_modified() ? $o->get_date_modified()->date('c') : null,
        'currency'       => $o->get_currency(),
        'total'          => (float)$o->get_total(),
        'total_tax'      => (float)$o->get_total_tax(),
        'shipping_total' => (float)$o->get_shipping_total(),
        'payment_method' => $o->get_payment_method(),
        'is_suborder'    => $o->get_parent_id() ? true : false,
      ];

      if ($with_meta && isset($meta_map[$oid])) {
        $row += $meta_map[$oid];
      }

      if ($with_lines) {
        // 1) încercă wp_orders_lines
        $lines = $lines_map[$oid] ?? [];

        // 2) dacă nu sunt, colectează din Woo
        if (empty($lines) && ($lines_mode === 'parent' || $lines_mode === 'aggregate_children')) {
          $lines = array_merge($lines, vogo_collect_lines_from_order($o));
        }

        // 3) agregă copii dacă este cerut
        if ($lines_mode === 'aggregate_children' || $lines_mode === 'children_only') {
          $child_ids = vogo_get_child_order_ids($oid);
          foreach ($child_ids as $cid) {
            $co = wc_get_order($cid);
            if ($co) { $lines = array_merge($lines, vogo_collect_lines_from_order($co)); }
          }
        }

        // 4) numai copii
        if ($lines_mode === 'children_only') {
          // dacă e părinte și n-ai copii, rămâne gol; dacă e copil, nu are alți copii
          if ($o->get_parent_id() > 0) {
            $lines = vogo_collect_lines_from_order($o);
          }
        }

        $row['lines'] = $lines;
      }

      if ($expose_children_ids) {
        $row['children'] = vogo_get_child_order_ids($oid);
      }

      $orders[] = $row;
    }
  }

  return [
    'success'     => true,
    'module'      => $module.'.OK',
    'user_id'     => $user_id,
    'page'        => $page,
    'per_page'    => $per_page,
    'total'       => $total,
    'total_pages' => $total_pages,
    'count'       => count($orders),
    'orders'      => $orders,
  ];
}


function account_orders_list(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
  $p=$request->get_params(); vogo_error_log3("[STEP 0.1] Raw payload received: ".json_encode($p)." | IP:$ip | USER:0");
  $debug = !empty($p['debug']) || $request->get_header('x-vogo-debug') === '1';
  $debug_info = [
    'debug' => $debug ? 1 : 0,
    'request' => [
      'ip' => $ip,
      'headers' => [
        'authorization' => $request->get_header('authorization') ? 'present' : 'missing',
        'access_token' => $request->get_header('access_token') ? 'present' : 'missing',
      ],
      'params' => $p,
    ],
  ];

  $resolve_order_description = static function($custom_description, array $lines): ?string {
    $custom_description = is_string($custom_description) ? trim($custom_description) : '';
    if ($custom_description !== '') {
      return $custom_description;
    }

    $best_line = null;
    foreach ($lines as $line) {
      $line_total = isset($line['line_total']) ? (float)$line['line_total'] : null;
      $line_id = isset($line['internal_line_id']) ? (int)$line['internal_line_id'] : (isset($line['order_item_id']) ? (int)$line['order_item_id'] : PHP_INT_MAX);

      if ($best_line === null) {
        $best_line = ['line' => $line, 'line_total' => $line_total, 'line_id' => $line_id];
        continue;
      }

      if ($line_total !== null && ($best_line['line_total'] === null || $line_total > $best_line['line_total'])) {
        $best_line = ['line' => $line, 'line_total' => $line_total, 'line_id' => $line_id];
        continue;
      }

      if ($line_total !== null && $best_line['line_total'] !== null && $line_total === $best_line['line_total'] && $line_id < $best_line['line_id']) {
        $best_line = ['line' => $line, 'line_total' => $line_total, 'line_id' => $line_id];
      }
    }

    if (!$best_line) {
      return null;
    }

    $product_name = isset($best_line['line']['product_name']) ? trim((string)$best_line['line']['product_name']) : '';
    if ($product_name === '') {
      return null;
    }

    return str_ends_with($product_name, '...') ? $product_name : ($product_name . '...');
  };

  $woo_lines_for_description = static function($order): array {
    if (!$order) {
      return [];
    }

    $lines = [];
    foreach ($order->get_items('line_item') as $item_id => $item) {
      $lines[] = [
        'order_item_id' => (int)$item_id,
        'product_name'  => $item->get_name(),
        'line_total'    => (float)$item->get_total(),
      ];
    }

    return $lines;
  };

  // STEP 1: Auth (model similar cu all-account.php: prefer JWT helper, fallback legacy access_token)
  $uid = 0;
  $ulogin = 'unknown';

  // 1.1 JWT din Authorization (flux standard)
  $jwt_candidate = extract_user_from_jwt_token($request);
  if (!($jwt_candidate instanceof WP_REST_Response) && !is_wp_error($jwt_candidate)) {
    $uid = (int)$jwt_candidate;
    $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
    $module .= ".jwt_user_id:$uid.jwt_username:$ulogin";
  } else {
    // 1.2 Fallback legacy: access_token numeric (= user_id)
    $access_token = $p['access_token'] ?? $request->get_header('access_token') ?? $request->get_header('Access-Token');
    if ($access_token === 'null') { $access_token = null; }
    $access_token = is_string($access_token) ? trim($access_token) : $access_token;

    if (!empty($access_token) && preg_match('/^\d+$/', (string)$access_token)) {
      $uid = (int)$access_token;
      $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
      $module .= ".legacy_user_id:$uid.legacy_user_login:$ulogin";
    } elseif (!empty($access_token) && is_string($access_token)) {
      // Compatibilitate: unele build-uri mobile trimit JWT în access_token în loc de Authorization.
      $request_with_bearer = new WP_REST_Request($request->get_method(), $request->get_route());
      foreach ((array)$request->get_params() as $k => $v) { $request_with_bearer->set_param($k, $v); }
      $request_with_bearer->set_header('Authorization', 'Bearer '.$access_token);

      $jwt_from_access = extract_user_from_jwt_token($request_with_bearer);
      if (!($jwt_from_access instanceof WP_REST_Response) && !is_wp_error($jwt_from_access)) {
        $uid = (int)$jwt_from_access;
        $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
        $module .= ".jwt_in_access_token_user_id:$uid.jwt_username:$ulogin";
      } else {
        return new WP_REST_Response(['success'=>false,'module'=>$module.'-EJWT','error'=>'invalid_token'],401);
      }
    }
  }


  if (empty($uid) || $uid <= 0 || !get_userdata($uid)) {
    return new WP_REST_Response(['success'=>false,'module'=>$module.'-EUSER','error'=>'invalid_user'],400);
  }

  // STEP 2: pagination
  $page=max(1,(int)($p['page']??1)); $per=max(1,min(100,(int)($p['per_page']??20))); $off=($page-1)*$per;

  // STEP 2a: status filter (active/history/all)
  // Frontend input:
  // - access_token (legacy user_id) OR JWT (Authorization: Bearer <token>) header
  // - page (int, default 1)
  // - per_page (int, default 20, max 100)
  // - list_type = active | history | all (default)
  // Example call (JSON body):
  // {
  //   "access_token": "<user_id_or_jwt>",
  //   "page": 1,
  //   "per_page": 20,
  //   "list_type": "active"
  // }
  // Example endpoint: POST /wp-json/vogo/v1/account/account_orders_list
  $list_type = strtolower(trim((string)($p['list_type'] ?? 'all')));
  $status_input = $p['status'] ?? ($p['statuses'] ?? []);
  if (is_string($status_input)) {
    $status_input = array_filter(array_map('trim', explode(',', $status_input)));
  } elseif (!is_array($status_input)) {
    $status_input = [];
  }

  $custom_active_statuses = ['READY','ACCEPTED','STARTED','IN_PROGRESS','COMMING_SOON','ARRIVED','PACKAGED','COURIER'];
  $custom_history_statuses = ['CLOSED','CANCELLED','DELIVERED','FINISHED'];
  $woo_active_statuses = ['processing','on-hold','pending'];
  $woo_history_statuses = ['completed','cancelled','refunded','failed'];

  $requested_custom_statuses = array_values(array_unique(array_filter(array_map(
    fn($s) => strtoupper(ltrim(sanitize_text_field((string)$s), 'wc-')),
    $status_input
  ))));
  $requested_woo_statuses = array_values(array_unique(array_filter(array_map(
    fn($s) => strtolower(ltrim(sanitize_text_field((string)$s), 'wc-')),
    $status_input
  ))));

  if ($list_type === 'active') {
    $status_filter = $requested_custom_statuses ? array_values(array_intersect($custom_active_statuses, $requested_custom_statuses)) : $custom_active_statuses;
    $woo_statuses = $requested_woo_statuses ? array_values(array_intersect($woo_active_statuses, $requested_woo_statuses)) : $woo_active_statuses;
  } elseif ($list_type === 'history') {
    $status_filter = $requested_custom_statuses ? array_values(array_intersect($custom_history_statuses, $requested_custom_statuses)) : $custom_history_statuses;
    $woo_statuses = $requested_woo_statuses ? array_values(array_intersect($woo_history_statuses, $requested_woo_statuses)) : $woo_history_statuses;
  } else {
    $status_filter = $requested_custom_statuses;
    $woo_statuses = $requested_woo_statuses ?: array_keys(wc_get_order_statuses());
  }

  $status_filter_is_explicit_and_empty = !empty($status_input) && empty($status_filter);

  // STEP 3: tables
  $tbl_o=$wpdb->prefix.'orders'; $tbl_l=$wpdb->prefix.'orders_lines';

  // STEP 3a: sync missing Woo parent orders from the last 24h into custom table
  $existing_orders = (int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$tbl_o} WHERE parent_order_id=0 AND client_id=%d",
    $uid
  ));
  $debug_info['custom_orders'] = [
    'table' => $tbl_o,
    'existing_parents' => $existing_orders,
  ];

  $sync_24h = vogo_sync_recent_woo_orders_for_user($uid, 24, $debug);
  if ($debug) {
    $debug_info['sync_24h'] = $sync_24h;
  }

  $debug_info['custom_orders']['total_parents'] = (int)$wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$tbl_o} WHERE parent_order_id=0 AND client_id=%d",
    $uid
  ));

  if ($status_filter_is_explicit_and_empty) {
    return [
      'success'=>true,'module'=>$module.'.TEND','message'=>'No orders',
      'user_id'=>$uid,'user_login'=>$ulogin,'page'=>$page,'per_page'=>$per,'total'=>0,'has_more'=>false,'data'=>[],
      'debug_info'=>$debug ? $debug_info : null,
    ];
  }

  // STEP 4: total parents
  $status_sql = '';
  $status_args = [];
  if ($status_filter) {
    $status_sql = ' AND status IN (' . implode(',', array_fill(0, count($status_filter), '%s')) . ')';
    $status_args = $status_filter;
  }
  $q_total=$wpdb->prepare(
    "SELECT COUNT(*) FROM {$tbl_o} WHERE parent_order_id=0 AND client_id=%d{$status_sql}",
    array_merge([$uid], $status_args)
  );
  vogo_error_log3("##############SQL: $q_total"); $total=(int)$wpdb->get_var($q_total);
  $debug_info['custom_orders']['total_parents'] = $total;

  // STEP 5: fetch parents (ALL COLUMNS in schema order)
  $q_par=$wpdb->prepare(
    "SELECT 
      IF(MOD(id, 3) = 1, 1, 0) AS is_reopen, id,parent_order_id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,
      notes_customer,notes_provider,notes_transporter,city_id,total_amount,currency,payment_method_title,
      status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields,
      created_by,modified_at,modified_by,order_short_description,relevant_image,provider_name
     FROM {$tbl_o}
     WHERE parent_order_id=0 AND client_id=%d{$status_sql}
     ORDER BY created_at DESC
     LIMIT %d OFFSET %d",
     array_merge([$uid], $status_args, [$per,$off])
  );
  vogo_error_log3("##############SQL: $q_par");
  $parents=$wpdb->get_results($q_par,ARRAY_A);

  if(!$parents){
    vogo_error_log3("[STEP 5] No parent orders | IP:$ip | USER:$uid");

    // Fallback: return Woo orders directly if custom table is still empty
    $user = get_userdata($uid);
    $email = $user ? $user->user_email : '';
    if ($status_filter_is_explicit_and_empty) {
      $woo_statuses = [];
    }

    $customer_ids = $uid > 0 ? [$uid] : [];
    $woo_ids_all = wc_get_orders([
      'type'          => 'shop_order',
      'status'        => $woo_statuses,
      'parent'        => 0,
      'customer_id'   => $uid,
      'return'        => 'ids',
      'limit'         => -1,
    ]);
    $woo_ids_all = array_values(array_unique(array_map('intval', $woo_ids_all)));
    if ($email && !empty($woo_statuses)) {
      $woo_by_email = wc_get_orders([
        'type'          => 'shop_order',
        'status'        => $woo_statuses,
        'parent'        => 0,
        'billing_email' => $email,
        'return'        => 'ids',
        'limit'         => -1,
      ]);
      $woo_ids_all = array_values(array_unique(array_merge($woo_ids_all, array_map('intval', $woo_by_email))));
    }
    if ($woo_ids_all) {
      $woo_ids_all = wc_get_orders([
        'include' => $woo_ids_all,
        'orderby' => 'date',
        'order'   => 'DESC',
        'return'  => 'ids',
        'limit'   => -1,
      ]);
    }

    $woo_total = count($woo_ids_all);
    $woo_pages = (int)ceil(($per > 0 ? $woo_total / $per : 0));
    $woo_ids = array_slice($woo_ids_all, $off, $per);
    $debug_info['woo_fallback'] = [
      'statuses' => $woo_statuses,
      'customer_ids' => $customer_ids,
      'lookup_by_customer' => 0,
      'lookup_by_email' => 0,
      'total' => $woo_total,
      'ids_count' => count($woo_ids),
      'ids_sample' => array_slice($woo_ids, 0, 5),
    ];

    $woo_data = [];
    foreach ($woo_ids as $oid) {
      $o = wc_get_order($oid);
      if (!$o) { continue; }
      $woo_lines = $woo_lines_for_description($o);
      $best_line_total = null;
      $best_line_image = null;
      foreach ($o->get_items('line_item') as $item) {
        $line_total = (float)$item->get_total();
        $product_id = (int)$item->get_product_id();
        $variation_id = (int)$item->get_variation_id();
        $thumb_source_id = $variation_id ?: $product_id;
        $img_url = $thumb_source_id ? get_the_post_thumbnail_url($thumb_source_id, 'full') : null;
        if ($img_url && ($best_line_total === null || $line_total > $best_line_total)) {
          $best_line_total = $line_total;
          $best_line_image = $img_url;
        }
      }
      $ship = $o->get_address('shipping');
      $address_end = trim(implode(', ', array_filter([
        $ship['address_1'] ?? null,
        $ship['address_2'] ?? null,
        $ship['city'] ?? null,
        $ship['state'] ?? null,
        $ship['postcode'] ?? null,
        $ship['country'] ?? null,
      ])));

      $woo_data[] = [
        'is_reopen'              => 0,
        'id'                     => (int)$o->get_id(),
        'parent_order_id'        => (int)$o->get_parent_id(),
        'client_id'              => $uid,
        'provider_id'            => null,
        'picking_point_id'       => null,
        'pick_latitude'          => null,
        'pick_longitude'         => null,
        'notes_customer'         => null,
        'notes_provider'         => null,
        'notes_transporter'      => null,
        'city_id'                => null,
        'total_amount'           => wc_format_decimal($o->get_total(), 2),
        'currency'               => $o->get_currency(),
        'payment_method_title'   => $o->get_payment_method_title(),
        'status'                 => strtoupper((string)$o->get_status()),
        'delivery_type'          => null,
        'created_at'             => $o->get_date_created() ? $o->get_date_created()->date('Y-m-d H:i:s') : null,
        'end_lat'                => null,
        'end_long'               => null,
        'address_pick'           => null,
        'address_end'            => $address_end ?: null,
        'distance_km'            => null,
        'calculated_fields'      => null,
        'created_by'             => null,
        'modified_at'            => $o->get_date_modified() ? $o->get_date_modified()->date('Y-m-d H:i:s') : null,
        'modified_by'            => null,
        'order_short_description'=> $resolve_order_description(null, $woo_lines),
        'order_description'      => $resolve_order_description(null, $woo_lines),
        'relevant_image'         => null,
        'order_image_url'        => $best_line_image,
        'provider_name'          => null,
        'children'               => [],
      ];
    }

    if ($woo_data) {
      $has_more = (($page - 1) * $per + count($woo_data)) < $woo_total;
      vogo_error_log3("[STEP 5] Woo fallback orders returned | count:".count($woo_data)." | USER:$uid");
      vogo_error_log3("VOGO_LOG_END");
      return [
        'success'=>true,'module'=>$module.'.WOO_FALLBACK','message'=>'Orders retrieved',
        'user_id'=>$uid,'user_login'=>$ulogin,'page'=>$page,'per_page'=>$per,'total'=>$woo_total,'has_more'=>$has_more,
        'data'=>$woo_data,'total_pages'=>$woo_pages,'count'=>count($woo_data),
        'debug_info'=>$debug_info,
      ];
    }

    vogo_error_log3("VOGO_LOG_END");
    return [
      'success'=>true,'module'=>$module.'.TEND','message'=>'No orders',
      'user_id'=>$uid,'user_login'=>$ulogin,'page'=>$page,'per_page'=>$per,'total'=>$total,'has_more'=>false,'data'=>[],
      'debug_info'=>$debug_info,
    ];
  }

  // STEP 6: parent IDs
  $pids=array_map(fn($r)=>(int)$r['id'],$parents); $in_p=implode(',',array_fill(0,count($pids),'%d'));

  // STEP 7: children for these parents (ALL COLUMNS)
  $q_ch=$wpdb->prepare(
    "SELECT 
      id AS order_id,parent_order_id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,
      notes_customer,notes_provider,notes_transporter,city_id,total_amount,currency,payment_method_title,
      status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields,
      created_by,modified_at,modified_by,order_short_description,relevant_image,provider_name
     FROM {$tbl_o}
     WHERE parent_order_id IN ($in_p)
     ORDER BY created_at DESC",
    ...$pids
  );
  vogo_error_log3("##############SQL: $q_ch");
  $children=$wpdb->get_results($q_ch,ARRAY_A);
  $children_by_parent=[]; $child_ids=[];
  foreach($children as $c){ $children_by_parent[(int)$c['parent_order_id']][]=$c; $child_ids[]=(int)$c['order_id']; }

  /* STEP 8: lines for all children (ALL COLUMNS + product_image) */
/* STEP 8: lines for all children (ALL COLUMNS + product_image from attachments) */
$lines_by_child=[];
if($child_ids){
  $in_c=implode(',',array_fill(0,count($child_ids),'%d'));
  $q_li=$wpdb->prepare(
    "SELECT 
       l.id AS internal_line_id,l.order_id,l.order_item_id,l.product_name,l.product_id,l.variation_id,l.qty,
       l.line_subtotal,l.line_subtotal_tax,l.line_total,l.line_tax,l.tax_rate,
       l.discount_total,l.discount_percent,l.created_at,l.created_by,l.modified_at,l.modified_by,
       l.vendor_id,l.vendor_name,
       /* attachment id via _thumbnail_id: prefer variation, fallback product */
       COALESCE(
         (SELECT CAST(pm_v.meta_value AS UNSIGNED)
            FROM {$wpdb->postmeta} pm_v
           WHERE pm_v.post_id = CAST(l.variation_id AS UNSIGNED) AND pm_v.meta_key = '_thumbnail_id' LIMIT 1),
         (SELECT CAST(pm_p.meta_value AS UNSIGNED)
            FROM {$wpdb->postmeta} pm_p
           WHERE pm_p.post_id = CAST(l.product_id   AS UNSIGNED) AND pm_p.meta_key = '_thumbnail_id' LIMIT 1)
       ) AS attachment_id
     FROM {$tbl_l} l
     WHERE l.order_id IN ($in_c)
     ORDER BY l.order_item_id ASC",
    ...$child_ids
  );
  vogo_error_log3("##############SQL: $q_li");
  $lines=$wpdb->get_results($q_li,ARRAY_A);

  foreach($lines as &$l){
    $att = (int)($l['attachment_id']??0);
    if($att>0){
      $orig = wp_get_attachment_url($att);                 // URL corect din attachments
      $thumb= wp_get_attachment_image_src($att,'woocommerce_thumbnail');
      $l['product_image'] = [
        'id'           => $att,
        'url'          => $orig ?: null,
        'original_url' => $orig ?: null,
        'thumb_url'    => is_array($thumb)?$thumb[0]:null,
        'thumb_w'      => is_array($thumb)?(int)$thumb[1]:null,
        'thumb_h'      => is_array($thumb)?(int)$thumb[2]:null,
        'srcset'       => wp_get_attachment_image_srcset($att,'woocommerce_thumbnail') ?: null,
        'sizes'        => wp_get_attachment_image_sizes($att,'woocommerce_thumbnail') ?: null,
      ];
    } else {
      // ultim fallback: thumbnail direct din WP
      $pid = (int)($l['variation_id']?:$l['product_id']);
      $url = $pid ? get_the_post_thumbnail_url($pid,'full') : null;
      $l['product_image'] = $url ? ['id'=>null,'url'=>$url,'original_url'=>$url] : null;
    }
    unset($l['attachment_id']);
    $lines_by_child[(int)$l['order_id']][]=$l;
  }
  unset($l);
}


  $pick_order_image_url = static function(array $lines): ?string {
    $best_line = null;
    foreach ($lines as $line) {
      $line_total = isset($line['line_total']) ? (float)$line['line_total'] : null;
      $line_id = isset($line['internal_line_id']) ? (int)$line['internal_line_id'] : PHP_INT_MAX;

      if ($best_line === null) {
        $best_line = ['line' => $line, 'line_total' => $line_total, 'line_id' => $line_id];
        continue;
      }

      $should_replace = false;
      if ($line_total !== null && ($best_line['line_total'] === null || $line_total > $best_line['line_total'])) {
        $should_replace = true;
      } elseif ($line_total !== null && $best_line['line_total'] !== null && $line_total === $best_line['line_total'] && $line_id < $best_line['line_id']) {
        $should_replace = true;
      }

      if ($should_replace) {
        $best_line = ['line' => $line, 'line_total' => $line_total, 'line_id' => $line_id];
      }
    }

    if (!$best_line) {
      return null;
    }

    $product_image = $best_line['line']['product_image'] ?? null;
    if (is_array($product_image)) {
      return $product_image['url'] ?? ($product_image['original_url'] ?? ($product_image['thumb_url'] ?? null));
    }

    return is_string($product_image) ? $product_image : null;
  };



  // STEP 9: assemble
  foreach($parents as &$pr){ 
    $pid=(int)$pr['id']; $kids=$children_by_parent[$pid]??[];
    $parent_best_total = null;
    $parent_order_image_url = !empty($pr['relevant_image']) ? (string)$pr['relevant_image'] : null;
    $parent_lines_for_description = [];
    if($kids){
      foreach($kids as &$k){
        $k_lines = $lines_by_child[(int)$k['order_id']]??[];
        $k['order_image_url'] = !empty($k['relevant_image']) ? (string)$k['relevant_image'] : $pick_order_image_url($k_lines);
        $k['order_description'] = $resolve_order_description($k['order_short_description'] ?? null, $k_lines);
        if (empty($k['order_short_description']) && !empty($k['order_description'])) {
          $k['order_short_description'] = $k['order_description'];
        }
        $parent_lines_for_description = array_merge($parent_lines_for_description, $k_lines);

        $k_lines_public = $k_lines;
        foreach($k_lines_public as &$line_public){ unset($line_public['internal_line_id']); }
        unset($line_public);
        $k['lines']=$k_lines_public;

        foreach($k_lines as $line){
          $line_total = isset($line['line_total']) ? (float)$line['line_total'] : null;
          if($line_total === null){ continue; }
          if($parent_best_total === null || $line_total > $parent_best_total){
            $parent_best_total = $line_total;
            $parent_order_image_url = $pick_order_image_url([$line]);
          }
        }
      }
    }

    if (!$parent_lines_for_description) {
      $parent_lines_for_description = $woo_lines_for_description(wc_get_order($pid));
    }

    $pr['order_description'] = $resolve_order_description($pr['order_short_description'] ?? null, $parent_lines_for_description);
    if (empty($pr['order_short_description']) && !empty($pr['order_description'])) {
      $pr['order_short_description'] = $pr['order_description'];
    }

    $pr['order_image_url'] = $parent_order_image_url;
    $pr['children']=$kids;
  } unset($pr,$k);

  $has_more=(($page-1)*$per + count($parents)) < $total;
  vogo_error_log3("[STEP 9] Payload ready | parents:".count($parents)." children:".count($children)." | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END");

  return [
    'success'=>true,'module'=>$module.'.TEND','message'=>'Orders retrieved',
    'user_id'=>$uid,'user_login'=>$ulogin,'page'=>$page,'per_page'=>$per,'total'=>$total,'has_more'=>$has_more,
    'data'=>$parents,
    'debug_info'=>$debug ? $debug_info : null,
  ];
}

// order details -----------------------------------------------------------------------------
function account_order_details(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $ip=$_SERVER['REMOTE_ADDR']??'UNKNOWN'; vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0");
  $p=$request->get_json_params(); vogo_error_log3("[STEP 0.1] Raw JSON payload received: ".json_encode($p)." | IP:$ip | USER:0");

  /* STEP 1: Auth (model similar cu all-account.php: prefer JWT helper, fallback legacy access_token) */
  $uid = 0;
  $ulogin = 'unknown';

  $jwt_candidate = extract_user_from_jwt_token($request);
  if (!($jwt_candidate instanceof WP_REST_Response) && !is_wp_error($jwt_candidate)) {
    $uid = (int)$jwt_candidate;
    $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
    $module .= ".jwt_user_id:$uid.jwt_username:$ulogin";
  } else {
    $access_token = $p['access_token'] ?? $request->get_header('access_token') ?? $request->get_header('Access-Token');
    if ($access_token === 'null') { $access_token = null; }
    $access_token = is_string($access_token) ? trim($access_token) : $access_token;

    if (!empty($access_token) && preg_match('/^\d+$/', (string)$access_token)) {
      $uid = (int)$access_token;
      $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
      $module .= ".legacy_user_id:$uid.legacy_user_login:$ulogin";
    } elseif (!empty($access_token) && is_string($access_token)) {
      $request_with_bearer = new WP_REST_Request($request->get_method(), $request->get_route());
      foreach ((array)$request->get_params() as $k => $v) { $request_with_bearer->set_param($k, $v); }
      $request_with_bearer->set_header('Authorization', 'Bearer '.$access_token);

      $jwt_from_access = extract_user_from_jwt_token($request_with_bearer);
      if (!($jwt_from_access instanceof WP_REST_Response) && !is_wp_error($jwt_from_access)) {
        $uid = (int)$jwt_from_access;
        $ulogin = ($u=get_userdata($uid))?$u->user_login:'unknown';
        $module .= ".jwt_in_access_token_user_id:$uid.jwt_username:$ulogin";
      } else {
        return new WP_REST_Response(['success'=>false,'module'=>$module.'-EJWT','error'=>'invalid_token'],401);
      }
    }
  }

  if (empty($uid) || $uid <= 0 || !get_userdata($uid)) {
    return new WP_REST_Response(['success'=>false,'module'=>$module.'-EUSER','error'=>'invalid_user'],400);
  }

  /* STEP 2: input */
  $order_id=(int)($p['order_id']??0);
  if($order_id<=0){ vogo_error_log3("[STEP 2] Missing order_id | IP:$ip | USER:$uid"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'module'=>$module.'-EARGS','error'=>'missing_order_id'],400); }

  /* STEP 3: tables */
  $tbl_o=$wpdb->prefix.'orders'; $tbl_l=$wpdb->prefix.'orders_lines'; $tbl_addr=$wpdb->prefix.'wc_order_addresses';

  /* STEP 3a: sync missing Woo parent orders from last 24h for current user */
  vogo_sync_recent_woo_orders_for_user($uid, 24, false);

  /* STEP 4: resolve parent id, validate ownership */
  $q_res=$wpdb->prepare("SELECT id,parent_order_id,client_id FROM {$tbl_o} WHERE id=%d LIMIT 1",$order_id);
  vogo_error_log3("##############SQL: $q_res"); $res=$wpdb->get_row($q_res,ARRAY_A);
  if(!$res){
    vogo_error_log3("[STEP 4] Not found in custom table, trying Woo fallback for #$order_id");

    $request_user = get_userdata($uid);
    $request_user_email = $request_user && !empty($request_user->user_email) ? strtolower(trim((string)$request_user->user_email)) : '';

    $is_owner = static function($order, int $user_id, string $email): bool {
      if(!$order){ return false; }
      $customer_id = (int)$order->get_customer_id();
      if($customer_id > 0 && $customer_id === $user_id){ return true; }
      $billing_email = strtolower(trim((string)$order->get_billing_email()));
      return !empty($email) && !empty($billing_email) && $billing_email === $email;
    };

    $build_woo_order_data = static function($order) {
      if(!$order){ return null; }

      $ship = $order->get_address('shipping');
      $billing = $order->get_address('billing');
      $address_end = trim(implode(', ', array_filter([
        $ship['address_1'] ?? null,
        $ship['address_2'] ?? null,
        $ship['city'] ?? null,
        $ship['state'] ?? null,
        $ship['postcode'] ?? null,
        $ship['country'] ?? null,
      ])));

      $lines = [];
      foreach($order->get_items('line_item') as $item_id => $item){
        $product_id = (int)$item->get_product_id();
        $variation_id = (int)$item->get_variation_id();
        $thumb_source_id = $variation_id ?: $product_id;
        $img_url = $thumb_source_id ? get_the_post_thumbnail_url($thumb_source_id, 'full') : null;

        $lines[] = [
          'order_id' => (int)$order->get_id(),
          'order_item_id' => (int)$item_id,
          'product_name' => $item->get_name(),
          'product_id' => $product_id,
          'variation_id' => $variation_id,
          'qty' => (string)$item->get_quantity(),
          'line_subtotal' => wc_format_decimal($item->get_subtotal(), 2),
          'line_subtotal_tax' => wc_format_decimal($item->get_subtotal_tax(), 2),
          'line_total' => wc_format_decimal($item->get_total(), 2),
          'line_tax' => wc_format_decimal($item->get_total_tax(), 2),
          'tax_rate' => null,
          'discount_total' => wc_format_decimal(max(0, (float)$item->get_subtotal() - (float)$item->get_total()), 2),
          'discount_percent' => null,
          'created_at' => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : null,
          'created_by' => null,
          'modified_at' => $order->get_date_modified() ? $order->get_date_modified()->date('Y-m-d H:i:s') : null,
          'modified_by' => null,
          'vendor_id' => null,
          'vendor_name' => null,
          'product_image' => $img_url ? ['id'=>null,'url'=>$img_url,'original_url'=>$img_url] : null,
        ];
      }

      return [
        'id' => (int)$order->get_id(),
        'parent_order_id' => (int)$order->get_parent_id(),
        'client_id' => null,
        'provider_id' => null,
        'picking_point_id' => null,
        'pick_latitude' => null,
        'pick_longitude' => null,
        'notes_customer' => $order->get_customer_note() ?: null,
        'notes_provider' => null,
        'notes_transporter' => null,
        'city_id' => null,
        'total_amount' => wc_format_decimal($order->get_total(), 2),
        'currency' => $order->get_currency(),
        'payment_method_title' => $order->get_payment_method_title(),
        'status' => strtoupper((string)$order->get_status()),
        'delivery_type' => null,
        'created_at' => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d H:i:s') : null,
        'end_lat' => null,
        'end_long' => null,
        'address_pick' => null,
        'address_end' => $address_end ?: null,
        'distance_km' => null,
        'calculated_fields' => null,
        'created_by' => null,
        'modified_at' => $order->get_date_modified() ? $order->get_date_modified()->date('Y-m-d H:i:s') : null,
        'modified_by' => null,
        'order_short_description' => null,
        'relevant_image' => null,
        'provider_name' => null,
        'addresses' => [
          'billing' => !empty($billing) ? $billing : null,
          'shipping' => !empty($ship) ? $ship : null,
        ],
        'lines' => $lines,
      ];
    };

    $current_order = wc_get_order($order_id);
    if(!$current_order){
      vogo_error_log3("[STEP 4] Woo fallback order not found #$order_id");
      vogo_error_log3("VOGO_LOG_END");
      return new WP_REST_Response(['success'=>false,'module'=>$module.'-ENOTF','error'=>'order_not_found'],404);
    }

    if(!$is_owner($current_order, $uid, $request_user_email)){
      vogo_error_log3("[STEP 4] Woo fallback forbidden #$order_id for user $uid");
      vogo_error_log3("VOGO_LOG_END");
      return new WP_REST_Response(['success'=>false,'module'=>$module.'-EFORB','error'=>'forbidden'],403);
    }

    $woo_parent_id = (int)$current_order->get_parent_id();
    $parent_order = $woo_parent_id > 0 ? wc_get_order($woo_parent_id) : $current_order;
    if(!$parent_order){
      vogo_error_log3("[STEP 4] Woo fallback parent not found #$woo_parent_id");
      vogo_error_log3("VOGO_LOG_END");
      return new WP_REST_Response(['success'=>false,'module'=>$module.'-ENOPAR','error'=>'parent_not_found'],404);
    }

    if(!$is_owner($parent_order, $uid, $request_user_email)){
      vogo_error_log3("[STEP 4] Woo fallback parent forbidden #$woo_parent_id for user $uid");
      vogo_error_log3("VOGO_LOG_END");
      return new WP_REST_Response(['success'=>false,'module'=>$module.'-EFORB','error'=>'forbidden'],403);
    }

    $parent_data = $build_woo_order_data($parent_order);
    if(!$parent_data){
      vogo_error_log3("[STEP 4] Woo fallback parent payload failed #$woo_parent_id");
      vogo_error_log3("VOGO_LOG_END");
      return new WP_REST_Response(['success'=>false,'module'=>$module.'-ENOPAR','error'=>'parent_not_found'],404);
    }

    $children_data = [];
    $child_orders = wc_get_orders([
      'type' => 'shop_order',
      'parent' => (int)$parent_order->get_id(),
      'limit' => -1,
      'orderby' => 'date',
      'order' => 'DESC',
    ]);

    foreach($child_orders as $child_order){
      if(!$is_owner($child_order, $uid, $request_user_email)){ continue; }
      $child_payload = $build_woo_order_data($child_order);
      if($child_payload){ $children_data[] = $child_payload; }
    }

    if(empty($children_data)){
      $children_data[] = $build_woo_order_data($current_order);
    }

    $parent_data['children'] = array_values(array_filter($children_data));

    vogo_error_log3("[STEP 4] Woo fallback details ready | parent:".(int)$parent_order->get_id()." children:".count($parent_data['children'])." | IP:$ip | USER:$uid");
    vogo_error_log3("VOGO_LOG_END");

    return new WP_REST_Response([
      'success'=>true,
      'module'=>$module.'.WOO_FALLBACK',
      'message'=>'Order details',
      'user_id'=>$uid,
      'user_login'=>$ulogin,
      'data'=>$parent_data,
    ],200);
  }
  if((int)$res['client_id']!==$uid){ vogo_error_log3("[STEP 4] Forbidden #$order_id for user $uid"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'module'=>$module.'-EFORB','error'=>'forbidden'],403); }
  $parent_id=((int)$res['parent_order_id']===0)?(int)$res['id']:(int)$res['parent_order_id'];

  /* STEP 5: fetch parent (ALL COLUMNS) */
  $q_par=$wpdb->prepare("SELECT id,parent_order_id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,notes_customer,notes_provider,notes_transporter,city_id,total_amount,currency,payment_method_title,status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields,created_by,modified_at,modified_by,order_short_description,relevant_image,provider_name FROM {$tbl_o} WHERE id=%d AND client_id=%d LIMIT 1",$parent_id,$uid);
  vogo_error_log3("##############SQL: $q_par"); $parent=$wpdb->get_row($q_par,ARRAY_A);
  if(!$parent){ vogo_error_log3("[STEP 5] Parent not found #$parent_id"); vogo_error_log3("VOGO_LOG_END"); return new WP_REST_Response(['success'=>false,'module'=>$module.'-ENOPAR','error'=>'parent_not_found'],404); }

  /* STEP 6: fetch children (ALL COLUMNS) */
  $q_ch=$wpdb->prepare("SELECT id AS order_id,parent_order_id,client_id,provider_id,picking_point_id,pick_latitude,pick_longitude,notes_customer,notes_provider,notes_transporter,city_id,total_amount,currency,payment_method_title,status,delivery_type,created_at,end_lat,end_long,address_pick,address_end,distance_km,calculated_fields,created_by,modified_at,modified_by,order_short_description,relevant_image,provider_name FROM {$tbl_o} WHERE parent_order_id=%d ORDER BY created_at DESC",$parent_id);
  vogo_error_log3("##############SQL: $q_ch"); $children=$wpdb->get_results($q_ch,ARRAY_A); $child_ids=array_map(fn($r)=>(int)$r['order_id'],$children);

/* STEP 6a: HPOS addresses (billing+shipping) pentru parent + copii */
$tbl_addr = $wpdb->prefix.'wc_order_addresses';
$all_ids = array_merge([$parent_id], $child_ids);
$addr = []; if($all_ids){
  $ph = implode(',', array_fill(0, count($all_ids), '%d'));
  $q = $wpdb->prepare("SELECT order_id,address_type,country,city,state,address_1,address_2,postcode,first_name,last_name,company,email,phone
                       FROM {$tbl_addr}
                       WHERE address_type IN ('billing','shipping') AND order_id IN ($ph)", ...$all_ids);
  vogo_error_log3("##############SQL: $q");
  foreach($wpdb->get_results($q, ARRAY_A) as $r){
    $oid=(int)$r['order_id']; $type=$r['address_type'];
    unset($r['order_id'],$r['address_type']);
    $addr[$oid][$type]=$r;
  }
}

  /* STEP 7: lines for all children (attachments only for images) */
  $lines_by_child=[];
  if($child_ids){
    $in_c=implode(',',array_fill(0,count($child_ids),'%d'));
    $q_li=$wpdb->prepare(
      "SELECT l.order_id,l.order_item_id,l.product_name,l.product_id,l.variation_id,l.qty,l.line_subtotal,l.line_subtotal_tax,l.line_total,l.line_tax,l.tax_rate,l.discount_total,l.discount_percent,l.created_at,l.created_by,l.modified_at,l.modified_by,l.vendor_id,l.vendor_name,
         COALESCE((SELECT CAST(pm_v.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_v WHERE pm_v.post_id=CAST(l.variation_id AS UNSIGNED) AND pm_v.meta_key='_thumbnail_id' LIMIT 1),
                  (SELECT CAST(pm_p.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_p WHERE pm_p.post_id=CAST(l.product_id   AS UNSIGNED) AND pm_p.meta_key='_thumbnail_id' LIMIT 1)) AS attachment_id
       FROM {$tbl_l} l
       WHERE l.order_id IN ($in_c)
       ORDER BY l.order_item_id ASC",
      ...$child_ids
    );
    vogo_error_log3("##############SQL: $q_li"); $lines=$wpdb->get_results($q_li,ARRAY_A);

    foreach($lines as &$l){
      // normalize line numeric fields to string/decimal format for mobile model consistency
      $l['qty'] = isset($l['qty']) && $l['qty'] !== null ? (string)$l['qty'] : null;
      foreach (['line_subtotal','line_subtotal_tax','line_total','line_tax','tax_rate','discount_total','discount_percent'] as $money_key) {
        if (isset($l[$money_key]) && $l[$money_key] !== null && $l[$money_key] !== '') {
          $l[$money_key] = wc_format_decimal($l[$money_key], 2);
        }
      }

      $att=(int)($l['attachment_id']??0);
      if($att>0){
        $orig=wp_get_attachment_url($att); $thumb=wp_get_attachment_image_src($att,'woocommerce_thumbnail');
        $l['product_image']=['id'=>$att,'url'=>$orig?:null,'original_url'=>$orig?:null,'thumb_url'=>is_array($thumb)?$thumb[0]:null,'thumb_w'=>is_array($thumb)?(int)$thumb[1]:null,'thumb_h'=>is_array($thumb)?(int)$thumb[2]:null,'srcset'=>wp_get_attachment_image_srcset($att,'woocommerce_thumbnail')?:null,'sizes'=>wp_get_attachment_image_sizes($att,'woocommerce_thumbnail')?:null];
      } else {
        $pid=(int)($l['variation_id']?:$l['product_id']); $url=$pid?get_the_post_thumbnail_url($pid,'full'):null;
        $l['product_image']=$url?['id'=>null,'url'=>$url,'original_url'=>$url]:null;
      }
      unset($l['attachment_id']); $lines_by_child[(int)$l['order_id']][]=$l;
    }
    unset($l);
  }

 /* STEP 8: assemble */
$parent['addresses'] = $addr[$parent_id] ?? ['billing'=>null,'shipping'=>null];
foreach($children as &$c){
  $oid=(int)$c['order_id'];
  $c['addresses'] = $addr[$oid] ?? ['billing'=>null,'shipping'=>null];
  $c['lines'] = $lines_by_child[$oid] ?? [];
}
unset($c);
$parent['children'] = $children;

  vogo_error_log3("[STEP 8] Details ready | parent:$parent_id children:".count($children)." | IP:$ip | USER:$uid");
  vogo_error_log3("VOGO_LOG_END");

  return new WP_REST_Response([
    'success'=>true,'module'=>$module.'.TEND','message'=>'Order details',
    'user_id'=>$uid,'user_login'=>$ulogin,
    'data'=>$parent
  ],200);
}
