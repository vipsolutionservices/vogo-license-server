<?php
$MODULE_PHP='general-endpoints.php';



add_action('rest_api_init', function () {

  register_rest_route('vogo/v1/util','/get_address_from_lat_long',[
    'methods'  => 'POST',
    'callback' => 'get_address_from_lat_long',
    'permission_callback' => '__return_true'
  ]);  

  register_rest_route('vogo/v1/util','/get_postcode_from_address',[ //param in: country; city; street with number; 
    'methods'  => 'POST',
    'methods'  => 'POST',
    'callback' => 'get_postcode_from_address',
    'permission_callback' => '__return_true'
  ]);    

  register_rest_route('vogo/v1/util','/get_lat_long_from_address',[ //param in: country; city; street with number; 
    'methods'  => 'POST',
    'callback' => 'get_lat_long_from_address',
    'permission_callback' => '__return_true'
  ]);      

  register_rest_route('vogo/v1/util','/get_my_invoices',[ //returns out list from orders: invoice_id=order_id;
    //invoice_date = order date; invoice_number = order number; invoice_ammount = order_ammount;
    // download_link: https://test07.vogo.family/myaccount/get_invoice?p_id=invoice id.
    'methods'  => 'POST',
    'callback' => 'get_my_invoices',
    'permission_callback' => '__return_true'
  ]);     

  register_rest_route('vogo/v1/util','/update_order_lat_long',[
    'methods'  => 'POST',
    'callback' => 'update_order_lat_long',
    'permission_callback' => '__return_true'
  ]);    

    register_rest_route('vogo/v1/lov', '/get_areas_of_interest', [
        'methods' => 'GET',
        'callback' => 'vogo_get_areas_of_interest',
        'permission_callback' => 'vogo_permission_check'
    ]);

	register_rest_route('vogo/v1/lov', '/get_cities', [
        'methods' => 'GET',
        'callback' => 'get_city_list',
        'permission_callback' => 'vogo_permission_check'
    ]);

    //backward compatibility
	register_rest_route('vogo/v1', 'vogofamily/cities', [
        'methods' => 'POST',
        'callback' => 'get_city_list',
        'permission_callback' => 'vogo_permission_check'
    ]);    

    register_rest_route('vogo/v1', '/add_role/(?P<role_key>[a-zA-Z0-9_\-]+)', [
        'methods'  => 'POST',
        'callback' => 'vogo_add_role_simple',
        'permission_callback' => 'vogo_permission_check'
    ]);

  register_rest_route('vogo/v1/debug', '/frontend-optimization', [
    'methods'             => 'GET',
    'callback'            => 'vogo_debug_frontend_optimization',
    'permission_callback' => 'vogo_permission_check'
  ]);    

});    


/**
 * vogo_get_areas_of_interest
 *
 * Fetches active areas of interest from the database and logs the action.
 * Endpoint: GET /wp-json/vogo/v1/areas-of-interest
 */
function vogo_get_areas_of_interest(WP_REST_Request $request) {
    global $wpdb;

    // Current user (if logged in)
    $current_user = wp_get_current_user();

    // Client IP address
    $ip = vogo_get_client_ip();

    // Define the table name
    $table = $wpdb->prefix . 'vogo_areas_of_interest';

    // Fetch all active areas
    $results = $wpdb->get_results(
        "SELECT id, area_name, description, created_at, position
         FROM $table
         WHERE is_active = 1
         ORDER BY position ASC",
        ARRAY_A
    );

    // Determine if any records were found
    $log_success = count($results) > 0 ? 1 : 0;

    // Build log info
    $log_action_info = 'Returned ' . count($results) . ' areas of interest.';

    // Log the action
    vogo_log_action(
        $current_user,
        $current_user->exists() ? $current_user->user_login : '',
        $ip,
        $log_success,
        'M-GET-AREAS',
        $log_action_info
    );

    return new WP_REST_Response([
        'success' => true,
        'data' => $results
    ], 200);
}

/**
 * Return the full list of cities from wp_cities
 */
function get_city_list(WP_REST_Request $request) {
  global $wpdb;

  // VOGO_LOG_START
  $user_id = 0; $user_login = 'unknown'; $ip = vogo_get_client_ip(); $active_db = $wpdb->dbname;
  vogo_error_log3("[get_city_list] [user:$user_login] [STEP 0] VOGO_LOG_START | IP: $ip | USER: $user_login | ACTIVE DB: $active_db");

  try {
    // [STEP 1] Extract current user from JWT
    $user_info = extract_user_from_jwt_token($request);
    if ($user_info instanceof WP_REST_Response) return $user_info;
    $user_id = $user_info;
    $user_obj = get_user_by('ID', $user_id);
    $user_login = $user_obj ? $user_obj->user_login : 'unknown';
    vogo_error_log3("[get_city_list] [user:$user_login] [STEP 1] User authenticated | ID: $user_id");

    // [STEP 2] Prepare table and query
    $table = $wpdb->prefix . 'cities';
    $query = "SELECT id, city_name, status FROM $table WHERE status = 1 ORDER BY position ASC";
    vogo_error_log3("[get_city_list] [user:$user_login] [STEP 2] ##############SQL: $query");

    // [STEP 3] Execute query
    $results = $wpdb->get_results($query, ARRAY_A);
    $success = is_array($results) && count($results) > 0;

    if (!$success && $wpdb->last_error) {
      vogo_error_log3("[get_city_list] [user:$user_login] [STEP 3] ❌ SQL ERROR: {$wpdb->last_error}");
      return new WP_REST_Response([
        'success'   => false,
        'error'     => 'DB error',
        'sql_error' => $wpdb->last_error
      ], 500);
    }

    // [STEP 4] Log action
    $log_msg = 'Returned ' . count($results) . ' cities.';
    vogo_error_log3("[get_city_list] [user:$user_login] [STEP 4] ✅ $log_msg");
    vogo_log_action($user_obj, $user_login, $ip, $success ? 1 : 0, 'M-GET-CITIES', $log_msg);

    // [STEP 5] Return JSON response
    return new WP_REST_Response([
      'success'    => true,
      'data'       => $results,
      'user_id'    => $user_id,
      'user_login' => $user_login
    ], 200);
  } catch (Throwable $e) {
    vogo_error_log3("[get_city_list] [user:$user_login] [STEP X] ❌ Exception: " . $e->getMessage());
    return new WP_REST_Response([
      'success' => false,
      'error'   => 'Server error',
      'details' => $e->getMessage()
    ], 500);
  }

  // VOGO_LOG_END
}

/**
 * vogo_get_judete_list
 *
 * Fetches the list of cities from the database and logs the action.
 * Example endpoint: GET /wp-json/vogo/v1/cities
 */
function vogo_get_judete_list(WP_REST_Request $request) {
    global $wpdb;

    // Get the current user (if logged in)
    $current_user = wp_get_current_user();

    // Get the client IP address
    $ip = vogo_get_client_ip();

    // Define the table
    $table = $wpdb->prefix . 'vogo_city';

    // Fetch all cities ordered by position
    $results = $wpdb->get_results(
        "SELECT
            id,
            position,
            country,
            county,
            city_name,
            population,
            date_created,
            date_updated,
            user_created,
            user_updated
         FROM $table
         ORDER BY position ASC",
        ARRAY_A
    );

    // Determine success
    $log_success = count($results) > 0 ? 1 : 0;

    // Build log info
    $log_action_info = 'Returned ' . count($results) . ' cities.';

    // Log the action
    vogo_log_action(
        $current_user,
        $current_user->exists() ? $current_user->user_login : '',
        $ip,
        $log_success,
        'M-GET-CITIES',
        $log_action_info
    );

    return new WP_REST_Response([
        'success' => true,
        'data' => $results
    ], 200);
}


function vogo_add_role_simple($request) {
    $module = 'add-role';
    $role_key = sanitize_key($request['role_key']);
    $role_name = ucwords(str_replace('_', ' ', $role_key));
    $capabilities = ['read' => true];

    // STEP 1: Validare parametru
    if (empty($role_key)) {
        vogo_error_log2($module, '[STEP 1] ❌ Lipsă role_key în URL');
        return new WP_REST_Response(['success' => false, 'error' => 'role_key este obligatoriu'], 400);
    }

    // STEP 2: Verificăm dacă există deja
    if (get_role($role_key)) {
        vogo_error_log2($module, "[STEP 2] ⚠️ Rolul '$role_key' deja există");
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Rolul deja există.',
            'role_key' => $role_key
        ], 200);
    }

    // STEP 3: Adăugare rol
    add_role($role_key, $role_name, $capabilities);
    vogo_error_log2($module, "[STEP 3] ✅ Rol '$role_key' adăugat ca '$role_name'");

    return new WP_REST_Response([
        'success' => true,
        'role_key' => $role_key,
        'role_name' => $role_name,
        'capabilities' => $capabilities,
        'message' => 'Rol adăugat cu succes.'
    ], 201);
}


function vogo_debug_frontend_optimization(WP_REST_Request $request) {
  global $wpdb;

  // Check Redis
  $redis_status = class_exists('Redis') ? (extension_loaded('redis') ? 'enabled' : 'installed_but_not_loaded') : 'not_installed';

  // Check autoload bloat
  $autoload_heavy = $wpdb->get_results("SELECT option_name, LENGTH(option_value) AS size FROM {$wpdb->options} WHERE autoload = 'yes' ORDER BY size DESC LIMIT 10");

  // Inactive plugins
  $inactive_plugins = array_filter(get_plugins(), function ($plugin, $key) {
    return !is_plugin_active($key);
  }, ARRAY_FILTER_USE_BOTH);

  // Cron jobs
  $cron_jobs = _get_cron_array();
  $cron_summary = is_array($cron_jobs) ? array_keys($cron_jobs) : [];

  // REST API status
  $rest_enabled = apply_filters('rest_enabled', true) ? 'enabled' : 'disabled';

  // Lazy load detection
  $lazy_load = (bool)get_theme_mod('lazyload_images', false);

  // Output
  return [
    'success' => true,
    'redis_status' => $redis_status,
    'autoload_bloat' => $autoload_heavy,
    'inactive_plugins_count' => count($inactive_plugins),
    'inactive_plugins' => array_keys($inactive_plugins),
    'cron_jobs_count' => count($cron_summary),
    'cron_jobs' => $cron_summary,
    'rest_api' => $rest_enabled,
    'lazy_load_images' => $lazy_load,
    'php_version' => phpversion(),
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time'),
    'wp_debug' => (defined('WP_DEBUG') && WP_DEBUG) ? 'enabled' : 'disabled'
  ];
}

function update_order_lat_long(WP_REST_Request $request){
  global $wpdb;
  $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
  vogo_error_log3("VOGO_LOG_START | ACTIVE DB: ".DB_NAME." | IP:$ip | USER:0 | EP:map/update_order_lat_long");

  // [STEP 0.1] Raw query payload
  $q = $request->get_params();
  vogo_error_log3("[STEP 0.1] Raw QUERY payload: ".json_encode($q)." | IP:$ip | USER:0");

  // [STEP 1] JWT user (headers work also on GET)
  $user_id = extract_user_from_jwt_token($request);
  if (is_wp_error($user_id)){ vogo_error_log3("[STEP 1 ERR] JWT invalid | IP:$ip | USER:0"); vogo_error_log3("VOGO_LOG_END"); return $user_id; }
  $user = get_user_by('ID',$user_id); $user_login = $user?->user_login ?? '';

  // [STEP 2] Validate input
  $parent_id = (int)($q['parent_id'] ?? 0);
  if ($parent_id <= 0){
    vogo_error_log3("[STEP 2 ERR] missing/invalid parent_id | IP:$ip | USER:$user_id");
    vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response([
      'success'=>false,'error'=>'missing_parent_id','user_id'=>$user_id,'user_login'=>$user_login
    ],400);
  }

  // [STEP 3] Geocode parent (uses wp_orders.address_end)
  $parent_result = vogo_order_set_latlong($parent_id);

  // [STEP 4] Geocode all children (HPOS)
  $children_result = vogo_set_latlong_for_children($parent_id);

  // [STEP 5] Done
  vogo_error_log3("[STEP 5] Completed for parent_id=$parent_id | IP:$ip | USER:$user_id");
  vogo_error_log3("VOGO_LOG_END");

  return new WP_REST_Response([
    'success'=>true,
    'parent_id'=>$parent_id,
    'parent_result'=>$parent_result,
    'children_result'=>$children_result,
    'user_id'=>$user_id,
    'user_login'=>$user_login
  ],200);
}


function get_address_from_lat_long(WP_REST_Request $request){
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $jwt_user_id=null; $jwt_user_name='unknown';
  try{ $c=extract_user_from_jwt_token($request); if(!($c instanceof WP_REST_Response)){ $id=(int)$c; if($id>0){ $u=get_userdata($id); if($u){ $jwt_user_id=$id; $jwt_user_name=$u->user_login; } } } }catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  $p=$request->get_json_params(); if(empty($p)) $p=$_REQUEST;
  $lat=isset($p['lat'])?(float)$p['lat']:null;
  $lon=isset($p['long'])?(float)$p['long']:(isset($p['lng'])?(float)$p['lng']:null);
  $lang=isset($p['lang'])?sanitize_text_field($p['lang']):'en';
  if($lat===null||$lon===null||$lat<-90||$lat>90||$lon<-180||$lon>180){ return ['success'=>false,'error'=>'Invalid lat/long','module'=>$module.'.ERR1.PARAM']; }

  $url=add_query_arg(['format'=>'jsonv2','lat'=>$lat,'lon'=>$lon,'addressdetails'=>1,'accept-language'=>$lang],'https://nominatim.openstreetmap.org/reverse');
  $resp=wp_remote_get($url,['timeout'=>8,'user-agent'=>'VOGO/1.0 (+https://vogo.family) WordPress']);
  if(is_wp_error($resp)) return ['success'=>false,'error'=>'Geocode request failed','http_error'=>$resp->get_error_message(),'module'=>$module.'.ERR2.HTTP'];
  $code=wp_remote_retrieve_response_code($resp); $body=wp_remote_retrieve_body($resp);
  if($code<200||$code>=300||!$body) return ['success'=>false,'error'=>'Geocode bad response','http_code'=>$code,'module'=>$module.'.ERR2.HTTP_CODE'];
  $j=json_decode($body,true); if(!is_array($j)) return ['success'=>false,'error'=>'Geocode parse error','module'=>$module.'.ERR3.JSON'];

  $a=isset($j['address'])&&is_array($j['address'])?$j['address']:[];
  $house=$a['house_number']??''; $road=$a['road']??($a['pedestrian']??($a['footway']??'')); $neigh=$a['neighbourhood']??($a['suburb']??($a['city_district']??'')); $city=$a['city']??($a['town']??($a['village']??($a['municipality']??($a['county']??'')))); $state=$a['state']??($a['region']??''); $pc=$a['postcode']??''; $cc=strtoupper($a['country_code']??''); $country=$a['country']??''; $addr1=trim(trim($road.' '.$house)); $display=isset($j['display_name'])?(string)$j['display_name']:'';

  return [
    'success'=>true,
    'module'=>$module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,
    'jwt_user_name'=>$jwt_user_name,
    'query'=>['lat'=>$lat,'long'=>$lon,'lang'=>$lang],
    'address'=>[
      'address_1'=>$addr1,
      'address_2'=>$neigh,
      'city'=>$city,
      'state'=>$state,
      'postcode'=>$pc,
      'country'=>$country,
      'country_code'=>$cc,
      'display'=>$display,
      'raw'=>$a
    ]
  ];
}

function get_postcode_from_address(WP_REST_Request $request){
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $jwt_user_id=null; $jwt_user_name='unknown';
  try{ $c=extract_user_from_jwt_token($request); if(!($c instanceof WP_REST_Response)){ $id=(int)$c; if($id>0){ $u=get_userdata($id); if($u){ $jwt_user_id=$id; $jwt_user_name=$u->user_login; } } } }catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  // STEP1
  $p=$request->get_json_params(); if(empty($p)) $p=$_REQUEST;
  $country=isset($p['country'])?trim((string)$p['country']):'';
  $city=isset($p['city'])?trim((string)$p['city']):'';
  $street=isset($p['street'])?trim((string)$p['street']):'';
  $lang=isset($p['lang'])?sanitize_text_field($p['lang']):'en';
  if($country===''||$city===''||$street===''){ return ['success'=>false,'error'=>'Missing params: country, city, street','module'=>$module.'.ERR1.PARAM']; }
  $q="$street, $city, $country";

  // STEP2
  $url=add_query_arg(['format'=>'jsonv2','q'=>$q,'addressdetails'=>1,'limit'=>1,'accept-language'=>$lang],'https://nominatim.openstreetmap.org/search');
  $resp=wp_remote_get($url,['timeout'=>8,'user-agent'=>'VOGO/1.0 (+https://vogo.family) WordPress']);
  if(is_wp_error($resp)) return ['success'=>false,'error'=>'Geocode request failed','http_error'=>$resp->get_error_message(),'module'=>$module.'.ERR2.HTTP'];
  $code=wp_remote_retrieve_response_code($resp); $body=wp_remote_retrieve_body($resp);
  if($code<200||$code>=300||!$body) return ['success'=>false,'error'=>'Geocode bad response','http_code'=>$code,'module'=>$module.'.ERR2.HTTP_CODE'];
  $j=json_decode($body,true); if(!is_array($j)||!count($j)) return ['success'=>false,'error'=>'No results','module'=>$module.'.ERR3.EMPTY'];

  // STEP3
  $it=$j[0]; $addr=is_array($it['address']??null)?$it['address']:[];
  $pc=$addr['postcode']??''; $house=$addr['house_number']??''; $road=$addr['road']??($addr['pedestrian']??($addr['footway']??'')); $neigh=$addr['neighbourhood']??($addr['suburb']??($addr['city_district']??'')); $cityN=$addr['city']??($addr['town']??($addr['village']??($addr['municipality']??($addr['county']??'')))); $stateN=$addr['state']??($addr['region']??''); $countryN=$addr['country']??''; $ccN=strtoupper($addr['country_code']??''); $addr1=trim(trim($road.' '.$house)); $display=isset($it['display_name'])?(string)$it['display_name']:'';

  return [
    'success'=>true,
    'module'=>$module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,
    'jwt_user_name'=>$jwt_user_name,
    'query'=>['country'=>$country,'city'=>$city,'street'=>$street,'lang'=>$lang],
    'result'=>[
      'postcode'=>$pc,
      'address_1'=>$addr1,
      'address_2'=>$neigh,
      'city'=>$cityN,
      'state'=>$stateN,
      'country'=>$countryN,
      'country_code'=>$ccN,
      'display'=>$display,
      'lat'=>isset($it['lat'])?(float)$it['lat']:null,
      'long'=>isset($it['lon'])?(float)$it['lon']:null,
      'raw'=>$addr
    ]
  ];
}


add_action('rest_api_init', function(){
  register_rest_route('vogo/v1/util','/get_lat_long_from_address',[
    'methods'=>'POST',
    'callback'=>'get_lat_long_from_address',
    'permission_callback'=>'__return_true'
  ]);
});

function get_lat_long_from_address(WP_REST_Request $request){
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;
  $jwt_user_id=null; $jwt_user_name='unknown';
  try{ $c=extract_user_from_jwt_token($request); if(!($c instanceof WP_REST_Response)){ $id=(int)$c; if($id>0){ $u=get_userdata($id); if($u){ $jwt_user_id=$id; $jwt_user_name=$u->user_login; } } } }catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  // STEP1
  $p=$request->get_json_params(); if(empty($p)) $p=$_REQUEST;
  $country=isset($p['country'])?trim((string)$p['country']):''; 
  $city=isset($p['city'])?trim((string)$p['city']):''; 
  $street=isset($p['street'])?trim((string)$p['street']):''; 
  $lang=isset($p['lang'])?sanitize_text_field($p['lang']):'en';
  if($country===''||$city===''||$street===''){ return ['success'=>false,'error'=>'Missing params: country, city, street','module'=>$module.'.ERR1.PARAM']; }
  $q="$street, $city, $country";

  // STEP2
  $url=add_query_arg(['format'=>'jsonv2','q'=>$q,'addressdetails'=>1,'limit'=>1,'accept-language'=>$lang],'https://nominatim.openstreetmap.org/search');
  $resp=wp_remote_get($url,['timeout'=>8,'user-agent'=>'VOGO/1.0 (+https://vogo.family) WordPress']);
  if(is_wp_error($resp)) return ['success'=>false,'error'=>'Geocode request failed','http_error'=>$resp->get_error_message(),'module'=>$module.'.ERR2.HTTP'];
  $code=wp_remote_retrieve_response_code($resp); $body=wp_remote_retrieve_body($resp);
  if($code<200||$code>=300||!$body) return ['success'=>false,'error'=>'Geocode bad response','http_code'=>$code,'module'=>$module.'.ERR2.HTTP_CODE'];
  $j=json_decode($body,true); if(!is_array($j)||!count($j)) return ['success'=>false,'error'=>'No results','module'=>$module.'.ERR3.EMPTY'];

  // STEP3
  $it=$j[0]; $addr=is_array($it['address']??null)?$it['address']:[];
  $lat=isset($it['lat'])?(float)$it['lat']:null; $lon=isset($it['lon'])?(float)$it['lon']:null;
  $house=$addr['house_number']??''; $road=$addr['road']??($addr['pedestrian']??($addr['footway']??'')); $neigh=$addr['neighbourhood']??($addr['suburb']??($addr['city_district']??'')); $cityN=$addr['city']??($addr['town']??($addr['village']??($addr['municipality']??($addr['county']??'')))); $stateN=$addr['state']??($addr['region']??''); $pc=$addr['postcode']??''; $countryN=$addr['country']??''; $ccN=strtoupper($addr['country_code']??''); $addr1=trim(trim($road.' '.$house)); $display=isset($it['display_name'])?(string)$it['display_name']:'';

  return [
    'success'=>true,
    'module'=>$module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,
    'jwt_user_name'=>$jwt_user_name,
    'query'=>['country'=>$country,'city'=>$city,'street'=>$street,'lang'=>$lang],
    'result'=>[
      'lat'=>$lat,
      'long'=>$lon,
      'address_1'=>$addr1,
      'address_2'=>$neigh,
      'city'=>$cityN,
      'state'=>$stateN,
      'postcode'=>$pc,
      'country'=>$countryN,
      'country_code'=>$ccN,
      'display'=>$display,
      'raw'=>$addr
    ]
  ];
}



function get_my_invoices(WP_REST_Request $request){
  global $wpdb;
  $MODULE_PHP=basename(__FILE__); $module=$MODULE_PHP.'.'.__FUNCTION__;

  $jwt_user_id=null; $jwt_user_name='unknown';
  try{ $c=extract_user_from_jwt_token($request); if(!($c instanceof WP_REST_Response)){ $id=(int)$c; if($id>0){ $u=get_userdata($id); if($u){ $jwt_user_id=$id; $jwt_user_name=$u->user_login; }}}}catch(Throwable $e){}
  $module=$module.'.jwt_user_id:'.$jwt_user_id.'.jwt_username:'.$jwt_user_name;

  //STEP1
  $p=$request->get_json_params(); if(empty($p)) $p=$_REQUEST;
  $user_id=extract_user_from_jwt_token($request); if($user_id instanceof WP_REST_Response) return $user_id; if(is_wp_error($user_id)) return $user_id;
  $uid=(int)$user_id;

  //STEP2
  $tbl_o=$wpdb->prefix.'orders';
  $rows=$wpdb->get_results($wpdb->prepare(
    "SELECT id,created_at,total_amount FROM {$tbl_o} WHERE client_id=%d AND parent_order_id=0 ORDER BY created_at DESC",$uid
  ),ARRAY_A);

  //STEP3
  $out=[];
  foreach($rows as $r){
    $out[]=[
      'invoice_id'=>$r['id'],
      'invoice_date'=>$r['created_at'],
      'invoice_number'=>$r['id'],
      'invoice_amount'=>$r['total_amount'],
      'download_link'=>'https://test07.vogo.family/SPV_VIPTESS_12.pdf'
    ];
  }

  return [
    'success'=>true,
    'module'=>$module.'.TEND',
    'jwt_user_id'=>$jwt_user_id,
    'jwt_user_name'=>$jwt_user_name,
    'user_id'=>$uid,
    'invoices'=>$out
  ];
}