<?php
$MODULE_PHP='document-endpoints.php';

//require_once $rest_dir . 'vogolib.php';


	//USER-DOCUMENTS

add_action('rest_api_init', function () {    
	register_rest_route('vogo/v1', '/ensure-user-doc-dir/(?P<user_id>\d+)', [
		'methods'  => 'POST',
		'callback' => 'vogo_ensure_user_doc_directory',
		'permission_callback' => function () {
			return current_user_can('edit_users'); // Admin-level required
		},
	]);

    register_rest_route('vogo-api/v1', '/user_document_data', [
        'methods' => 'POST',
        'callback' => 'vogo_add_user_document_data',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('vogo/v1', '/upload-user-document/(?P<user_id>\d+)/(?P<document_id>\d+)', [
        'methods'  => 'POST',
        'callback' => 'vogo_handle_user_document_upload',
        'permission_callback' => '__return_true',
    ]);


    register_rest_route('vogo/v1', '/upload-user-doc/(?P<user_id>\d+)/(?P<document_id>\d+)', array(
		'methods' => 'POST',
		'callback' => 'vogo_upload_user_doc',
		'permission_callback' => '__return_true',
	));

    register_rest_route('vogo-api/v1', '/get_required_documents_by_role/(?P<role>[a-zA-Z0-9_-]+)', [
        'methods'  => 'GET',
        'callback' => 'vogo_get_required_documents_by_role',
        'permission_callback' => 'vogo_permission_check', // securizat pentru App Store
    ]);

        // ===========================
    // GET USER DOCS BY TYPE (POST)
    // URL: /wp-json/vogo/v1/my-account/get-user-doc/{p_doc_type_id}
    // ===========================
        register_rest_route('vogo/v1', '/get-user-doc/(?P<p_doc_type_id>\d+)', [
            'methods'             => 'POST',
            'callback'            => 'get_user_doc_by_type',
            'permission_callback' => 'vogo_permission_check',
        ]);
});

    

/**
 * Ensure the user-specific document directory exists under wp-content/uploads/user-documents/{user_id}
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function vogo_ensure_user_doc_directory($request)
{
    $user_id = intval($request['user_id']);
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

    if (!$user_id || !get_user_by('ID', $user_id)) {
        vogo_log_action(null, '', $ip, 0, 'ensure_user_doc_dir_invalid_user', 'Invalid or missing user ID');
        return new WP_REST_Response(['success' => false, 'error' => 'Invalid user ID'], 400);
    }

    // Get WordPress upload base directory
    $upload_dir = wp_upload_dir();
    $base_path  = $upload_dir['basedir'] . '/user-documents/' . $user_id;

    // Attempt to create directory if not exists
    if (!file_exists($base_path)) {
        if (!wp_mkdir_p($base_path)) {
            vogo_log_action($user_id, '', $ip, 0, 'ensure_user_doc_dir_failed', 'Could not create directory');
            return new WP_REST_Response(['success' => false, 'error' => 'Failed to create directory'], 500);
        }
    }

    vogo_log_action($user_id, '', $ip, 1, 'ensure_user_doc_dir_success', 'User document directory ensured');
    return new WP_REST_Response(['success' => true, 'path' => $base_path], 200);
}

/**
 * Adds a document entry for a user in user_document_data table.
 */
function vogo_add_user_document_data($request) {
    global $wpdb;
    $params = $request->get_json_params();

    // Extract and sanitize input
    $user_id = intval($params['user_id'] ?? 0);
    $document_id = intval($params['document_id'] ?? 0);
    $document_link = sanitize_text_field($params['document_link'] ?? '');
    $created_by = intval($params['created_by'] ?? 0); // usually same as user_id

    // Validate input
    if ($user_id <= 0 || $document_id <= 0 || empty($document_link)) {
        return new WP_REST_Response(['success' => false, 'error' => 'Missing required fields'], 400);
    }

    // Ensure directory exists
    $upload_dir = wp_upload_dir();
    $doc_dir = $upload_dir['basedir'] . '/user-documents/';
    if (!file_exists($doc_dir)) {
        wp_mkdir_p($doc_dir);
    }

    // Insert into DB
    $result = $wpdb->insert(
        $wpdb->prefix . 'user_document_data',
        [
            'user_id' => $user_id,
            'document_id' => $document_id,
            'document_link' => $document_link,
            'created_by' => $created_by,
            'updated_by' => $created_by
        ],
        ['%d', '%d', '%s', '%d', '%d']
    );

    // Logging (style VOGO)
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
    $status = $result ? 1 : 0;
    $msg = $result ? 'Document saved' : 'Insert failed';
    vogo_log_action($user_id, $document_link, $ip, $status, 'user_document_save', $msg);

    if (!$result) {
        return new WP_REST_Response(['success' => false, 'error' => 'Database insert failed'], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'id' => $wpdb->insert_id
    ], 201);
}


function vogo_handle_user_document_upload(WP_REST_Request $request) {

        return new WP_REST_Response(['success' => false, 'payload' => $payload], 400);

//vogo_error_log(json_encode($payload));

    $user_id     = (int) $request->get_param('user_id');
    $document_id = (int) $request->get_param('document_id');

    // 🛡️ Validări de bază
    if (!$user_id || !$document_id) {
        return new WP_REST_Response(['success' => false, 'error' => 'Missing parameters'], 400);
    }

    if (empty($_FILES) || !isset($_FILES['file'])) {
        return new WP_REST_Response(['success' => false, 'error' => 'No file provided'], 400);
    }

    // 🗂️ Pregătire folder upload: wp-content/uploads/user-documents/{user_id}/
    $upload_dir = wp_upload_dir();
    $base_dir = trailingslashit($upload_dir['basedir']) . 'user-documents/' . $user_id . '/';
    wp_mkdir_p($base_dir); // creează automat recursiv dacă nu există

    // 📂 Procesare fișier upload
    $file = $_FILES['file'];
    $filename = sanitize_file_name($file['name']);
    $target_path = $base_dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        return new WP_REST_Response(['success' => false, 'error' => 'Upload failed'], 500);
    }

    // 📝 Salvare în DB
    global $wpdb;
    $table = $wpdb->prefix . 'user_document_data';
    $document_link = 'user-documents/' . $user_id . '/' . $filename;

    $result = $wpdb->insert($table, [
        'user_id'       => $user_id,
        'document_id'   => $document_id,
        'document_link' => $document_link,
        'created_at'    => current_time('mysql'),
        'created_by'    => get_current_user_id(),
        'updated_at'    => current_time('mysql'),
        'updated_by'    => get_current_user_id(),
    ]);

    if (!$result) {
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'DB insert failed',
            'details' => $wpdb->last_error  // ← aici returnezi mesajul SQL efectiv
        ], 500);
    }

    return new WP_REST_Response([
        'success'        => true,
        'document_link'  => $document_link,
        'message'        => 'Document uploaded successfully'
    ], 200);
}

function vogo_upload_user_doc(WP_REST_Request $request) {
    global $wpdb;

    vogo_error_log("[DEBUG] STEP 1: Funcție vogo_get_test2() pornită");

    $user_id     = (int) $request->get_param('user_id');
    $document_id = (int) $request->get_param('document_id');
    vogo_error_log("[DEBUG] STEP 2: user_id = $user_id, document_id = $document_id");

    // Verificare utilizator autentificat prin JWT
    $current_user = wp_get_current_user();
    $jwt_user_id = $current_user->ID;
    vogo_error_log("[DEBUG] STEP 3: JWT user ID = $jwt_user_id");

    // Validare JWT vs user_id din request
    if (!$jwt_user_id || $jwt_user_id !== $user_id) {
     //   vogo_error_log("[ERROR] STEP 4: JWT user ID nu se potrivește cu user_id din request");
        return new WP_REST_Response([
            'success' => false,
            'error'   => "Unauthorized access for user_id: $user_id"
        ], 403);
    }
    //vogo_error_log("[DEBUG] STEP 5: Autorizare JWT reușită");

    // Verificare fișier primit
    //vogo_error_log("[DEBUG] STEP 6: Conținut \$_FILES = " . print_r($_FILES, true));

if (!isset($_FILES['file'])) {
    vogo_error_log('[DEBUG] STEP 6.1: Cheia "file" nu este setată în $_FILES.');
} else {
    vogo_error_log('[DEBUG] STEP 6.1: Fișier primit: ' . print_r($_FILES['file'], true));
}    

//vogo_error_log('[DEBUG] CONTENT_TYPE = ' . $_SERVER['CONTENT_TYPE']);
//vogo_error_log('[DEBUG] CONTENT_LENGTH = ' . $_SERVER['CONTENT_LENGTH']);
//vogo_error_log('[DEBUG] RAW INPUT = ' . file_get_contents('php://input'));


    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        vogo_error_log("[ERROR] STEP 7: Fișierul nu a fost uploadat corect sau lipsește");
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'No file uploaded or upload error'
        ], 400);
    }

    $file     = $_FILES['file'];
    $filename = sanitize_file_name($file['name']);
    vogo_error_log("[DEBUG] STEP 8: Nume fișier = $filename");

    // Creează folderul
    $upload_dir = wp_upload_dir();
    $base_dir = trailingslashit($upload_dir['basedir']) . 'user-documents/' . $user_id . '/';
    $document_link = 'user-documents/' . $user_id . '/' . $filename;
    $target_path = $base_dir . $filename;

    vogo_error_log("[DEBUG] STEP 9: Folder upload = $base_dir");

    if (!wp_mkdir_p($base_dir)) {
        vogo_error_log("[ERROR] STEP 10: Nu pot crea folderul $base_dir");
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'Could not create upload directory'
        ], 500);
    }

    // Salvare efectivă fișier
    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
        vogo_error_log("[ERROR] STEP 11: move_uploaded_file() eșuat pentru " . $file['tmp_name']);
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'Failed to save uploaded file'
        ], 500);
    }

    vogo_error_log("[DEBUG] STEP 12: Fișier salvat în $target_path");

    // Insert în DB
    $result = $wpdb->insert($wpdb->prefix . 'user_document_data', [
        'user_id'       => $user_id,
        'document_id'   => $document_id,
        'document_link' => $document_link,
        'created_at'    => current_time('mysql'),
        'created_by'    => $jwt_user_id,
        'updated_at'    => current_time('mysql'),
        'updated_by'    => $jwt_user_id,
    ]);

    if (!$result) {
        vogo_error_log("[ERROR] STEP 13: Eroare la insert în DB - " . $wpdb->last_error);
        return new WP_REST_Response([
            'success' => false,
            'error'   => 'Database insert failed',
            'details' => $wpdb->last_error
        ], 500);
    }

    vogo_error_log("[SUCCESS] STEP 14: Upload și salvare DB completă");

    return new WP_REST_Response([
        'success'       => true,
        'document_link' => $document_link,
        'message'       => 'Document uploaded and saved successfully'
    ], 200);
}


function vogo_get_required_documents_by_role(WP_REST_Request $request) {
    global $wpdb;

    // [STEP 1] Verificăm dacă JWT-ul a setat corect userul curent
    $current_user_id = get_current_user_id();
    if (!$current_user_id) {
        vogo_error_log('[vogo-api][STEP 1] ❌ Eșec autentificare: user_id inexistent');
        return new WP_REST_Response([
            'success' => false,
            'error' => 'Authentication failed'
        ], 403);
    }
    vogo_error_log('[vogo-api][STEP 1] ✅ Autentificare validă - user_id: ' . $current_user_id);

    // [STEP 2] Preluăm parametrul `role` din URL
    $role = sanitize_text_field($request->get_param('role'));
    if (!$role) {
        vogo_error_log('[vogo-api][STEP 2] ❌ Parametru `role` lipsă');
        return new WP_REST_Response([
            'success' => false,
            'error' => 'Missing role parameter'
        ], 400);
    }
    vogo_error_log('[vogo-api][STEP 2] ✅ Parametru role primit: ' . $role);

    // [STEP 3] Construim numele complet al tabelei
    $table = $wpdb->prefix . 'user_documents_def';
    vogo_error_log('[vogo-api][STEP 3] ✅ Tabela folosită: ' . $table);

    // [STEP 4] Construim interogarea SQL
    $query = $wpdb->prepare("
        SELECT id, document_type, apply_to_role, required, position
        FROM $table
        WHERE required = 1 AND apply_to_role = %s
        ORDER BY position ASC
    ", $role);
    vogo_error_log('[vogo-api][STEP 4] ✅ Interogare SQL pregătită pentru rol: ' . $role);

    // [STEP 5] Executăm interogarea
    $results = $wpdb->get_results($query);
    vogo_error_log('[vogo-api][STEP 5] ✅ Rezultate obținute: ' . count($results) . ' rânduri');

    // [STEP 6] Returnăm răspunsul JSON către client (Flutter / Postman etc.)
    return new WP_REST_Response([
        'success' => true,
        'count'   => count($results),
        'data'    => $results,
    ]);
}

/**
 * Returns the last (latest) document for the authenticated user and given p_doc_type_id.
 * - user_id is extracted strictly from JWT
 * - default: returns JSON metadata
 * - when download=true: returns RAW file with correct headers (inline/attachment)
 */
function get_user_doc_by_type(WP_REST_Request $request) {
    global $wpdb;

    vogo_error_log3("VOGO_LOG_START | ACTIVE DB: " . DB_NAME . " | [STEP 0.1] Raw JSON payload received: " . json_encode($request->get_params()));

    // STEP 1: JWT -> user_id
    $jwt_user = extract_user_from_jwt_token($request);
    if ($jwt_user instanceof WP_REST_Response) {
        vogo_error_log3("[STEP 1] JWT extraction failed | IP:" . $_SERVER['REMOTE_ADDR']);
        return $jwt_user;
    }
    $user_id = (int)$jwt_user;
    $u = get_user_by('id', $user_id);
    $user_login = $u ? $u->user_login : '';
    vogo_error_log3("[STEP 1.1] user_id=$user_id user_login=$user_login | IP:" . $_SERVER['REMOTE_ADDR']);

    // STEP 2: Params
    $p_doc_type_id = (int)$request->get_param('p_doc_type_id');
    if ($p_doc_type_id <= 0) {
        vogo_error_log3("[ERROR] STEP 2 Invalid p_doc_type_id | IP:" . $_SERVER['REMOTE_ADDR']);
        return new WP_REST_Response([
            'success'     => false,
            'error'       => 'Invalid p_doc_type_id',
            'user_id'     => $user_id,
            'user_login'  => $user_login,
        ], 400);
    }
    // download/inline flags (from body or query)
    $download = filter_var($request->get_param('download'), FILTER_VALIDATE_BOOLEAN);
    $inline   = filter_var($request->get_param('inline'), FILTER_VALIDATE_BOOLEAN);

    // STEP 3: Query only the latest document for that type
    $table = $wpdb->prefix . 'user_document_data';
    $sql = $wpdb->prepare(
        "SELECT id, user_id, document_id AS p_doc_type_id, document_link, created_at, created_by, updated_at, updated_by
         FROM {$table}
         WHERE user_id = %d AND document_id = %d
         ORDER BY updated_at DESC, id DESC
         LIMIT 1",
        $user_id, $p_doc_type_id
    );
    vogo_error_log3("##############SQL: $sql");
    $row = $wpdb->get_row($sql, ARRAY_A);

    if ($wpdb->last_error) {
        vogo_error_log3("[ERROR] STEP 3 SQL error: " . $wpdb->last_error . " | IP:" . $_SERVER['REMOTE_ADDR']);
        return new WP_REST_Response([
            'success'    => false,
            'error'      => 'Database query failed',
            'sql_error'  => $wpdb->last_error,
            'user_id'    => $user_id,
            'user_login' => $user_login,
        ], 500);
    }

    if (!$row) {
        vogo_error_log3("[STEP 3.1] No document found for user_id=$user_id & type=$p_doc_type_id | IP:" . $_SERVER['REMOTE_ADDR']);
        return new WP_REST_Response([
            'success'     => true,
            'count'       => 0,
            'item'        => null,
            'user_id'     => $user_id,
            'user_login'  => $user_login,
            'message'     => 'No document for given type',
        ], 200);
    }

    // STEP 4: Security: ensure path is under uploads/user-documents/<user_id>/
    $uploads   = wp_upload_dir();
    $basedir   = trailingslashit($uploads['basedir']);
    $safe_root = $basedir . 'user-documents/' . $user_id . '/';
    $abs_path  = realpath($basedir . $row['document_link']);

    // Validate resolved path
    if (!$abs_path || strpos($abs_path, realpath($safe_root)) !== 0) {
        vogo_error_log3("[ERROR] STEP 4 Path traversal or outside allowed dir. abs_path=$abs_path | safe_root=$safe_root | IP:" . $_SERVER['REMOTE_ADDR']);
        return new WP_REST_Response([
            'success'     => false,
            'error'       => 'File path not allowed',
            'user_id'     => $user_id,
            'user_login'  => $user_login,
        ], 403);
    }

    // STEP 5: If download requested, return RAW file with headers
    if ($download === true) {
        if (!file_exists($abs_path) || !is_readable($abs_path)) {
            vogo_error_log3("[ERROR] STEP 5 File missing or unreadable: $abs_path | IP:" . $_SERVER['REMOTE_ADDR']);
            return new WP_REST_Response([
                'success'     => false,
                'error'       => 'File not found',
                'user_id'     => $user_id,
                'user_login'  => $user_login,
            ], 404);
        }

        // Detect mime
        $mime = 'application/octet-stream';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $det = finfo_file($finfo, $abs_path);
                if ($det) { $mime = $det; }
                finfo_close($finfo);
            }
        } else {
            $ft = wp_check_filetype(basename($abs_path));
            if (!empty($ft['type'])) { $mime = $ft['type']; }
        }

        $contents = file_get_contents($abs_path);
        $filename = basename($abs_path);

        $resp = new WP_REST_Response($contents, 200);
        $resp->header('Content-Type', $mime);
        $resp->header('Content-Length', (string) filesize($abs_path));
        $disp = $inline ? 'inline' : 'attachment';
        $resp->header('Content-Disposition', $disp . '; filename="' . $filename . '"');
        vogo_error_log3("[STEP 5] Returning RAW file: $filename ($mime) | IP:" . $_SERVER['REMOTE_ADDR']);
        vogo_error_log3("VOGO_LOG_END");
        return $resp;
    }

    // STEP 6: Default JSON metadata
    vogo_error_log3("[STEP 6] Returning metadata only | IP:" . $_SERVER['REMOTE_ADDR']);
    vogo_error_log3("VOGO_LOG_END");
    return new WP_REST_Response([
        'success'     => true,
        'count'       => 1,
        'item'        => $row,
        'user_id'     => $user_id,
        'user_login'  => $user_login,
        'message'     => 'Document fetched',
    ], 200);
}